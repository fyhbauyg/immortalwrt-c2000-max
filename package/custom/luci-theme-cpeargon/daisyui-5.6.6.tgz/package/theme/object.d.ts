interface Theme {
  "color-scheme": string
  "--color-base-100": string
  "--color-base-200": string
  "--color-base-300": string
  "--color-base-content": string
  "--color-primary": string
  "--color-primary-content": string
  "--color-secondary": string
  "--color-secondary-content": string
  "--color-accent": string
  "--color-accent-content": string
  "--color-neutral": string
  "--color-neutral-content": string
  "--color-info": string
  "--color-info-content": string
  "--color-success": string
  "--color-success-content": string
  "--color-warning": string
  "--color-warning-content": string
  "--color-error": string
  "--color-error-content": string
  "--radius-selector": string
  "--radius-field": string
  "--radius-box": string
  "--size-selector": string
  "--size-field": string
  "--border": string
  "--depth": string
  "--noise": string
}


interface Themes {
  cyberpunk: Theme
  silk: Theme
  emerald: Theme
  winter: Theme
  bumblebee: Theme
  coffee: Theme
  cupcake: Theme
  dark: Theme
  pastel: Theme
  light: Theme
  acid: Theme
  black: Theme
  dracula: Theme
  halloween: Theme
  lemonade: Theme
  sunset: Theme
  synthwave: Theme
  corporate: Theme
  business: Theme
  valentine: Theme
  aqua: Theme
  caramellatte: Theme
  retro: Theme
  night: Theme
  cmyk: Theme
  dim: Theme
  lofi: Theme
  wireframe: Theme
  nord: Theme
  autumn: Theme
  garden: Theme
  luxury: Theme
  fantasy: Theme
  forest: Theme
  abyss: Theme
  [key: string]: Theme
}

declare const themes: Themes
export default themes