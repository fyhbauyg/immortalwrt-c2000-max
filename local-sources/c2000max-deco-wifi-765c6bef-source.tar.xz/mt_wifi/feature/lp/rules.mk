LP_PATH := $(PARENT_DIR)/feature/lp

obj_feature += \
	$(LP_PATH)/lp.o
