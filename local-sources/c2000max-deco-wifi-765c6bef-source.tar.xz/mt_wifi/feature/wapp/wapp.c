/*
 * Copyright (c) [2020], MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws.
 * The information contained herein is confidential and proprietary to
 * MediaTek Inc. and/or its licensors.
 * Except as otherwise provided in the applicable licensing terms with
 * MediaTek Inc. and/or its licensors, any reproduction, modification, use or
 * disclosure of MediaTek Software, and information contained herein, in whole
 * or in part, shall be strictly prohibited.
*/
/****************************************************************************
****************************************************************************

	Module Name:
	wapp.c

	Abstract:

	Revision History:
	Who         When          What
	--------    ----------    ----------------------------------------------
*/

#ifdef WAPP_SUPPORT
#include "rt_config.h"

#include "wapp/wapp_cmm_type.h"
#ifdef MAP_R6
#include "bss_mngr.h"
extern struct bss_manager bss_mngr;
#endif
#define BEACON_REPORT_MAX_OPT_SUB_IE_LEN 250
#define BEACON_REPORT_MAX_IE_LEN (26 + BEACON_REPORT_MAX_OPT_SUB_IE_LEN)

#ifdef DOT11_HE_AX
UINT8 peer_max_bw_cap(INT8 ch_width_set);
#endif /*DOT11_HE_AX*/

UCHAR ESPI_AC_BE_DEFAULT[3] = {0xF8, 0xFF, 0x00};
UCHAR ESPI_AC_BK_DEFAULT[3] = {0xF9, 0xFF, 0x00};
UCHAR ESPI_AC_VO_DEFAULT[3] = {0xFA, 0xFF, 0x00};
UCHAR ESPI_AC_VI_DEFAULT[3] = {0xFB, 0xFF, 0x00};

#define CLI_REQ_MIN_INTERVAL	5 /* sec */

#ifdef CONFIG_MAP_SUPPORT
VOID wapp_send_cac_stop(
	IN PRTMP_ADAPTER pAd,
	IN UINT32 ifindex,
	IN UCHAR channel,
	IN UCHAR ret)
{
	struct wapp_event event;
	wapp_cac_info *cac_info;

	event.event_id = WAPP_CAC_STOP;
	event.ifindex = ifindex;
	cac_info = &event.data.cac_info;
	cac_info->channel = channel;
	cac_info->ret = ret;
	wapp_send_wapp_qry_rsp(pAd, &event);
}

#endif
UINT8 get_channel_utilization(PRTMP_ADAPTER pAd, u32 ifindex)
{
	UCHAR	i, Channel;
	UINT16 	l;
	UINT32  ObssAirTime = 0;
	UINT32  MyTxAirTime = 0;
	UINT32  MyRxAirTime = 0;
	UCHAR ObssAirOccupyPercentage = 0;
	UCHAR MyAirOccupyPercentage = 0;
	UINT32  res;
	struct wifi_dev *wdev = NULL;
#ifdef EM_PLUS_SUPPORT
	UINT32  EDCCA = 0;
	UCHAR EDCCAOccupyPercentage = 0;
#endif

	for (l = 0; l < WDEV_NUM_MAX; l++) {
		if (pAd->wdev_list[l] != NULL) {
			wdev = pAd->wdev_list[l];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == ifindex)) {
				break;
			}
		}
	}

	if (wdev == NULL) {
		return 0;
	}

	Channel = wdev->channel;
	i = hc_get_hw_band_idx(pAd);
#ifdef CONFIG_MAP_SUPPORT
	ObssAirTime = Get_OBSS_AirTime_MAP(pAd, i);
	MyTxAirTime = Get_My_Tx_AirTime_MAP(pAd, i);
	MyRxAirTime = Get_My_Rx_AirTime_MAP(pAd, i);
#else
	ObssAirTime = Get_OBSS_AirTime(pAd, i);
	MyTxAirTime = Get_My_Tx_AirTime(pAd, i);
	MyRxAirTime = Get_My_Rx_AirTime(pAd, i);
#endif /* CONFIG_MAP_SUPPORT */

#ifdef EM_PLUS_SUPPORT
	EDCCA = Get_EDCCA_Time(pAd, i);
#endif
	MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
	"One sec values Channel %d,Band %d, ObssAirTime %d, MyTxAirTime %d, MyRxAirTime %d\n",
	Channel, i, ObssAirTime, MyTxAirTime, MyRxAirTime);
	if (ObssAirTime != 0)
		ObssAirOccupyPercentage = (ObssAirTime*100)/ONE_SEC_2_US;
#ifdef EM_PLUS_SUPPORT
	if (EDCCA != 0)
		EDCCAOccupyPercentage = (EDCCA*100)/ONE_SEC_2_US;
#endif

	if (MyTxAirTime != 0 || MyRxAirTime != 0)
		MyAirOccupyPercentage = ((MyTxAirTime + MyRxAirTime) * 100)/ONE_SEC_2_US;

	if (MyAirOccupyPercentage >= 100) {
		MTWF_DBG(pAd, DBG_CAT_CHN, CATCHN_CHN, DBG_LVL_DEBUG,
			"MyAirOccupyPercentage exceeds and return 255!!\n");
		return 255;
	}
#ifndef EM_PLUS_SUPPORT
	res = (MyAirOccupyPercentage + ObssAirOccupyPercentage);
#else
	res = (MyAirOccupyPercentage + ObssAirOccupyPercentage + EDCCAOccupyPercentage);
#endif

	if (res >= 100) {
		MTWF_DBG(pAd, DBG_CAT_CHN, CATCHN_CHN, DBG_LVL_DEBUG,
			 "TotalOccupyPercentage exceeds and return 255!!\n");
		return 255;
	}
	/* convert to a scale of 255 */
	res *= 255;
	res = (res / 100);
	MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"final ch util res %d\n", res);
	return res;
}
VOID wext_send_wapp_qry_rsp2(
	PNET_DEV pNetDev,
	struct wapp_event2 *event)
{

	UINT buflen = sizeof(struct wapp_event2);

	event->len = buflen - sizeof(event->len) - sizeof(event->event_id);

	RtmpOSWrielessEventSend(pNetDev, RT_WLAN_EVENT_CUSTOM,
			OID_WAPP_EVENT2, NULL, (PUCHAR)event, sizeof(struct wapp_event2));
}

VOID wext_send_wapp_qry_rsp(
	PNET_DEV pNetDev,
	struct wapp_event *event)
{

	UINT buflen = sizeof(struct wapp_event);

	event->len = buflen - sizeof(event->len) - sizeof(event->event_id);

	RtmpOSWrielessEventSend(pNetDev, RT_WLAN_EVENT_CUSTOM,
			OID_WAPP_EVENT, NULL, (PUCHAR)event, sizeof(struct wapp_event));
}

INT wapp_send_wdev_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;
	struct wapp_event event;
	wapp_dev_info *dev_info;

	event.event_id = WAPP_DEV_QUERY_RSP;
	event.ifindex = req->data.ifindex;
	dev_info = &event.data.dev_info;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == event.ifindex)) {
				dev_info->ifindex = event.ifindex;
				dev_info->dev_type = wdev->wdev_type;
				COPY_MAC_ADDR(dev_info->mac_addr, wdev->if_addr);
				NdisCopyMemory(dev_info->ifname, RtmpOsGetNetDevName(wdev->if_dev), IFNAMSIZ);
				dev_info->radio_id = HcGetBandByWdev(wdev);
				dev_info->adpt_id = (uintptr_t) pAd;
				dev_info->wireless_mode = wdev->PhyMode;
				dev_info->dev_active = HcIsRadioAcq(wdev);
				wapp_send_wapp_qry_rsp(pAd, &event);
				if (IS_MAP_TURNKEY_ENABLE(pAd) &&
					wdev->wdev_type == WDEV_TYPE_STA) {
					if (wdev->func_idx >= MAX_APCLI_NUM)
						continue;
					SetApCliEnableByWdev(pAd, wdev, FALSE);
				}
			}
		}
	}
	return 0;
}

INT wapp_send_wdev_info_report(PRTMP_ADAPTER pAd, struct wifi_dev *wdev)
{
	struct wapp_event event;
	wapp_dev_info *dev_info;

	if (!wdev)
		return -1;

	event.event_id = WAPP_DEV_QUERY_RSP;
	event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
	dev_info = &event.data.dev_info;
	dev_info->ifindex = event.ifindex;
	dev_info->dev_type = wdev->wdev_type;
	COPY_MAC_ADDR(dev_info->mac_addr, wdev->if_addr);
	NdisCopyMemory(dev_info->ifname, RtmpOsGetNetDevName(wdev->if_dev), IFNAMSIZ);
	dev_info->radio_id = HcGetBandByWdev(wdev);
	dev_info->adpt_id = (uintptr_t) pAd;
	dev_info->wireless_mode = wdev->PhyMode;
	dev_info->dev_active = HcIsRadioAcq(wdev);
	wapp_send_wapp_qry_rsp(pAd, &event);

	return 0;
}

INT wapp_send_wdev_ht_cap_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;
	struct wapp_event event;
	wdev_ht_cap *ht_cap;

	event.event_id = WAPP_HT_CAP_QUERY_RSP;
	event.ifindex = req->data.ifindex;

	ht_cap = &event.data.ht_cap;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == event.ifindex)) {
				ht_cap->tx_stream = wlan_config_get_tx_stream(wdev);
				ht_cap->rx_stream = wlan_config_get_rx_stream(wdev);
				ht_cap->sgi_20 = (wlan_config_get_ht_gi(wdev) == GI_400) ? \
								 1:0;
				ht_cap->sgi_40 = (wlan_config_get_ht_gi(wdev) == GI_400) ? \
								 1:0;
				ht_cap->ht_40 = (wlan_operate_get_ht_bw(wdev) == BW_40) ? \
								 1:0;
				wapp_send_wapp_qry_rsp(pAd, &event);
			}
		}
	}
	return 0;
}

INT wapp_send_wdev_vht_cap_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;
	struct wapp_event event;
	wdev_vht_cap *vht_cap;
	VHT_CAP_INFO drv_vht_cap;
	VHT_OP_IE drv_vht_op;
	struct mcs_nss_caps *mcs_nss = MCS_NSS_CAP(pAd);

	NdisZeroMemory(&drv_vht_op, sizeof(VHT_OP_IE));
	NdisCopyMemory(&drv_vht_cap, &pAd->CommonCfg.vht_cap_ie.vht_cap, sizeof(VHT_CAP_INFO));

	event.event_id = WAPP_VHT_CAP_QUERY_RSP;
	event.ifindex = req->data.ifindex;

	vht_cap = &event.data.vht_cap;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == event.ifindex)) {
				mt_WrapSetVHTETxBFCap(pAd, wdev, &drv_vht_cap);

				drv_vht_op.basic_mcs_set.mcs_ss1 = VHT_MCS_CAP_NA;
				drv_vht_op.basic_mcs_set.mcs_ss2 = VHT_MCS_CAP_NA;
				drv_vht_op.basic_mcs_set.mcs_ss3 = VHT_MCS_CAP_NA;
				drv_vht_op.basic_mcs_set.mcs_ss4 = VHT_MCS_CAP_NA;
				drv_vht_op.basic_mcs_set.mcs_ss5 = VHT_MCS_CAP_NA;
				drv_vht_op.basic_mcs_set.mcs_ss6 = VHT_MCS_CAP_NA;
				drv_vht_op.basic_mcs_set.mcs_ss7 = VHT_MCS_CAP_NA;
				drv_vht_op.basic_mcs_set.mcs_ss8 = VHT_MCS_CAP_NA;

				/* BW 80M or 40M is the default setting*/
				switch	(wlan_operate_get_rx_stream(wdev)) {
				case 4:
					drv_vht_op.basic_mcs_set.mcs_ss4 = mcs_nss->max_vht_mcs;
					fallthrough;
				case 3:
					drv_vht_op.basic_mcs_set.mcs_ss3 = mcs_nss->max_vht_mcs;
					fallthrough;
				case 2:
					drv_vht_op.basic_mcs_set.mcs_ss2 = mcs_nss->max_vht_mcs;
					fallthrough;
				case 1:
					drv_vht_op.basic_mcs_set.mcs_ss1 = mcs_nss->max_vht_mcs;
					break;
				}

				/* BW 20M only */
				if (wlan_config_get_vht_bw(wdev) == VHT_BW_2040
					&& wlan_config_get_ht_bw(wdev) == HT_BW_20
					&& mcs_nss->max_vht_mcs == VHT_MCS_CAP_9) {

					switch	(wlan_operate_get_rx_stream(wdev)) {
					case 4:
						drv_vht_op.basic_mcs_set.mcs_ss4 = VHT_MCS_CAP_8;
						fallthrough;
					case 3:
						drv_vht_op.basic_mcs_set.mcs_ss3 = VHT_MCS_CAP_9;
						fallthrough;
					case 2:
						drv_vht_op.basic_mcs_set.mcs_ss2 = VHT_MCS_CAP_8;
						fallthrough;
					case 1:
						drv_vht_op.basic_mcs_set.mcs_ss1 = VHT_MCS_CAP_8;
						break;
					}

				}

				/* BW 160M or 80M+80M */
				if ((wlan_config_get_vht_bw(wdev) == VHT_BW_160 || wlan_config_get_vht_bw(wdev) == VHT_BW_8080)
					&& wlan_config_get_ht_bw(wdev) == HT_BW_40
					&& mcs_nss->max_vht_mcs == VHT_MCS_CAP_9) {
					switch	(wlan_operate_get_rx_stream(wdev)) {
					case 4:
						drv_vht_op.basic_mcs_set.mcs_ss4 = VHT_MCS_CAP_9;
						fallthrough;
					case 3:
						drv_vht_op.basic_mcs_set.mcs_ss3 = VHT_MCS_CAP_8;
						fallthrough;
					case 2:
						drv_vht_op.basic_mcs_set.mcs_ss2 = VHT_MCS_CAP_9;
						fallthrough;
					case 1:
						drv_vht_op.basic_mcs_set.mcs_ss1 = VHT_MCS_CAP_9;
						break;
					}
				}

				NdisMoveMemory(vht_cap->sup_tx_mcs,
								&drv_vht_op.basic_mcs_set,
								sizeof(vht_cap->sup_tx_mcs));
				NdisMoveMemory(vht_cap->sup_rx_mcs,
								&drv_vht_op.basic_mcs_set,
								sizeof(vht_cap->sup_rx_mcs));
				vht_cap->tx_stream = wlan_config_get_tx_stream(wdev);
				vht_cap->rx_stream = wlan_config_get_tx_stream(wdev);
				vht_cap->sgi_80 = (wlan_config_get_ht_gi(wdev) == GI_400) ? \
								 1:0;
				vht_cap->sgi_160 = (wlan_config_get_ht_gi(wdev) == GI_400) ? \
								 1:0;
				vht_cap->vht_160 = (wlan_operate_get_vht_bw(wdev) == BW_160) ? \
								 1:0;
				vht_cap->vht_8080 = (wlan_operate_get_vht_bw(wdev) == BW_8080) ? \
								 1:0;
				vht_cap->su_bf = (drv_vht_cap.bfer_cap_su) ? \
								 1:0;
				vht_cap->mu_bf = (drv_vht_cap.bfer_cap_mu) ? \
								 1:0;
				wapp_send_wapp_qry_rsp(pAd, &event);
			}
		}
	}
	return 0;
}

INT wapp_send_wdev_misc_cap_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;
	struct wapp_event event;
	wdev_misc_cap *misc_cap;

	event.event_id = WAPP_MISC_CAP_QUERY_RSP;
	event.ifindex = 0;
	misc_cap = &event.data.misc_cap;
	NdisZeroMemory(misc_cap, sizeof(wdev_misc_cap));

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)) {
				event.ifindex = req->data.ifindex;
				misc_cap->max_num_of_cli = 64;
				misc_cap->max_num_of_bss = MAX_MBSSID_NUM(pAd);
				misc_cap->num_of_bss = pAd->ApCfg.BssidNum;
#ifdef CONFIG_MAP_SUPPORT
				misc_cap->max_num_of_block_cli = BLOCK_LIST_NUM;
#endif
				wapp_send_wapp_qry_rsp(pAd, &event);
			}
		}
	}
	return 0;
}
#ifdef DOT11_HE_AX
u16 get_nss_from_he_chwidth(MAC_TABLE_ENTRY *mac_entry, u8 bw)
{
	int i = 0;
	switch (bw) {
	case HE_BW_20:
	case HE_BW_2040:
	case HE_BW_80: /*For Bw less than equal to 80*/
		if (mac_entry->cap.ch_bw.he_ch_width & (SUPP_40M_CW_IN_24G_BAND | SUPP_40M_80M_CW_IN_5G_6G_BAND))
			for (i = 0; i < DOT11AX_MAX_STREAM; i++) {
				if (mac_entry->cap.rate.he80_rx_nss_mcs[i] == 3)
					break;
			}
		break;
	case HE_BW_160: /*For Bw 160 support*/
		if (mac_entry->cap.ch_bw.he_ch_width & SUPP_160M_CW_IN_5G_6G_BAND)
			for (i = 0; i < DOT11AX_MAX_STREAM; i++) {
				if (mac_entry->cap.rate.he160_rx_nss_mcs[i] == 3)
					break;
			}
		break;
	case HE_BW_8080: /*For Bw 8080 support*/
		if (mac_entry->cap.ch_bw.he_ch_width & SUPP_160M_8080M_CW_IN_5G_6G_BAND)
			for (i = 0; i < DOT11AX_MAX_STREAM; i++) {
				if (mac_entry->cap.rate.he8080_rx_nss_mcs[i] == 3)
					break;
			}
		break;
	default:
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
			"bw is inwalid!!\n");
		break;
	}
	return i;
}

u16 he_bw_conv(u16 he_bw)
{
	switch (he_bw) {
	case HE_BW_20:
		return BW_20;
	case HE_BW_2040:
		return BW_40;
	case HE_BW_80:
		return BW_80;
	case HE_BW_160:
		return BW_160;
	case HE_BW_8080:
		return BW_8080;
	default:
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
						"return default he_bw: BW_20\n");
		return BW_20;
	}
}
#endif /*DOT11_HE_AX*/
#ifdef CONFIG_MAP_SUPPORT
#if (defined(MTK_MLO_MAP_SUPPORT) && defined(DOT11_EHT_BE))
void wapp_fill_client_mlo_info(PRTMP_ADAPTER pAd, wapp_client_info *cli_info, MAC_TABLE_ENTRY *pEntry)
{
	struct mld_entry_t *mld_entry = NULL;
#ifdef MAP_R6
	u8 j = 0;
	u8 i = 0;
	struct _MAC_TABLE_ENTRY *link_entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;
	u8 index = 0;
#ifdef CONFIG_AP_SUPPORT
	struct _BSS_STRUCT *mbss = NULL;
#endif /* CONFIG_AP_SUPPORT */
#endif /*MAP_R6*/

	if (pEntry && pEntry->mlo.mlo_en) {
		cli_info->mlo_join = pEntry->mlo_join;
		cli_info->mlo.mlo_en = pEntry->mlo.mlo_en;
		cli_info->mlo.is_setup_link_entry = pEntry->mlo.is_setup_link_entry;
		cli_info->mlo.link_info.link_id = pEntry->mlo.link_info.link_id;
		cli_info->mlo.link_info.tid_bitmap_dl = pEntry->mlo.link_info.tid_map_dl;
		cli_info->mlo.link_info.tid_bitmap_ul = pEntry->mlo.link_info.tid_map_ul;
		cli_info->EmlsrBitmap = pEntry->EmlsrBitmap;
#ifdef MAP_R6
		memcpy(cli_info->mlo.sta_mld_addr, pEntry->mlo.mld_addr, MAC_ADDR_LEN);
		if (pEntry->wdev) {
			if (pEntry->wdev->wdev_type == WDEV_TYPE_AP) {
				mbss = &pAd->ApCfg.MBSSID[pEntry->wdev->func_idx];
				index = mbss->mld_grp_idx;
			}
#ifdef MLD_GROUP_ID_REMAPPING_V1
			mld = mld_idx_mapping_v1_load(index);
#else
			if (BMGR_VALID_MLD_GRP_IDX(index))
				mld = GET_MLD_BY_GRP_IDX(index);
#endif
			if (BMGR_VALID_MLO_DEV(mld))
				memcpy(cli_info->mlo.ap_mld_addr, mld->mld_addr, MAC_ADDR_LEN);
		}
#endif
		mt_os_lockless_enter(os_lockless_ctx_get());
		mld_entry = get_mld_entry_by_mac(pEntry->mlo.mld_addr);

		if (mld_entry) {
			memcpy(cli_info->mlo.mld_info.addr, mld_entry->addr, MAC_ADDR_LEN);
			cli_info->mlo.mld_info.mld_sta_idx = mld_entry->mld_sta_idx;
			cli_info->mlo.mld_info.nsep = mld_entry->nsep;
			cli_info->mlo.mld_info.emlmr = mld_entry->emlmr;
			cli_info->mlo.mld_info.emlsr = mld_entry->emlsr;
			cli_info->mlo.mld_info.eml_cap = mld_entry->eml_cap;
			cli_info->mlo.mld_info.setup_link_wcid = mld_entry->setup_link_wcid;
			cli_info->mlo.mld_info.setup_link_id = mld_entry->setup_link_link_id;
			cli_info->mlo.mld_info.link_num = mld_entry->link_num;
			cli_info->mlo.mld_info.valid = mld_entry->valid;
#ifdef MAP_R6
			for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++)
				memset(cli_info->mlo.affiliated_info[i].affiliated_ap_bssid, 0, MAC_ADDR_LEN);
			for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++) {
				link_entry = (struct _MAC_TABLE_ENTRY *)mld_entry->link_entry[i];
				if (!link_entry)
					continue;

				if (!link_entry->mlo.is_setup_link_entry)
					j++;
				cli_info->mlo.affiliated_ap_num = j;
				if (link_entry->wdev) {
					if (j > 0 && !link_entry->mlo.is_setup_link_entry)
						COPY_MAC_ADDR(cli_info->mlo.affiliated_info[j-1].affiliated_ap_bssid, link_entry->wdev->bssid);
				}
			}
#endif
		} else
			MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				"mld_entry = NULL\n");
#ifdef MAP_R6
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"affiliated ap num sent from driver is %d\n", cli_info->mlo.affiliated_ap_num);
#endif
		mt_os_lockless_exit(os_lockless_ctx_get());
	}
}
#endif
#endif

INT wapp_fill_ap_info(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev,
	wapp_client_info *cli_info,
	PSTA_ADMIN_CONFIG pApCliEntry)
{
	MAC_TABLE_ENTRY *pEntry = NULL;

	pEntry = MacTableLookup(pAd, pApCliEntry->Bssid);
	if (pEntry == NULL)
		return 0;

	memcpy(cli_info->mac_addr, wdev->if_addr, MAC_ADDR_LEN);
	memcpy(cli_info->bssid, pEntry->Addr, MAC_ADDR_LEN);
	cli_info->sta_status = \
		(pEntry->wdev->PortSecured == WPA_802_1X_PORT_SECURED) ?
		WAPP_STA_CONNECTED : WAPP_STA_DISCONNECTED;
#ifdef CONFIG_MAP_SUPPORT
#if (defined(MTK_MLO_MAP_SUPPORT) && defined(DOT11_EHT_BE))
	wapp_fill_client_mlo_info(pAd, cli_info, pEntry);
#endif

	if (IS_MAP_ENABLE(pAd) &&
		IS_ENTRY_A4(pEntry)) {
		cli_info->is_APCLI = 1;
	} else
#endif
		cli_info->is_APCLI = 0;
	return 0;
}

#ifdef CONFIG_MAP_SUPPORT
INT wapp_fill_client_info_new(
	PRTMP_ADAPTER pAd,
	wapp_client_info *cli_info,
	MAC_TABLE_ENTRY *mac_entry)
{
	STA_TR_ENTRY *tr_entry;
	ULONG DataRate = 0, DataRate_r = 0;
	union _HTTRANSMIT_SETTING HTPhyMode;
	union _HETRANSMIT_SETTING HEPhyMode;

#ifdef CONFIG_MAP_SUPPORT
	union _EHTTRANSMIT_SETTING EHTPhyMode;
#endif
	PRTMP_ADAPTER pAd2;
#ifdef DOT11_HE_AX
	UINT8 he_dcm = 0, he_mcs = 0, he_nss = 0, he_sgi = 0, he_stbc = 0;
#endif
#ifdef CONFIG_MAP_SUPPORT
	UINT8 eht_dcm = 0, eht_mcs = 0, eht_nss = 0, eht_sgi = 0, eht_stbc = 0;
#endif

#ifdef EM_PLUS_SUPPORT
	EXT_EVENT_TX_STATISTIC_RESULT_T rTxStatResult_2;
#endif

	USHORT PhyMode = 0;
#ifdef MAP_R3
	int i = 0;
	struct ppdu_caps *ppdu = NULL;
#endif

	memset(&HTPhyMode, 0, sizeof(union _HTTRANSMIT_SETTING));
	memset(&HEPhyMode, 0, sizeof(union _HETRANSMIT_SETTING));
#ifdef CONFIG_MAP_SUPPORT
	memset(&EHTPhyMode, 0, sizeof(union _EHTTRANSMIT_SETTING));
#endif

	/* before tx_rx_ctl move to phy_device , we map mac_entry to correct pAd*/
	if (mac_entry->pAd != pAd) {
		pAd2 = mac_entry->pAd;
	} else
		pAd2 = pAd;

	tr_entry = tr_entry_get(pAd2, mac_entry->wcid);
	COPY_MAC_ADDR(cli_info->mac_addr, mac_entry->Addr);
	if (mac_entry->wdev) {
		COPY_MAC_ADDR(cli_info->bssid, mac_entry->wdev->bssid);
		PhyMode = mac_entry->wdev->PhyMode;
#ifdef MAP_R3
		ppdu = (struct ppdu_caps *)wlan_config_get_ppdu_caps(mac_entry->wdev);
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"Port secure for tr:%u wdev:%u\n",
		tr_entry->PortSecured, mac_entry->wdev->PortSecured);
#endif
	} else
		NdisZeroMemory(cli_info->bssid, MAC_ADDR_LEN);

	if (mac_entry->wdev && mac_entry->wdev->wdev_type == WDEV_TYPE_AP) {
#if defined(EM_PLUS_SUPPORT)
		cli_info->sta_status = WAPP_STA_CONNECTED;
#else
	if (IS_MAP_API_ENABLE(pAd)) {
		cli_info->sta_status = (mac_entry->wdev->PortSecured == WPA_802_1X_PORT_SECURED) ?
			WAPP_STA_CONNECTED : WAPP_STA_DISCONNECTED;
	} else {
		cli_info->sta_status = WAPP_STA_CONNECTED;
	}
#endif
	} else
		cli_info->sta_status = (tr_entry->PortSecured == WPA_802_1X_PORT_SECURED) ?
			WAPP_STA_CONNECTED : WAPP_STA_DISCONNECTED;

#if (defined(MTK_MLO_MAP_SUPPORT) && defined(DOT11_EHT_BE))
	if (mac_entry->wdev && mac_entry->wdev->PortSecured == WPA_802_1X_PORT_SECURED)
		wapp_fill_client_mlo_info(pAd, cli_info, mac_entry);
#endif

	cli_info->assoc_time = mac_entry->StaConnectTime;
	cli_info->assoc_req_len = mac_entry->assoc_req_len;
	HEPhyMode.word = (UINT32)mac_entry->map_LastTxRate;
#ifdef CONFIG_MAP_SUPPORT
	EHTPhyMode.word = (UINT32)mac_entry->map_LastTxRate;
#endif
#ifdef MAP_R2
	cli_info->IsReassoc = mac_entry->IsReassocSta;
#endif

#ifdef EM_PLUS_SUPPORT
	os_zero_mem(&rTxStatResult_2, sizeof(EXT_EVENT_TX_STATISTIC_RESULT_T));

	HTPhyMode.word = GetTxRatePerSta_stats_info(pAd, mac_entry->wcid, &rTxStatResult_2);

	HTPhyMode.field.MODE = rTxStatResult_2.rEntryTxRate.MODE;
	if (rTxStatResult_2.rEntryTxRate.MODE == MODE_VHT)
		HTPhyMode.field.MCS = (((rTxStatResult_2.rEntryTxRate.VhtNss - 1) & 0x3) << 4)
								+ rTxStatResult_2.rEntryTxRate.MCS;
	else
		HTPhyMode.field.MCS =  rTxStatResult_2.rEntryTxRate.MCS;
	HTPhyMode.field.BW = rTxStatResult_2.rEntryTxRate.BW;
	HTPhyMode.field.ShortGI = rTxStatResult_2.rEntryTxRate.ShortGI;
	HTPhyMode.field.STBC = rTxStatResult_2.rEntryTxRate.STBC;
	HTPhyMode.field.ldpc = rTxStatResult_2.rEntryTxRate.ldpc;
#endif
#ifdef CONFIG_MAP_SUPPORT
	if (EHTPhyMode.field.MODE == MODE_EHT_MU) {
#ifdef EM_PLUS_SUPPORT
		eht_mcs = rTxStatResult_2.rEntryTxRate.MCS & 0xf;
		eht_dcm = rTxStatResult_2.rEntryTxRate.MCS & 0x10 ? 1 : 0;
		eht_nss = rTxStatResult_2.rEntryTxRate.VhtNss;
		eht_sgi =	rTxStatResult_2.rEntryTxRate.ShortGI ? 1 : 0;
		eht_stbc = rTxStatResult_2.rEntryTxRate.STBC;
		get_rate_eht(eht_mcs, rTxStatResult_2.rEntryTxRate.BW, eht_nss, eht_dcm, &DataRate);
#else
		eht_mcs = EHTPhyMode.field.MCS & 0xf;
		eht_dcm = EHTPhyMode.field.MCS	& 0x10 ? 1 : 0;
		eht_nss = ((EHTPhyMode.field.MCS & (0x3 << 4)) >> 4) + 1;
		eht_sgi = EHTPhyMode.field.ShortGI;
		get_rate_eht(eht_mcs, EHTPhyMode.field.BW, eht_nss, eht_dcm, &DataRate);
#endif
		if (eht_sgi == 1)
			DataRate = (DataRate * 967) >> 10;
		else if (eht_sgi == 2)
			DataRate = (DataRate * 870) >> 10;
		cli_info->downlink = (u16) DataRate;
	} else
#endif
#ifdef DOT11_HE_AX
	if (IS_HE_MODE(HEPhyMode.field.MODE)) {
#ifdef EM_PLUS_SUPPORT
		he_mcs = rTxStatResult_2.rEntryTxRate.MCS & 0xf;
		he_dcm = rTxStatResult_2.rEntryTxRate.MCS & 0x10 ? 1 : 0;
		he_nss = rTxStatResult_2.rEntryTxRate.VhtNss;
		he_sgi = rTxStatResult_2.rEntryTxRate.ShortGI ? 1 : 0;
		get_rate_he(he_mcs, rTxStatResult_2.rEntryTxRate.BW, he_nss, he_dcm, &DataRate);
#else
		he_mcs = HEPhyMode.field.MCS & 0xf;
		he_dcm = HEPhyMode.field.MCS  & 0x10 ? 1 : 0;
		he_nss = HEPhyMode.field.Nss;
		he_sgi = HEPhyMode.field.ShortGI;
		get_rate_he(he_mcs, HEPhyMode.field.BW, he_nss, he_dcm, &DataRate);
#endif
		if (he_sgi == 1)
			DataRate = (DataRate * 967) >> 10;
		else if (he_sgi == 2)
			DataRate = (DataRate * 870) >> 10;
		cli_info->downlink = (u16) DataRate;
	} else
#endif
	{
#ifndef EM_PLUS_SUPPORT
		HTPhyMode.word = (UINT32)mac_entry->map_LastTxRate;
#endif
		getRate(HTPhyMode, &DataRate);
		cli_info->downlink = (u16) DataRate;
		/* Though NSS1VHT20MCS9 and NSS2VHT20MCS9 rates are not specified in
		* IEEE802.11, we do use them */
		if ((HTPhyMode.field.MODE == MODE_VHT) && (HTPhyMode.field.BW == BW_20) &&
			((HTPhyMode.field.MCS & 0xf) == 9)) {
			u8 vht_nss = ((HTPhyMode.field.MCS & (0x3 << 4)) >> 4) + 1;

			if (vht_nss == 1)
				cli_info->downlink = HTPhyMode.field.ShortGI ? 96 : 86;
			else if (vht_nss == 2)
				cli_info->downlink = HTPhyMode.field.ShortGI ? 192 : 173;
		}
	}

	HEPhyMode.word = (UINT32) mac_entry->map_LastRxRate;
#ifdef CONFIG_MAP_SUPPORT
	EHTPhyMode.word = mac_entry->map_LastRxRate;
	if (IS_ENTRY_PEER_AP(mac_entry)) {
		EXT_EVENT_TX_STATISTIC_RESULT_T rTxStatResult;
		int no_apcli_mode = 0;

		os_zero_mem(&rTxStatResult, sizeof(EXT_EVENT_TX_STATISTIC_RESULT_T));

		EHTPhyMode.word = GetTxRatePerSta_stats_info(pAd, mac_entry->wcid, &rTxStatResult);
		eht_mcs = rTxStatResult.rEntryTxRate.MCS & 0xf;
		eht_dcm = rTxStatResult.rEntryTxRate.MCS & 0x10 ? 1 : 0;
		eht_nss = rTxStatResult.rEntryTxRate.VhtNss - 1;
		eht_sgi =   rTxStatResult.rEntryTxRate.ShortGI ? 1 : 0;
		eht_stbc = rTxStatResult.rEntryTxRate.STBC;
		eht_nss = (eht_nss + 1)/(eht_stbc + 1);
		if (rTxStatResult.rEntryTxRate.MODE == MODE_EHT_MU)
			get_rate_eht(eht_mcs, rTxStatResult.rEntryTxRate.BW, eht_nss, eht_dcm, &DataRate_r);
		else if (IS_HE_MODE(rTxStatResult.rEntryTxRate.MODE))
			get_rate_he(eht_mcs, rTxStatResult.rEntryTxRate.BW, eht_nss, eht_dcm, &DataRate_r);
		else {
			no_apcli_mode = 1;
			HTPhyMode.word = (UINT32) EHTPhyMode.word;
			HTPhyMode.field.MODE = rTxStatResult.rEntryTxRate.MODE;
			HTPhyMode.field.MCS =  rTxStatResult.rEntryTxRate.MCS;
			HTPhyMode.field.BW = rTxStatResult.rEntryTxRate.BW;
			HTPhyMode.field.ShortGI = rTxStatResult.rEntryTxRate.ShortGI;
			HTPhyMode.field.STBC = rTxStatResult.rEntryTxRate.STBC;
			HTPhyMode.field.ldpc = rTxStatResult.rEntryTxRate.ldpc;

			getRate(HTPhyMode, &DataRate_r);
			/* Though NSS1VHT20MCS9 and NSS2VHT20MCS9 rates are not specified in
			 * IEEE802.11, we do use them */
			if ((HTPhyMode.field.MODE == MODE_VHT) && (HTPhyMode.field.BW == BW_20) &&
				((HTPhyMode.field.MCS & 0xf) == 9)) {
				u8 vht_nss = ((HTPhyMode.field.MCS & (0x3 << 4)) >> 4) + 1;

				if (vht_nss == 1)
					cli_info->uplink = HTPhyMode.field.ShortGI ? 96 : 86;
				else if (vht_nss == 2)
					cli_info->uplink = HTPhyMode.field.ShortGI ? 192 : 173;
			}
		}

		if (no_apcli_mode != 1) {
			if (eht_sgi == 1)
				DataRate_r = (DataRate_r * 967) >> 10;
		}

		cli_info->uplink = (u16) DataRate_r;
	} else if (EHTPhyMode.field.MODE == MODE_EHT_MU) {
		eht_mcs = EHTPhyMode.field.MCS & 0xf;
		eht_dcm = EHTPhyMode.field.MCS	& 0x10 ? 1 : 0;
#ifndef EM_PLUS_SUPPORT
		eht_nss = ((EHTPhyMode.field.MCS & (0x3 << 4)) >> 4);
#else
		eht_nss = EHTPhyMode.field.Nss;
#endif
		eht_sgi =  EHTPhyMode.field.ShortGI;
		eht_stbc = EHTPhyMode.field.STBC;
		eht_nss = (eht_nss + 1)/(eht_stbc + 1);
		get_rate_eht(eht_mcs, EHTPhyMode.field.BW, eht_nss, eht_dcm, &DataRate_r);

		if (eht_sgi == 1)
			DataRate_r = (DataRate_r * 967) >> 10;
		else if (eht_sgi == 2)
			DataRate_r = (DataRate_r * 870) >> 10;
		cli_info->uplink = (u16) DataRate_r;
	} else
#endif
#ifdef DOT11_HE_AX
	if (IS_HE_MODE(HEPhyMode.field.MODE)) {
		he_mcs = HEPhyMode.field.MCS & 0xf;
		he_dcm = HEPhyMode.field.MCS & 0x10 ? 1 : 0;
		he_nss = HEPhyMode.field.Nss;
		he_sgi = HEPhyMode.field.ShortGI;
		he_stbc = HEPhyMode.field.STBC;
		he_nss = (he_nss + 1)/(he_stbc + 1);
		get_rate_he(he_mcs, HEPhyMode.field.BW, he_nss, he_dcm, &DataRate_r);
		if (he_sgi == 1)
			DataRate_r = (DataRate_r * 967) >> 10;
		else if (he_sgi == 2)
			DataRate_r = (DataRate_r * 870) >> 10;
		cli_info->uplink = (u16) DataRate_r;
	} else
#endif
	{
		HTPhyMode.word = (UINT32) mac_entry->map_LastRxRate;
		getRate(HTPhyMode, &DataRate_r);
		cli_info->uplink = (u16) DataRate_r;

		/* Though NSS1VHT20MCS9 and NSS2VHT20MCS9 rates are not specified in
		* IEEE802.11, we do use them */
		if ((HTPhyMode.field.MODE == MODE_VHT) && (HTPhyMode.field.BW == BW_20) &&
			((HTPhyMode.field.MCS & 0xf) == 9)) {
			u8 vht_nss = ((HTPhyMode.field.MCS & (0x3 << 4)) >> 4) + 1;

			if (vht_nss == 1)
				cli_info->uplink = HTPhyMode.field.ShortGI ? 96 : 86;
			else if (vht_nss == 2)
				cli_info->uplink = HTPhyMode.field.ShortGI ? 192 : 173;
		}
	}
	cli_info->uplink_rssi = RTMPAvgRssi(pAd2, &mac_entry->RssiSample);
#ifdef CONFIG_DOT11V_WNM
	cli_info->cli_caps.btm_capable = mac_entry->bBSSMantSTASupport == TRUE ? 1 : 0;
#endif
	cli_info->bLocalSteerDisallow = false;
#ifdef DOT11K_RRM_SUPPORT
	if ((mac_entry->RrmEnCap.field.BeaconPassiveMeasureCap ||
		mac_entry->RrmEnCap.field.BeaconActiveMeasureCap)) {
		cli_info->cli_caps.rrm_capable = 1;
	} else {
		cli_info->cli_caps.rrm_capable = 0;
	}
#endif
#ifdef MBO_SUPPORT
	cli_info->cli_caps.mbo_capable = (mac_entry->bIndicateCDC || mac_entry->bIndicateNPC) ? 1 : 0;
#endif
	/* Phy Caps */
	cli_info->cli_caps.phy_mode = mac_entry->MaxHTPhyMode.field.MODE;
	/*11 AX Support*/
#ifdef CONFIG_MAP_SUPPORT
	if (cli_info->cli_caps.phy_mode == MODE_EHT) {
		cli_info->cli_caps.bw = EHTPhyMode.field.BW;
		cli_info->cli_caps.nss = eht_nss;
	} else
#endif
#ifdef DOT11_HE_AX
	if (cli_info->cli_caps.phy_mode == MODE_HE) {
		if (mac_entry->wdev && WMODE_CAP_2G(mac_entry->wdev->PhyMode))
			cli_info->cli_caps.bw = peer_max_bw_cap(mac_entry->cap.ch_bw.he_ch_width & 0x01);
		else
			cli_info->cli_caps.bw = peer_max_bw_cap(mac_entry->cap.ch_bw.he_ch_width & 0x0E);
		cli_info->cli_caps.nss_he.nss_80 = get_nss_from_he_chwidth(mac_entry, HE_BW_80);
		cli_info->cli_caps.nss_he.nss_160 = get_nss_from_he_chwidth(mac_entry, HE_BW_160);
		cli_info->cli_caps.nss_he.nss_8080 = get_nss_from_he_chwidth(mac_entry, HE_BW_8080);
		cli_info->cli_caps.nss = get_nss_from_he_chwidth(mac_entry, cli_info->cli_caps.bw);
		cli_info->cli_caps.bw = he_bw_conv(cli_info->cli_caps.bw);
	} else
#endif /*DOT11_HE_AX*/
	{ /*Non 11 AX Support*/
	cli_info->cli_caps.bw = mac_entry->MaxHTPhyMode.field.BW;
	cli_info->cli_caps.nss = ((mac_entry->MaxHTPhyMode.field.MCS & (0x3 << 4)) >> 4) + 1;
	}
	cli_info->bBTMSteerDisallow = false;

#ifdef EM_PLUS_SUPPORT
	if (((IS_ENTRY_CLIENT(mac_entry) || IS_ENTRY_PEER_AP(mac_entry) || IS_ENTRY_REPEATER(mac_entry))
					&& (mac_entry->Sst == SST_ASSOC)) || IS_ENTRY_WDS(mac_entry)) {
		Get_Pkt_Cnt_Per_Sta(pAd, mac_entry->wcid, &mac_entry->txMsduRetryCnt, &mac_entry->txMsduDropCnt);
	}
#endif
	/*traffic stats*/
	cli_info->bytes_sent = mac_entry->TxBytesMAP/1024;/*KBytes*/
	cli_info->bytes_received = mac_entry->RxBytesMAP/1024;/*KBytes*/
	cli_info->packets_sent = mac_entry->TxPackets.u.LowPart;
	cli_info->packets_received = mac_entry->RxPackets.u.LowPart;
#ifdef EM_PLUS_SUPPORT
	cli_info->tx_packets_errors = mac_entry->txMsduDropCnt + mac_entry->TxFailCount;
#else
	cli_info->tx_packets_errors = mac_entry->TxFailCount; /* to do */
#endif
	cli_info->rx_packets_errors = 0; /* not support */
	cli_info->retransmission_count = mac_entry->txMsduRetryCnt;
	cli_info->link_availability = 50; /* to do */
	cli_info->tx_tp = (u32)(mac_entry->AvgTxBytes);
	cli_info->rx_tp = (u32)(mac_entry->AvgRxBytes);

	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"WAPP-STA: %02x:%02x:%02x:%02x:%02x:%02x, rssi=%d, tx-rate=%u, rx-rate=%u",
		PRINT_MAC(cli_info->mac_addr), cli_info->uplink_rssi,
		cli_info->downlink, cli_info->uplink);

	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"tx-bytes=%u, rx-byte=%u, tx-pkt=%u rx-pkt=%u, tx-err=%u, tx-retran=%u\n",
		cli_info->bytes_sent, cli_info->bytes_received, cli_info->packets_sent,
		cli_info->packets_received, cli_info->tx_packets_errors,
		cli_info->retransmission_count);

	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"sgi=%u, he_sgi=%u, eht_sgi=%u\n",
		HTPhyMode.field.ShortGI, he_sgi, eht_sgi);

#ifdef CONFIG_MAP_SUPPORT
	if (IS_MAP_ENABLE(pAd2) &&
		IS_ENTRY_A4(mac_entry)) {
		cli_info->is_APCLI = 1;
	} else
#endif
		cli_info->is_APCLI = 0;

#ifdef MAP_R3
	cli_info->tid_cnt = MAX_TID;
	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"WF6:Driver:Setting TID value for %02x:%02x:%02x:%02x:%02x:%02x\n",
		PRINT_MAC(cli_info->mac_addr));
	if (ppdu) {
		for (i = 0; i < MAX_TID; i++) {
			cli_info->status_tlv[i].tid = i;
			if (WMODE_CAP_AX(PhyMode))
				cli_info->status_tlv[i].tid_q_size = (u16)(BA_WIN_SZ_256);
			else
				cli_info->status_tlv[i].tid_q_size = (u16)(BA_WIN_SZ_64);
			MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
				"WF6:Driver:tid_cnt %x, tid %x, tid_q_size %x\n",
				cli_info->tid_cnt, cli_info->status_tlv[i].tid, cli_info->status_tlv[i].tid_q_size);
		}
	}
#endif


	return 0;
}

#endif


INT wapp_fill_client_info(
	PRTMP_ADAPTER pAd,
	wapp_client_info *cli_info,
	MAC_TABLE_ENTRY *mac_entry)
{
	STA_TR_ENTRY *tr_entry;

	ULONG DataRate = 0, DataRate_r = 0;
	union _HTTRANSMIT_SETTING HTPhyMode;
	EXT_EVENT_TX_STATISTIC_RESULT_T rTxStatResult;
	union _HTTRANSMIT_SETTING LastTxRate;
#ifdef DOT11_HE_AX
	UINT8 he_dcm = 0, he_mcs = 0;

#endif
#ifdef MAP_R3
	int i = 0;
#endif

	memset(&HTPhyMode, 0, sizeof(union _HTTRANSMIT_SETTING));
	memset(&LastTxRate, 0, sizeof(union _HTTRANSMIT_SETTING));
	MtCmdGetTxStatistic(pAd, GET_TX_STAT_ENTRY_TX_RATE, 0/*Don't Care*/, mac_entry->wcid, &rTxStatResult);
	LastTxRate.field.MODE = rTxStatResult.rEntryTxRate.MODE;
	LastTxRate.field.BW = rTxStatResult.rEntryTxRate.BW;
	LastTxRate.field.ldpc = rTxStatResult.rEntryTxRate.ldpc ? 1 : 0;
	LastTxRate.field.ShortGI = rTxStatResult.rEntryTxRate.ShortGI ? 1 : 0;
	LastTxRate.field.STBC = rTxStatResult.rEntryTxRate.STBC;

#ifdef DOT11_HE_AX
	if (LastTxRate.field.MODE == MODE_HE_SU_REMAPPING) {
		he_mcs = rTxStatResult.rEntryTxRate.MCS & 0xf;
		he_dcm = rTxStatResult.rEntryTxRate.MCS & 0x10 ? 1 : 0;
		get_rate_he(he_mcs, rTxStatResult.rEntryTxRate.BW, rTxStatResult.rEntryTxRate.VhtNss, he_dcm, &DataRate);
	} else
#endif
	if (LastTxRate.field.MODE == MODE_VHT)
		LastTxRate.field.MCS = (((rTxStatResult.rEntryTxRate.VhtNss - 1) & 0x3) << 4) + rTxStatResult.rEntryTxRate.MCS;
	else if (LastTxRate.field.MODE == MODE_OFDM)
		LastTxRate.field.MCS = getLegacyOFDMMCSIndex(rTxStatResult.rEntryTxRate.MCS) & 0x0000003F;
	else
		LastTxRate.field.MCS = rTxStatResult.rEntryTxRate.MCS;

	mac_entry->LastTxRate = (UINT32)LastTxRate.word;

	tr_entry = tr_entry_get(pAd, mac_entry->wcid);

	COPY_MAC_ADDR(cli_info->mac_addr, mac_entry->Addr);
	COPY_MAC_ADDR(cli_info->bssid, mac_entry->wdev->bssid);
	cli_info->sta_status = \
				(tr_entry->PortSecured == WPA_802_1X_PORT_SECURED) ?
				WAPP_STA_CONNECTED : WAPP_STA_DISCONNECTED;
	cli_info->assoc_time = mac_entry->StaConnectTime;
#ifdef CONFIG_MAP_SUPPORT
	cli_info->assoc_req_len = mac_entry->assoc_req_len;
#ifdef MAP_R2
	cli_info->IsReassoc = mac_entry->IsReassocSta;
#endif
#endif /* MAP_SUPPORT */
#ifdef DOT11_HE_AX
		if (LastTxRate.field.MODE == MODE_HE_SU_REMAPPING) {
			cli_info->downlink = (u16) DataRate;
		} else
#endif
		{
			HTPhyMode.word = (USHORT)mac_entry->LastTxRate;
			getRate(HTPhyMode, &DataRate);
			cli_info->downlink = (u16) DataRate;
		}
	/* Though NSS1VHT20MCS9 and NSS2VHT20MCS9 rates are not specified in
	 * IEEE802.11, we do use them */
	if ((HTPhyMode.field.MODE == MODE_VHT) && (HTPhyMode.field.BW == BW_20) &&
			((HTPhyMode.field.MCS & 0xf) == 9)) {
		u8 vht_nss = ((HTPhyMode.field.MCS & (0x3 << 4)) >> 4) + 1;
		if (vht_nss == 1)
			cli_info->downlink = HTPhyMode.field.ShortGI ? 96 : 86;
		else if (vht_nss == 2)
			cli_info->downlink = HTPhyMode.field.ShortGI ? 192 : 173;
	}

	HTPhyMode.word = (USHORT) mac_entry->LastRxRate;
	getRate(HTPhyMode, &DataRate_r);
	cli_info->uplink = (u16) DataRate_r;

	cli_info->uplink_rssi = RTMPAvgRssi(pAd, &mac_entry->RssiSample);
#ifdef CONFIG_DOT11V_WNM
	cli_info->cli_caps.btm_capable = mac_entry->bBSSMantSTASupport == TRUE ? 1 : 0;
#endif
	cli_info->bLocalSteerDisallow = false;
#ifdef DOT11K_RRM_SUPPORT
	if ((mac_entry->RrmEnCap.field.BeaconPassiveMeasureCap ||
		 mac_entry->RrmEnCap.field.BeaconActiveMeasureCap)) {
		cli_info->cli_caps.rrm_capable = 1;
	} else {
		cli_info->cli_caps.rrm_capable = 0;
	}
#endif
#ifdef MBO_SUPPORT
	cli_info->cli_caps.mbo_capable = (mac_entry->bIndicateCDC || mac_entry->bIndicateNPC) ? 1 : 0;
#endif
	/* Phy Caps */
	cli_info->cli_caps.phy_mode = mac_entry->MaxHTPhyMode.field.MODE;
	/*11 AX Support*/
#ifdef DOT11_HE_AX
	if (cli_info->cli_caps.phy_mode == MODE_HE) {
		if (mac_entry->wdev && WMODE_CAP_2G(mac_entry->wdev->PhyMode))
			cli_info->cli_caps.bw = peer_max_bw_cap(mac_entry->cap.ch_bw.he_ch_width & 0x01);
		else
			cli_info->cli_caps.bw = peer_max_bw_cap(mac_entry->cap.ch_bw.he_ch_width & 0x0E);
		cli_info->cli_caps.nss_he.nss_80 = get_nss_from_he_chwidth(mac_entry, HE_BW_80);
		cli_info->cli_caps.nss_he.nss_160 = get_nss_from_he_chwidth(mac_entry, HE_BW_160);
		cli_info->cli_caps.nss_he.nss_8080 = get_nss_from_he_chwidth(mac_entry, HE_BW_8080);
		cli_info->cli_caps.nss = get_nss_from_he_chwidth(mac_entry, cli_info->cli_caps.bw);
		cli_info->cli_caps.bw = he_bw_conv(cli_info->cli_caps.bw);
	} else
#endif /*DOT11_HE_AX*/
	{ /*Non 11 AX Support*/
		cli_info->cli_caps.bw = mac_entry->MaxHTPhyMode.field.BW;
		cli_info->cli_caps.nss = ((mac_entry->MaxHTPhyMode.field.MCS & (0x3 << 4)) >> 4) + 1;
	}
	cli_info->bBTMSteerDisallow = false;
	/*traffic stats*/
#ifdef CONFIG_MAP_SUPPORT
	cli_info->bytes_sent = mac_entry->TxBytesMAP/1024;/*KBytes*/
	cli_info->bytes_received = mac_entry->RxBytesMAP/1024;/*KBytes*/
#else
	cli_info->bytes_sent = mac_entry->TxBytes/1024;/*KBytes*/
	cli_info->bytes_received = mac_entry->RxBytes/1024;/*KBytes*/
#endif
	cli_info->packets_sent = mac_entry->TxPackets.u.LowPart;
	cli_info->packets_received = mac_entry->RxPackets.u.LowPart;
	cli_info->tx_packets_errors = 0; /* to do */
	cli_info->rx_packets_errors = 0; /* to do */
	cli_info->retransmission_count = 0; /* to do */
	cli_info->link_availability = 50; /* to do */
	cli_info->tx_tp = (u32)(mac_entry->AvgTxBytes);
	cli_info->rx_tp = (u32)(mac_entry->AvgRxBytes);
#ifdef CONFIG_MAP_SUPPORT
	if (IS_MAP_ENABLE(pAd) &&
		IS_ENTRY_A4(mac_entry)) {
		cli_info->is_APCLI = 1;
	} else
#endif
		cli_info->is_APCLI = 0;

#ifdef MAP_R3
	cli_info->tid_cnt = MAX_TID;
	MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"WF6:Driver:Setting TID value for %02x:%02x:%02x:%02x:%02x:%02x\n",
		PRINT_MAC(cli_info->mac_addr));
	for (i = 0; i < MAX_TID; i++) {
		cli_info->status_tlv[i].tid = i;
		if (mac_entry->wdev && WMODE_CAP_AX(mac_entry->wdev->PhyMode))
			cli_info->status_tlv[i].tid_q_size = (u16)(BA_WIN_SZ_256);
		else
			cli_info->status_tlv[i].tid_q_size = (u16)(BA_WIN_SZ_64);
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"WF6:Driver:tid_cnt %x, tid %x, tid_q_size %x\n",
			cli_info->tid_cnt, cli_info->status_tlv[i].tid, cli_info->status_tlv[i].tid_q_size);
	}
#endif
	return 0;
}

INT wapp_send_cli_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wapp_event event;
	wapp_client_info *cli_info;
	MAC_TABLE_ENTRY *mac_entry;

	event.event_id = WAPP_CLI_QUERY_RSP;
	cli_info = &event.data.cli_info;

	for (i = 0; VALID_UCAST_ENTRY_WCID(pAd, i); i++) {
		mac_entry = entry_get(pAd, i);
#ifdef MAP_R6
		memset(cli_info, 0, sizeof(*cli_info));
#endif /* MAP_R6 */
		if (IS_ENTRY_CLIENT(mac_entry)
			&& NdisCmpMemory(mac_entry->Addr, req->data.mac_addr, MAC_ADDR_LEN) == 0
			&& mac_entry->wdev->if_dev
			&& req->data.ifindex == RtmpOsGetNetIfIndex(mac_entry->wdev->if_dev)) {
			wapp_fill_client_info_new(pAd, cli_info, mac_entry);
#ifdef MAP_R2
			/*printk("build sta ext params\n");*/
			cli_info->ext_metric_info.sta_info.last_data_dl_rate = mac_entry->LastTxRate;
			cli_info->ext_metric_info.sta_info.last_data_ul_rate = mac_entry->LastRxRate;
			cli_info->ext_metric_info.sta_info.utilization_rx =
				mac_entry->TxRxTime[0][0] + mac_entry->TxRxTime[1][0] +
				mac_entry->TxRxTime[2][0] + mac_entry->TxRxTime[3][0];
			cli_info->ext_metric_info.sta_info.utilization_tx =
				mac_entry->TxRxTime[0][1] + mac_entry->TxRxTime[1][1] +
				mac_entry->TxRxTime[2][1] + mac_entry->TxRxTime[3][1];
#endif
			event.ifindex = req->data.ifindex;
			wapp_send_wapp_qry_rsp(pAd, &event);
			return 0;
		}
	}

	COPY_MAC_ADDR(cli_info->mac_addr, req->data.mac_addr);
	cli_info->sta_status = WAPP_STA_DISCONNECTED;
	event.ifindex = req->data.ifindex;
	wapp_send_wapp_qry_rsp(pAd, &event);
	return 0;
}

INT wapp_send_cli_list_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	struct wapp_event event;

	event.event_id = WAPP_CLI_LIST_QUERY_RSP;
	event.ifindex = req->data.ifindex;
	wapp_send_wapp_qry_rsp(pAd, &event);
	return 0;
}


INT wapp_handle_cli_list_query(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	int band_idx = 0;
	struct wifi_dev *twdev;
	struct wifi_dev *wdev;
	struct wapp_event event;
	wapp_client_info *cli_info;
	MAC_TABLE_ENTRY *mac_entry;
	event.event_id = WAPP_CLI_QUERY_RSP;
	cli_info = &event.data.cli_info;


	for (i = 0; i < MAX_MBSSID_NUM(pAd) && i < MAX_BEACON_NUM; i++) {
		twdev = &pAd->ApCfg.MBSSID[i].wdev;
		if (req->data.ifindex ==  RtmpOsGetNetIfIndex(twdev->if_dev)) {
			band_idx = HcGetBandByWdev(twdev);
			MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
					"band_idx=%d\n", band_idx);
			break;
		}
	}


	for (i = 0; VALID_UCAST_ENTRY_WCID(pAd, i); i++) {
#ifdef MAP_R6
		memset(cli_info, 0, sizeof(*cli_info));
#endif /* MAP_R6 */
		mac_entry = entry_get(pAd, i);
		if (IS_ENTRY_CLIENT(mac_entry)) {/* report all entry no matter which wdev it is belonged */
			wdev = mac_entry->wdev;
			if (wdev->if_dev == NULL) {
				MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
					"!!!! wdev->ifdev = NULL\n");
				continue;
			}
			if (band_idx != HcGetBandByWdev(wdev))
				continue;
#ifdef CONFIG_MAP_SUPPORT
			wapp_fill_client_info_new(pAd, cli_info, mac_entry);
#else
			wapp_fill_client_info(pAd, cli_info, mac_entry);
#endif
#ifdef MAP_R2
			cli_info->ext_metric_info.sta_info.last_data_dl_rate = cli_info->downlink;
			cli_info->ext_metric_info.sta_info.last_data_ul_rate = cli_info->uplink;
			cli_info->ext_metric_info.sta_info.utilization_rx =
				mac_entry->TxRxTime[0][0] + mac_entry->TxRxTime[1][0] +
				mac_entry->TxRxTime[2][0] + mac_entry->TxRxTime[3][0];
			cli_info->ext_metric_info.sta_info.utilization_tx =
				mac_entry->TxRxTime[0][1] + mac_entry->TxRxTime[1][1] +
				mac_entry->TxRxTime[2][1] + mac_entry->TxRxTime[3][1];
#endif
				event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
				wapp_send_wapp_qry_rsp(pAd, &event);
#ifdef MBO_SUPPORT
			if (IS_MBO_ENABLE(wdev)) {
				if (mac_entry->bIndicateNPC && mac_entry->bindicate_NPC_event){
					MboIndicateStaInfoToDaemon(pAd,
											&mac_entry->MboStaInfoNPC,
											MBO_MSG_STA_PREF_UPDATE);
					 mac_entry->bindicate_NPC_event = FALSE;
				}
				if (mac_entry->bIndicateCDC && mac_entry->bindicate_CDC_event){
					MboIndicateStaInfoToDaemon(pAd,
											&mac_entry->MboStaInfoCDC,
											MBO_MSG_CDC_UPDATE);
					mac_entry->bindicate_CDC_event = FALSE;
				}
			}
#endif /* MBO_SUPPORT */
		}
	}

	wapp_send_cli_list_query_rsp(pAd, req);
	return 0;
}

/* AP Assoc */
INT wapp_send_ap_join_event(
	PRTMP_ADAPTER pAd,
	PSTA_ADMIN_CONFIG pApCliEntry)
{
	struct wifi_dev *wdev;
	struct wapp_event event;
	wapp_client_info *cli_info;

	if (pApCliEntry) {
		wdev = &pApCliEntry->wdev;
		if (wdev->if_dev) {
			event.event_id = WAPP_AP_JOIN_EVENT;
			event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
			cli_info = &event.data.cli_info;
#ifdef MAP_R6
			memset(cli_info, 0, sizeof(*cli_info));
#endif /* MAP_R6 */
			wapp_fill_ap_info(pAd, wdev, cli_info, pApCliEntry);
			wapp_send_wapp_qry_rsp(pAd, &event);
		}
	}

	return 0;
}

/* client assoc */
INT wapp_send_cli_join_event(
	PRTMP_ADAPTER pAd,
	MAC_TABLE_ENTRY *mac_entry)
{
	struct wifi_dev *wdev;
	struct wapp_event event;
	wapp_client_info *cli_info;

	if (mac_entry) {
		wdev = mac_entry->wdev;
		if (wdev->if_dev) {
			event.event_id = WAPP_CLI_JOIN_EVENT;
			event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
			cli_info = &event.data.cli_info;
#ifdef MAP_R6
			memset(cli_info, 0, sizeof(*cli_info));
#endif /* MAP_R6 */
			wapp_fill_client_info_new(pAd, cli_info, mac_entry);
			wapp_send_wapp_qry_rsp(pAd, &event);
#ifdef MBO_SUPPORT
		if (IS_MBO_ENABLE(wdev)) {
			if (mac_entry->bIndicateNPC && mac_entry->bindicate_NPC_event){
				MboIndicateStaInfoToDaemon(pAd, &mac_entry->MboStaInfoNPC, MBO_MSG_STA_PREF_UPDATE);
				mac_entry->bindicate_NPC_event = FALSE;
			}
			if (mac_entry->bIndicateCDC && mac_entry->bindicate_CDC_event){
				MboIndicateStaInfoToDaemon(pAd, &mac_entry->MboStaInfoCDC, MBO_MSG_CDC_UPDATE);
				mac_entry->bindicate_CDC_event	= FALSE;
			}
		}
#endif /* MBO_SUPPORT */
		}
	}

	return 0;
}

INT wapp_send_cli_all_leave_event(
	PRTMP_ADAPTER pAd,
	UINT32 ifindex,
	UCHAR *mac_addr,
	MAC_TABLE_ENTRY *mac_entry)
{
	struct wapp_event event;
	wapp_client_info *cli_info;

	event.event_id = WAPP_CLI_ALL_LEAVE_EVENT;
	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
		"in driver WAPP_CLI_ALL_LEAVE_EVENT reason %d\n", mac_entry->DisconnectReason);
	event.ifindex = ifindex;
	cli_info = &event.data.cli_info;
	cli_info->is_APCLI = 0;
	COPY_MAC_ADDR(cli_info->mac_addr, mac_addr);
#if (defined(MAP_R6) && defined(DOT11_EHT_BE))
	if (mac_entry->mlo.mlo_en) {
		cli_info->mlo.mlo_en = 1;
		COPY_MAC_ADDR(cli_info->mlo.sta_mld_addr, mac_entry->mlo.mld_addr);
		if (mac_entry->wdev)
			COPY_MAC_ADDR(cli_info->mlo.ap_mld_addr, mac_entry->wdev->bssid);
	}
#endif
	cli_info->disassoc_reason = mac_entry->DisconnectReason;
	wapp_send_wapp_qry_rsp(pAd, &event);

	return 0;
}

/* client disaccos */
INT wapp_send_cli_leave_event(
	PRTMP_ADAPTER pAd,
	UINT32 ifindex,
	UCHAR *mac_addr,
	MAC_TABLE_ENTRY *mac_entry)
{
	struct wapp_event event;
	wapp_client_info *cli_info;

	event.event_id = WAPP_CLI_LEAVE_EVENT;
	event.ifindex = ifindex;
	cli_info = &event.data.cli_info;
#ifdef MAP_R6
	memset(cli_info, 0, sizeof(*cli_info));
#endif /* MAP_R6 */

#ifdef CONFIG_MAP_SUPPORT
	if (IS_MAP_ENABLE(pAd) &&
		IS_ENTRY_A4(mac_entry)) {
		cli_info->is_APCLI = 1;
	} else
#endif
		cli_info->is_APCLI = 0;
	COPY_MAC_ADDR(cli_info->mac_addr, mac_addr);
#if (defined(MAP_R6) && defined(DOT11_EHT_BE))
	if (mac_entry->mlo.mlo_en) {
		cli_info->mlo.mlo_en = 1;
		wapp_fill_client_mlo_info(pAd, cli_info, mac_entry);
	}
#endif
	cli_info->disassoc_reason = mac_entry->DisconnectReason;
	wapp_send_wapp_qry_rsp(pAd, &event);

	return 0;
}

#ifdef MAP_R2

INT wapp_send_sta_disassoc_stats_event(
	PRTMP_ADAPTER pAd,
	MAC_TABLE_ENTRY *pEntry,
	USHORT reason)
{
	struct wapp_event event;
	wapp_client_info *cli_info;

	if (pEntry->wdev->if_dev) {
		event.event_id = WAPP_STA_DISASSOC_EVENT;
		cli_info = &event.data.cli_info;
#ifdef MAP_R6
		memset(cli_info, 0, sizeof(*cli_info));
#endif /* MAP_R6 */

		wapp_fill_client_info_new(pAd, cli_info, pEntry);
		cli_info->disassoc_reason = reason;
		/*printk("disassoc stats evt: reason code: %d\n", cli_info->disassoc_reason);*/
		event.ifindex = pEntry->wdev->if_dev->ifindex;
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}

void wapp_handle_sta_disassoc(PRTMP_ADAPTER pAd, UINT16 wcid, UINT16 Reason)
{
	STA_TR_ENTRY *tr_entry	= tr_entry_get(pAd, wcid);
	MAC_TABLE_ENTRY *pEntry = entry_get(pAd, wcid);

	if (tr_entry->PortSecured == WPA_802_1X_PORT_SECURED)
		pEntry->DisconnectReason = Reason;
	else
		wapp_send_sta_connect_rejected(pAd, pEntry->wdev, pEntry->Addr,
					pEntry->bssid,
					WAPP_ASSOC, Reason, 0, Reason);
}

#endif


INT wapp_send_apcli_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
#ifdef APCLI_SUPPORT
	u8 i;
	struct wifi_dev *wdev;
	struct wapp_event event;
	wapp_client_info *cli_info;
	MAC_TABLE_ENTRY *mac_entry;
	PSTA_ADMIN_CONFIG apcli_entry;
#if (defined(MTK_MLO_MAP_SUPPORT) && defined(DOT11_EHT_BE))
	MAC_TABLE_ENTRY *pEntry = NULL;
#endif

	event.event_id = WAPP_APCLI_QUERY_RSP;
	event.ifindex = req->data.ifindex;
	cli_info = &event.data.cli_info;

	for (i = 0; i < MAX_MULTI_STA; i++) {
#ifdef MAP_R6
		memset(cli_info, 0, sizeof(*cli_info));
#endif /* MAP_R6 */

		apcli_entry = &pAd->StaCfg[i];
		wdev = &apcli_entry->wdev;
		if (!apcli_entry || !wdev) {
			MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				"entry or wdev null continue\n");
			continue;
		}

#if (defined(MTK_MLO_MAP_SUPPORT) && defined(DOT11_EHT_BE))
		pEntry = MacTableLookup(pAd, apcli_entry->Bssid);

		if (pEntry == NULL) {
			MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR, "pEntry NULL\n");
			continue;
		}
#endif
		if (((apcli_entry->ApcliInfStat.Valid == TRUE)
#if (defined(MTK_MLO_MAP_SUPPORT) && defined(DOT11_EHT_BE))
			|| (pEntry->mlo.mlo_en)
#endif
		)
			&& wdev->if_dev
			&& (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)) {
			mac_entry = entry_get(pAd, apcli_entry->MacTabWCID);
			if (IS_ENTRY_PEER_AP(mac_entry)) {
				wapp_fill_client_info_new(pAd, cli_info, mac_entry);
				wapp_send_wapp_qry_rsp(pAd, &event);
				break;
			}
		}
	}
#endif

	return 0;
}


INT wapp_send_cli_probe_event(
	PRTMP_ADAPTER pAd,
	UINT32 ifindex,
	UCHAR *mac_addr,
	MLME_QUEUE_ELEM *elem)
{
	struct wapp_event event;
	wapp_probe_info *probe_info;
	struct raw_rssi_info *raw_rssi;
	RSSI_SAMPLE rssi;

	raw_rssi = &elem->rssi_info;

	rssi.AvgRssi[0] = raw_rssi->raw_rssi[0];
	rssi.AvgRssi[1] = raw_rssi->raw_rssi[1];
	rssi.AvgRssi[2] = raw_rssi->raw_rssi[2];
	rssi.AvgRssi[3] = raw_rssi->raw_rssi[3];

	event.event_id = WAPP_CLI_PROBE_EVENT;
	event.ifindex = ifindex;
	probe_info = &event.data.probe_info;
	COPY_MAC_ADDR(probe_info->mac_addr, mac_addr);
	probe_info->channel = elem->Channel;
	probe_info->rssi = RTMPAvgRssi(pAd, &rssi);
	if (elem->MsgLen <= PREQ_IE_LEN) {
		NdisCopyMemory(probe_info->preq, elem->Msg, elem->MsgLen);
		probe_info->preq_len = elem->MsgLen;
	} else {
		NdisCopyMemory(probe_info->preq, elem->Msg, PREQ_IE_LEN);
		probe_info->preq_len = PREQ_IE_LEN;
	}

	wapp_send_wapp_qry_rsp(pAd, &event);
	return 0;
}

VOID wapp_send_bcn_report(
	IN PRTMP_ADAPTER pAd,
	IN PMAC_TABLE_ENTRY pEntry,
	IN PUCHAR report,
	IN ULONG report_len)
{
	struct wifi_dev *wdev;
	struct wapp_event *event = NULL;
	UCHAR count = 0, i = 0;
	PEID_STRUCT eid_ptr = NULL;
	if (pEntry && IS_ENTRY_CLIENT(pEntry)) {
		os_alloc_mem(pAd, (UCHAR **)&event, sizeof(*event));
		if (!event)
			return;
		NdisZeroMemory(event, sizeof(*event));
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"Sta Addr = "MACSTR"\n", MAC2STR(pEntry->Addr));
		wdev = pEntry->wdev;
		if (wdev->if_dev == NULL) {
			MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				"!!!! wdev->ifdev = NULL\n");
			os_free_mem(event);
			return;
		}
		event->event_id = WAPP_RCEV_BCN_REPORT;
		event->ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		eid_ptr = (PEID_STRUCT) report;
		COPY_MAC_ADDR(event->data.bcn_rpt_info.sta_addr, pEntry->Addr);

		if (report_len > 0) {
			if (report_len % BCN_RPT_LEN)
				count = report_len/BCN_RPT_LEN + 1;
			else
				count = report_len/BCN_RPT_LEN;
			for (i = 0 ; i < count ; i++) {
				if (i == (count - 1)) {
					event->data.bcn_rpt_info.bcn_rpt_len = report_len;
					event->data.bcn_rpt_info.last_fragment = 1;
					NdisCopyMemory(event->data.bcn_rpt_info.bcn_rpt, &report[i*BCN_RPT_LEN], report_len);
				} else {
					event->data.bcn_rpt_info.bcn_rpt_len = BCN_RPT_LEN;
					event->data.bcn_rpt_info.last_fragment = 0;
					NdisCopyMemory(event->data.bcn_rpt_info.bcn_rpt, &report[i*BCN_RPT_LEN], BCN_RPT_LEN);
					report_len -= BCN_RPT_LEN;
				}
				wapp_send_wapp_qry_rsp(pAd, event);
			}
		} else {
			event->data.bcn_rpt_info.bcn_rpt_len = report_len;
			event->data.bcn_rpt_info.last_fragment = 1;
			wapp_send_wapp_qry_rsp(pAd, event);
		}
		os_free_mem(event);
	}
}


VOID wapp_send_bcn_report_complete(
	IN PRTMP_ADAPTER pAd,
	IN PMAC_TABLE_ENTRY pEntry)
{
	struct wifi_dev *wdev;
	struct wapp_event event;

	if (pEntry && IS_ENTRY_CLIENT(pEntry)) {
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"Sta Addr = "MACSTR"\n", MAC2STR(pEntry->Addr));
		wdev = pEntry->wdev;
		if (wdev->if_dev) {
			event.event_id = WAPP_RCEV_BCN_REPORT_COMPLETE;
			event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
			COPY_MAC_ADDR(event.data.bcn_rpt_info.sta_addr, pEntry->Addr);
			wapp_send_wapp_qry_rsp(pAd, &event);
		}
	}
}

#ifdef AIR_MONITOR
VOID wapp_send_air_mnt_rssi(
	IN PRTMP_ADAPTER pAd,
	IN PMAC_TABLE_ENTRY pEntry,
	IN PMNT_STA_ENTRY pMntEntry)
{
	struct wifi_dev *wdev;
	struct wapp_event event;

	if (pEntry && IS_ENTRY_MONITOR(pEntry)) {
		wdev = pEntry->wdev;
		if (wdev->if_dev) {
			event.event_id = WAPP_RCEV_MONITOR_INFO;
			event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
			COPY_MAC_ADDR(event.data.mnt_info.sta_addr, pMntEntry->addr);
			if (pAd->MntMaxPktCnt == 0)
				event.data.mnt_info.rssi = RTMPAvgRssi(pAd, &pMntEntry->RssiSample);
			else
				event.data.mnt_info.rssi = pMntEntry->RssiTotal/(LONG)pMntEntry->Count;
			wapp_send_wapp_qry_rsp(pAd, &event);
		}
	}
}
#endif

#ifdef CONFIG_MAP_SUPPORT
VOID wapp_send_cac_period_event(
	IN PRTMP_ADAPTER pAd,
	IN UINT32 ifindex,
	IN UCHAR channel,
	IN UCHAR cac_enable,
	IN USHORT cac_time)
{
	struct wapp_event event;
	wapp_cac_info *cac_info = NULL;
	event.event_id = WAPP_CAC_PERIOD_EVENT;
	event.ifindex = ifindex;
	cac_info = &event.data.cac_info;
	cac_info->channel = channel;
	cac_info->ret = cac_enable;
	cac_info->cac_timer = cac_time;
	wapp_send_wapp_qry_rsp(pAd, &event);
}
#endif

#ifdef DPP_R2_SUPPORT
VOID RTMPIoctlGetCCEResults(
	IN PRTMP_ADAPTER pAd, struct wapp_req *req) {
	struct wapp_event event;
	BSS_ENTRY *bss;
	struct cce_vendor_ie_result result;
	int i = 0, index = 0, j = 0;
	UINT16 l = 0;
	BSS_TABLE *ScanTab = NULL;
	struct wifi_dev *wdev = NULL;
	u8 dup = 0;
#ifdef MAP_R3_6E_SUPPORT
	u8 band_6g = 0;
	int k = 0;
#endif

	for (l = 0; l < WDEV_NUM_MAX; l++) {
		if (pAd->wdev_list[l] != NULL) {
			wdev = pAd->wdev_list[l];
			if (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)
				break;
		}
	}

	if (wdev == NULL) {
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				"wdev is null\n");
		return;
	}

	ScanTab = get_scan_tab_by_wdev(pAd, wdev);

	NdisZeroMemory(&result, sizeof(struct cce_vendor_ie_result));

	if (ScanTab->BssNr == 0) {
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"no bss present in scan tab\n");
		/*return;*/
	}

#ifdef MAP_R3_6E_SUPPORT
	if (WMODE_CAP_6G(wdev->PhyMode)) {
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"(DPP) 6G BAND wdev found\n");
		band_6g = 1;
	}
#endif

	for (i = 0; i < ScanTab->BssNr; i++) {
		dup = 0;
		bss = &ScanTab->BssEntry[i];

		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_DEBUG,
			"(DPP) ABOVE CCE res_channl[%d] = %d, cce_flag:%d, cce_channel:%d\n",
			i, result.cce_ch[i], bss->cce_vendor_ie_found, bss->Channel);

		if (bss->cce_vendor_ie_found == TRUE) {
			/*check if the channel is already in the list*/
			for (j = 0; j < index; j++) {
				if (result.cce_ch[j] == bss->Channel
#ifdef MAP_R3_6E_SUPPORT
					|| (band_6g && (j < MAX_RNR_CHANNEL) && (result.rnr_6e_ch[j] == bss->Channel))
#endif
				) {
					dup = 1;
					break;
				}
			}
			if (dup == 1)
				continue;

#ifdef MAP_R3_6E_SUPPORT
			if (!band_6g)
#endif
				result.cce_ch[index] = bss->Channel;

#ifdef MAP_R3_6E_SUPPORT
			else if (bss->Channel != 0) {
				/* Appending 6G Band Scan channels in rnr array*/
				if (k < MAX_RNR_CHANNEL) {
					result.rnr_6e_ch[k] = bss->Channel;
					k = k + 1;
					result.rnr_6e_num = k;
				}

				if (index < MAX_RNR_CHANNEL)
					MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_DEBUG,
						"(DPP) PSC SCAN channel%d,\n", result.rnr_6e_ch[index]);
			}
#endif
#ifdef MAP_R3_6E_SUPPORT
			if (bss->rnr_info.channel != 0 && (!band_6g)) {
				/* Appending RNR Information when scannig for 2G,5G band*/
				dup = 0;
				for (j = 0; (j < k) && (j < MAX_RNR_CHANNEL); j++) {
					if (result.rnr_6e_ch[j] == bss->Channel) {
						dup = 1;
						break;
					}
				}

				if (dup == 0) {
					if (k < MAX_RNR_CHANNEL) {
						result.rnr_6e_ch[k] = bss->rnr_info.channel;
						k = k + 1;
						result.rnr_6e_num = k;
					}
				}
			}

			if (!band_6g) {
				MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_DEBUG,
					"(DPP) bss->rnr_info.channel%d,\n", bss->rnr_info.channel);
#endif
				result.num++;
#ifdef MAP_R3_6E_SUPPORT
			}
#endif
			if (index < MAX_CCE_CHANNEL - 1)
				index++;
		}
	}

	for (i = 0; (i < result.num) && (i < MAX_CCE_CHANNEL); i++)
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"result.num = %d, channl[%d] = %d\n", result.num, i, result.cce_ch[i]);

	event.event_id = WAPP_DPP_CCE_RSP;
	event.ifindex = req->data.ifindex;
	NdisCopyMemory(&event.data.cce_ie_result, &result, sizeof(struct cce_vendor_ie_result));
	wapp_send_wapp_qry_rsp(pAd, &event);

	return;
}

#endif

VOID wapp_send_csa_event(
	IN PRTMP_ADAPTER pAd,
	IN UINT32 ifindex,
	IN UCHAR new_channel)
{
	struct wapp_event event;
	wapp_csa_info *csa_info;

	event.event_id = WAPP_CSA_EVENT;
	event.ifindex = ifindex;
	csa_info = &event.data.csa_info;
	csa_info->new_channel = new_channel;
	wapp_send_wapp_qry_rsp(pAd, &event);
}

VOID wapp_send_cli_active_change(
	IN PRTMP_ADAPTER pAd,
	IN PMAC_TABLE_ENTRY pEntry,
	IN STA_STATUS stat)
{
	struct wifi_dev *wdev;
	struct wapp_event event;

	if (pEntry && IS_ENTRY_CLIENT(pEntry)) {
		wdev = pEntry->wdev;
		if (wdev->if_dev) {
			event.event_id = WAPP_CLI_ACTIVE_CHANGE;
			event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
			event.data.cli_info.status = stat;
			COPY_MAC_ADDR(event.data.cli_info.mac_addr, pEntry->Addr);
			wapp_send_wapp_qry_rsp(pAd, &event);
		}
	}
}

VOID setChannelList(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev,
	wdev_chn_info *chn_list)
{
	int i = 0;
#ifdef CONFIG_MAP_SUPPORT
	UCHAR band_idx;
	PDFS_PARAM pDfsParam = &pAd->CommonCfg.DfsParameter;
	band_idx = HcGetBandByWdev(wdev);
#endif
	for (i = 0; (i < pAd->ChannelListNum) && (i < (sizeof(chn_list->ch_list)/sizeof(struct chnList))) && (i < MAX_NUM_OF_CHANNELS);
		i++) {
		chn_list->ch_list[i].channel =  pAd->ChannelList[i].Channel;

		/* Set Preference & reason */
		if (pAd->ChannelList[i].DfsReq) {
#ifdef CONFIG_MAP_SUPPORT /* TODO: move to MAP */
			chn_list->ch_list[i].pref |= (OP_DISALLOWED_DUE_TO_DFS | NON_PREF);
			if ((pAd->CommonCfg.RDDurRegion == CE) &&
				DfsCacRestrictBand(pAd, pDfsParam->band_bw, pAd->ChannelList[i].Channel, 0))
				chn_list->ch_list[i].cac_timer = 605;
			else
				chn_list->ch_list[i].cac_timer = 65;
#endif /* CONFIG_MAP_SUPPORT */
		}
		if (pAd->ChannelList[i].Channel == wlan_operate_get_cen_ch_1(wdev)) {
#ifdef CONFIG_MAP_SUPPORT /* TODO: move to MAP */
			chn_list->ch_list[i].pref |= PREF_SCORE_14;
#endif /* CONFIG_MAP_SUPPORT */
		}
	}

}

INT wapp_send_op_class_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
#ifndef MAP_6E_SUPPORT
	INT i;
	struct wifi_dev *wdev;
	struct wapp_event event;
	wdev_op_class_info *op_class;

	NdisZeroMemory((void *)&event, sizeof(struct wapp_event));
	event.event_id = WAPP_OP_CLASS_RSP;
	event.ifindex = req->data.ifindex;
	op_class = &event.data.op_class;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == event.ifindex)) {
#ifdef CONFIG_MAP_SUPPORT
				op_class->num_of_op_class = map_set_op_class_info(pAd, wdev, op_class);
#endif /* CONFIG_MAP_SUPPORT */
				wapp_send_wapp_qry_rsp(pAd, &event);
			}
		}
	}
	return 0;
#else
	return 0;
#endif
}

#ifdef DPP_SUPPORT
void wext_send_dpp_frame_tx_status(PRTMP_ADAPTER pAd, struct wifi_dev *wdev,
				BOOLEAN tx_error, UINT16 seq_no)
{
	struct wapp_event event;
	struct wapp_dpp_frm_tx_status *req_data;

	if (!wdev) {
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
						"wdev is null\n");
		return;
	}
	MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"sending tx status to wapp status=%d\n", tx_error);
	event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
	req_data = (struct wapp_dpp_frm_tx_status *)&event.data;
	req_data->tx_success = tx_error;
	req_data->seq_no = seq_no;
	event.event_id = WAPP_DPP_ACTION_FRAME_STATUS;
	wapp_send_wapp_qry_rsp(pAd, &event);
}

void cache_dpp_frame_rx_event(struct wifi_dev *wdev, const char *peer_mac_addr, UINT channel,
					const char *frm, UINT16 frm_len, BOOL is_gas, UINT32 frm_count)
{
	char *buf;
	struct wapp_event *event;
	struct wapp_dpp_action_frame *req_data;
	UINT16 buflen = 0;
	struct dpp_frame_list *dpp_frame;

	buflen = sizeof(*event) + frm_len;
	os_alloc_mem(NULL, (UCHAR **)&buf, buflen);
	if (buf == NULL) {
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
			"Fail to allocate memory!\n");
	} else {
		NdisZeroMemory(buf, buflen);

		event = (struct wapp_event *)buf;
		event->ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		event->event_id = WAPP_DPP_ACTION_FRAME_RECEIVED;

		req_data = (struct wapp_dpp_action_frame *)&(event->data.frame);
		NdisCopyMemory(req_data->src, peer_mac_addr, 6);
		req_data->frm_len = frm_len;
		if (!req_data->frm_len) {
			MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				"invalid frame_length for this dpp action frame\n");
			os_free_mem(buf);
			return;
		}
		req_data->chan = channel;
		req_data->is_gas = is_gas;
		req_data->wapp_dpp_frame_id_no = frm_count;
		NdisCopyMemory(req_data->frm, frm, frm_len);
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
			"wdev->wdev_idx %d event->ifindex %d,store fid %d\n", wdev->wdev_idx,
			event->ifindex, req_data->wapp_dpp_frame_id_no);
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"source mac address for dpp frame :%02x:%02x:%02x:%02x:%02x:%02x\n",
			PRINT_MAC(req_data->src));
		os_alloc_mem(NULL, (UCHAR **)&dpp_frame, sizeof(struct dpp_frame_list));
		if (dpp_frame == NULL) {
			MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				"Fail to allocate memory!\n");
			os_free_mem(buf);
		} else {
			NdisZeroMemory(dpp_frame, sizeof(struct dpp_frame_list));

			dpp_frame->dpp_frame_event = event;
			DlListAddTail(&wdev->dpp_frame_event_list, &dpp_frame->List);
		}
	}
}

void wext_send_dpp_frame_rx_event(IN PRTMP_ADAPTER pAdapter, struct wifi_dev *wdev, UINT32 frm_count)
{
	struct wapp_event *event;
	UINT16 buflen = 0;
	char *buf = NULL;

	buflen = sizeof(*event);
	os_alloc_mem(NULL, (UCHAR **)&buf, buflen);
	if (buf == NULL) {
		MTWF_DBG(pAdapter, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				"Fail to allocate memory!\n");
	} else {
		NdisZeroMemory(buf, buflen);
		event = (struct wapp_event *)buf;

		event->ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		event->event_id = WAPP_DPP_ACTION_FRAME_RECEIVED;
		event->data.wapp_dpp_frame_id_no = frm_count;
		MTWF_DBG(pAdapter, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"sending event to wapp with frame id %d\n", event->data.wapp_dpp_frame_id_no);

		wapp_send_wapp_qry_rsp(pAdapter, event);
		os_free_mem(buf);
	}
}

void wext_send_dpp_action_frame(PRTMP_ADAPTER pAd, struct wifi_dev *wdev, const char *peer_mac_addr, UINT channel,
							  const char *frm, UINT16 frm_len, BOOL is_gas)
{
	/* MAKING EVENT TO BE STORED IN LIST WITH FRAME*/
	cache_dpp_frame_rx_event(wdev, peer_mac_addr, channel, frm, frm_len, is_gas, pAd->dpp_rx_frm_counter);
	/*MAKING EVENT TO BE SENT TO WAPP  */
	wext_send_dpp_frame_rx_event(pAd, wdev, pAd->dpp_rx_frm_counter);
	pAd->dpp_rx_frm_counter++;
}
#endif /* DPP_SUPPORT */

#ifdef RT_CFG80211_SUPPORT
#endif

#ifdef MAP_R3
void wext_send_sta_info(PRTMP_ADAPTER pAd, struct wifi_dev *wdev,
				MAC_TABLE_ENTRY *pEntry)
{
	struct wapp_event event;
	struct wapp_sta_info *req_data;

	if (!wdev) {
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
						"wdev is null\n");
		return;
	}
	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
						"sending sta info to wapp\n");
	event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
	req_data = (struct wapp_sta_info *)&event.data;
	if (wdev->wdev_type == WDEV_TYPE_AP) {
		if (pEntry->func_tb_idx >= MAX_BEACON_NUM) {
			MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
						"invalid idx %u\n", pEntry->func_tb_idx);
			return;
		}
#ifdef MAP_R6
		if (pEntry->mlo.mlo_en)
			NdisCopyMemory(req_data->src, pEntry->mlo.mld_addr, MAC_ADDR_LEN);
		else
#endif
			NdisCopyMemory(req_data->src, pEntry->Addr, MAC_ADDR_LEN);
		req_data->SsidLen = pAd->ApCfg.MBSSID[pEntry->func_tb_idx].SsidLen;
		NdisCopyMemory(req_data->ssid,
			pAd->ApCfg.MBSSID[pEntry->func_tb_idx].Ssid, (MAX_LEN_OF_SSID+1));
	} else {
		if (pEntry->func_tb_idx >= MAX_MULTI_STA) {
			MTWF_DBG(pAd, DBG_CAT_CLIENT, CATAP_WAPP, DBG_LVL_ERROR,
						"invalid idx %u\n", pEntry->func_tb_idx);
			return;
		}
		NdisCopyMemory(req_data->src, pEntry->wdev->if_addr, MAC_ADDR_LEN);
		req_data->SsidLen = pAd->StaCfg[pEntry->func_tb_idx].SsidLen;
		NdisCopyMemory(req_data->ssid,
			pAd->StaCfg[pEntry->func_tb_idx].Ssid, (MAX_LEN_OF_SSID+1));
	}
	/* if (!IS_AKM_DPP(pEntry->SecConfig.AKMMap)) */
	NdisCopyMemory(req_data->passphrase, pEntry->wdev->SecConfig.PSK, LEN_PSK);
	req_data->pmk_len = pEntry->SecConfig.pmk_len;
	NdisCopyMemory(req_data->pmk, pEntry->SecConfig.PMK, pEntry->SecConfig.pmk_len);
	req_data->ptk_len = pEntry->SecConfig.ptk_len;
	NdisCopyMemory(req_data->ptk, pEntry->SecConfig.PTK, pEntry->SecConfig.ptk_len);
	event.event_id = WAPP_STA_INFO;

	wapp_send_wapp_qry_rsp(pAd, &event);
}

void wext_send_dpp_uri_info(PRTMP_ADAPTER pAd, struct wifi_dev *wdev,
				PWSC_CTRL pWscControl)
{
	struct wapp_event event;
	struct wapp_uri_info *req_data;

	if (!wdev) {
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
						"wdev is null\n");
		return;
	}
	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_DEBUG,
						"sending URI info to wapp\n");
	event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
	req_data = (struct wapp_uri_info *)&event.data;

	NdisCopyMemory(req_data->src_mac, pWscControl->WscPeerInfo.WscPeerMAC, MAC_ADDR_LEN);
	req_data->uri_len = (u8)pWscControl->rcvd_uri_len;
	NdisCopyMemory(req_data->rcvd_uri, pWscControl->rcvd_dpp_uri, req_data->uri_len);
	req_data->rcvd_uri[req_data->uri_len] = '\0';
	event.event_id = WAPP_R3_DPP_URI_INFO;

	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
				"Sta Addr = %02x:%02x:%02x:%02x:%02x:%02x wdev:%s URI to wapp:%s with len:%u\n",
				PRINT_MAC(req_data->src_mac), RtmpOsGetNetDevName(wdev->if_dev),
				req_data->rcvd_uri, req_data->uri_len);

	wapp_send_wapp_qry_rsp(pAd, &event);
}
#endif /* MAP_R3 */

/*
INT wapp_send_bss_info_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;
	struct wapp_event event;
	wdev_bss_info *bss_info;
	char *key_src;

	NdisZeroMemory(&event, sizeof(event));
	event.event_id = WAPP_BSS_INFO_RSP;
	event.ifindex = req->data.ifindex;
	bss_info = &event.data.bss_info;


	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == event.ifindex)) {
				if (i >= MAX_MBSSID_NUM(pAd) || wdev->wdev_type != WDEV_TYPE_AP) {
					MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
						"wdev %d is not an AP\n", i);
					break;
				}
				bss_info->SsidLen = pAd->ApCfg.MBSSID[i].SsidLen;
				NdisMoveMemory(bss_info->ssid, pAd->ApCfg.MBSSID[i].Ssid, (MAX_LEN_OF_SSID+1));
				NdisMoveMemory(bss_info->bssid, wdev->bssid, MAC_ADDR_LEN);
				NdisMoveMemory(bss_info->if_addr, wdev->if_addr, MAC_ADDR_LEN);
#ifdef CONFIG_MAP_SUPPORT
				bss_info->map_role = wdev->MAPCfg.DevOwnRole;
				bss_info->auth_mode = pAd->ApCfg.MBSSID[i].wdev.SecConfig.AKMMap;
				bss_info->enc_type = pAd->ApCfg.MBSSID[i].wdev.SecConfig.PairwiseCipher;
#ifdef WSC_AP_SUPPORT
				key_src = &(pAd->ApCfg.MBSSID[i].wdev.WscControl.WpaPsk[0]);
#else
#ifndef RT_CFG80211_SUPPORT
				key_src = &(pAd->ApCfg.MBSSID[i].PSK[0]);
#endif
#endif
				bss_info->key_len = strlen(key_src);
				if (bss_info->key_len < sizeof(bss_info->key)) {
					// include null terminator
					NdisMoveMemory(&(bss_info->key[0]), key_src, bss_info->key_len + 1);
				} else {
					bss_info->key_len = sizeof(bss_info->key) - 1;
					NdisMoveMemory(&(bss_info->key[0]), key_src, bss_info->key_len);
					bss_info->key[bss_info->key_len] = '\0';
				}
				bss_info->hidden_ssid = pAd->ApCfg.MBSSID[i].bHideSsid;
#endif
				wapp_send_wapp_qry_rsp(pAd, &event);
			}
		}
	}

	return 0;
}
*/


INT wapp_send_ap_metric_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;
	struct wapp_event event;
	wdev_ap_metric *ap_metric;
	BSS_STRUCT *mbss;

	event.event_id = WAPP_AP_METRIC_RSP;
	event.ifindex = req->data.ifindex;
	ap_metric = &event.data.ap_metrics;
	NdisZeroMemory(ap_metric, sizeof(wdev_ap_metric));

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == event.ifindex)) {
				mbss = &pAd->ApCfg.MBSSID[wdev->func_idx];
				NdisMoveMemory(ap_metric->bssid, wdev->bssid, MAC_ADDR_LEN);
				ap_metric->cu = get_channel_utilization(pAd, event.ifindex);
				NdisCopyMemory(ap_metric->ESPI_AC[ESPI_BE], mbss->ESPI_AC_BE, sizeof(mbss->ESPI_AC_BE));
				NdisCopyMemory(ap_metric->ESPI_AC[ESPI_BK], mbss->ESPI_AC_BK, sizeof(mbss->ESPI_AC_BK));
				NdisCopyMemory(ap_metric->ESPI_AC[ESPI_VO], mbss->ESPI_AC_VO, sizeof(mbss->ESPI_AC_VO));
				NdisCopyMemory(ap_metric->ESPI_AC[ESPI_VI], mbss->ESPI_AC_VI, sizeof(mbss->ESPI_AC_VI));
#ifdef MAP_R6
// saurabh : tx rx values need to be checked
				ap_metric->mlo_ext_ap_metric.mlo_pkts_tx = (mbss->ucPktsTx + mbss->bcPktsTx + mbss->mcPktsTx);
				ap_metric->mlo_ext_ap_metric.mlo_pkts_rx = (mbss->ucPktsRx + mbss->bcPktsRx + mbss->mcPktsRx);
				ap_metric->mlo_ext_ap_metric.mlo_tx_error_count = mbss->TxErrorCount;

				ap_metric->mlo_ext_ap_metric.mlo_bc_rx =
					mbss->mlo_bcBytesRx == 0?0:((mbss->mlo_bcBytesRx/1024) == 0?1:mbss->mlo_bcBytesRx/1024);
				ap_metric->mlo_ext_ap_metric.mlo_bc_tx =
					mbss->mlo_bcBytesTx == 0?0:((mbss->mlo_bcBytesTx/1024) == 0?1:mbss->mlo_bcBytesTx/1024);
				ap_metric->mlo_ext_ap_metric.mlo_mc_rx =
					mbss->mlo_mcBytesRx == 0?0:((mbss->mlo_mcBytesRx/1024) == 0?1:mbss->mlo_mcBytesRx/1024);
				ap_metric->mlo_ext_ap_metric.mlo_mc_tx =
					mbss->mlo_mcBytesTx == 0?0:((mbss->mlo_mcBytesTx/1024) == 0?1:mbss->mlo_mcBytesTx/1024);
				ap_metric->mlo_ext_ap_metric.mlo_uc_rx =
					mbss->mlo_ucBytesRx == 0?0:((mbss->mlo_ucBytesRx/1024) == 0?1:mbss->mlo_ucBytesRx/1024);
				ap_metric->mlo_ext_ap_metric.mlo_uc_tx =
					mbss->mlo_ucBytesTx == 0?0:((mbss->mlo_ucBytesTx/1024) == 0?1:mbss->mlo_ucBytesTx/1024);
#endif
#ifdef MAP_R2
				/*TODO: take care of WHNAT*/
				ap_metric->ext_ap_metric.bc_rx =
					mbss->bcBytesRx == 0?0:((mbss->bcBytesRx/1024) == 0?1:mbss->bcBytesRx/1024);
				ap_metric->ext_ap_metric.bc_tx =
					mbss->bcBytesTx == 0?0:((mbss->bcBytesTx/1024) == 0?1:mbss->bcBytesTx/1024);
				ap_metric->ext_ap_metric.mc_rx =
					mbss->mcBytesRx == 0?0:((mbss->mcBytesRx/1024) == 0?1:mbss->mcBytesRx/1024);
				ap_metric->ext_ap_metric.mc_tx =
					mbss->mcBytesTx == 0?0:((mbss->mcBytesTx/1024) == 0?1:mbss->mcBytesTx/1024);
				ap_metric->ext_ap_metric.uc_rx =
					mbss->ucBytesRx == 0?0:((mbss->ucBytesRx/1024) == 0?1:mbss->ucBytesRx/1024);
				ap_metric->ext_ap_metric.uc_tx =
					mbss->ucBytesTx == 0?0:((mbss->ucBytesTx/1024) == 0?1:mbss->ucBytesTx/1024);
#endif
				wapp_send_wapp_qry_rsp(pAd, &event);
			}
		}
	}

	return 0;
}

#ifdef MAP_R2
static UINT8 wapp_rssi_to_rcpi(CHAR rssi)
{
	if (!rssi)
		return 255; /* not available */
	if (rssi < -110)
		return 0;
	if (rssi > 0)
		return 220;
	return (rssi + 110) * 2;
}

INT wapp_send_radio_metric_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;
	struct wapp_event event;
	wdev_radio_metric *radio_metric;
	int band_idx = 0;
#ifdef EM_PLUS_SUPPORT
	u32 sum = 0;
#endif

	event.event_id = WAPP_RADIO_METRIC_RSP;
	event.ifindex = req->data.ifindex;
	radio_metric = &event.data.radio_metrics;
	NdisZeroMemory(radio_metric, sizeof(wdev_radio_metric));
	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == event.ifindex)) {
				band_idx = HcGetBandByWdev(wdev);
				/*TODO: Raghav: NF logic in Harrier*/
				radio_metric->cu_noise = wapp_rssi_to_rcpi(pAd->noise_floor);
#ifdef EM_PLUS_SUPPORT
				if (((Get_My_Tx_AirTime_MAP(pAd, band_idx)*255)/ONE_SEC_2_US) > 255)
					radio_metric->cu_tx = 255;
				else
#endif
					radio_metric->cu_tx =
						(Get_My_Tx_AirTime_MAP(pAd, band_idx)*255)/ONE_SEC_2_US;
#ifdef EM_PLUS_SUPPORT
				if (((Get_My_Rx_AirTime_MAP(pAd, band_idx)*255)/ONE_SEC_2_US) > 255)
					radio_metric->cu_rx = 255;
				else
#endif
					radio_metric->cu_rx =
					(Get_My_Rx_AirTime_MAP(pAd, band_idx)*255)/ONE_SEC_2_US;
#ifdef EM_PLUS_SUPPORT
				if (((Get_OBSS_AirTime_MAP(pAd, band_idx)*255)/ONE_SEC_2_US) > 255)
					radio_metric->cu_other = 255;
				else
#endif
					radio_metric->cu_other =
					(Get_OBSS_AirTime_MAP(pAd, band_idx)*255)/ONE_SEC_2_US;
#ifdef EM_PLUS_SUPPORT
				if (((Get_EDCCA_Time(pAd, band_idx)*255)/ONE_SEC_2_US) > 255)
					radio_metric->edcca = 255;
				else
#endif
					radio_metric->edcca =
						(Get_EDCCA_Time(pAd, band_idx)*255)/ONE_SEC_2_US;

#ifdef EM_PLUS_SUPPORT
				sum = radio_metric->cu_tx + radio_metric->cu_rx + radio_metric->cu_other + radio_metric->edcca;
				if (sum > 255) {
					radio_metric->edcca = radio_metric->cu_tx + radio_metric->cu_rx
						+ radio_metric->cu_other > 255 ? 0 :
						(255 - radio_metric->cu_tx + radio_metric->cu_rx + radio_metric->cu_other);
				}
#endif
				wapp_send_wapp_qry_rsp(pAd, &event);
			}
		}
	}

	return 0;
}
VOID Update_Mib_Bucket_for_map(RTMP_ADAPTER *pAd)
{
	UCHAR   j = 0;

	if (pAd->OneSecMibBucket.Enabled == TRUE) {
		pAd->OneSecMibBucket.ChannelBusyTimeCcaNavTx = 0;
		pAd->OneSecMibBucket.ChannelBusyTime = 0;
		pAd->OneSecMibBucket.OBSSAirtime = 0;
		pAd->OneSecMibBucket.MyTxAirtime = 0;
		pAd->OneSecMibBucket.MyRxAirtime = 0;
		pAd->OneSecMibBucket.EDCCAtime = 0;
		pAd->OneSecMibBucket.MdrdyCount = 0;
		pAd->OneSecMibBucket.PdCount = 0;
		pAd->OneSecMibBucket.TxDataAirtime = 0;
		pAd->OneSecMibBucket.RxDataAirtime = 0;
		pAd->OneSecMibBucket.ObssDataAirtime = 0;

		for (j = 0 ; j < 2 ; j++) {
			pAd->OneSecMibBucket.ChannelBusyTimeCcaNavTx += pAd->MsMibBucket.ChannelBusyTimeCcaNavTx[j];
			pAd->OneSecMibBucket.ChannelBusyTime += pAd->MsMibBucket.ChannelBusyTime[j];
			pAd->OneSecMibBucket.OBSSAirtime += pAd->MsMibBucket.OBSSAirtime[j];
			pAd->OneSecMibBucket.MyTxAirtime += pAd->MsMibBucket.MyTxAirtime[j];
			pAd->OneSecMibBucket.MyRxAirtime += pAd->MsMibBucket.MyRxAirtime[j];
			pAd->OneSecMibBucket.EDCCAtime += pAd->MsMibBucket.EDCCAtime[j];
			pAd->OneSecMibBucket.MdrdyCount += pAd->MsMibBucket.MdrdyCount[j];
			pAd->OneSecMibBucket.PdCount += pAd->MsMibBucket.PdCount[j];
		pAd->MsMibBucket.TxDataAirtime[j] = 0;
		pAd->MsMibBucket.RxDataAirtime[j] = 0;
		pAd->MsMibBucket.ObssDataAirtime[j] = 0;
		}
	}
}

#endif

INT wapp_send_ch_util_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	struct wapp_event event;
	event.event_id = WAPP_CH_UTIL_QUERY_RSP;
	event.ifindex = req->data.ifindex;
	event.data.ch_util = get_channel_utilization(pAd, event.ifindex);
	wapp_send_wapp_qry_rsp(pAd, &event);
	return 0;
}

INT wapp_send_ap_config_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;
	struct wapp_event event;
	wdev_ap_config *ap_conf;

	event.event_id = WAPP_AP_CONFIG_RSP;
	event.ifindex = req->data.ifindex;
	ap_conf = &event.data.ap_conf;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == event.ifindex)) {
#ifdef CONFIG_MAP_SUPPORT /* TODO: move to MAP */
				ap_conf->sta_report_on_cop = wdev->MAPCfg.bUnAssocStaLinkMetricRptOpBss;
				ap_conf->sta_report_not_cop = wdev->MAPCfg.bUnAssocStaLinkMetricRptNonOpBss;
				ap_conf->rssi_steer = wdev->MAPCfg.bAgentInitRssiSteering;
#endif /* CONFIG_MAP_SUPPORT */
				wapp_send_wapp_qry_rsp(pAd, &event);

			}
		}
	}
	return 0;
}
#ifdef WPS_UNCONFIG_FEATURE_SUPPORT
INT wapp_send_wps_config(
	struct _RTMP_ADAPTER *ad,
	struct wifi_dev *wdev,
	IN  PWSC_CREDENTIAL pCredential)
{

	struct wapp_event event;
	u8 index = 0;

	if (wdev == NULL) {
		MTWF_DBG(ad, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
		"Error :: Wapp_Send_wps_config --> wdev NULL");
		return 0;
	}
	if (wdev->if_dev) {
		event.event_id = WAPP_CONFIG_WPS_EVENT;
		event.ifindex = wdev->if_dev->ifindex;

		NdisZeroMemory(event.data.wps_conf_info.SSID, MAX_LEN_OF_SSID);
		if (pCredential->SSID.SsidLength <= ARRAY_SIZE(event.data.wps_conf_info.SSID))
			NdisMoveMemory(event.data.wps_conf_info.SSID, pCredential->SSID.Ssid, pCredential->SSID.SsidLength);
		else
			MTWF_DBG(ad, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				"Not have enough buffer size for event.data.wps_conf_info.SSID!\n");

		NdisMoveMemory(event.data.wps_conf_info.MacAddr, pCredential->MacAddr, MAC_ADDR_LEN);

		RTMPZeroMemory(event.data.wps_conf_info.Key, 64);
		RTMPMoveMemory(event.data.wps_conf_info.Key, pCredential->Key, pCredential->KeyLength);

		event.data.wps_conf_info.KeyLength = pCredential->KeyLength;
		event.data.wps_conf_info.AuthType = pCredential->AuthType;
		event.data.wps_conf_info.EncrType = pCredential->EncrType;
		event.data.wps_conf_info.bss_role = pCredential->bss_role;
		event.data.wps_conf_info.channel  = wdev->channel;

		index = wdev->wdev_idx;
		event.data.wps_conf_info.index = index;
		MTWF_DBG(ad, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"SSID = %s, psk = %s, len = %d",
			event.data.wps_conf_info.SSID, event.data.wps_conf_info.Key,
			event.data.wps_conf_info.KeyLength);
		MTWF_DBG(ad, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"Auth = %d, EncyType = %d, Bss_role = %d",
			event.data.wps_conf_info.AuthType, event.data.wps_conf_info.EncrType,
			event.data.wps_conf_info.bss_role);
		MTWF_DBG(ad, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"MAC :: 02x%x:02x%x:02x%x:02x%x:02x%x:02x%x",
			event.data.wps_conf_info.MacAddr[0], event.data.wps_conf_info.MacAddr[1],
			event.data.wps_conf_info.MacAddr[2], event.data.wps_conf_info.MacAddr[3],
			event.data.wps_conf_info.MacAddr[4], event.data.wps_conf_info.MacAddr[5]);
		MTWF_DBG(ad, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"channel == %d, index = %d\n", wdev->channel, index);

		wapp_send_wapp_qry_rsp(ad, &event);
	}
	return 0;
}
#endif

INT wapp_send_bss_state_change(
	struct _RTMP_ADAPTER *pAd,
	struct wifi_dev *wdev,
	UINT8 bss_state)
{
	struct wapp_event event;

	if (wdev->if_dev) {
		event.event_id = WAPP_BSS_STATE_CHANGE;
		event.ifindex = wdev->if_dev->ifindex;
		event.data.bss_state_info.interface_index = event.ifindex;
		event.data.bss_state_info.bss_state = bss_state;
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}

INT wapp_send_ch_change_rsp(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev,
	UINT8 ControlChannel)
{
	struct wapp_event event;

	if (wdev->if_dev) {
		event.event_id = WAPP_CH_CHANGE;
		event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		event.data.ch_change_info.interface_index = event.ifindex;
		event.data.ch_change_info.new_ch = (u_int8_t)ControlChannel;
		event.data.ch_change_info.op_class =
			get_regulatory_class(pAd, ControlChannel, wdev->PhyMode, wdev);
		event.data.eht_ch_change = wdev->eht_ch_change;
		wdev->eht_ch_change = 0;
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}

INT wapp_send_ssid_change_rsp(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev,
	u8 *ssid, UCHAR ssid_len)
{
	struct wapp_event event;

	if (wdev->if_dev) {
		event.event_id = WAPP_SSID_CHANGE;
		event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		event.data.SSID.SsidLength = ssid_len;
		os_move_mem(event.data.SSID.Ssid, ssid, ssid_len);
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}
#ifdef MAP_R3
INT wapp_send_ch_change_rsp_map_r3(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev,
	UINT8 ControlChannel)
{
	struct wapp_event event;

	if (wdev->if_dev) {
		event.event_id = WAPP_CH_CHANGE_R3;
		event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		event.data.ch_change_info.interface_index = event.ifindex;
		event.data.ch_change_info.new_ch = (u_int8_t)ControlChannel;
		event.data.ch_change_info.op_class = get_regulatory_class(pAd, ControlChannel, wdev->PhyMode, wdev);
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}
#endif
/*
*	INT wapp_send_txpower_change_rsp(
*	PRTMP_ADAPTER pAd,
*	)
*	{
*		struct wapp_event event;
*		event.event_id = WAPP_TX_POWER_CHANGE;
*		event.ifindex = ;
*		event.data.txpwr_change_info.interface_index =event.ifindex;
*		event.data.txpwr_change_info.new_tx_pwr =;
*		wext_send_wapp_qry_rsp(pAd->net_dev, &event);
*		return 0;
*	}
*/

#ifdef CONFIG_STA_SUPPORT
INT wapp_send_apcli_association_change(
	UINT8 apcli_assoc_state,
	PRTMP_ADAPTER pAd,
	PSTA_ADMIN_CONFIG pApCliEntry)
{
	struct wapp_event event;

	if (pApCliEntry->wdev.if_dev && (!pApCliEntry->wdev.bh_ready_sent
	    || apcli_assoc_state == WAPP_APCLI_DISASSOCIATED)) {
		event.event_id = WAPP_APCLI_ASSOC_STATE_CHANGE;
		event.ifindex = pApCliEntry->wdev.if_dev->ifindex;
		event.data.apcli_association_info.interface_index = event.ifindex;
		event.data.apcli_association_info.apcli_assoc_state = apcli_assoc_state;
#ifdef CONFIG_MAP_SUPPORT
		if (IS_MAP_ENABLE(pAd))
			event.data.apcli_association_info.PeerMAPEnable = pApCliEntry->PeerMAPEnable;
#endif
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}
#endif /* CONFIG_STA_SUPPORT */

#ifdef CONVERTER_MODE_SWITCH_SUPPORT
INT wapp_send_apcli_association_change_vendor10(
	UINT8 apcli_assoc_state,
	PRTMP_ADAPTER pAd,
	PSTA_ADMIN_CONFIG pApCliEntry)
{
	struct wapp_event event;

	event.event_id = WAPP_APCLI_ASSOC_STATE_CHANGE_VENDOR10;
	event.ifindex = pApCliEntry->wdev.if_dev->ifindex;
	event.data.apcli_association_info.interface_index = event.ifindex;
	event.data.apcli_association_info.apcli_assoc_state = apcli_assoc_state;
	wapp_send_wapp_qry_rsp(pAd, &event);
	return 0;
}
#endif /* CONVERTER_MODE_SWITCH_SUPPORT */

INT wapp_send_bssload_crossing(
	struct _RTMP_ADAPTER *pAd,
	struct wifi_dev *wdev,
	UCHAR bssload_high_thrd,
	UCHAR bssload_low_thrd,
	UCHAR bssload)
{
	struct wapp_event event;

	if (wdev->if_dev) {
		event.event_id = WAPP_BSSLOAD_CROSSING;
		event.ifindex = wdev->if_dev->ifindex;
		event.data.bssload_crossing_info.interface_index = event.ifindex;
		event.data.bssload_crossing_info.bssload = bssload;
		event.data.bssload_crossing_info.bssload_high_thrd = bssload_high_thrd;
		event.data.bssload_crossing_info.bssload_low_thrd = bssload_low_thrd;
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}

INT wapp_send_sta_connect_rejected(
	struct _RTMP_ADAPTER *pAd,
	struct wifi_dev *wdev,
	UCHAR *sta_mac_addr,
	UCHAR *bssid,
	UINT8 connect_stage,
	UINT16 reason,
	USHORT status_code,
	USHORT reason_code)
{
	struct wapp_event event;

	if (wdev && wdev->if_dev && bssid && sta_mac_addr) {
		event.event_id = WAPP_STA_CNNCT_REJ;
		event.ifindex = wdev->if_dev->ifindex;
		event.data.sta_cnnct_rej_info.interface_index = event.ifindex;
		os_move_mem(event.data.sta_cnnct_rej_info.bssid, bssid, MAC_ADDR_LEN);
		os_move_mem(event.data.sta_cnnct_rej_info.sta_mac, sta_mac_addr, MAC_ADDR_LEN);
		event.data.sta_cnnct_rej_info.cnnct_fail.connect_stage = connect_stage;
		event.data.sta_cnnct_rej_info.cnnct_fail.reason = reason;
#ifdef MAP_R2
		event.data.sta_cnnct_rej_info.assoc_status_code = status_code;
		event.data.sta_cnnct_rej_info.assoc_reason_code = reason_code;
#endif
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return TRUE;
}

INT wapp_bss_start(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i, j;
	struct wifi_dev *wdev, *wdev_active;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)) {
				for (j = 0; j < WDEV_NUM_MAX; j++) {
					wdev_active = pAd->wdev_list[j];
					if (wdev_active && HcIsRadioAcq(wdev_active) &&
						(HcGetBandByWdev(wdev) == HcGetBandByWdev(wdev_active))) {
						wdev->channel = wdev_active->channel;
						break;
					}
				}

				if (wdev->func_idx < 0 || wdev->func_idx >= MAX_BEACON_NUM) {
					MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR, "%s: failed\n", __func__);
					return 0;
				}

#ifdef CONFIG_MAP_SUPPORT
				if (pAd->ApCfg.MBSSID[wdev->func_idx].is_bss_stop_by_map)
					pAd->ApCfg.MBSSID[wdev->func_idx].is_bss_stop_by_map = FALSE;
#endif
				APStartUpByBss(pAd, &pAd->ApCfg.MBSSID[wdev->func_idx]);
				break;
			}
		}
	}
	return 0;
}

INT wapp_bss_stop(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;
#ifdef CONFIG_MAP_SUPPORT
	BSS_STRUCT *pMbss;
#endif
	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)) {
				MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_DEBUG,
					"req->data.ifindex = %d\n", req->data.ifindex);

				if (wdev->func_idx < 0 || wdev->func_idx >= MAX_BEACON_NUM) {
					MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR, "%s: failed\n", __func__);
					return 0;
				}

#ifdef CONFIG_MAP_SUPPORT
				if (IS_MAP_ENABLE(pAd)) {

					pMbss = &pAd->ApCfg.MBSSID[wdev->func_idx];
					pMbss->wdev.avoid_apcli_linkdown = TRUE;
				}
#endif
#ifdef CONFIG_MAP_SUPPORT
				pAd->ApCfg.MBSSID[wdev->func_idx].is_bss_stop_by_map = TRUE;
#endif
				APStopByBss(pAd, &pAd->ApCfg.MBSSID[wdev->func_idx]);
#ifdef CONFIG_MAP_SUPPORT
				if (IS_MAP_ENABLE(pAd))
					pMbss->wdev.avoid_apcli_linkdown = FALSE;
#endif
			}
		}
	}
	return 0;
}

INT wapp_bss_load_thrd_set(
	struct _RTMP_ADAPTER *ad,
	struct wapp_req *req)
{
	int i = 0;
	UINT8 high_thrd;
	UINT8 low_thrd;
	struct wifi_dev *wdev;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (ad->wdev_list[i] != NULL) {
			wdev = ad->wdev_list[i];
			if (wdev->if_dev && wdev->if_dev->ifindex == req->data.ifindex) {
				high_thrd = req->data.bssload_thrd.high_bssload_thrd;
				low_thrd = req->data.bssload_thrd.low_bssload_thrd;
				ad->bss_load_info.high_thrd = high_thrd;
				ad->bss_load_info.low_thrd = low_thrd;
				return 0;
			}
		}
	}

	MTWF_DBG(ad, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
						"wdev not found\n");
	return 1;
}

/*
 *==========================================================================
 *	Description:
 *		Periodically check the BSS load. Once the load status changes into an abnormal situation (above the
 *		high threshold/below the low threshold), the WAPP event will be sent. Notice that the event won't
 *		be sent if the load status stays in the same abnormal situation.
 *==========================================================================
 */
VOID wapp_bss_load_check(
	struct _RTMP_ADAPTER *ad)
{
	int i;
	UINT8 new_load;
	UINT8 new_status;
	UINT8 current_status;
	UINT8 high_thrd;
	UINT8 low_thrd;
	ULONG up_time;
	struct wifi_dev *wdev = NULL;
	BSS_STRUCT *pMbss = NULL;

	NdisGetSystemUpTime(&up_time);
#ifdef AP_QLOAD_SUPPORT
	QBSS_LoadUpdate(ad, up_time);
#endif /* AP_QLOAD_SUPPORT */
	for (i = 0; i < ad->ApCfg.BssidNum; i++) {
		pMbss = &ad->ApCfg.MBSSID[i];
		if (pMbss->wdev.DevInfo.WdevActive)  {
			wdev = &pMbss->wdev;
			if (wdev->if_dev == NULL)
				continue;

			high_thrd = ad->bss_load_info.high_thrd;
			low_thrd = ad->bss_load_info.low_thrd;
			current_status = ad->bss_load_info.current_status;

			new_load = get_channel_utilization(ad, wdev->if_dev->ifindex);

			if (new_load >= high_thrd)
				new_status = WAPP_BSSLOAD_HIGH;
			else if (new_load <= low_thrd)
				new_status = WAPP_BSSLOAD_LOW;
			else
				new_status = WAPP_BSSLOAD_NORMAL;

			/*The status changes & the new status is an abnormal situation*/
			if (new_status != current_status && new_status != WAPP_BSSLOAD_NORMAL)
				wapp_send_bssload_crossing(ad, wdev, high_thrd, low_thrd, new_load);

			ad->bss_load_info.current_load = new_load;
			ad->bss_load_info.current_status = new_status;
		}
	}
}

INT wapp_config_ap_setting(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)) {
#ifdef CONFIG_MAP_SUPPORT
				wdev->MAPCfg.bUnAssocStaLinkMetricRptOpBss = req->data.ap_conf.sta_report_on_cop;
				wdev->MAPCfg.bUnAssocStaLinkMetricRptNonOpBss = req->data.ap_conf.sta_report_not_cop;
				wdev->MAPCfg.bAgentInitRssiSteering = req->data.ap_conf.rssi_steer;
#endif
			}
		}
	}
	return 0;
}

/* set Tx Power Perventage */
INT wapp_set_tx_power_prctg(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;
	UINT8 prctg = (UINT8) req->data.value;
	UCHAR Band_Idx = 0;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)) {
				Band_Idx = HcGetBandByWdev(wdev);
				MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
					"ifindex = %u, prctg = %u\n", req->data.ifindex, prctg);
				if (prctg > 0) {
					TxPowerPercentCtrl(pAd, TRUE, Band_Idx);
					TxPowerDropCtrl(pAd, prctg, Band_Idx);
					chip_set_mgmt_pkt_txpwr(pAd, wdev, prctg);
				} else {
					TxPowerPercentCtrl(pAd, FALSE, Band_Idx);
				}
			}
		}
	}
	return 0;
}

INT wapp_set_steer_policy(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)) {
#ifdef CONFIG_MAP_SUPPORT
				pAd->ApCfg.SteerPolicy.steer_policy = req->data.str_policy.steer_policy;
				pAd->ApCfg.SteerPolicy.cu_thr = req->data.str_policy.cu_thr;
				pAd->ApCfg.SteerPolicy.rcpi_thr = req->data.str_policy.rcpi_thr;
#endif
			}
		}
	}
	return 0;
}

INT wapp_send_bssload_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	INT i;
	struct wifi_dev *wdev;
	struct wapp_event event;

	event.event_id = WAPP_BSSLOAD_RSP;
	event.ifindex = req->data.ifindex;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == event.ifindex)) {
				event.data.bssload_info.sta_cnt = MacTableAssocStaNumGet(pAd);
				event.data.bssload_info.ch_util = get_channel_utilization(pAd, event.ifindex);
				event.data.bssload_info.AvalAdmCap = (0x7a12); /* 0x7a12 * 32us = 1 second */
				wapp_send_wapp_qry_rsp(pAd, &event);
			}
		}
	}

	return 0;
}

INT wapp_send_he_cap_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{

	return 0;
}

INT wapp_send_apcli_rssi_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	struct wapp_event event;
	PMAC_TABLE_ENTRY mac_entry;
	wapp_apcli_association_info *apcli_info;

	event.event_id = WAPP_APCLI_RSSI_RSP;
	event.ifindex = req->data.ifindex;
	apcli_info = &event.data.apcli_association_info;

	mac_entry = MacTableLookup(pAd, req->data.mac_addr);
	if (mac_entry && mac_entry->wdev->if_dev && IS_ENTRY_PEER_AP(mac_entry)) {
		if (req->data.ifindex == RtmpOsGetNetIfIndex(mac_entry->wdev->if_dev)) {
			apcli_info->rssi = RTMPAvgRssi(pAd, &mac_entry->RssiSample);
			wapp_send_wapp_qry_rsp(pAd, &event);
		}
	}

	return 0;
}

INT wapp_send_sta_rssi_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	struct wapp_event event;
	PMAC_TABLE_ENTRY mac_entry;
	wapp_client_info *cli_info;

	event.event_id = WAPP_STA_RSSI_RSP;
	event.ifindex = req->data.ifindex;
	cli_info = &event.data.cli_info;

	mac_entry = MacTableLookup(pAd, req->data.mac_addr);
	if (mac_entry && mac_entry->wdev->if_dev && IS_ENTRY_CLIENT(mac_entry)) {
		if (req->data.ifindex == RtmpOsGetNetIfIndex(mac_entry->wdev->if_dev)) {
			COPY_MAC_ADDR(cli_info->mac_addr, mac_entry->Addr);
			cli_info->uplink_rssi = RTMPAvgRssi(pAd, &mac_entry->RssiSample);
			wapp_send_wapp_qry_rsp(pAd, &event);
		}
	}

	return 0;
}

INT wapp_send_cosr_sta_rssi_query_rsp(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
	struct wapp_event event;
	PMAC_TABLE_ENTRY mac_entry;
	wapp_client_info *cli_info;

	event.event_id = WAPP_COSR_STA_RSSI_RSP;
	event.ifindex = req->data.ifindex;
	cli_info = &event.data.cli_info;

	mac_entry = MacTableLookup(pAd, req->data.mac_addr);
	if (mac_entry && mac_entry->wdev->if_dev && IS_ENTRY_CLIENT(mac_entry)) {
		if (req->data.ifindex == RtmpOsGetNetIfIndex(mac_entry->wdev->if_dev)) {
			COPY_MAC_ADDR(cli_info->mac_addr, mac_entry->Addr);
			cli_info->uplink_rssi = RTMPAvgRssi(pAd, &mac_entry->RssiSample);
			wapp_send_wapp_qry_rsp(pAd, &event);
		}
	}

	return 0;
}

/* set SRG Bitmap  */
INT wapp_set_srg_bitmap(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
#ifdef MAP_R3
	INT i;
	struct wifi_dev *wdev;
	UCHAR Band_Idx = 0;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)) {
				Band_Idx = HcGetBandByWdev(wdev);
				MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
					"ifindex = %u\n", req->data.ifindex);
				SrMeshSrgBitMapControl(pAd, TRUE, (PUINT_8)&req->data.bm_info);
			}
		}
	}
#endif
	return 0;
}

/* Update Topology  */
INT wapp_srg_topology_update(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
#ifdef MAP_R3
	INT i;
	struct wifi_dev *wdev;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)) {
				MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
					"ifindex = %u Band:%u\n", req->data.ifindex, req->data.band_index);
				SrMeshTopologyUpdate(pAd, (PUINT_8)&req->data.topology_update, req->data.band_index);
			}
		}
	}
#endif
	return 0;
}

/* set SRG Uplink Traffic Status  */
INT wapp_set_srg_uplink_traffic_status(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
#ifdef MAP_R3
	INT i;
	struct wifi_dev *wdev;
	UINT8 status = (UINT8) req->data.value;
	UCHAR Band_Idx = 0;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)) {
				Band_Idx = HcGetBandByWdev(wdev);
				MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
					"ifindex = %u, status = %u\n", req->data.ifindex, status);
				SrSetUplinkTrafficStatus(pAd, Band_Idx, status);
			}
		}
	}
#endif
	return 0;
}

/* set SRG STA Mode Report  */
INT wapp_send_sta_mode_rpt_cmd(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
#ifdef CFG_SUPPORT_FALCON_SR
	INT i;
	struct wifi_dev *wdev;
	UINT8 status = (UINT8) req->data.value;
	UCHAR Band_Idx = 0;

	for (i = 0; i < WDEV_NUM_MAX; i++) {
		if (pAd->wdev_list[i] != NULL) {
			wdev = pAd->wdev_list[i];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex)) {
				Band_Idx = hc_get_hw_band_idx(pAd);
				MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
					"ifindex = %u, status = %u\n", req->data.ifindex, status);
				SrSetMeshRemoteStaModeRpt(pAd, Band_Idx, status);
			}
		}
	}
#endif /* CFG_SUPPORT_FALCON_SR */
	return 0;
}

/* get SR Support Mode Rep  */
INT wapp_send_sr_support_mode_query_rsp(
	PRTMP_ADAPTER pAd, UINT32 value)
{
#ifdef CFG_SUPPORT_FALCON_SR
	struct wapp_event event;

	event.event_id = WAPP_SR_SUPPORT_MODE_RSP;
	event.ifindex = pAd->CommonCfg.SRmode_req_ifindex;
	event.data.sr_support_mode = value;

	MTWF_DBG(pAd, DBG_CAT_CFG, CATCFG_SR, DBG_LVL_INFO,
		"[%s] support mode = %d, req_ifindex = %d\n",
		__func__, event.data.sr_support_mode, event.ifindex);

	wapp_send_wapp_qry_rsp(pAd, &event);
#endif /* CFG_SUPPORT_FALCON_SR */
	return 0;
}

INT wapp_handle_sr_support_mode_query_req(
	PRTMP_ADAPTER pAd,
	struct wapp_req *req)
{
#ifdef CFG_SUPPORT_FALCON_SR
	NDIS_STATUS Status = NDIS_STATUS_SUCCESS;
	POS_COOKIE pObj = (POS_COOKIE) pAd->OS_Cookie;
	struct wifi_dev *wdev =
	    get_wdev_by_ioctl_idx_and_iftype(pAd, pObj->ioctl_if, pObj->ioctl_if_type);
	UINT_8 u1DbdcIdx = BAND0;
	UINT_8 isSet = 0;
	UINT_8 u1CmdSubId = UNI_CMD_SR_CFG_SR_SUPPORT_MODE;
	UINT_32 u4Value = 0;

	if (wdev != NULL)
		u1DbdcIdx = HcGetBandByWdev(wdev);
	else
		return NDIS_STATUS_FAILURE;

	pAd->CommonCfg.SRmode_req_ifindex = req->data.ifindex;
	MTWF_DBG(pAd, DBG_CAT_CFG, CATCFG_SR, DBG_LVL_NOTICE,
		"[%s] req ifindex = %d\n", __func__, pAd->CommonCfg.SRmode_req_ifindex);
#ifdef WIFI_UNIFIED_COMMAND
	Status = UniSrCmd(pAd, u1CmdSubId, u1DbdcIdx, u4Value, isSet);
	if (Status != NDIS_STATUS_SUCCESS)
		MTWF_DBG(pAd, DBG_CAT_CFG, CATCFG_SR, DBG_LVL_ERROR,
			"[%s] status = %d\n", __func__, Status);
	return Status;
#else
	MTWF_DBG(pAd, DBG_CAT_CFG, CATCFG_SR, DBG_LVL_ERROR,
		"not support ShowSrCfgSrSupportMode cmd\n");
	return NDIS_STATUS_FAILURE;
#endif
#else
	return 0;
#endif /* CFG_SUPPORT_FALCON_SR */
}

#ifdef WSC_AP_SUPPORT
INT wapp_send_wsc_scan_complete_notification(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev)
{
	struct wapp_event event;
	WSC_CTRL *pWscControl = &wdev->WscControl;

	if (wdev->if_dev) {
		event.len = 0;
		event.event_id = WAPP_WSC_SCAN_COMP_NOTIF;
		event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		event.data.wsc_scan_info.bss_count =
			pWscControl->WscPBCBssCount;
		if (pWscControl->WscPBCBssCount == 1) {
			NdisCopyMemory(event.data.wsc_scan_info.Uuid,
				pWscControl->WscPeerUuid, sizeof(pWscControl->WscPeerUuid));
		}
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}
#endif /* WSC_AP_SUPPORT */

#ifdef WSC_INCLUDED
INT wapp_send_wsc_eapol_start_notification(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev)
{
	struct wapp_event event;

	if (wdev->if_dev) {
		event.len = 0;
		event.event_id = WAPP_WSC_EAPOL_START_NOTIF;
		event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}

INT wapp_send_wsc_eapol_complete_notif(
	PRTMP_ADAPTER pAd,
	PWSC_CTRL pWscControl)
{
	struct wapp_event event;
	struct wapp_bhsta_info *bsta_info = &event.data.bhsta_info;
	struct wifi_dev *wdev = (struct wifi_dev *)pWscControl->wdev;

	if (wdev->if_dev) {
		event.len = 0;
		event.event_id = WAPP_WSC_EAPOL_COMPLETE_NOTIF;
		event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		bsta_info->peer_map_enable = 0;

		if (IS_MAP_ENABLE(pAd) &&
			(pWscControl->RegData.PeerInfo.map_DevPeerRole & BIT(MAP_ROLE_BACKHAUL_STA))) {
			bsta_info->peer_map_enable = 1;
		}

		COPY_MAC_ADDR(bsta_info->connected_bssid, wdev->bssid);
		COPY_MAC_ADDR(bsta_info->mac_addr, pWscControl->EntryAddr);
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}
#endif /* WSC_INCLUDED */

#ifdef CONFIG_MAP_SUPPORT
INT wapp_send_scan_complete_notification(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev)
{
	struct wapp_event event;

	if (wdev->if_dev) {
		event.len = 0;
		event.event_id = WAPP_SCAN_COMPLETE_NOTIF;
		event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}
#endif /* CONFIG_MAP_SUPPORT */

#ifdef CONFIG_CPE_SUPPORT
INT lppe_send_scan_complete_notification(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev)
{
	struct wapp_event event;
	UINT buflen = sizeof(struct wapp_event);

	if (wdev->if_dev) {
		event.len = 0;
		event.event_id = LPPE_SCAN_COMPLETE_NOTIF;
		event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		event.len = buflen - sizeof(event.len) - sizeof(event.event_id);
		NdisCopyMemory(event.data.ifname, RtmpOsGetNetDevName(wdev->if_dev), IFNAMSIZ);

		RtmpOSWrielessEventSend(pAd->net_dev, RT_WLAN_EVENT_CUSTOM,
			OID_LPPE_EVENT, NULL, (PUCHAR)&event, sizeof(struct wapp_event));
	}
	return 0;
}
#endif

#ifdef A4_CONN
/* client disaccos */
INT wapp_send_a4_entry_missing(
	PRTMP_ADAPTER pAd,
	UINT32 ifindex,
	UCHAR *ip)
{
	struct wapp_event event;
	UCHAR *a4_missing_entry_ip;

	event.event_id = WAPP_A4_ENTRY_MISSING_NOTIF;
	event.ifindex = ifindex;
	a4_missing_entry_ip = (UCHAR *)&event.data.a4_missing_entry_ip;

	NdisCopyMemory(a4_missing_entry_ip, ip, 4);
	wapp_send_wapp_qry_rsp(pAd, &event);

	return 0;
}
#endif
/* client disaccos */
INT wapp_send_radar_detect_notif(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev,
	unsigned char channel,
	unsigned char bw,
	unsigned char ch_status
	)
{
	struct wapp_event event;

	if (wdev->if_dev) {
		event.event_id = WAPP_RADAR_DETECT_NOTIF;
		event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
		event.data.radar_notif.channel = channel;
		event.data.radar_notif.status = ch_status;
		event.data.radar_notif.bw = bw;
		wapp_send_wapp_qry_rsp(pAd, &event);
	}
	return 0;
}

#ifdef WIFI_MD_COEX_SUPPORT
INT wapp_send_lte_safe_chn_event(
	PRTMP_ADAPTER pAd, UINT64 *safe_chn_bitmask)
{
	struct wapp_event event;

	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"safe_chn_bitmask:%llu-%llu-%llu\n", safe_chn_bitmask[0],
		safe_chn_bitmask[1], safe_chn_bitmask[2]);

	event.event_id = WAPP_UNSAFE_CHANNEL_EVENT;
	NdisCopyMemory(event.data.unsafe_ch_notif.ch_bitmap, safe_chn_bitmask,
		sizeof(UINT64) * 3);
	wapp_send_wapp_qry_rsp(pAd, &event);
	return 0;
}

INT wapp_send_band_status_event(
	PRTMP_ADAPTER pAd, struct wifi_dev *wdev, BOOLEAN status)
{
	struct wapp_event event;

	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"update band status[%d]", status);
	event.event_id = WAPP_BAND_STATUS_CHANGE_EVENT;
	event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
	event.data.band_status.status = status;
	wapp_send_wapp_qry_rsp(pAd, &event);
	return 0;
}
#endif

#ifdef CONFIG_MAP_SUPPORT
#ifdef MAP_R3
INT wapp_send_trigger_reconfig(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev)
{
	struct wapp_event event;

	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO, "\n");
	event.event_id = WAPP_R3_RECONFIG_TRIGGER;
	event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
	wapp_send_wapp_qry_rsp(pAd, &event);
	return 0;
}
#endif
#endif

#if defined(CONFIG_MAP_SUPPORT) && defined(MAP_R3)
INT wapp_send_uplink_traffic_event(
	PRTMP_ADAPTER pAd, struct wifi_dev *wdev, UINT8 u1UlStatus)
{

	struct wapp_event event;

	event.event_id = WAPP_UPLINK_TRAFFIC_EVENT;
	event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
	event.data.mesh_sr_info.ul_traffic_status = u1UlStatus;

	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"uplink traffic event, ifindex:%u status:%u\n", event.ifindex, u1UlStatus);

	wapp_send_wapp_qry_rsp(pAd, &event);
	return 0;
}

INT wapp_send_sr_self_srg_bm_event(
	IN PRTMP_ADAPTER pAd, IN struct wifi_dev *wdev, IN PUINT8 prSrgBitmap)
{
	struct wapp_event event;
	struct _BSS_INFO_ARGUMENT_T *bssinfo = &wdev->bss_info_argument;
	struct bss_color_ctrl *bss_color = &bssinfo->bss_color;

	event.event_id = WAPP_SELF_SRG_BITMAP_EVENT;
	event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
	event.data.mesh_sr_info.bss_color = bss_color->color;
	NdisCopyMemory(&(event.data.mesh_sr_info.bm_info), prSrgBitmap,
		sizeof(struct wapp_srg_bitmap));

	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"ifindex:%u bss color %d Color:[63_32][%u]-[31_0][%u] PBssid::[63_32][%u]-[31_0][%u]\n",
		event.ifindex, event.data.mesh_sr_info.bss_color,
		event.data.mesh_sr_info.bm_info.color_63_32,
		event.data.mesh_sr_info.bm_info.color_31_0,
		event.data.mesh_sr_info.bm_info.bssid_63_32,
		event.data.mesh_sr_info.bm_info.bssid_31_0);

	wapp_send_wapp_qry_rsp(pAd, &event);
	return 0;
}

INT wapp_send_sta_mode_rpt_event(
	PRTMP_ADAPTER pAd, struct wifi_dev *wdev, BOOLEAN IsStaAllHe)
{
	struct wapp_event event;

	event.event_id = WAPP_STA_MODE_RPT_EVENT;
	event.ifindex = RtmpOsGetNetIfIndex(wdev->if_dev);
	event.data.mesh_sr_info.ul_traffic_status = IsStaAllHe;

	MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
		"STA Mode Rpt event, ifindex:%u IsStaAllHe:%u\n", event.ifindex, IsStaAllHe);

	wapp_send_wapp_qry_rsp(pAd, &event);
	return 0;
}
#endif /* defined(CONFIG_MAP_SUPPORT) && defined(MAP_R3) */

VOID RTMPIoctlGetScanResults(
	IN	PRTMP_ADAPTER	pAdapter, struct wapp_req *req)
{
	struct wapp_event event;
	INT last_bss_cnt = 0;
	INT		i = 0;
	/*INT			WaitCnt = 0;*/
	UINT32		bss_start_idx;
	BSS_ENTRY *bss;
	struct scan_bss_info *pBss;
	wdev_ht_cap *ht_cap;
	wdev_vht_cap *vht_cap;
	wdev_he_cap *he_cap;
	char *mcsptr = NULL;
#ifdef MTK_MLO_MAP_SUPPORT
	INT             j = 0;
	char *mcsptr_sta = NULL;
#endif
	UINT8 he_ch_width = HE_BW_80;
	UINT8 txrx_stream;
	UINT16	l;
	INT custom_event_length;
	UINT32 TotalLen;
	INT count = 0, max_bss;
	BSS_TABLE *ScanTab = NULL;
	struct wifi_dev *wdev = NULL;
	INT he_op_bw = 0;


	for (l = 0; l < WDEV_NUM_MAX; l++) {
		if (pAdapter->wdev_list[l] != NULL) {
			wdev = pAdapter->wdev_list[l];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex))
				break;
		}
	}

	if (wdev == NULL)
		return;

	ScanTab = get_scan_tab_by_wdev(pAdapter, wdev);
#ifndef IWEVCUSTOM_PAYLOD_MAX_LEN
#define IWEVCUSTOM_PAYLOD_MAX_LEN 220
#endif

#ifdef MTK_MLO_MAP_SUPPORT
#ifdef MAP_R6
#define IWEVCUSTOM_PAYLOD_MAX_LEN_MAP 415
#else
#define IWEVCUSTOM_PAYLOD_MAX_LEN_MAP 400
#endif
#endif

#ifdef MTK_MLO_MAP_SUPPORT
	custom_event_length = IWEVCUSTOM_PAYLOD_MAX_LEN_MAP;
#else
	custom_event_length = IWEVCUSTOM_PAYLOD_MAX_LEN;
#endif

	MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_DEBUG, "RTMPIoctlGetSiteSurvey - enter\n");
	/*
	 * At the moment there is a single scan tab across the pAd
	 * that means if scan id or if_index has changed, it doesn't
	 * make sense of continuing the last get scan command.
	 */
	if ((pAdapter->last_scan_req.scan_id != req->data.value) ||
	    (pAdapter->last_scan_req.if_index != req->data.ifindex)) {
		pAdapter->last_scan_req.scan_id = req->data.value;
		pAdapter->last_scan_req.if_index = req->data.ifindex;
		/* Storing the first bss nr in the bs_nr */
		pAdapter->last_scan_req.bss_nr = ScanTab->BssNr;
	} else
		last_bss_cnt = pAdapter->last_scan_req.last_bss_cnt;

	if (ScanTab->BssNr == 0) {
		MTWF_DBG(pAdapter, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
				"no bss present in scan tab\n");
	}
	max_bss = custom_event_length / sizeof(struct scan_bss_info);

	bss_start_idx = last_bss_cnt;

	TotalLen = (sizeof(CHAR) * 5) + ((sizeof(struct scan_bss_info)) * max_bss) + (sizeof(UINT32) * 2);
	if ((max_bss > 0) && (TotalLen > custom_event_length))
		max_bss--;

	if (max_bss == 0) {
		MTWF_DBG(pAdapter, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				"bss size is too big for wireless send event\n");
		return;
	}

	NdisZeroMemory(&event, sizeof(event));
	event.event_id = WAPP_SCAN_RESULT_RSP;
	event.ifindex = req->data.ifindex;

	if (ScanTab->BssNr == 0) {
		/* Send the event as this is possible scenario during in DFS channe */
		goto send_event;
	}

	if (bss_start_idx > (ScanTab->BssNr - 1)) {
		event.data.scan_info.bss_count = 0;
		goto send_event;
	}

	for (i = bss_start_idx; i < ScanTab->BssNr && count < max_bss; i++) {
		bss = &ScanTab->BssEntry[i];
		pBss = &event.data.scan_info.bss;

		ht_cap = &pBss->ht_cap;
		vht_cap = &pBss->vht_cap;
		he_cap = &pBss->he_cap;
		if (bss->Channel == 0) {
			i++;
			MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
					"break from here bss Channel is 0, i %d", i);
			break;
		}
		pBss->Channel = bss->Channel;
		pBss->CentralChannel = bss->CentralChannel;
		pBss->Rssi = bss->Rssi;
		ht_cap->tx_stream = 0; /* TODO */
		ht_cap->rx_stream = 0; /* TODO */
		ht_cap->sgi_20 = bss->HtCapability.HtCapInfo.ShortGIfor20;
		ht_cap->sgi_40 = bss->HtCapability.HtCapInfo.ShortGIfor40;
		ht_cap->ht_40 = bss->AddHtInfo.AddHtInfo.RecomWidth;/*current operating bw*/

		NdisMoveMemory(vht_cap->sup_tx_mcs,
						&bss->vht_cap_ie.mcs_set.tx_mcs_map,
						sizeof(vht_cap->sup_tx_mcs));
		NdisMoveMemory(vht_cap->sup_rx_mcs,
						&bss->vht_cap_ie.mcs_set.rx_mcs_map,
						sizeof(vht_cap->sup_rx_mcs));
		if (bss->vht_cap_ie.mcs_set.rx_mcs_map.mcs_ss4 != VHT_MCS_CAP_NA)
			vht_cap->rx_stream = 4;
		else if (bss->vht_cap_ie.mcs_set.rx_mcs_map.mcs_ss3 != VHT_MCS_CAP_NA)
			vht_cap->rx_stream = 3;
		else if (bss->vht_cap_ie.mcs_set.rx_mcs_map.mcs_ss2 != VHT_MCS_CAP_NA)
			vht_cap->rx_stream = 2;
		else
			vht_cap->rx_stream = 1;

		if (bss->vht_cap_ie.mcs_set.tx_mcs_map.mcs_ss4 != VHT_MCS_CAP_NA)
			vht_cap->tx_stream = 4;
		else if (bss->vht_cap_ie.mcs_set.tx_mcs_map.mcs_ss3 != VHT_MCS_CAP_NA)
			vht_cap->tx_stream = 3;
		else if (bss->vht_cap_ie.mcs_set.tx_mcs_map.mcs_ss2 != VHT_MCS_CAP_NA)
			vht_cap->tx_stream = 2;
		else
			vht_cap->tx_stream = 1;
		vht_cap->sgi_80 = bss->vht_cap_ie.vht_cap.sgi_80M;
		vht_cap->sgi_160 = bss->vht_cap_ie.vht_cap.sgi_160M;
		vht_cap->vht_160 = bss->vht_op_ie.vht_op_info.ch_width;
		/* ch width can be 1 for 80, 160, 80/80 */
		if (bss->vht_op_ie.vht_op_info.ch_width == 1) {
			if (((bss->vht_op_ie.vht_op_info.ccfs_1) - (bss->vht_op_ie.vht_op_info.ccfs_0)) == 8 ||
					((bss->vht_op_ie.vht_op_info.ccfs_1) - (bss->vht_op_ie.vht_op_info.ccfs_0)) == -8)
				vht_cap->vht_160 = 2;
		}
		vht_cap->vht_8080 = 0; /* TODO */
		vht_cap->su_bf = bss->vht_cap_ie.vht_cap.bfee_cap_su;
		vht_cap->mu_bf = bss->vht_cap_ie.vht_cap.bfee_cap_mu;
#ifdef DOT11_HE_AX
		he_ch_width = peer_max_bw_cap(GET_DOT11AX_CH_WIDTH(bss->he_caps.phy_cap.phy_capinfo_1));
		mcsptr = he_cap->he_mcs;
		NdisCopyMemory(mcsptr, &bss->he_caps.txrx_mcs_nss, sizeof(struct he_txrx_mcs_nss));
		if (he_ch_width == HE_BW_160) {
			he_cap->he_160 = 1;
		} else
			he_cap->he_160 = 0;
		he_op_bw = (bss->he6g_opinfo.ctrl & HE_6G_OP_CONTROL_CH_WIDTH_MASK);
		if (he_op_bw == 1)
			ht_cap->ht_40 = 1;
		else if (he_op_bw == 2)
			vht_cap->vht_160 = 1;
		else if (he_op_bw == 3)
			vht_cap->vht_160 = 2;
#endif
		pBss->MinSNR = bss->MinSNR;
		pBss->Privacy = bss->Privacy;
		pBss->SsidLen = bss->SsidLen;
		NdisCopyMemory(pBss->Ssid, bss->Ssid, pBss->SsidLen);
		COPY_MAC_ADDR(pBss->Bssid, bss->Bssid);
		pBss->AuthMode = bss->AuthMode;
#ifdef CONFIG_MAP_SUPPORT
		NdisCopyMemory(&pBss->map_info, &bss->map_info, sizeof(struct map_vendor_ie));
		pBss->map_vendor_ie_found = bss->map_vendor_ie_found;
#ifdef WSC_INCLUDED
		pBss->AuthMode = WscGetAuthType(bss->AKMMap);
		pBss->EncrypType = WscGetEncryType(bss->PairwiseCipher);
#endif /* WSC_INCLUDED */
#ifdef MAP_R2
		pBss->QbssLoad.bValid = bss->QbssLoad.bValid;
		pBss->QbssLoad.StaNum = bss->QbssLoad.StaNum;
		pBss->QbssLoad.ChannelUtilization = bss->QbssLoad.ChannelUtilization;
#endif
#ifdef MAP_6E_SUPPORT
		pBss->rnr_6e.channel = bss->rnr_info.channel;	/* 6E channel to be filled*/
		pBss->rnr_6e.op = bss->rnr_info.op;		/*op class for 6E channel*/
		pBss->rnr_6e.cce_ind = bss->cce_vendor_ie_found;	/* CCE indication on 6G*/
#endif
#ifdef CONFIG_MAP_SUPPORT
		pBss->eht_cap.eht_ch_width = bss->eht_cap.eht_ch_width;
		pBss->eht_cap.ccfs0 = bss->eht_cap.ccfs0;
		pBss->eht_cap.ccfs1 = bss->eht_cap.ccfs1;
		if (PD_CEHCK_MLO_V1_DISABLE(pAdapter->physical_dev)
		    || PD_CEHCK_MLO_V1_1_ENABLE(pAdapter->physical_dev)) {
			pBss->eht_cap.rx_stream = bss->eht_cap.rx_stream;
			pBss->eht_cap.tx_stream = bss->eht_cap.tx_stream;
			/*rx bit 0-3,tx bit 4-7*/
			pBss->eht_cap.rx_stream = pBss->eht_cap.rx_stream & 0x0f;
			pBss->eht_cap.tx_stream = (pBss->eht_cap.tx_stream & 0xf0) >> 4;
		} else {
			if (pBss->eht_cap.eht_ch_width == EHT_BW_20)
				txrx_stream = bss->eht_support_mcs_nss.eht_txrx_mcs_nss_20_only.max_tx_rx_mcs0_7_nss;
			else
				txrx_stream = bss->eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs0_9_nss;
			/*rx bit 0-3,tx bit 4-7*/
			pBss->eht_cap.rx_stream = txrx_stream & 0x0f;
			pBss->eht_cap.tx_stream = (txrx_stream & 0xf0) >> 4;
		}

#if (defined(MTK_MLO_MAP_SUPPORT) && defined(DOT11_EHT_BE))
			pBss->ml_capable = bss->ml_capable;
		if (pBss->ml_capable == TRUE) {
			os_zero_mem(&pBss->ml_info, sizeof(struct multi_link_bss_info));

			NdisCopyMemory(&pBss->ml_info.mld_addr, &bss->ml_info.mld_addr, MAC_ADDR_LEN);
			pBss->ml_info.link_num = bss->ml_info.link_num;
			for (j = 0 ; j <  BSS_MNGR_MAX_BAND_NUM ; j++) {
				os_zero_mem(&pBss->ml_info.sta_profiles[j], sizeof(struct sta_profile_info));
				pBss->ml_info.sta_profiles[j].channel = bss->ml_info.sta_profiles[j].channel;

				if (wdev) {
					if (WMODE_CAP_6G(wdev->PhyMode)) {
						pBss->ml_info.sta_profiles[0].rfband = 0;
						pBss->ml_info.sta_profiles[1].rfband = 1;
						pBss->ml_info.sta_profiles[2].rfband = 255;
					} else if (WMODE_CAP_5G(wdev->PhyMode)) {
						pBss->ml_info.sta_profiles[0].rfband = 0;
						pBss->ml_info.sta_profiles[1].rfband = 255;
						pBss->ml_info.sta_profiles[2].rfband = 2;
					} else if (WMODE_CAP_2G(wdev->PhyMode)) {
						pBss->ml_info.sta_profiles[0].rfband = 255;
						pBss->ml_info.sta_profiles[1].rfband = 1;
						pBss->ml_info.sta_profiles[2].rfband = 2;
					}
				}
			//if HT exists
			pBss->ml_info.sta_profiles[j].ht_cap.sgi_20 = bss->ml_info.sta_profiles[j].HtCapability.HtCapInfo.ShortGIfor20;
			pBss->ml_info.sta_profiles[j].ht_cap.sgi_40 = bss->ml_info.sta_profiles[j].HtCapability.HtCapInfo.ShortGIfor40;
			pBss->ml_info.sta_profiles[j].ht_cap.ht_40 = bss->ml_info.sta_profiles[j].HtCapability.HtCapInfo.ChannelWidth;

			//if VHT exists
			NdisMoveMemory(&pBss->ml_info.sta_profiles[j].vht_cap.sup_tx_mcs,
						&bss->ml_info.sta_profiles[j].vht_cap_ie.mcs_set.tx_mcs_map,
						sizeof(vht_cap->sup_tx_mcs));
			NdisMoveMemory(&pBss->ml_info.sta_profiles[j].vht_cap.sup_rx_mcs,
						&bss->ml_info.sta_profiles[j].vht_cap_ie.mcs_set.rx_mcs_map,
						sizeof(vht_cap->sup_rx_mcs));

			if (bss->ml_info.sta_profiles[j].vht_cap_ie.mcs_set.rx_mcs_map.mcs_ss4 != VHT_MCS_CAP_NA)
				pBss->ml_info.sta_profiles[j].vht_cap.rx_stream = 4;
			else if (bss->ml_info.sta_profiles[j].vht_cap_ie.mcs_set.rx_mcs_map.mcs_ss3 != VHT_MCS_CAP_NA)
				pBss->ml_info.sta_profiles[j].vht_cap.rx_stream = 3;
			else if (bss->ml_info.sta_profiles[j].vht_cap_ie.mcs_set.rx_mcs_map.mcs_ss2 != VHT_MCS_CAP_NA)
				pBss->ml_info.sta_profiles[j].vht_cap.rx_stream = 2;
			else
				pBss->ml_info.sta_profiles[j].vht_cap.rx_stream = 1;

			if (bss->ml_info.sta_profiles[j].vht_cap_ie.mcs_set.tx_mcs_map.mcs_ss4 != VHT_MCS_CAP_NA)
				pBss->ml_info.sta_profiles[j].vht_cap.tx_stream = 4;
			else if (bss->vht_cap_ie.mcs_set.tx_mcs_map.mcs_ss3 != VHT_MCS_CAP_NA)
				pBss->ml_info.sta_profiles[j].vht_cap.tx_stream = 3;
			else if (bss->vht_cap_ie.mcs_set.tx_mcs_map.mcs_ss2 != VHT_MCS_CAP_NA)
				pBss->ml_info.sta_profiles[j].vht_cap.tx_stream = 2;
			else
				pBss->ml_info.sta_profiles[j].vht_cap.tx_stream = 1;

			pBss->ml_info.sta_profiles[j].vht_cap.sgi_80 = bss->ml_info.sta_profiles[j].vht_cap_ie.vht_cap.sgi_80M;
			pBss->ml_info.sta_profiles[j].vht_cap.sgi_160 = bss->ml_info.sta_profiles[j].vht_cap_ie.vht_cap.sgi_160M;
			pBss->ml_info.sta_profiles[j].vht_cap.vht_160 = bss->ml_info.sta_profiles[j].vht_op_ie.vht_op_info.ch_width;
			pBss->ml_info.sta_profiles[j].vht_cap.su_bf = bss->ml_info.sta_profiles[j].vht_cap_ie.vht_cap.bfee_cap_su;
			pBss->ml_info.sta_profiles[j].vht_cap.mu_bf = bss->ml_info.sta_profiles[j].vht_cap_ie.vht_cap.bfee_cap_mu;
#ifdef DOT11_HE_AX
		pBss->ml_info.sta_profiles[j].he_ch_width = peer_max_bw_cap(GET_DOT11AX_CH_WIDTH(bss->ml_info.sta_profiles[j].he_caps.phy_cap.phy_capinfo_1));
		mcsptr_sta = pBss->ml_info.sta_profiles[j].he_cap.he_mcs;
		NdisCopyMemory(mcsptr_sta, &bss->ml_info.sta_profiles[j].he_caps.txrx_mcs_nss, sizeof(struct he_txrx_mcs_nss));
		if (pBss->ml_info.sta_profiles[j].he_ch_width == HE_BW_160) {
			pBss->ml_info.sta_profiles[j].he_cap.he_160 = 1;
			mcsptr_sta += sizeof(struct he_txrx_mcs_nss);
			NdisCopyMemory(mcsptr_sta, &bss->ml_info.sta_profiles[j].he_mcs_nss_160, sizeof(struct he_txrx_mcs_nss));
		} else
			pBss->ml_info.sta_profiles[j].he_cap.he_160 = 0;
#endif
				//if EHT exists
#ifdef CONFIG_MAP_SUPPORT
			pBss->ml_info.sta_profiles[j].eht_cap.eht_ch_width = bss->ml_info.sta_profiles[j].eht_cap.eht_ch_width;
			pBss->ml_info.sta_profiles[j].eht_cap.ccfs0 = bss->ml_info.sta_profiles[j].eht_cap.ccfs0;
			pBss->ml_info.sta_profiles[j].eht_cap.ccfs1 = bss->ml_info.sta_profiles[j].eht_cap.ccfs1;

			txrx_stream = bss->ml_info.sta_profiles[j].eht_support_mcs_nss.eht_txrx_mcs_nss[0].max_tx_rx_mcs0_9_nss;
			pBss->ml_info.sta_profiles[j].eht_cap.rx_stream = txrx_stream & 0x0f;
			pBss->ml_info.sta_profiles[j].eht_cap.tx_stream = (txrx_stream & 0xf0) >> 4;

			if (wdev) {
				if (WMODE_CAP_6G(wdev->PhyMode)) {
					pBss->ml_info.sta_profiles[0].eht_cap.eht_ch_width = pBss->ml_info.sta_profiles[0].ht_cap.ht_40;
					if (pBss->ml_info.sta_profiles[1].vht_cap.vht_160 == 0)
						pBss->ml_info.sta_profiles[1].eht_cap.eht_ch_width = 2;
					else
						pBss->ml_info.sta_profiles[1].eht_cap.eht_ch_width = 3;
				} else if (WMODE_CAP_5G(wdev->PhyMode)) {
					pBss->ml_info.sta_profiles[0].eht_cap.eht_ch_width = pBss->ml_info.sta_profiles[0].ht_cap.ht_40;
				} else  if (WMODE_CAP_2G(wdev->PhyMode)) {
					if (pBss->ml_info.sta_profiles[1].vht_cap.vht_160 == 0)
						pBss->ml_info.sta_profiles[1].eht_cap.eht_ch_width = 2;
					else
						pBss->ml_info.sta_profiles[1].eht_cap.eht_ch_width = 3;
				}
			}
#endif
		}
	}
#endif /*MTK_MLO_MAP_SUPPORT*/
#endif
#endif
		count++;
		if (pBss->SsidLen)
			MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
				"RTMPIoctlGetSiteSurvey - ssid %s\n", pBss->Ssid);
	}
	MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_DEBUG,
		"RTMPIoctlGetSiteSurvey - max_bss%d\n len=%u count=%d", max_bss, TotalLen, count);
	event.data.scan_info.bss_count = count;
	pAdapter->last_scan_req.last_bss_cnt = i;
	if (i < pAdapter->last_scan_req.bss_nr)
		event.data.scan_info.more_bss = 1;
	if (ScanTab->BssNr < pAdapter->last_scan_req.bss_nr)
		event.data.scan_info.more_bss = 0;
send_event:
	wapp_send_wapp_qry_rsp(pAdapter, &event);
}

#ifdef CONFIG_CPE_SUPPORT
VOID RTMPLppeGetScanResults(
	IN	PRTMP_ADAPTER	pAdapter, struct wapp_req *req)
{
	struct wapp_event *event;
	INT last_bss_cnt = 0;
	RTMP_STRING *msg;
	INT		i = 0;
	/*INT			WaitCnt = 0;*/
	UINT32		bss_start_idx;
	BSS_ENTRY *bss;
	struct scan_bss_info *pBss;
	wdev_ht_cap *ht_cap;
	wdev_vht_cap *vht_cap;
	wdev_he_cap *he_cap;
	char *mcsptr = NULL;
	UINT8 he_ch_width = HE_BW_80;
	UINT16	l;
	INT custom_event_length;
	UINT32 TotalLen;
	INT count = 0, max_bss;
	BSS_TABLE *ScanTab = NULL;
	struct wifi_dev *wdev = NULL;

	for (l = 0; l < WDEV_NUM_MAX; l++) {
		if (pAdapter->wdev_list[l] != NULL) {
			wdev = pAdapter->wdev_list[l];
			if (wdev->if_dev && (RtmpOsGetNetIfIndex(wdev->if_dev) == req->data.ifindex))
				break;
		}
	}

	if (wdev == NULL)
		return;

	ScanTab = get_scan_tab_by_wdev(pAdapter, wdev);
#ifndef IWEVCUSTOM_PAYLOD_MAX_LEN
#define IWEVCUSTOM_PAYLOD_MAX_LEN 220
#endif
	custom_event_length = IWEVCUSTOM_PAYLOD_MAX_LEN;
	TotalLen = custom_event_length;

	MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_DEBUG, "RTMPIoctlGetSiteSurvey - enter\n");
	/*
	 * At the moment there is a single scan tab across the pAd
	 * that means if scan id or if_index has changed, it doesn't
	 * make sense of continuing the last get scan command.
	 */
	if ((pAdapter->last_scan_req_lppe.scan_id != req->data.value) ||
	    (pAdapter->last_scan_req_lppe.if_index != req->data.ifindex)) {
		pAdapter->last_scan_req_lppe.scan_id = req->data.value;
		pAdapter->last_scan_req_lppe.if_index = req->data.ifindex;
	} else
		last_bss_cnt = pAdapter->last_scan_req_lppe.last_bss_cnt;

	if (ScanTab->BssNr == 0) {
		MTWF_DBG(pAdapter, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
				"no bss present in scan tab\n");
	}
	max_bss = custom_event_length / sizeof(struct scan_bss_info);

	bss_start_idx = last_bss_cnt;

	TotalLen = (sizeof(CHAR) * 4) + ((sizeof(struct scan_bss_info)) * max_bss) + (sizeof(UINT32) * 2);
	if ((max_bss > 0) && (TotalLen > custom_event_length))
		max_bss--;

	if (max_bss == 0) {
		MTWF_DBG(pAdapter, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				"bss size is too big for wireless send event\n");
		return;
	}
	TotalLen = (sizeof(CHAR) * 4) + ((sizeof(struct scan_bss_info)) * max_bss) + (sizeof(UINT32) * 2);
	os_alloc_mem(NULL, (PUCHAR *)&msg, TotalLen);

	if (msg == NULL) {
		MTWF_DBG(pAdapter, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				"RTMPIoctlGetSiteSurvey - msg memory alloc fail.\n");
		return;
	}

	NdisZeroMemory(msg, TotalLen);

	event = (struct wapp_event *)msg;
	event->event_id = LPPE_SCAN_RESULT_RSP;
	event->ifindex = req->data.ifindex;

	if (ScanTab->BssNr == 0) {
		/* Send the event as this is possible scenario during in DFS channe */
		goto send_event;
	}

	if (bss_start_idx > (ScanTab->BssNr - 1)) {
		event->data.scan_info.bss_count = 0;
		goto send_event;
	}

	for (i = bss_start_idx; i < ScanTab->BssNr && count < max_bss; i++) {
		bss = &ScanTab->BssEntry[i];
		pBss = &event->data.scan_info.bss;

		ht_cap = &pBss->ht_cap;
		vht_cap = &pBss->vht_cap;
		he_cap = &pBss->he_cap;
		if (bss->Channel == 0)
			break;
		pBss->Channel = bss->Channel;
		pBss->CentralChannel = bss->CentralChannel;
		pBss->Rssi = bss->Rssi;
		ht_cap->tx_stream = 0; /* TODO */
		ht_cap->rx_stream = 0; /* TODO */
		ht_cap->sgi_20 = bss->HtCapability.HtCapInfo.ShortGIfor20;
		ht_cap->sgi_40 = bss->HtCapability.HtCapInfo.ShortGIfor40;
		ht_cap->ht_40 = bss->HtCapability.HtCapInfo.ChannelWidth;

		NdisMoveMemory(vht_cap->sup_tx_mcs,
						&bss->vht_cap_ie.mcs_set.tx_mcs_map,
						sizeof(vht_cap->sup_tx_mcs));
		NdisMoveMemory(vht_cap->sup_rx_mcs,
						&bss->vht_cap_ie.mcs_set.rx_mcs_map,
						sizeof(vht_cap->sup_rx_mcs));
		if (bss->vht_cap_ie.mcs_set.rx_mcs_map.mcs_ss4 != VHT_MCS_CAP_NA)
			vht_cap->rx_stream = 4;
		else if (bss->vht_cap_ie.mcs_set.rx_mcs_map.mcs_ss3 != VHT_MCS_CAP_NA)
			vht_cap->rx_stream = 3;
		else if (bss->vht_cap_ie.mcs_set.rx_mcs_map.mcs_ss2 != VHT_MCS_CAP_NA)
			vht_cap->rx_stream = 2;
		else
			vht_cap->rx_stream = 1;

		if (bss->vht_cap_ie.mcs_set.tx_mcs_map.mcs_ss4 != VHT_MCS_CAP_NA)
			vht_cap->tx_stream = 4;
		else if (bss->vht_cap_ie.mcs_set.tx_mcs_map.mcs_ss3 != VHT_MCS_CAP_NA)
			vht_cap->tx_stream = 3;
		else if (bss->vht_cap_ie.mcs_set.tx_mcs_map.mcs_ss2 != VHT_MCS_CAP_NA)
			vht_cap->tx_stream = 2;
		else
			vht_cap->tx_stream = 1;
		vht_cap->sgi_80 = bss->vht_cap_ie.vht_cap.sgi_80M;
		vht_cap->sgi_160 = bss->vht_cap_ie.vht_cap.sgi_160M;
		vht_cap->vht_160 = bss->vht_op_ie.vht_op_info.ch_width;
		vht_cap->vht_8080 = 0; /* TODO */
		vht_cap->su_bf = bss->vht_cap_ie.vht_cap.bfee_cap_su;
		vht_cap->mu_bf = bss->vht_cap_ie.vht_cap.bfee_cap_mu;
#ifdef DOT11_HE_AX
		he_ch_width = peer_max_bw_cap(GET_DOT11AX_CH_WIDTH(bss->he_caps.phy_cap.phy_capinfo_1));
		mcsptr = he_cap->he_mcs;
		NdisCopyMemory(mcsptr, &bss->he_caps.txrx_mcs_nss, sizeof(struct he_txrx_mcs_nss));
		if (he_ch_width == HE_BW_160) {
			he_cap->he_160 = 1;
			mcsptr += sizeof(struct he_txrx_mcs_nss);
			NdisCopyMemory(mcsptr, &bss->he_mcs_nss_160, sizeof(struct he_txrx_mcs_nss));
		} else
			he_cap->he_160 = 0;
#endif
		pBss->MinSNR = bss->MinSNR;
		pBss->Privacy = bss->Privacy;
		pBss->SsidLen = bss->SsidLen;
		NdisCopyMemory(pBss->Ssid, bss->Ssid, pBss->SsidLen);
		COPY_MAC_ADDR(pBss->Bssid, bss->Bssid);
		pBss->AuthMode = bss->AuthMode;
#ifdef CONFIG_MAP_SUPPORT
		NdisCopyMemory(&pBss->map_info, &bss->map_info, sizeof(struct map_vendor_ie));
		pBss->map_vendor_ie_found = bss->map_vendor_ie_found;
		pBss->AuthMode = WscGetAuthType(bss->AKMMap);
		pBss->EncrypType = WscGetEncryType(bss->PairwiseCipher);
#ifdef MAP_R2
		pBss->QbssLoad.bValid = bss->QbssLoad.bValid;
		pBss->QbssLoad.StaNum = bss->QbssLoad.StaNum;
		pBss->QbssLoad.ChannelUtilization = bss->QbssLoad.ChannelUtilization;
#endif
#endif
		count++;
		if (pBss->SsidLen)
			MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
				"RTMPIoctlGetSiteSurvey - ssid %s\n", pBss->Ssid);
	}
	MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_DEBUG,
		"max_bss%d\n len=%u count=%d", max_bss, TotalLen, count);
	event->data.scan_info.bss_count = count;
	pAdapter->last_scan_req_lppe.last_bss_cnt = i;
	if (i < ScanTab->BssNr)
		event->data.scan_info.more_bss = 1;
send_event:
	RtmpOSWrielessEventSend(pAdapter->net_dev, RT_WLAN_EVENT_CUSTOM,
			OID_LPPE_EVENT, NULL, (PUCHAR)event, TotalLen);

	os_free_mem((PUCHAR)msg);
}
#endif

VOID RTMPIoctlSendNullDataFrame(
	IN	PRTMP_ADAPTER	pAdapter, struct wapp_req *req)
{
	INT count, pkt_count;
	MAC_TABLE_ENTRY *pEntry = MacTableLookup(pAdapter, req->data.mac_addr);
	/* use Null or QoS Null to detect the ACTIVE station */
	BOOLEAN bQosNull = FALSE;

	if (!pEntry) {
		MTWF_DBG(pAdapter, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
			"given station not found\n");
		return;
	}

	pkt_count = req->data.value;

	if (pkt_count <= 0 || pkt_count >= 256) {
		MTWF_DBG(pAdapter, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
			"invalid pkt_count\n");
		return;
	}

	if (CLIENT_STATUS_TEST_FLAG(pEntry, fCLIENT_STATUS_WMM_CAPABLE))
		bQosNull = TRUE;

	for (count = 0; count < pkt_count && count < 256; count++) {
		/* TODO status */
		RtmpEnqueueNullFrame(pAdapter, pEntry->Addr, pEntry->CurrTxRate,
						 pEntry->Aid, pEntry->func_tb_idx, bQosNull, TRUE, 0);
	}
}

void wapp_prepare_nop_channel_list(PRTMP_ADAPTER pAd,
	struct nop_channel_list_s *nop_list)
{
#ifdef MT_DFS_SUPPORT
	UINT_8 i;
	PCHANNEL_CTRL pChCtrl = NULL;
	pChCtrl = hc_get_channel_ctrl(pAd->hdev_ctrl);

	for (i = 0; i < pChCtrl->ChListNum; i++) {
		if ((pChCtrl->ChList[i].NonOccupancy > 0 || pChCtrl->ChList[i].NOPSaveForClear > 0)
			&& nop_list->channel_count < MAX_NUM_OF_CHANNELS) {
			nop_list->channel_list[nop_list->channel_count] = pChCtrl->ChList[i].Channel;
			nop_list->channel_count++;
		}
	}
#endif /* MT_DFS_SUPPORT */
}
INT	wapp_event_handle(
	struct _RTMP_ADAPTER *pAd,
	struct wifi_dev *wdev,
	struct wapp_req *req)
{
	switch (req->req_id) {
	case WAPP_DEV_QUERY_REQ:
		wapp_send_wdev_query_rsp(pAd, req);
		break;
	case WAPP_HT_CAP_QUERY_REQ:
		wapp_send_wdev_ht_cap_rsp(pAd, req);
		break;
	case WAPP_VHT_CAP_QUERY_REQ:
		wapp_send_wdev_vht_cap_rsp(pAd, req);
		break;
	case WAPP_MISC_CAP_QUERY_REQ:
		wapp_send_wdev_misc_cap_rsp(pAd, req);
		break;
	case WAPP_CLI_QUERY_REQ:
		wapp_send_cli_query_rsp(pAd, req);
		break;
	case WAPP_CLI_LIST_QUERY_REQ:
		wapp_handle_cli_list_query(pAd, req);
		break;
	case WAPP_OP_CLASS_QUERY_REQ:
		wapp_send_op_class_query_rsp(pAd, req);
		break;
/*
	case WAPP_BSS_INFO_QUERY_REQ:
		wapp_send_bss_info_query_rsp(pAd, req);
		break;
*/
	case WAPP_AP_METRIC_QUERY_REQ:
		wapp_send_ap_metric_query_rsp(pAd, req);
		break;
#ifdef MAP_R2
	case WAPP_RADIO_METRICS_REQ:
		wapp_send_radio_metric_query_rsp(pAd, req);
		break;
#endif
	case WAPP_CH_UTIL_QUERY_REQ:
		wapp_send_ch_util_query_rsp(pAd, req);
		break;
	case WAPP_APCLI_QUERY_REQ:
		wapp_send_apcli_query_rsp(pAd, req);
		break;
	case WAPP_BSS_START_REQ:
		wapp_bss_start(pAd, req);
		break;
	case WAPP_BSS_STOP_REQ:
		wapp_bss_stop(pAd, req);
		break;
	case WAPP_BSS_LOAD_THRD_SET_REQ:
		wapp_bss_load_thrd_set(pAd, req);
		break;
	case WAPP_TXPWR_PRCTG_REQ:
		wapp_set_tx_power_prctg(pAd, req);
		break;
	case WAPP_STEERING_POLICY_SET_REQ:
		wapp_set_steer_policy(pAd, req);
		break;
	case WAPP_AP_CONFIG_SET_REQ:
		wapp_config_ap_setting(pAd, req);
		break;
	case WAPP_BSSLOAD_QUERY_REQ:
		wapp_send_bssload_query_rsp(pAd, req);
		break;
	case WAPP_HECAP_QUERY_REQ:
		wapp_send_he_cap_query_rsp(pAd, req);
		break;
	case WAPP_STA_RSSI_QUERY_REQ:
		wapp_send_sta_rssi_query_rsp(pAd, req);
		break;
	case WAPP_COSR_STA_RSSI_QUERY_REQ:
		wapp_send_cosr_sta_rssi_query_rsp(pAd, req);
		break;
	case WAPP_APCLI_RSSI_QUERY_REQ:
		wapp_send_apcli_rssi_query_rsp(pAd, req);
		break;
	case WAPP_GET_SCAN_RESULTS:
		RTMPIoctlGetScanResults(pAd, req);
		break;
#ifdef WSC_INCLUDED
	case WAPP_WSC_PBC_EXEC:
		{
#ifdef CONFIG_STA_SUPPORT
			PWSC_CTRL pWscControl = NULL;

			pWscControl = &wdev->WscControl;
			WscPBCExec(pAd, FALSE, pWscControl);
#endif /* CONFIG_STA_SUPPORT */
			break;
		}
#endif /* WSC_INCLUDED */
	case WAPP_SEND_NULL_FRAMES:
		RTMPIoctlSendNullDataFrame(pAd, req);
		break;
#ifdef WSC_INCLUDED
	case WAPP_WSC_SET_BH_PROFILE:
		{
			PWSC_CTRL pWscControl = NULL;
			int i = 0;

			pWscControl = &wdev->WscControl;
			for (i = 0; i < pWscControl->WscBhProfiles.ProfileCnt; i++) {
				if (MAC_ADDR_EQUAL(pWscControl->WscBhProfiles.Profile[i].MacAddr,
					req->data.bh_wsc_profile.MacAddr)) {
					NdisCopyMemory(&pWscControl->WscBhProfiles.Profile[i],
						&req->data.bh_wsc_profile, sizeof(WSC_CREDENTIAL));
					break;
				}
			}
			if (i == pWscControl->WscBhProfiles.ProfileCnt) {
				NdisCopyMemory(&pWscControl->WscBhProfiles.Profile[i],
					&req->data.bh_wsc_profile, sizeof(WSC_CREDENTIAL));
				pWscControl->WscBhProfiles.ProfileCnt++;
			}
			break;
		}
#endif /* WSC_INCLUDED */
#ifdef CONFIG_MAP_SUPPORT
	case WAPP_SET_SCAN_BH_SSIDS:
		NdisZeroMemory(&wdev->MAPCfg.scan_bh_ssids,
			sizeof(wdev->MAPCfg.scan_bh_ssids));
		NdisCopyMemory(&wdev->MAPCfg.scan_bh_ssids,
			&req->data.scan_bh_ssids, sizeof(wdev->MAPCfg.scan_bh_ssids));
		break;
	case WAPP_SET_AVOID_SCAN_CAC:
		pAd->bMAPAvoidScanDuringCac = (UINT8) req->data.value;
		break;
#endif /* CONFIG_MAP_SUPPORT */
#ifdef DPP_R2_SUPPORT
		case WAPP_GET_CCE_RESULT:
			RTMPIoctlGetCCEResults(pAd, req);
			break;
#endif

	case WAPP_SET_SRG_BITMAP:
		wapp_set_srg_bitmap(pAd, req);
		break;

	case WAPP_SET_TOPOLOGY_UPDATE:
		wapp_srg_topology_update(pAd, req);
		break;

	case WAPP_SET_SRG_UPLINK_STATUS:
		wapp_set_srg_uplink_traffic_status(pAd, req);
		break;

	case WAPP_SET_SRG_STA_MODE_RPT:
		wapp_send_sta_mode_rpt_cmd(pAd, req);
		break;

	case WAPP_SR_SUPPORT_MODE_QUERY_REQ:
		MTWF_DBG(pAd, DBG_CAT_CFG, CATCFG_SR, DBG_LVL_NOTICE,
			"[SUPPORT_MODE_QUERY_REQ] wapp req id=%d\n", req->req_id);
		wapp_handle_sr_support_mode_query_req(pAd, req);
		break;

	default:
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO, "invalid wapp req id=%d\n", req->req_id);
		break;
	}
	return 0;
}

INT set_wapp_param(
	IN PRTMP_ADAPTER pAd,
	UINT32 Param,
	UINT32 Value)
{
	POS_COOKIE pObj = (POS_COOKIE)pAd->OS_Cookie;
	UCHAR APIndex = pObj->ioctl_if;
	PWNM_CTRL pWNMCtrl;
#ifdef CONFIG_DOT11U_INTERWORKING
	PGAS_CTRL pGASCtrl;
#endif /* CONFIG_DOT11U_INTERWORKING */
#ifdef CONFIG_HOTSPOT_R2
	PHOTSPOT_CTRL pHSCtrl;
	struct wifi_dev *wdev;
	pHSCtrl = &pAd->ApCfg.MBSSID[APIndex].HotSpotCtrl;
	wdev = &pAd->ApCfg.MBSSID[APIndex].wdev;
#endif /* CONFIG_HOTSPOT_R2 */

	pWNMCtrl = &pAd->ApCfg.MBSSID[APIndex].WNMCtrl;
#ifdef CONFIG_DOT11U_INTERWORKING
	pGASCtrl = &pAd->ApCfg.MBSSID[APIndex].GASCtrl;
#endif /* CONFIG_DOT11U_INTERWORKING */

	switch (Param) {
	case PARAM_WNM_BSS_TRANSITION_MANAGEMENT:
		pWNMCtrl->WNMBTMEnable = Value;
		break;

#ifdef CONFIG_DOT11U_INTERWORKING
	case PARAM_EXTERNAL_ANQP_SERVER_TEST:
		pGASCtrl->ExternalANQPServerTest = Value;
		break;

	case PARAM_GAS_COME_BACK_DELAY:
		pGASCtrl->cb_delay = Value;
		break;

	case PARAM_MMPDU_SIZE:
		pGASCtrl->MMPDUSize = Value;
		break;
#endif /* CONFIG_DOT11U_INTERWORKING */

	case PARAM_WNM_NOTIFICATION:
		pWNMCtrl->WNMNotifyEnable = Value;
		break;
#ifdef CONFIG_HOTSPOT_R2

	case PARAM_QOSMAP:
		pHSCtrl->QosMapEnable = Value;
		hotspot_update_bssflag(pAd, fgQosMapEnable, Value, pHSCtrl);
		break;
	case PARAM_DGAF_DISABLED:
		pHSCtrl->DGAFDisable = Value;
		hotspot_update_bssflag(pAd, fgDGAFDisable, Value, pHSCtrl);
		break;

	case PARAM_PROXY_ARP:
		pWNMCtrl->ProxyARPEnable = Value;
		hotspot_update_bssflag(pAd, fgProxyArpEnable, Value, pHSCtrl);
		break;

	case PARAM_L2_FILTER:
		pHSCtrl->L2Filter = Value;
		break;

	case PARAM_ICMPV4_DENY:
		pHSCtrl->ICMPv4Deny = Value;
		break;

#endif /* CONFIG_HOTSPOT_R2 */
	default:
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR, "Unknown Parameter:%d\n", Param);
		break;
	}
#ifdef CONFIG_HOTSPOT_R2
	/* for 7615 offload to CR4 */
	hotspot_update_bss_info_to_cr4(pAd, APIndex, wdev->bss_info_argument.ucBssIndex);
#endif /* CONFIG_HOTSPOT_R2 */

	return 0;
}

static INT set_wapp_cmm_ie(
	IN PRTMP_ADAPTER pAd,
	IN UINT8 EID,
	IN RTMP_STRING *IE,
	IN UINT32 IELen,
	IN UCHAR apidx)
{
	PWNM_CTRL pWNMCtrl =  &pAd->ApCfg.MBSSID[apidx].WNMCtrl;
#ifdef CONFIG_DOT11U_INTERWORKING
	PGAS_CTRL pGasCtrl = &pAd->ApCfg.MBSSID[apidx].GASCtrl;
#endif /* CONFIG_DOT11U_INTERWORKING */
#ifdef CONFIG_HOTSPOT_R2
	PHOTSPOT_CTRL pHSCtrl = &pAd->ApCfg.MBSSID[apidx].HotSpotCtrl;
#endif /* CONFIG_HOTSPOT_R2 */

	INT32 Ret;
	PUCHAR tmp_buf_ptr = NULL;

	Ret = os_alloc_mem(NULL, &tmp_buf_ptr, IELen);
	if (Ret != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
			"Not enough memory\n");
		return FALSE;
	}
	NdisMoveMemory(tmp_buf_ptr, IE, IELen);

	switch (EID) {
#ifdef CONFIG_DOT11U_INTERWORKING
	case IE_INTERWORKING:
		OS_SEM_LOCK(&pGasCtrl->IeLock);
		if (pGasCtrl->InterWorkingIE)
			os_free_mem(pGasCtrl->InterWorkingIE);
		pGasCtrl->InterWorkingIE = tmp_buf_ptr;
		pGasCtrl->InterWorkingIELen = IELen;
		OS_SEM_UNLOCK(&pGasCtrl->IeLock);
#ifdef CONFIG_HOTSPOT_R2
		OS_SEM_LOCK(&pHSCtrl->IeLock);
		pHSCtrl->AccessNetWorkType  = (*(IE + 2)) & 0x0F;
		if (IELen > 3) {
			pHSCtrl->IsHessid = TRUE;

			if (IELen == 7)
				NdisMoveMemory(pHSCtrl->Hessid, IE + 3, MAC_ADDR_LEN);
			else
				NdisMoveMemory(pHSCtrl->Hessid, IE + 5, MAC_ADDR_LEN);
		}
		OS_SEM_UNLOCK(&pHSCtrl->IeLock);
#endif /* CONFIG_HOTSPOT_R2 */
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO, "Set Interworking IE\n");
		break;
	case IE_ADVERTISEMENT_PROTO:
		OS_SEM_LOCK(&pGasCtrl->IeLock);
		if (pGasCtrl->AdvertisementProtoIE)
			os_free_mem(pGasCtrl->AdvertisementProtoIE);
		pGasCtrl->AdvertisementProtoIE = tmp_buf_ptr;
		pGasCtrl->AdvertisementProtoIELen = IELen;
		OS_SEM_UNLOCK(&pGasCtrl->IeLock);
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"Set Advertisement Protocol IE\n");
		break;

	case IE_ROAMING_CONSORTIUM:
		OS_SEM_LOCK(&pGasCtrl->IeLock);
		if (pGasCtrl->RoamingConsortiumIE)
			os_free_mem(pGasCtrl->RoamingConsortiumIE);
		pGasCtrl->RoamingConsortiumIE = tmp_buf_ptr;
		pGasCtrl->RoamingConsortiumIELen = IELen;
		OS_SEM_UNLOCK(&pGasCtrl->IeLock);
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"Set Roaming Consortium IE\n");
		break;
#endif /* CONFIG_DOT11U_INTERWORKING */

	case IE_TIME_ADVERTISEMENT:
		OS_SEM_LOCK(&pWNMCtrl->IeLock);
		if (pWNMCtrl->TimeadvertisementIE)
			os_free_mem(pWNMCtrl->TimeadvertisementIE);
		pWNMCtrl->TimeadvertisementIE = tmp_buf_ptr;
		pWNMCtrl->TimeadvertisementIELen = IELen;
		OS_SEM_UNLOCK(&pWNMCtrl->IeLock);
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
			"Set Time Advertisement IE\n");
		break;

	case IE_TIME_ZONE:
		OS_SEM_LOCK(&pWNMCtrl->IeLock);
		if (pWNMCtrl->TimezoneIE)
			os_free_mem(pWNMCtrl->TimezoneIE);
		pWNMCtrl->TimezoneIE = tmp_buf_ptr;
		pWNMCtrl->TimezoneIELen = IELen;
		OS_SEM_UNLOCK(&pWNMCtrl->IeLock);
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO, "Set Time Zone IE\n");
		break;

#ifdef CONFIG_HOTSPOT_R2
	case IE_QOS_MAP_SET: {
		int tmp = 0;
		char *pos = (char *)(IE + 2);

		OS_SEM_LOCK(&pHSCtrl->IeLock);
		if (pHSCtrl->QosMapSetIE)
			os_free_mem(pHSCtrl->QosMapSetIE);
		pHSCtrl->QosMapSetIE = tmp_buf_ptr;
		pHSCtrl->QosMapSetIELen = IELen;
		OS_SEM_UNLOCK(&pHSCtrl->IeLock);

		for (tmp = 0; tmp < (IELen - 16 - 2) / 2; tmp++) {
			pHSCtrl->DscpException[tmp] = *pos & 0xff;
			pHSCtrl->DscpException[tmp] |= (*(pos + 1) & 0xff) << 8;
			pos += 2;
			MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
				"DscpException[%d]:0x%x\n", tmp, pHSCtrl->DscpException[tmp]);
		}

		for (tmp = 0; tmp < 8; tmp++) {
			pHSCtrl->DscpRange[tmp] = *pos & 0xff;
			pHSCtrl->DscpRange[tmp] |= (*(pos + 1) & 0xff) << 8;
			pos += 2;
			MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
				"DscpRange[%d]:0x%x\n", tmp, pHSCtrl->DscpRange[tmp]);
		}

		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_WARN,
			"=========================================== Set Qos MAP Set IE\n");
		break;
	}
#endif /* CONFIG_HOTSPOT_R2 */

#ifdef QOS_R1
	case EID_QOS_R1_MAP_SET:
		if (IS_QOS_ENABLE(pAd))
			QoS_MapIE_Config(pAd, apidx, IE, IELen);

		os_free_mem(tmp_buf_ptr);
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_WARN,
			"-->Set Qos R1/R2 MAP Set IE\n");
		break;
#endif /* QOS_R1 */

	default:
	    os_free_mem(tmp_buf_ptr);
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR, "Unknown IE(EID = %d)\n", EID);
		break;
	}
	/* Update Beacon Template */
	if (pAd->ApCfg.MBSSID[apidx].wdev.bAllowBeaconing) {
		UpdateBeaconHandler(pAd, &pAd->ApCfg.MBSSID[apidx].wdev, BCN_REASON(BCN_UPDATE_IE_CHG));
	}

	return TRUE;
}

#ifdef DPP_R2_SUPPORT
static void Set_DPP_VENDOR_SPECIFIC_IE(
	IN PRTMP_ADAPTER pAd,
	IN UINT8 OUIType,
	IN RTMP_STRING *IE,
	IN UINT32 IELen,
	IN UCHAR apidx)
{
	struct wifi_dev *wdev = &pAd->ApCfg.MBSSID[apidx].wdev;

	MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO, "Set DPP IE\n");
	os_zero_mem(wdev->DPPCfg.cce_ie_buf, 6);
	wdev->DPPCfg.cce_ie_len = IELen;
	if (wdev->DPPCfg.cce_ie_len <= ARRAY_SIZE(wdev->DPPCfg.cce_ie_buf))
		NdisMoveMemory(wdev->DPPCfg.cce_ie_buf, IE, wdev->DPPCfg.cce_ie_len);
	else
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
			"Not have enough buffer size for wdev->DPPCfg.cce_ie_buf!\n");
	if (wdev->bAllowBeaconing)
		UpdateBeaconHandler(pAd, wdev, BCN_REASON(BCN_UPDATE_IE_CHG));
}

VOID MakeDPPVendorIe(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wdev,
	ULONG *pFrameLen,
	UCHAR *pFrame)
{
	ULONG FrameLen = *pFrameLen;

	if (IS_MAP_ENABLE(pAd) && wdev->DPPCfg.cce_ie_len) {
		ULONG DPPIeTmpLen = 0;

		MakeOutgoingFrame(pFrame + FrameLen, &DPPIeTmpLen,
				wdev->DPPCfg.cce_ie_len, wdev->DPPCfg.cce_ie_buf,
				END_OF_ARGS);
		FrameLen += DPPIeTmpLen;
	}

	*pFrameLen = FrameLen;
}
#endif


static void Set_MTK_VENDOR_SPECIFIC_IE(
	IN PRTMP_ADAPTER pAd,
	IN UINT8 OUIType,
	IN RTMP_STRING * IE,
	IN UINT32 IELen,
	IN UCHAR ApIdx)
{
#ifdef CONFIG_MAP_SUPPORT
	struct wifi_dev *wdev = &pAd->ApCfg.MBSSID[ApIdx].wdev;

	if (!IS_MAP_TURNKEY_ENABLE(pAd)) {
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO,
				 "MAP turnkey is not enabled, skipping vendor ie settings\n");
		return;
	}
	MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO, "Set MTK IE\n");
	os_zero_mem(wdev->MAPCfg.vendor_ie_buf, VENDOR_SPECIFIC_LEN);
	wdev->MAPCfg.vendor_ie_len = IELen;
	if (wdev->MAPCfg.vendor_ie_len <= ARRAY_SIZE(wdev->MAPCfg.vendor_ie_buf))
		NdisMoveMemory(wdev->MAPCfg.vendor_ie_buf, IE, wdev->MAPCfg.vendor_ie_len);
	else
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
				 "Not have enough buffer size for wdev->MAPCfg.vendor_ie_buf!\n");
	if (wdev->bAllowBeaconing)
		UpdateBeaconHandler(pAd, wdev, BCN_REASON(BCN_UPDATE_IE_CHG));
#endif
}

#ifdef RT_CFG80211_SUPPORT
#endif

static INT Set_AP_VENDOR_SPECIFIC_IE(
	IN PRTMP_ADAPTER pAd,
	IN UINT8 OUIType,
	IN RTMP_STRING *IE,
	IN UINT32 IELen,
	IN UCHAR apidx)
{
#ifdef CONFIG_HOTSPOT
	PHOTSPOT_CTRL pHSCtrl = &pAd->ApCfg.MBSSID[apidx].HotSpotCtrl;
#endif
	INT32 Ret;
	PUCHAR tmp_buf_ptr = NULL;

	Ret = os_alloc_mem(NULL, &tmp_buf_ptr, IELen);
	if (Ret != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
			"Not enough memory\n");
		return FALSE;
	}
	NdisMoveMemory(tmp_buf_ptr, IE, IELen);

	switch (OUIType) {
#ifdef CONFIG_HOTSPOT

	case OUI_P2P:
		OS_SEM_LOCK(&pHSCtrl->IeLock);
		if (pHSCtrl->P2PIE)
			os_free_mem(pHSCtrl->P2PIE);
		pHSCtrl->P2PIE = tmp_buf_ptr;
		pHSCtrl->P2PIELen = IELen;
		OS_SEM_UNLOCK(&pHSCtrl->IeLock);
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO, "Set P2P IE\n");
		break;

	case OUI_HS2_INDICATION:
		OS_SEM_LOCK(&pHSCtrl->IeLock);
		if (pHSCtrl->HSIndicationIE)
			os_free_mem(pHSCtrl->HSIndicationIE);
		pHSCtrl->HSIndicationIE = tmp_buf_ptr;
		pHSCtrl->HSIndicationIELen = IELen;
		OS_SEM_UNLOCK(&pHSCtrl->IeLock);
		MTWF_DBG(NULL, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_INFO, "Set HS2.0 Indication IE\n");
		break;
#endif

	default:
		os_free_mem(tmp_buf_ptr);
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR, "Unknown OUIType = %d\n", OUIType);
		break;
	}

	return TRUE;
}

INT wapp_set_ap_ie(
	IN PRTMP_ADAPTER pAd,
	IN RTMP_STRING *IE,
	IN UINT32 IELen,
	IN UCHAR ApIdx)
{
	UINT8 EID;
	UINT8 OUIType;

	EID = *IE;

	switch (EID) {
	case IE_INTERWORKING:
	case IE_ADVERTISEMENT_PROTO:
	case IE_TIME_ADVERTISEMENT:
	case IE_TIME_ZONE:
	case IE_QOS_MAP_SET:
	case IE_ROAMING_CONSORTIUM:
#ifdef QOS_R1
	case EID_QOS_R1_MAP_SET:
#endif
		set_wapp_cmm_ie(pAd, EID, IE, IELen, ApIdx);
		break;

	case IE_VENDOR_SPECIFIC:
		if (IELen <= 5) {
			MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_DEBUG,
				"Invalid IE(IELen = %d)\n", IELen);
			break;
		}
		OUIType = *(IE + 5);
		if (NdisEqualMemory(&IE[2], &MTK_OUI[0], 3))
			Set_MTK_VENDOR_SPECIFIC_IE(pAd, OUIType, IE, IELen, ApIdx);
#ifdef DPP_R2_SUPPORT
		else if (NdisEqualMemory(&IE[2], &DPP_OUI[0], 3) &&
					(OUIType == WFA_DPP_CCE_OUITYPE))
			Set_DPP_VENDOR_SPECIFIC_IE(pAd, OUIType, IE, IELen, ApIdx);
#endif
#ifdef RT_CFG80211_SUPPORT
#endif
		else
			Set_AP_VENDOR_SPECIFIC_IE(pAd, OUIType, IE, IELen, ApIdx);
		break;

	default:
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR, "Unknown IE(EID = %d)\n", EID);
		break;
	}

	return TRUE;
}

int wapp_send_wapp_qry_rsp(IN PRTMP_ADAPTER pAd, IN struct wapp_event *event)
{
#ifdef RT_CFG80211_SUPPORT
	int ret = 0;

	ret = nl80211_send_wapp_qry_rsp(pAd, event);
	if (ret != 0) {
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
			"Err: event send fail!\n");
		return ret;
	}
#else
	wext_send_wapp_qry_rsp(pAd->net_dev, event);
#endif /* RT_CFG80211_SUPPORT */
	return 0;
}

int wapp_send_event_offchannel_info(IN PRTMP_ADAPTER pAd, IN void *data, IN int len)
{
#ifdef RT_CFG80211_SUPPORT
	int ret;

	ret = nl80211_send_event_offchannel_info(pAd, data, len);
	if (ret != 0) {
		MTWF_DBG(pAd, DBG_CAT_AP, CATAP_WAPP, DBG_LVL_ERROR,
			"Err: event send fail!\n");
		return ret;
	}
#else
	RtmpOSWrielessEventSend(pAd->net_dev, RT_WLAN_EVENT_CUSTOM, OID_OFFCHANNEL_INFO, NULL,
				data, len);
#endif /* RT_CFG80211_SUPPORT */
	return 0;
}

BOOLEAN wapp_init(
	PRTMP_ADAPTER pAd,
	BSS_STRUCT *pMbss
)
{
	NdisCopyMemory(pMbss->ESPI_AC_BE, ESPI_AC_BE_DEFAULT, sizeof(pMbss->ESPI_AC_BE));
	NdisCopyMemory(pMbss->ESPI_AC_BK, ESPI_AC_BK_DEFAULT, sizeof(pMbss->ESPI_AC_BK));
	NdisCopyMemory(pMbss->ESPI_AC_VO, ESPI_AC_VO_DEFAULT, sizeof(pMbss->ESPI_AC_VO));
	NdisCopyMemory(pMbss->ESPI_AC_VI, ESPI_AC_VI_DEFAULT, sizeof(pMbss->ESPI_AC_VI));
	return 0;
}
#endif /* WAPP_SUPPORT */
