/*
 * Copyright (c) [2020], MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws.
 * The information contained herein is confidential and proprietary to
 * MediaTek Inc. and/or its licensors.
 * Except as otherwise provided in the applicable licensing terms with
 * MediaTek Inc. and/or its licensors, any reproduction, modification, use or
 * disclosure of MediaTek Software, and information contained herein, in whole
 * or in part, shall be strictly prohibited.
*/
/****************************************************************************
 ****************************************************************************

    Abstract:


 */

#include "ap_autoChSel_cmm.h"
#include "rtmp_type.h"

#ifndef __AUTOCHSELECT_H__
#define __AUTOCHSELECT_H__


#define PERIODIC_ACS_CH_CHK_TIME 0 /* seconds */
#define PERIODIC_ACS_CH_UTIL_RATIO_THR 0 /* percent */
#define PERIODIC_ACS_CH_STA_NUM_THR 1
#define DEFAULT_ACS_SCAN_CH_IDX 0
#define DEFAULT_ACS_CH_LIST_NUM 0
#define DEFAULT_ACS_CH_STAT ACS_CH_STATE_NONE
#define DEFAULT_ACS_RESTORE_DWELL 150
#define DEFAULT_ACS_SCANNING_DWELL 200
#define DEFAULT_ACS_SCANNING_CH_NUM 2
#define DEFAULT_ACS_AUTO_CHANNEL_ALG 0
#define DEFAULT_ACS_MAX_ACS_TIMES 0
#define DEFAULT_ACS_SW_CH_THR 0
#define DEFAULT_ACS_PSC_ACS 0
#define DEFAULT_ACS_SKIP_LIST_NUM 0
#define DEFAULT_ACS_TX_POWER_CONS 0
#define DEFAULT_ACS_DATA_RATE_WEIGHT 1
#define DEFAULT_ACS_PRIO_WEIGHT 0

enum _WIFI_CH_BAND {
	WIFI_CH_BAND_2G = 0,
	WIFI_CH_BAND_5G,
	WIFI_CH_BAND_6G,
	WIFI_CH_BAND_NUM,
};

struct _ACS_CAND_CH_INFO {
	UCHAR channel;
	UCHAR ch_group_start_idx;
	UCHAR ch_group_end_idx;
	UCHAR ch_indx;
	ULONG ch_score;
	ULONG ch_group_max_score;
	ULONG ch_group_min_score;
	UCHAR ch_group_max_prio;
};

ULONG AutoChBssSearchWithSSID(
	IN PRTMP_ADAPTER pAd,
	IN PUCHAR Bssid,
	IN PUCHAR pSsid,
	IN UCHAR SsidLen,
	IN UCHAR Channel,
	IN struct wifi_dev *pwdev);

VOID APAutoChannelInit(
	IN PRTMP_ADAPTER pAd,
	IN struct wifi_dev *pwdev);

VOID UpdateChannelInfo(
	IN PRTMP_ADAPTER pAd,
	IN int ch,
	IN ChannelSel_Alg Alg,
	IN struct wifi_dev *pwdev);
VOID UpdatePreACSInfo(
	IN PRTMP_ADAPTER pAd,
	IN struct wifi_dev *pwdev);

#ifdef DFS_VENDOR10_CUSTOM_FEATURE
#define IS_V10_BOOTACS_INVALID(_pAd) \
	 (_pAd->CommonCfg.DfsParameter.bV10BootACSValid == TRUE)

#define SET_V10_BOOTACS_INVALID(_pAd, valid) \
	(_pAd->CommonCfg.DfsParameter.bV10BootACSValid = valid)

#define IS_V10_APINTF_DOWN(_pAd) \
		 (_pAd->CommonCfg.DfsParameter.bV10APInterfaceDownEnbl == TRUE)

#define SET_V10_APINTF_DOWN(_pAd, valid) \
		(_pAd->CommonCfg.DfsParameter.bV10APInterfaceDownEnbl = valid)

#define IS_V10_W56_AP_DOWN_ENBLE(_pAd) \
	 (_pAd->CommonCfg.DfsParameter.bV10W56APDownEnbl == TRUE)

#define SET_V10_W56_AP_DOWN(_pAd, valid) \
	(_pAd->CommonCfg.DfsParameter.bV10W56APDownEnbl = valid)

#define SET_V10_AP_BCN_UPDATE_ENBL(_pAd, enable) \
	(_pAd->CommonCfg.DfsParameter.bV10APBcnUpdateEnbl = enable)

#define IS_V10_AP_BCN_UPDATE_ENBL(_pAd) \
	 (_pAd->CommonCfg.DfsParameter.bV10APBcnUpdateEnbl == TRUE)


VOID AutoChannelSkipListAppend(
	IN PRTMP_ADAPTER pAd,
	IN UCHAR Ch);

VOID AutoChannelSkipChannels(
	IN PRTMP_ADAPTER pAd,
	IN UCHAR size,
	IN UINT16 grpStart);

VOID AutoChannelSkipListClear(
	IN PRTMP_ADAPTER pAd);

BOOLEAN DfsV10ACSMarkChnlConsumed(
	IN PRTMP_ADAPTER pAd,
	IN UCHAR channel);
#endif

ULONG AutoChBssInsertEntry(
	IN PRTMP_ADAPTER pAd,
	IN PUCHAR pBssid,
	IN CHAR Ssid[],
	IN UCHAR SsidLen,
	IN UCHAR ChannelNo,
	IN UCHAR ExtChOffset,
	IN CHAR Rssi,
	IN struct wifi_dev *pwdev);

VOID AutoChBssTableInit(
	IN PRTMP_ADAPTER pAd);

VOID ChannelInfoInit(
	IN PRTMP_ADAPTER pAd);

VOID AutoChBssTableDestroy(
	IN PRTMP_ADAPTER pAd);

VOID ChannelInfoDestroy(
	IN PRTMP_ADAPTER pAd);

VOID CheckPhyModeIsABand(
	IN PRTMP_ADAPTER pAd);

UCHAR SelectBestChannel(
	IN PRTMP_ADAPTER pAd,
	IN ChannelSel_Alg Alg,
	IN struct wifi_dev *pwdev);
UCHAR APAutoSelectChannel(
	IN PRTMP_ADAPTER pAd,
	IN struct wifi_dev *pwdev,
	IN ChannelSel_Alg Alg,
	IN BOOLEAN IsABand);

UCHAR MTAPAutoSelectChannel(
	IN RTMP_ADAPTER * pAd,
	IN struct wifi_dev *pwdev,
	IN ChannelSel_Alg Alg,
	IN BOOLEAN IsABand);

#ifdef AP_SCAN_SUPPORT

VOID ACSNormalEmergCheck(RTMP_ADAPTER *pAd);

INT show_acs_debug_proc(
	PRTMP_ADAPTER pAd,
	RTMP_STRING *arg);
#endif /* AP_SCAN_SUPPORT */

VOID AutoChSelBuildChannelList(
	IN RTMP_ADAPTER * pAd,
	IN struct wifi_dev *pwdev);

VOID AutoChSelBuildChannelListFor2G(
	IN RTMP_ADAPTER *pAd,
	IN struct wifi_dev *pwdev);

VOID AutoChSelBuildChannelListFor56G(
	IN RTMP_ADAPTER *pAd,
	IN struct wifi_dev *pwdev,
	IN UCHAR ucChBand);

VOID AutoChSelUpdateChannel(
	IN PRTMP_ADAPTER pAd,
	IN UCHAR Channel,
	IN BOOLEAN IsABand,
	IN struct wifi_dev *pwdev);

CHAR AutoChSelFindScanChIdx(
	IN RTMP_ADAPTER * pAd,
	IN struct wifi_dev *pwdev,
	IN CHAR LastScanChIdx);

VOID AutoChSelScanNextChannel(
	IN RTMP_ADAPTER * pAd,
	IN struct wifi_dev *pwdev);

VOID AutoChSelScanReqAction(
	IN RTMP_ADAPTER * pAd,
	IN MLME_QUEUE_ELEM * pElem);

VOID AutoChSelScanTimeoutAction(
	IN RTMP_ADAPTER * pAd,
	IN MLME_QUEUE_ELEM * pElem);

VOID AutoChSelScanStartSkipBuildChList(
	IN struct _RTMP_ADAPTER	*pAd,
	IN struct wifi_dev *pwdev);

BOOLEAN AutoChSelScanStart(
	IN RTMP_ADAPTER * pAd,
	IN struct wifi_dev *pwdev);

BOOLEAN mtk_cfg80211_auto_ch_sel(
	PRTMP_ADAPTER pAd,
	struct wifi_dev *wifi_wdev);

VOID AutoChSelScanTimeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3);

VOID AutoChSelRestoreTimeout(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3);

VOID AutoChSelStateMachineInit(
	IN RTMP_ADAPTER * pAd,
	IN UCHAR BandIdx,
	IN STATE_MACHINE * Sm,
	OUT STATE_MACHINE_FUNC Trans[]);

VOID AutoChSelInit(
	IN PRTMP_ADAPTER pAd);

#ifdef DFS_VENDOR10_CUSTOM_FEATURE
UINT8 SelectBestV10Chnl_From_List(
	IN RTMP_ADAPTER *pAd,
	IN UCHAR band_idx);
#endif

#ifdef OFFCHANNEL_SCAN_FEATURE
VOID ChannelInfoResetNew(
	IN PRTMP_ADAPTER pAd);
#endif

BOOLEAN is_same_band(
	struct _RTMP_ADAPTER *pAd,
	struct wifi_dev *pwdev);

VOID AutoChSelRelease(
	IN PRTMP_ADAPTER pAd);

INT ACS_Restore_During_Partial_Scan(
	IN PRTMP_ADAPTER pAd,
	IN struct wifi_dev *pwdev);

VOID auto_ch_select_set_cfg(
	IN RTMP_ADAPTER *pAd,
	IN RTMP_STRING *buffer);

VOID acs_set_scan_mode(RTMP_ADAPTER *pAd, RTMP_STRING *buffer);

VOID acs_set_scan_dwell(RTMP_ADAPTER *pAd, RTMP_STRING *buffer);

VOID acs_set_restore_dwell(RTMP_ADAPTER *pAd, RTMP_STRING *buffer);

VOID acs_set_partial_scan_ch_num(RTMP_ADAPTER *pAd, RTMP_STRING *buffer);

VOID acs_set_ch_util_thr(RTMP_ADAPTER *pAd, RTMP_STRING *buffer);

VOID acs_set_ch_ice_ch_util_thr(RTMP_ADAPTER *pAd, RTMP_STRING *buffer);

VOID acs_set_max_acs_times(RTMP_ADAPTER *pAd, RTMP_STRING *buffer);

VOID acs_set_sta_num_thr(RTMP_ADAPTER *pAd, RTMP_STRING *buffer);

VOID acs_set_switch_thr(RTMP_ADAPTER *pAd, RTMP_STRING *buffer);

VOID acs_config_init(RTMP_ADAPTER *pAd);

#ifdef CONFIG_6G_SUPPORT
VOID auto_ch_select_PSC_cfg(
	IN RTMP_ADAPTER *pAd,
	IN RTMP_STRING *buffer);
#endif

VOID auto_ch_select_reset_sm(
	IN RTMP_ADAPTER *pAd,
	IN struct wifi_dev *pwdev);

NDIS_STATUS set_idle_pwr_test(
	IN PRTMP_ADAPTER pAd,
	IN RTMP_STRING * arg);
#endif /* __AUTOCHSELECT_H__ */

INT AutoChSelSendPerChannelInfo(
	IN PRTMP_ADAPTER pAd,
	IN struct wifi_dev *wdev,
	IN int ch_index);

