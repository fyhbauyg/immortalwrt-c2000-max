/*
 * Copyright (c) [2020], MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws.
 * The information contained herein is confidential and proprietary to
 * MediaTek Inc. and/or its licensors.
 * Except as otherwise provided in the applicable licensing terms with
 * MediaTek Inc. and/or its licensors, any reproduction, modification, use or
 * disclosure of MediaTek Software, and information contained herein, in whole
 * or in part, shall be strictly prohibited.
*/
/****************************************************************************
 ****************************************************************************

    Module Name:
	action.c

    Abstract:
    Handle association related requests either from WSTA or from local MLME

    Revision History:
    Who         When          What
    --------    ----------    ----------------------------------------------
	Jan Lee		2006		created for rt2860
 */

#include "rt_config.h"
#include "action.h"

const CHAR *ACT_FSM_STATE_STR[MAX_ACT_STATE] = {
	"ACT_IDLE",
};

#define MCAST_WCID_TO_REMOVE 0 /* Pat: TODO */

extern UCHAR  ZeroSsid[32];

static VOID ReservedAction(
	IN PRTMP_ADAPTER pAd,
	IN MLME_QUEUE_ELEM * Elem);



/*
    ==========================================================================
    Description:
	association state machine init, including state transition and timer init
    Parameters:
	S - pointer to the association state machine
    Note:
	The state machine looks like the following

				    ASSOC_IDLE
	ASSOC_FSM_MLME_DISASSOC_REQ    mlme_disassoc_req_action
	ASSOC_FSM_PEER_DISASSOC_REQ    peer_disassoc_action
	ASSOC_FSM_PEER_ASSOC_REQ       drop
	ASSOC_FSM_PEER_REASSOC_REQ     drop
	MT2_CLS3ERR              cls3err_action
    ==========================================================================
 */
VOID ActionStateMachineInit(
	IN RTMP_ADAPTER * pAd,
	IN STATE_MACHINE * S,
	OUT STATE_MACHINE_FUNC Trans[])
{
	StateMachineInit(S, (STATE_MACHINE_FUNC *)Trans, MAX_ACT_STATE, MAX_ACT_MSG, (STATE_MACHINE_FUNC)Drop, ACT_IDLE, ACT_MACHINE_BASE);
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_SPECTRUM_CATE, (STATE_MACHINE_FUNC)PeerSpectrumAction);
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_QOS_CATE, (STATE_MACHINE_FUNC)PeerQOSAction);
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_DLS_CATE, (STATE_MACHINE_FUNC)ReservedAction);
#ifdef DOT11_N_SUPPORT
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_BA_CATE, (STATE_MACHINE_FUNC)PeerBAAction);
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_HT_CATE, (STATE_MACHINE_FUNC)PeerHTAction);
#ifdef DOT11_VHT_AC
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_VHT_CATE, (STATE_MACHINE_FUNC)PeerVHTAction);
#endif /* DOT11_VHT_AC */
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_ADD_BA_CATE, (STATE_MACHINE_FUNC)MlmeADDBAAction);
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_ORI_DELBA_CATE, (STATE_MACHINE_FUNC)MlmeDELBAAction);
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_REC_DELBA_CATE, (STATE_MACHINE_FUNC)MlmeDELBAAction);
#endif /* DOT11_N_SUPPORT */
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_PUBLIC_CATE, (STATE_MACHINE_FUNC)PeerPublicAction);
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_PD_CATE, (STATE_MACHINE_FUNC)PeerPublicAction);
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_RM_CATE, (STATE_MACHINE_FUNC)PeerRMAction);
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_QOS_CATE, (STATE_MACHINE_FUNC)MlmeQOSAction);
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_DLS_CATE, (STATE_MACHINE_FUNC)MlmeDLSAction);
	StateMachineSetAction(S, ACT_IDLE, MT2_ACT_INVALID, (STATE_MACHINE_FUNC)MlmeInvalidAction);
#ifdef CONFIG_AP_SUPPORT
#ifdef DOT11R_FT_SUPPORT
	StateMachineSetAction(S, ACT_IDLE, FT_CATEGORY_BSS_TRANSITION, (STATE_MACHINE_FUNC)FT_FtAction);
#endif /* DOT11R_FT_SUPPORT */
#endif /* CONFIG_AP_SUPPORT */
#ifdef DOT11W_PMF_SUPPORT
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_PMF_CATE, (STATE_MACHINE_FUNC)PMF_PeerAction);
#endif /* DOT11W_PMF_SUPPORT */
#ifdef CONFIG_DOT11V_WNM
	StateMachineSetAction(S, ACT_IDLE, CATEGORY_WNM, (STATE_MACHINE_FUNC)PeerWNMAction);
#endif /* CONFIG_DOT11V_WNM */
#ifdef DOT11_HE_AX
#ifdef WIFI_TWT_SUPPORT
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_S1G_CATE, (STATE_MACHINE_FUNC)peer_twt_action);
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_TWT_TEARDOWN_TWT, (STATE_MACHINE_FUNC)mlme_twt_teardown_action);
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_TWT_RESUME_INFO, (STATE_MACHINE_FUNC)mlme_twt_resume_info_action);
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_TWT_JOIN_BTWT, (STATE_MACHINE_FUNC)mlme_twt_handle_btwt_join_action);
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_WAIT_ACK_STS, (STATE_MACHINE_FUNC)mlme_twt_wait_ack_action);
#ifdef APCLI_SUPPORT
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_S1G_CATE_TWT_SETUP, (STATE_MACHINE_FUNC)twtMlmeSetupAction);
#endif /* APCLI_SUPPORT */
#endif /* WIFI_TWT_SUPPORT */
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_WNM_EVT_REPORT, (STATE_MACHINE_FUNC)sta_send_event_report);
#endif
	StateMachineSetAction(S, ACT_IDLE, CATEGORY_PD, (STATE_MACHINE_FUNC)PeerPublicAction);

#ifdef QOS_R1
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_ROBUST_AV_CATE, (STATE_MACHINE_FUNC)QoS_PeerRobust_AV_Action);
#if defined(MSCS_PROPRIETARY) || defined(QOS_R2)
	StateMachineSetAction(S, ACT_IDLE, MT2_CATEGORY_VSP, (STATE_MACHINE_FUNC)Peer_Vendor_Spec_Action);
#endif
#ifdef MSCS_PROPRIETARY
	StateMachineSetAction(S, ACT_IDLE, MT2_MLME_DABS_CFG_TIMEOUT, (STATE_MACHINE_FUNC)Peer_DABS_Cfg_Timeout);
#endif
#endif
#ifdef DOT11_EHT_BE
	StateMachineSetAction(S, ACT_IDLE, MT2_PEER_PROTECTED_EHT_CATE, (STATE_MACHINE_FUNC)PeerProtectEHTAction);
#endif /* DOT11_EHT_BE */
}

BOOLEAN act_fsm_state_transition(struct _RTMP_ADAPTER *ad, struct wifi_dev *wdev, ULONG NextState)
{
	ULONG OldState = 0;

	OldState = ad->Mlme.ActMachine.CurrState;
	ad->Mlme.ActMachine.CurrState = NextState;

	MTWF_DBG(ad, DBG_CAT_PROTO, CATPROTO_ACTION, DBG_LVL_INFO,
		"ACT: [%s] \t==============================================> [%s]\n",
		ACT_FSM_STATE_STR[OldState],
		ACT_FSM_STATE_STR[NextState]);

	return TRUE;
}

#ifdef DOT11_N_SUPPORT
VOID MlmeADDBAAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	MLME_ADDBA_REQ_STRUCT *pInfo;
	PUCHAR pOutBuffer = NULL;
	FRAME_ADDBA_REQ Frame;
	ULONG FrameLen;
	MAC_TABLE_ENTRY *pEntry = NULL;
	STA_TR_ENTRY *tr_entry;
	struct wifi_dev *wdev;

	if (MlmeAddBAReqSanity(pAd, Elem->Msg, Elem->MsgLen) != TRUE)
		return;

	pInfo = (MLME_ADDBA_REQ_STRUCT *)Elem->Msg;
	pEntry = entry_get(pAd, pInfo->Wcid);
	if (!pEntry) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR,
				"Abnormal: pEntry is NULL!\n");
		return;
	}
	tr_entry = tr_entry_get(pAd, pInfo->Wcid);

	if (pEntry->wdev == NULL) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR,
				"pEntry->wdev is NULL!\n");
		return;
	}
	wdev = pEntry->wdev;

	NdisZeroMemory(&Frame, sizeof(FRAME_ADDBA_REQ));

	if (MlmeAllocateMemory(pAd, &pOutBuffer) != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_INFO,
			"BA - allocate memory failed\n");
		return;
	}

#ifdef DOT11W_PMF_SUPPORT
	if ((pEntry->SecConfig.PmfCfg.UsePMFConnect == TRUE) &&
		(tr_entry->PortSecured != WPA_802_1X_PORT_SECURED)) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR,
			"PMF connection, Ignore AddBaReq Send DUE TO NOT IN PORTSECURED\n");
		MlmeFreeMemory(pOutBuffer);
		return;
	}
#endif /* DOT11W_PMF_SUPPORT */

	ActHeaderInit(pAd, &Frame.Hdr, pInfo->pAddr, wdev->if_addr, wdev->bssid);

	Frame.Category = CATEGORY_BA;
	Frame.Action = ADDBA_REQ;
	Frame.BaParm.AMSDUSupported = pInfo->amsdu_support;
	Frame.BaParm.BAPolicy = IMMED_BA;
	Frame.BaParm.TID = pInfo->TID;
	Frame.BaParm.BufSize = (pInfo->BaBufSize & 0x03FF);
	Frame.Token = pInfo->Token;
	Frame.TimeOutValue = pInfo->TimeOutValue;
	Frame.BaStartSeq.field.FragNum = 0;

	{
		UCHAR use_sw_query = 0;

		chip_do_extra_action(pAd, NULL, NULL, CHIP_EXTRA_ACTION_ADDBA_SSN, &use_sw_query, NULL);
		Frame.BaStartSeq.field.StartSeq = (use_sw_query ? chip_get_tid_sn(pAd, pInfo->Wcid, pInfo->TID) : 0);
	}

#ifdef UNALIGNMENT_SUPPORT
	{
		BA_PARM tmpBaParm;

		NdisMoveMemory((PUCHAR)(&tmpBaParm), (PUCHAR)(&Frame.BaParm), sizeof(BA_PARM));
		*(USHORT *)(&tmpBaParm) = cpu2le16(*(USHORT *)(&tmpBaParm));
		NdisMoveMemory((PUCHAR)(&Frame.BaParm), (PUCHAR)(&tmpBaParm), sizeof(BA_PARM));
	}
#else
	*(USHORT *)(&(Frame.BaParm)) = cpu2le16((*(USHORT *)(&(Frame.BaParm))));
#endif /* UNALIGNMENT_SUPPORT */
	Frame.TimeOutValue = cpu2le16(Frame.TimeOutValue);
	Frame.BaStartSeq.word = cpu2le16(Frame.BaStartSeq.word);
	MakeOutgoingFrame(pOutBuffer, &FrameLen,
					  sizeof(FRAME_ADDBA_REQ), &Frame,
					  END_OF_ARGS);
#ifdef DOT11_EHT_BE
	if (pInfo->BaBufSize & 0x1C00) {
		UINT8 addba_ext_ie = IE_ADDBA_EXT;
		UINT8 addba_ext_ie_len = 1;
		UINT8 addba_ext_value = 0;
		ULONG TmpLen = 0;

		SET_ADDBA_EXT_BUF_SIZE(
			addba_ext_value,
			(pInfo->BaBufSize & 0x1C00) >> ADDBA_BUF_SIZE_BITS);
		MakeOutgoingFrame(pOutBuffer + FrameLen, &TmpLen,
				1, &addba_ext_ie,
				1, &addba_ext_ie_len,
				1, &addba_ext_value,
				END_OF_ARGS);
		FrameLen += TmpLen;
	}
#endif /* DOT11_EHT_BE */
	MiniportMMRequest(pAd, (MGMT_USE_QUEUE_FLAG | WMM_UP2AC_MAP[pInfo->TID]), pOutBuffer, FrameLen, NULL);
	MlmeFreeMemory(pOutBuffer);
	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_INFO,
			 "BA - Send ADDBA request. StartSeq = %x,  FrameLen = %ld. BufSize = %d\n",
			  Frame.BaStartSeq.field.StartSeq, FrameLen, pInfo->BaBufSize);
}


/*
    ==========================================================================
    Description:
	send DELBA and delete BaEntry if any
    Parametrs:
	Elem - MLME message MLME_DELBA_REQ_STRUCT

	IRQL = DISPATCH_LEVEL

    ==========================================================================
 */
VOID MlmeDELBAAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	MLME_DELBA_REQ_STRUCT *pInfo;
	PUCHAR pOutBuffer = NULL;
	FRAME_DELBA_REQ Frame;
	ULONG FrameLen;
	MAC_TABLE_ENTRY *pEntry = NULL;
	struct wifi_dev *wdev;
	UCHAR *src_addr = NULL;

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_INFO, "\n");

	if (MlmeDelBAReqSanity(pAd, Elem->Msg, Elem->MsgLen) != TRUE)
		return;

	pInfo = (MLME_DELBA_REQ_STRUCT *)Elem->Msg;
	NdisZeroMemory(&Frame, sizeof(FRAME_DELBA_REQ));

	if (MlmeAllocateMemory(pAd, &pOutBuffer) != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR,
			"BA - allocate memory failed.\n");
		return;
	}

	pEntry = entry_get(pAd, pInfo->Wcid);

	if (!pEntry || !pEntry->wdev) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR,
			"No binding wdev for wcid(%d)\n", pInfo->Wcid);
		MlmeFreeMemory(pOutBuffer);
		return;
	}

	wdev = pEntry->wdev;
	src_addr = wdev->if_addr;

	/* SEND DELBA FRAME*/
	FrameLen = 0;
	ActHeaderInit(pAd, &Frame.Hdr, pEntry->Addr, src_addr, pEntry->wdev->bssid);
	Frame.Category = CATEGORY_BA;
	Frame.Action = DELBA;
	Frame.DelbaParm.Initiator = pInfo->Initiator;
	Frame.DelbaParm.TID = pInfo->TID;
	Frame.ReasonCode = REASON_TIMEOUT;
	*(USHORT *)(&Frame.DelbaParm) = cpu2le16(*(USHORT *)(&Frame.DelbaParm));
	Frame.ReasonCode = cpu2le16(Frame.ReasonCode);
	MakeOutgoingFrame(pOutBuffer, &FrameLen,
			  sizeof(FRAME_DELBA_REQ), &Frame,
			  END_OF_ARGS);
	MiniportMMRequest(pAd, (MGMT_USE_QUEUE_FLAG | WMM_UP2AC_MAP[pInfo->TID]),
			  pOutBuffer, FrameLen, NULL);
	MlmeFreeMemory(pOutBuffer);
	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_INFO,
		"Initiator = %d DELBA sent\n", pInfo->Initiator);
}

VOID mlme_send_addba_resp(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	PUCHAR pOutBuffer = NULL;
	FRAME_ADDBA_RSP ADDframe;
	MAC_TABLE_ENTRY *pEntry;
	MLME_ADDBA_RESP_STRUCT *pInfo;
	UCHAR *pAddr;
	ULONG FrameLen;
	struct wifi_dev *wdev = Elem->wdev;
#ifdef CONFIG_STA_SUPPORT
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);
#endif

	if (!wdev)
		return;

	if (mlme_addba_resp_sanity(pAd, Elem->Msg, Elem->MsgLen) != TRUE)
		return;

	if (MlmeAllocateMemory(pAd, &pOutBuffer) != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_INFO, "ACTION - PeerBAAction() allocate memory failed\n");
		return;
	}

	NdisZeroMemory(&ADDframe, sizeof(FRAME_ADDBA_RSP));

	pInfo = (MLME_ADDBA_RESP_STRUCT *)Elem->Msg;
	pEntry = entry_get(pAd, pInfo->wcid);
	if (!pEntry) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR,
			"Abnormal: pEntry is NULL.\n");
		MlmeFreeMemory(pOutBuffer);
		return;
	}
	pAddr = pInfo->addr;

#ifdef CONFIG_AP_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_AP(pAd) {
		UCHAR apidx;
#ifdef CONFIG_STA_SUPPORT

		if (IS_ENTRY_PEER_AP(pEntry) || IS_ENTRY_REPEATER(pEntry))
			ActHeaderInit(pAd, &ADDframe.Hdr, pAddr, wdev->if_addr, pAddr);
		else
#endif /* CONFIG_STA_SUPPORT */
#ifdef WDS_SUPPORT
			if (IS_ENTRY_WDS(pEntry))
				ActHeaderInit(pAd, &ADDframe.Hdr, pAddr, wdev->if_addr, pAddr);
			else
#endif /* WDS_SUPPORT */
			{
				apidx = pEntry->func_tb_idx;
				if (apidx >= MAX_BEACON_NUM) {
					MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR,
							"error AP index \n");
					MlmeFreeMemory(pOutBuffer);
					return;
				}
				ActHeaderInit(pAd, &ADDframe.Hdr, pAddr, pAd->ApCfg.MBSSID[apidx].wdev.if_addr, pAd->ApCfg.MBSSID[apidx].wdev.bssid);
			}
	}

#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
		if (!pStaCfg) {
			MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR,
					"pStaCfg is NULL\n");
			MlmeFreeMemory(pOutBuffer);
			return;
		}
		if (ADHOC_ON(pAd))
			ActHeaderInit(pAd, &ADDframe.Hdr, pAddr, pStaCfg->wdev.if_addr, pStaCfg->Bssid);
		else
			ActHeaderInit(pAd, &ADDframe.Hdr, pStaCfg->Bssid, pStaCfg->wdev.if_addr, pAddr);
	}
#endif /* CONFIG_STA_SUPPORT */

	ADDframe.Category = CATEGORY_BA;
	ADDframe.Action = ADDBA_RESP;
	ADDframe.Token = pInfo->token;
	ADDframe.StatusCode = pInfo->status;
	ADDframe.BaParm.BAPolicy = IMMED_BA;
	ADDframe.BaParm.AMSDUSupported = pInfo->amsdu_support;
	ADDframe.BaParm.TID = pInfo->tid;
	ADDframe.BaParm.BufSize = (pInfo->buf_size & 0x03FF);
	ADDframe.TimeOutValue = pInfo->timeout;

#ifdef UNALIGNMENT_SUPPORT
	{
		BA_PARM tmpBaParm;

		NdisMoveMemory((PUCHAR)(&tmpBaParm), (PUCHAR)(&ADDframe.BaParm), sizeof(BA_PARM));
		*(USHORT *)(&tmpBaParm) = cpu2le16(*(USHORT *)(&tmpBaParm));
		NdisMoveMemory((PUCHAR)(&ADDframe.BaParm), (PUCHAR)(&tmpBaParm), sizeof(BA_PARM));
	}
#else
	*(USHORT *)(&ADDframe.BaParm) = cpu2le16(*(USHORT *)(&ADDframe.BaParm));
#endif /* UNALIGNMENT_SUPPORT */
	ADDframe.StatusCode = cpu2le16(ADDframe.StatusCode);
	ADDframe.TimeOutValue = cpu2le16(ADDframe.TimeOutValue);
	MakeOutgoingFrame(pOutBuffer,               &FrameLen,
					  sizeof(FRAME_ADDBA_RSP),  &ADDframe,
					  END_OF_ARGS);
#ifdef DOT11_EHT_BE
	if (pInfo->buf_size & 0x1C00) {
		UINT8 addba_ext_ie = IE_ADDBA_EXT;
		UINT8 addba_ext_ie_len = 1;
		UINT8 addba_ext_value = 0;
		ULONG TmpLen = 0;

		SET_ADDBA_EXT_BUF_SIZE(
			addba_ext_value,
			(pInfo->buf_size & 0x1C00) >> ADDBA_BUF_SIZE_BITS);
		MakeOutgoingFrame(pOutBuffer + FrameLen, &TmpLen,
				1, &addba_ext_ie,
				1, &addba_ext_ie_len,
				1, &addba_ext_value,
				END_OF_ARGS);
		FrameLen += TmpLen;
	}
#endif /* DOT11_EHT_BE */

	if (pInfo->tid < ARRAY_SIZE(WMM_UP2AC_MAP))
		MiniportMMRequest(pAd, (MGMT_USE_QUEUE_FLAG | WMM_UP2AC_MAP[pInfo->tid]),
			pOutBuffer, FrameLen, NULL);
	else
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_INFO,
			"out of bound. wcid(%d): TID(%d)<==\n", Elem->Wcid, pInfo->tid);
	MlmeFreeMemory(pOutBuffer);

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_INFO, "(%d): TID(%d), BufSize(%d) <==\n",
			Elem->Wcid, ADDframe.BaParm.TID, ADDframe.BaParm.BufSize);
}

#endif /* DOT11_N_SUPPORT */


VOID MlmeQOSAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
#if defined(CONFIG_AP_SUPPORT) && defined(CONFIG_HOTSPOT_R2)
	MLME_QOS_ACTION_STRUCT *pInfo;
	PUCHAR			pOutBuffer = NULL;
	ULONG			FrameLen = 0;
	NDIS_STATUS	NStatus;
	FRAME_ACTION_HDR	Frame;

	pInfo = (MLME_QOS_ACTION_STRUCT *)Elem->Msg;
	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);  /*Get an unused nonpaged memory*/

	if (NStatus != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HS_R2, DBG_LVL_ERROR,
			"ACT - allocate memory failed\n");
		return;
	}

	if (pInfo->ActionField == ACTION_QOSMAP_CONFIG) {
		UCHAR OosMapIE = IE_QOS_MAP_SET;
		QOSMAP_SET *pQosMapBuf = &pInfo->QOSMap;
		BSS_STRUCT *mbss = &pAd->ApCfg.MBSSID[pInfo->apidx];
		UCHAR	ielen = 0;

		ActHeaderInit(pAd, &Frame.Hdr, pInfo->Addr, mbss->wdev.bssid, mbss->wdev.bssid);
		Frame.Category = CATEGORY_QOS;
		Frame.Action = ACTION_QOSMAP_CONFIG;
		ielen = pQosMapBuf->DSCP_Field_Len;
		MakeOutgoingFrame(pOutBuffer, &FrameLen,
						  sizeof(FRAME_ACTION_HDR),	  &Frame,
						  1,			&OosMapIE,
						  1,			&ielen,
						  ielen,		pQosMapBuf->DSCP_Field,
						  END_OF_ARGS);
		MiniportMMRequest(pAd, QID_AC_BE, pOutBuffer, FrameLen, NULL);
	}

	MlmeFreeMemory(pOutBuffer);
#endif /* defined(CONFIG_AP_SUPPORT) && defined(CONFIG_HOTSPOT_R2) */
}


VOID MlmeDLSAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
}


VOID MlmeInvalidAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	PFRAME_802_11 frame = (PFRAME_802_11)&Elem->Msg;
	/* Bypass HTC len 4 bytes */
	UINT8 htc_len = (frame->Hdr.FC.Order) ? 4 : 0;
	UINT8 Category = 0, Action = 0;

	if (htc_len) {
		NdisMoveMemory((void *)(Elem->Msg + LENGTH_802_11),
			(void *)(Elem->Msg + LENGTH_802_11 + htc_len),
			(Elem->MsgLen - htc_len));
	}

	Category = Elem->Msg[LENGTH_802_11];
	Action = Elem->Msg[LENGTH_802_11 + 1];


}


VOID PeerQOSAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
}




#ifdef DOT11_N_SUPPORT
VOID PeerBAAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	PFRAME_802_11 frame = (PFRAME_802_11)&Elem->Msg;
	/* Bypass HTC len 4 bytes */
	UINT8 htc_len = (frame->Hdr.FC.Order) ? 4 : 0;
	UINT8 Action = 0;

	if (htc_len) {
		NdisMoveMemory((void *)(Elem->Msg+LENGTH_802_11),
			(void *)(Elem->Msg+LENGTH_802_11+htc_len),
			(Elem->MsgLen-htc_len));
	}

	Action = Elem->Msg[LENGTH_802_11 + 1];

	switch (Action) {
	case ADDBA_REQ:
		peer_addba_req_action(pAd, Elem);
		break;

	case ADDBA_RESP:
		peer_addba_rsp_action(pAd, Elem);
		break;

	case DELBA:
		peer_delba_action(pAd, Elem);
		break;
	}
}


#ifdef DOT11N_DRAFT3
#ifdef CONFIG_AP_SUPPORT
extern UCHAR get_regulatory_class(IN PRTMP_ADAPTER pAd, UCHAR Channel, USHORT PhyMode, struct wifi_dev *wdev);

VOID ApPublicAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	UCHAR	Action = Elem->Msg[LENGTH_802_11 + 1];
	BSS_2040_COEXIST_IE	 BssCoexist;

	/* Format as in IEEE 7.4.7.2*/
	if (Action == ACTION_BSS_2040_COEXIST)
		BssCoexist.word = Elem->Msg[LENGTH_802_11 + 2];
}


VOID SendBSS2040CoexistMgmtAction(
	IN RTMP_ADAPTER *pAd,
	IN UINT16 Wcid,
	IN UCHAR apidx,
	IN UCHAR InfoReq)
{
	UCHAR *pOutBuffer = NULL;
	NDIS_STATUS NStatus;
	FRAME_ACTION_HDR Frame;
	ULONG FrameLen;
	BSS_2040_COEXIST_ELEMENT BssCoexistInfo;
	BSS_2040_INTOLERANT_CH_REPORT BssIntolerantInfo;
	UCHAR *pAddr1;
	struct wifi_dev *wdev = &pAd->ApCfg.MBSSID[apidx].wdev;

	if (wdev) {
		if (WDEV_BSS_STATE(wdev) < BSS_READY) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
					"wdev(%d) bss(%d) not ready (state:%d)!!\n",
					wdev->wdev_idx, apidx, WDEV_BSS_STATE(wdev));
			return;
		}

		if (wlan_config_get_ch_band(wdev) != CMD_CH_BAND_24G)
			return;
	}

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
		"Wcid=%d, apidx=%d, InfoReq=%d!\n",
		Wcid, apidx, InfoReq);
	NdisZeroMemory((PUCHAR)&BssCoexistInfo, sizeof(BSS_2040_COEXIST_ELEMENT));
	NdisZeroMemory((PUCHAR)&BssIntolerantInfo, sizeof(BSS_2040_INTOLERANT_CH_REPORT));
	BssCoexistInfo.ElementID = IE_2040_BSS_COEXIST;
	BssCoexistInfo.Len = 1;
	BssCoexistInfo.BssCoexistIe.word = pAd->CommonCfg.LastBSSCoexist2040.word;
	BssCoexistInfo.BssCoexistIe.field.InfoReq = InfoReq;
	BssIntolerantInfo.ElementID = IE_2040_BSS_INTOLERANT_REPORT;
	BssIntolerantInfo.Len = 1;
	BssIntolerantInfo.RegulatoryClass = get_regulatory_class(pAd, wdev->channel, wdev->PhyMode, wdev);
	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);  /*Get an unused nonpaged memory*/

	if (NStatus != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_ERROR,
			"ACT - allocate memory failed\n");
		return;
	}

	pAddr1 = entry_addr_get(pAd, Wcid);
	ActHeaderInit(pAd, &Frame.Hdr, pAddr1, wdev->if_addr, wdev->bssid);
	Frame.Category = CATEGORY_PUBLIC;
	Frame.Action = ACTION_BSS_2040_COEXIST;
	MakeOutgoingFrame(pOutBuffer, &FrameLen,
					  sizeof(FRAME_ACTION_HDR), &Frame,
					  sizeof(BSS_2040_COEXIST_ELEMENT), &BssCoexistInfo,
					  sizeof(BSS_2040_INTOLERANT_CH_REPORT), &BssIntolerantInfo,
					  END_OF_ARGS);
	MiniportMMRequest(pAd, QID_AC_BE, pOutBuffer, FrameLen, NULL);
	MlmeFreeMemory(pOutBuffer);
	MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
		"ACT - BSSCoexist2040=0x%x\n",
		BssCoexistInfo.BssCoexistIe.word);
}
#endif /* CONFIG_AP_SUPPORT */


#ifdef CONFIG_STA_SUPPORT
VOID StaPublicAction(RTMP_ADAPTER *pAd, BSS_2040_COEXIST_IE *pBssCoexIE, struct wifi_dev *wdev)
{
	MLME_SCAN_REQ_STRUCT ScanReq;
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, wdev);

	ASSERT(pStaCfg);

	if (!pStaCfg)
		return;

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
		"ACTION - StaPeerPublicAction  Bss2040Coexist = %x\n", *((PUCHAR)pBssCoexIE));

	/* AP asks Station to return a 20/40 BSS Coexistence mgmt frame.  So we first starts a scan, then send back 20/40 BSS Coexistence mgmt frame */
	if ((pBssCoexIE->field.InfoReq == 1) && (OPSTATUS_TEST_FLAG(pAd, fOP_STATUS_SCAN_2040))) {
		/* Clear record first.  After scan , will update those bit and send back to transmiter.*/
		pAd->CommonCfg.BSSCoexist2040.field.InfoReq = 1;
		pAd->CommonCfg.BSSCoexist2040.field.Intolerant40 = 0;
		pAd->CommonCfg.BSSCoexist2040.field.BSS20WidthReq = 0;
		/* Clear Trigger event table*/
		TriEventInit(pAd);
		/* Fill out stuff for scan request  and kick to scan*/
		ScanParmFill(pAd, &ScanReq, ZeroSsid, 0, BSS_ANY, SCAN_2040_BSS_COEXIST);
		cntl_scan_request(wdev, &ScanReq);
	}
}

#ifdef DOT11_VHT_AC
VOID StaSendVhtOmnAction(
	IN RTMP_ADAPTER * pAd,
	IN struct wifi_dev *wdev)
{
	UCHAR *pOutBuffer = NULL;
	FRAME_ACTION_HDR frame;
	ULONG frameLen;
	OPERATING_MODE op_mode_ntf;
	UCHAR op_vht_bw = wlan_operate_get_vht_bw(wdev);
	INT8 rx_streams = wlan_operate_get_rx_stream(wdev) - 1;

	if (MlmeAllocateMemory(pAd, &pOutBuffer) != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_INFO,
			"VHT OMN - allocate memory failed\n");
		return;
	}

	if (rx_streams < 0)
		rx_streams = 0;
	else if (rx_streams > 7)
		rx_streams = 7;

	NdisZeroMemory((PUCHAR)&op_mode_ntf, sizeof(OPERATING_MODE));
	op_mode_ntf.rx_nss_type = 0;
	op_mode_ntf.rx_nss = rx_streams;

	if (op_vht_bw == VHT_BW_2040) {
		if (wlan_operate_get_ht_bw(wdev) == HT_BW_40)
			op_mode_ntf.ch_width = 1;
		else
			op_mode_ntf.ch_width = 0;
	} else if (op_vht_bw == VHT_BW_80)
		op_mode_ntf.ch_width = 2;
	else if ((op_vht_bw == VHT_BW_160) ||
			 (op_vht_bw == VHT_BW_8080)) {
		op_mode_ntf.ch_width = 2;
		op_mode_ntf.bw160_bw8080 = 1;
	}

	ActHeaderInit(pAd, &frame.Hdr, wdev->bssid, wdev->if_addr, wdev->bssid);
	frame.Category = CATEGORY_VHT;
	frame.Action = ACT_VHT_OPMODE_NOTIFY;
	MakeOutgoingFrame(pOutBuffer, &frameLen,
					  sizeof(FRAME_ACTION_HDR), &frame,
					  sizeof(OPERATING_MODE), &op_mode_ntf,
					  END_OF_ARGS);
	MiniportMMRequest(pAd, QID_AC_BE, pOutBuffer, frameLen, NULL);
	MlmeFreeMemory(pOutBuffer);
	MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_VHT, DBG_LVL_INFO,
		"ACT - VHT OMN, RxNssType=%d, RxNss=%d, ChBW=%d, BW160/8080=%d\n",
		op_mode_ntf.rx_nss_type, op_mode_ntf.rx_nss, op_mode_ntf.ch_width, op_mode_ntf.bw160_bw8080);
}
#endif /* DOT11_VHT_AC */
#endif /* CONFIG_STA_SUPPORT */

/*
Description : Build Intolerant Channel Rerpot from Trigger event table.
return : how many bytes copied.
*/
ULONG BuildIntolerantChannelRep(RTMP_ADAPTER *pAd, UCHAR *pDest)
{
	ULONG			FrameLen = 0;
	ULONG			ReadOffset = 0;
	UCHAR			i, j, k, idx = 0;
	UCHAR			ChannelList[MAX_TRIGGER_EVENT];
	UCHAR			TmpRegClass;
	UCHAR			RegClassArray[7] = {0, 11, 12, 32, 33, 54, 55}; /* Those regulatory class has channel in 2.4GHz. See Annex J.*/

	RTMPZeroMemory(ChannelList, MAX_TRIGGER_EVENT);

	/* Find every regulatory class*/
	for (k = 0; k < 7; k++) {
		TmpRegClass = RegClassArray[k];
		idx = 0;

		/* Find Channel report with the same regulatory class in 2.4GHz.*/
		for (i = 0; i < pAd->CommonCfg.TriggerEventTab.EventANo; i++) {
			if (pAd->CommonCfg.TriggerEventTab.EventA[i].bValid == TRUE) {
				if (pAd->CommonCfg.TriggerEventTab.EventA[i].RegClass == TmpRegClass) {
					for (j = 0; j < idx; j++) {
						if (ChannelList[j] == (UCHAR)pAd->CommonCfg.TriggerEventTab.EventA[i].Channel)
							break;
					}

					if ((j == idx)) {
						ChannelList[idx] = (UCHAR)pAd->CommonCfg.TriggerEventTab.EventA[i].Channel;
						idx++;
					}

					pAd->CommonCfg.TriggerEventTab.EventA[i].bValid = FALSE;
				}

				MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_DEBUG,
					"ACT - Total Channel number = %d\n", idx);
			}
		}

		/* idx > 0 means this regulatory class has some channel report and need to copy to the pDest.*/
		if (idx > 0) {
			/* For each regaulatory IE report, contains all channels that has the same regulatory class.*/
			*(pDest + ReadOffset) = IE_2040_BSS_INTOLERANT_REPORT;  /* IE*/
			*(pDest + ReadOffset + 1) = 1 + idx;	/* Len = RegClass byte + channel byte.*/
			*(pDest + ReadOffset + 2) = TmpRegClass;	/* Len = RegClass byte + channel byte.*/
			RTMPMoveMemory(pDest + ReadOffset + 3, ChannelList, idx);
			FrameLen += (3 + idx);
			ReadOffset += (3 + idx);
		}
	}

	MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_DEBUG,
		"ACT (Size=%ld)\n", FrameLen);
	hex_dump("ACT-pDestMsg", pDest, FrameLen);
	return FrameLen;
}


/*
	==========================================================================
	Description:
	After scan, Update 20/40 BSS Coexistence IE and send out.
	According to 802.11n D3.03 11.14.10

	Parameters:
	==========================================================================
 */
VOID Update2040CoexistFrameAndNotify(
	IN PRTMP_ADAPTER	pAd,
	IN UINT16  Wcid,
	IN BOOLEAN	bAddIntolerantCha)
{
	BSS_2040_COEXIST_IE		OldValue;

	MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
		"ACT -BSSCoexist2040 = %x. EventANo = %d.\n",
		pAd->CommonCfg.BSSCoexist2040.word,
		pAd->CommonCfg.TriggerEventTab.EventANo);
	OldValue.word = pAd->CommonCfg.BSSCoexist2040.word;
	/* Reset value.*/
	pAd->CommonCfg.BSSCoexist2040.word = 0;

	if (pAd->CommonCfg.TriggerEventTab.EventBCountDown > 0)
		pAd->CommonCfg.BSSCoexist2040.field.BSS20WidthReq = 1;

	if (pAd->CommonCfg.bForty_Mhz_Intolerant == TRUE)
		pAd->CommonCfg.BSSCoexist2040.field.Intolerant40 = 1;

	/* Need to check !!!!*/
	/* How STA will set Intolerant40 if implementation dependent. Now we don't set this bit first!!!!!*/
	/* So Only check BSS20WidthReq change.*/
	/*if (OldValue.field.BSS20WidthReq != pAd->CommonCfg.BSSCoexist2040.field.BSS20WidthReq)*/
	{
		Send2040CoexistAction(pAd, Wcid, bAddIntolerantCha);
	}
}


/*
Description : Send 20/40 BSS Coexistence Action frame If one trigger event is triggered.
*/
VOID Send2040CoexistAction(
	IN RTMP_ADAPTER *pAd,
	IN UINT16 Wcid,
	IN BOOLEAN bAddIntolerantCha)
{
	UCHAR *pOutBuffer = NULL;
	NDIS_STATUS NStatus;
	FRAME_ACTION_HDR Frame;
	ULONG FrameLen;
	UINT32 IntolerantChaRepLen;
	UCHAR HtLen = 1;
#ifdef CONFIG_STA_SUPPORT
	struct wifi_dev *wdev;
	PSTA_ADMIN_CONFIG pStaCfg;
	struct _MAC_TABLE_ENTRY *entry = NULL;
#ifdef APCLI_SUPPORT
	UCHAR apidx = 0;
#endif /* APCLI_SUPPORT */
#endif /* CONFIG_STA_SUPPORT */
	IntolerantChaRepLen = 0;

#ifdef CONFIG_STA_SUPPORT
	entry = entry_get(pAd, Wcid);
	if (!entry) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_ERROR,
			"Abnormal: entry is NULL.\n");
		return;
	}
#endif /* CONFIG_STA_SUPPORT */

	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);  /*Get an unused nonpaged memory*/

	if (NStatus != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_ERROR,
			"ACT - allocate memory failed\n");
		return;
	}

#ifdef CONFIG_STA_SUPPORT
	wdev = entry_wdev_get(pAd, Wcid);
	pStaCfg = GetStaCfgByWdev(pAd, wdev);
	ActHeaderInit(pAd, &Frame.Hdr, entry->Addr, wdev->if_addr, pStaCfg->Bssid);
#ifdef APCLI_SUPPORT
	if (IS_ENTRY_PEER_AP(entry)) {
		apidx = entry_func_tb_idx_get(pAd, Wcid);
		ActHeaderInit(
			pAd, &Frame.Hdr, entry->Addr, pAd->StaCfg[apidx].wdev.if_addr, entry->Addr);
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_DEBUG,
			"\x1b[31m\n"MACSTR" \x1b[m\n",
			MAC2STR(entry->Addr));
	}

#endif /* APCLI_SUPPORT */
#endif /* CONFIG_STA_SUPPORT */
	Frame.Category = CATEGORY_PUBLIC;
	Frame.Action = ACTION_BSS_2040_COEXIST; /*COEXIST_2040_ACTION;*/
	MakeOutgoingFrame(pOutBuffer,				&FrameLen,
					  sizeof(FRAME_ACTION_HDR),	  &Frame,
					  1,                                &BssCoexistIe,
					  1,                                &HtLen,
					  1,                                &pAd->CommonCfg.BSSCoexist2040.word,
					  END_OF_ARGS);

	if (bAddIntolerantCha == TRUE)
		IntolerantChaRepLen = BuildIntolerantChannelRep(pAd, pOutBuffer + FrameLen);

	/*2009 PF#3: IOT issue with Motorola AP. It will not check the field of BSSCoexist2040.*/
	/*11.14.12 Switching between 40 MHz and 20 MHz*/
	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
		"IntolerantChaRepLen=%d, BSSCoexist2040=0x%x!\n",
		IntolerantChaRepLen, pAd->CommonCfg.BSSCoexist2040.word);

	if (!((IntolerantChaRepLen == 0) && (pAd->CommonCfg.BSSCoexist2040.word == 0)))
		MiniportMMRequest(pAd, QID_AC_BE, pOutBuffer, FrameLen + IntolerantChaRepLen, NULL);

	MlmeFreeMemory(pOutBuffer);
	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
		"ACT - BSSCoexist2040 = 0x%x\n",
		pAd->CommonCfg.BSSCoexist2040.word);
}

#ifdef CONFIG_STA_SUPPORT
VOID UpdateBssScanParm(RTMP_ADAPTER *pAd, OVERLAP_BSS_SCAN_IE APBssScan)
{
	pAd->CommonCfg.Dot11BssWidthChanTranDelayFactor = le2cpu16(APBssScan.DelayFactor); /*APBssScan.DelayFactor[1] * 256 + APBssScan.DelayFactor[0];*/

	/* out of range defined in MIB... So fall back to default value.*/
	if ((pAd->CommonCfg.Dot11BssWidthChanTranDelayFactor < 5) || (pAd->CommonCfg.Dot11BssWidthChanTranDelayFactor > 100)) {
		pAd->CommonCfg.Dot11BssWidthChanTranDelayFactor = 5;
	}

	pAd->CommonCfg.Dot11BssWidthTriggerScanInt = le2cpu16(APBssScan.TriggerScanInt); /*APBssScan.TriggerScanInt[1] * 256 + APBssScan.TriggerScanInt[0];*/

	/* out of range defined in MIB... So fall back to default value.*/
	if ((pAd->CommonCfg.Dot11BssWidthTriggerScanInt < 10) || (pAd->CommonCfg.Dot11BssWidthTriggerScanInt > 900)) {
		pAd->CommonCfg.Dot11BssWidthTriggerScanInt = 900;
	}

	pAd->CommonCfg.Dot11OBssScanPassiveDwell = le2cpu16(APBssScan.ScanPassiveDwell); /*APBssScan.ScanPassiveDwell[1] * 256 + APBssScan.ScanPassiveDwell[0];*/

	/* out of range defined in MIB... So fall back to default value.*/
	if ((pAd->CommonCfg.Dot11OBssScanPassiveDwell < 5) || (pAd->CommonCfg.Dot11OBssScanPassiveDwell > 1000)) {
		pAd->CommonCfg.Dot11OBssScanPassiveDwell = 20;
	}

	pAd->CommonCfg.Dot11OBssScanActiveDwell = le2cpu16(APBssScan.ScanActiveDwell); /*APBssScan.ScanActiveDwell[1] * 256 + APBssScan.ScanActiveDwell[0];*/

	/* out of range defined in MIB... So fall back to default value.*/
	if ((pAd->CommonCfg.Dot11OBssScanActiveDwell < 10) || (pAd->CommonCfg.Dot11OBssScanActiveDwell > 1000)) {
		pAd->CommonCfg.Dot11OBssScanActiveDwell = 10;
	}

	pAd->CommonCfg.Dot11OBssScanPassiveTotalPerChannel = le2cpu16(APBssScan.PassiveTalPerChannel); /*APBssScan.PassiveTalPerChannel[1] * 256 + APBssScan.PassiveTalPerChannel[0];*/

	/* out of range defined in MIB... So fall back to default value.*/
	if ((pAd->CommonCfg.Dot11OBssScanPassiveTotalPerChannel < 200) || (pAd->CommonCfg.Dot11OBssScanPassiveTotalPerChannel > 10000)) {
		pAd->CommonCfg.Dot11OBssScanPassiveTotalPerChannel = 200;
	}

	pAd->CommonCfg.Dot11OBssScanActiveTotalPerChannel = le2cpu16(APBssScan.ActiveTalPerChannel); /*APBssScan.ActiveTalPerChannel[1] * 256 + APBssScan.ActiveTalPerChannel[0];*/

	/* out of range defined in MIB... So fall back to default value.*/
	if ((pAd->CommonCfg.Dot11OBssScanActiveTotalPerChannel < 20) || (pAd->CommonCfg.Dot11OBssScanActiveTotalPerChannel > 10000)) {
		pAd->CommonCfg.Dot11OBssScanActiveTotalPerChannel = 20;
	}

	pAd->CommonCfg.Dot11OBssScanActivityThre = le2cpu16(APBssScan.ScanActThre); /*APBssScan.ScanActThre[1] * 256 + APBssScan.ScanActThre[0];*/

	/* out of range defined in MIB... So fall back to default value.*/
	if (pAd->CommonCfg.Dot11OBssScanActivityThre > 100) {
		pAd->CommonCfg.Dot11OBssScanActivityThre = 25;
	}

	pAd->CommonCfg.Dot11BssWidthChanTranDelay = (ULONG)(pAd->CommonCfg.Dot11BssWidthTriggerScanInt * pAd->CommonCfg.Dot11BssWidthChanTranDelayFactor);
}

#endif /* CONFIG_STA_SUPPORT */


BOOLEAN ChannelSwitchSanityCheck(
	IN	PRTMP_ADAPTER	pAd,
	IN    UINT16  Wcid,
	IN    UCHAR  NewChannel,
	IN    UCHAR  Secondary)
{
	UCHAR		i;
	struct wifi_dev *wdev = NULL;
	CHANNEL_CTRL *pChCtrl;

	if (!VALID_UCAST_ENTRY_WCID(pAd, Wcid))
		return FALSE;

	wdev = entry_wdev_get(pAd, Wcid);
	pChCtrl = hc_get_channel_ctrl(pAd->hdev_ctrl);
	if ((NewChannel > 7) && (Secondary == 1))
		return FALSE;

	if ((NewChannel < 5) && (Secondary == 3))
		return FALSE;

	/* 0. Check if new channel is in the channellist.*/
	for (i = 0; i < pChCtrl->ChListNum; i++) {
		if (pChCtrl->ChList[i].Channel == NewChannel)
			break;
	}

	if (i == pChCtrl->ChListNum)
		return FALSE;

	return TRUE;
}

static VOID PeerBss2040CoexistAction(
	RTMP_ADAPTER * pAd,
	MLME_QUEUE_ELEM *Elem,
	struct _RTMP_CHIP_CAP *cap,
	PSTA_ADMIN_CONFIG pStaCfg)
{
	BSS_2040_COEXIST_ELEMENT *pCoexistInfo;
	BSS_2040_COEXIST_IE *pBssCoexistIe;
	BSS_2040_INTOLERANT_CH_REPORT *pIntolerantReport = NULL;
	BOOLEAN bNeedFallBack = FALSE;
	CHANNEL_CTRL *pChCtrl = NULL;
#ifdef APCLI_SUPPORT
	struct _MAC_TABLE_ENTRY *entry;
#endif /* APCLI_SUPPORT */

#ifdef CONFIG_AP_SUPPORT
	struct wifi_dev *wdev = NULL;

	if (!VALID_UCAST_ENTRY_WCID(pAd, Elem->Wcid)) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_ERROR,
					" Wrong Wcid:%d !!! need to check the root cause!!!!",
					Elem->Wcid);
		return;
	}

	wdev = entry_wdev_get(pAd, Elem->Wcid);

	if (!wdev) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_ERROR,
					"%s :wdev is NULL!!!!", __func__);
		return;
	}
	if (wlan_config_get_ch_band(wdev) != CMD_CH_BAND_24G) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_NOTICE,
			"not 2G band, ignore 20/40 BSS Coexistence action frame!!\n");
		return;
	}
#endif /* CONFIG_AP_SUPPORT */

	if (Elem->MsgLen <= (LENGTH_802_11 + sizeof(BSS_2040_COEXIST_ELEMENT))) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_ERROR,
			"20/40 BSS Coexistence Management Frame length too short!len=%ld!\n"
			, Elem->MsgLen);
		return;
	}
#ifdef APCLI_SUPPORT
	entry = entry_get(pAd, Elem->Wcid);
	if (!entry || !IS_ENTRY_CLIENT(entry))
		return;
#endif /* APCLI_SUPPORT */

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
		"ACTION - 20/40 BSS Coexistence Management action---->\n");
	hex_dump("CoexistenceMgmtFrame", Elem->Msg, Elem->MsgLen);
	pCoexistInfo = (BSS_2040_COEXIST_ELEMENT *) &Elem->Msg[LENGTH_802_11 + 2];

	if (Elem->MsgLen >= (LENGTH_802_11 + sizeof(BSS_2040_COEXIST_ELEMENT) + sizeof(BSS_2040_INTOLERANT_CH_REPORT)))
		pIntolerantReport = (BSS_2040_INTOLERANT_CH_REPORT *)((PUCHAR)pCoexistInfo + sizeof(BSS_2040_COEXIST_ELEMENT));

	if (
#ifdef BW_VENDOR10_CUSTOM_FEATURE
		IS_APCLI_BW_SYNC_FEATURE_ENBL(pAd) ||
#endif
		pAd->CommonCfg.bBssCoexEnable == FALSE || (pAd->CommonCfg.bForty_Mhz_Intolerant == TRUE)) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
		"20/40 BSS CoexMgmt=%d, bForty_Mhz_Intolerant=%d, ignore this action!!\n",
		pAd->CommonCfg.bBssCoexEnable,
		pAd->CommonCfg.bForty_Mhz_Intolerant);
		return;
	}

	pBssCoexistIe = (BSS_2040_COEXIST_IE *)(&pCoexistInfo->BssCoexistIe);
#ifdef CONFIG_AP_SUPPORT
	if (pAd->OpMode != OPMODE_AP)
		return;
#endif /* CONFIG_AP_SUPPORT */

	pChCtrl = hc_get_channel_ctrl(pAd->hdev_ctrl);

	if ((pBssCoexistIe->field.BSS20WidthReq == 1) || (pBssCoexistIe->field.Intolerant40 == 1)) {
		bNeedFallBack = TRUE;
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
		"BSS_2040_COEXIST: BSS20WidthReq=%d, Intolerant40=%d!\n",
		pBssCoexistIe->field.BSS20WidthReq,
		pBssCoexistIe->field.Intolerant40);
	} else if ((pIntolerantReport) && (pIntolerantReport->Len > 1)) {
		int i;
		UCHAR *ptr;
		INT retVal;
		BSS_COEX_CH_RANGE coexChRange;

		ptr = pIntolerantReport->ChList;
		bNeedFallBack = TRUE;
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
			"The pIntolerantReport len = %d, chlist=",
			pIntolerantReport->Len);

		for (i = 0; i < (pIntolerantReport->Len - 1); i++, ptr++)
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO, "%d,", *ptr);

		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
			"\n");

		retVal = GetBssCoexEffectedChRange(pAd, wdev, &coexChRange, wdev->channel);

		if (retVal == TRUE && coexChRange.effectChStart < MAX_NUM_OF_CHANNELS && coexChRange.effectChEnd < MAX_NUM_OF_CHANNELS) {
			ptr = pIntolerantReport->ChList;
			bNeedFallBack = FALSE;

			if (coexChRange.effectChStart > MAX_NUM_OF_CHANNELS
			|| coexChRange.effectChEnd > MAX_NUM_OF_CHANNELS) {
				MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT,
					DBG_LVL_ERROR,
					"EffectedChRange over range(%d~%d)\n",
					coexChRange.effectChStart, coexChRange.effectChEnd);
				return;
			}
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT,
			DBG_LVL_INFO,
			"Check Channel List in effectedChList(%d~%d)\n",
			pChCtrl->ChList[coexChRange.effectChStart].Channel,
			pChCtrl->ChList[coexChRange.effectChEnd].Channel);

			for (i = 0; i < (pIntolerantReport->Len - 1); i++, ptr++) {
				UCHAR chEntry;

				chEntry = *ptr;

				if (chEntry >= pChCtrl->ChList[coexChRange.effectChStart].Channel &&
					chEntry <= pChCtrl->ChList[coexChRange.effectChEnd].Channel) {
					MTWF_DBG(NULL, DBG_CAT_PROTO,
						CATPROTO_HT, DBG_LVL_INFO,
						"Found in effect range=%d!\n",
						*ptr);
					bNeedFallBack = TRUE;
					break;
				}
			}
			MTWF_DBG(NULL, DBG_CAT_PROTO,
			CATPROTO_HT, DBG_LVL_INFO,
			"After CoexChRange Check, bNeedFallBack=%d!\n",
			bNeedFallBack);
		}

		if (bNeedFallBack) {
			pBssCoexistIe->field.Intolerant40 = 1;
			pBssCoexistIe->field.BSS20WidthReq = 1;
		}
	}

	if (bNeedFallBack) {
		UCHAR apidx;

		NdisMoveMemory((PUCHAR)&pAd->CommonCfg.LastBSSCoexist2040,
						(PUCHAR)pBssCoexistIe,
						sizeof(BSS_2040_COEXIST_IE));
		pAd->CommonCfg.Bss2040CoexistFlag |= BSS_2040_COEXIST_INFO_SYNC;

		/*set bForty_Mhz_Intolerant to TRUE to
		ignore the following BSS_2040_COEXIST Management frame
		to intercept action frame attacks*/
		pAd->CommonCfg.bForty_Mhz_Intolerant = TRUE;

		if (!(pAd->CommonCfg.Bss2040CoexistFlag & BSS_2040_COEXIST_TIMER_FIRED)) {
			MTWF_DBG(NULL, DBG_CAT_PROTO,
			CATPROTO_HT, DBG_LVL_INFO,
			"hire the Bss2040CoexistTimer with timeout=%ld!\n",
				pAd->CommonCfg.Dot11BssWidthChanTranDelay);
			pAd->CommonCfg.Bss2040CoexistFlag |= BSS_2040_COEXIST_TIMER_FIRED;
			/* More 5 sec for the scan report of STAs.*/
			RTMPSetTimer(&pAd->CommonCfg.Bss2040CoexistTimer,
							(pAd->CommonCfg.Dot11BssWidthChanTranDelay) * 1000);
		} else {
			MTWF_DBG(NULL, DBG_CAT_PROTO,
				CATPROTO_HT, DBG_LVL_INFO,
				"Already fallback to 20MHz");
			MTWF_DBG(NULL, DBG_CAT_PROTO,
				CATPROTO_HT, DBG_LVL_INFO,
				", Extend Bss2040CoexistTimer!\n");
			/* More 5 sec for the scan report of STAs.*/
			RTMPModTimer(&pAd->CommonCfg.Bss2040CoexistTimer,
							(pAd->CommonCfg.Dot11BssWidthChanTranDelay) * 1000);
		}

		for (apidx = 0; apidx < pAd->ApCfg.BssidNum; apidx++)
			SendBSS2040CoexistMgmtAction(pAd, MCAST_WCID_TO_REMOVE, apidx, 0);

#ifdef APCLI_SUPPORT
		if (wdev->wdev_type == WDEV_TYPE_STA) {
			UINT16 i;
			MAC_TABLE_ENTRY *pEntry = NULL;

			//find root ap
			for (i = 0; VALID_UCAST_ENTRY_WCID(pAd, i); i++) {
				pEntry = entry_get(pAd, i);
				if ((pEntry->wdev != NULL) && (IS_ENTRY_PEER_AP(pEntry))
					&& is_same_band(pAd, pEntry->wdev)) {
					MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_NOTICE,
						"sending 20/40 coexist frame to root AP.");
					Update2040CoexistFrameAndNotify(pAd, pEntry->wcid, TRUE);
				}
			}
		}

#endif
		if (pAd->CommonCfg.Bss2040CoexistFlag & BSS_2040_COEXIST_INFO_SYNC) {
			UCHAR cfg_ht_bw = wlan_config_get_ht_bw(wdev);
			UCHAR cfg_ext_cha = wlan_config_get_ext_cha(wdev);

			MTWF_DBG(NULL, DBG_CAT_PROTO,
				CATPROTO_HT, DBG_LVL_INFO,
				"DTIM Period reached, BSS20WidthReq=%d, Intolerant40=%d!\n",
				pAd->CommonCfg.LastBSSCoexist2040.field.BSS20WidthReq,
				pAd->CommonCfg.LastBSSCoexist2040.field.Intolerant40);
			pAd->CommonCfg.Bss2040CoexistFlag &= (~BSS_2040_COEXIST_INFO_SYNC);

			if (pAd->CommonCfg.LastBSSCoexist2040.field.BSS20WidthReq ||
				pAd->CommonCfg.LastBSSCoexist2040.field.Intolerant40) {
				wlan_operate_set_ht_bw(wdev, HT_BW_20, EXTCHA_NONE);
			} else {
				/*recover to origin bw & extcha*/
				wlan_operate_set_ht_bw(wdev, cfg_ht_bw, cfg_ext_cha);
			}

			MTWF_DBG(NULL, DBG_CAT_PROTO,
				CATPROTO_HT, DBG_LVL_INFO,
				"\tNow RecomWidth=%d, ExtChanOffset=%d\n",
				wlan_operate_get_ht_bw(wdev),
				wlan_operate_get_ext_cha(wdev));
			pAd->CommonCfg.Bss2040CoexistFlag |= BSS_2040_COEXIST_INFO_NOTIFY;
#ifdef RACTRL_FW_OFFLOAD_SUPPORT

			/* Update BSS2040COEX for pEntry */
			if (cap->fgRateAdaptFWOffload == TRUE) {
				CMD_STAREC_AUTO_RATE_UPDATE_T rRaParam;

				NdisZeroMemory(&rRaParam, sizeof(CMD_STAREC_AUTO_RATE_UPDATE_T));
				rRaParam.u4Field = RA_PARAM_HT_2040_COEX;
				RAParamUpdate(
					pAd, entry, &rRaParam);
			}

#endif /* RACTRL_FW_OFFLOAD_SUPPORT */
		}

		MTWF_DBG(NULL, DBG_CAT_PROTO,
			CATPROTO_HT, DBG_LVL_INFO,
			"2040_COEXIST Update Beacon for idx:%d\n",
			entry->apidx);
		UpdateBeaconHandler(pAd, wdev, BCN_REASON(BCN_UPDATE_IE_CHG));
	}



#ifdef CONFIG_STA_SUPPORT
	IF_DEV_CONFIG_OPMODE_ON_STA(pAd)
	{
		if (INFRA_ON(pStaCfg))
			StaPublicAction(pAd, pBssCoexistIe, Elem->wdev);
	}
#endif /* CONFIG_STA_SUPPORT */

}

#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */

VOID PeerPublicAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	UCHAR Action = Elem->Msg[LENGTH_802_11 + 1];
#ifdef CONFIG_STA_SUPPORT
	PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, Elem->wdev);
#endif
#ifdef CONFIG_AP_SUPPORT
#ifdef RACTRL_FW_OFFLOAD_SUPPORT
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
#endif /* RACTRL_FW_OFFLOAD_SUPPORT */
#endif /* CONFIG_AP_SUPPORT */
#if defined(WAPP_SUPPORT) && defined(CONFIG_AP_SUPPORT) && defined(CONFIG_DOT11U_INTERWORKING)
#ifdef DPP_SUPPORT
	if (!pAd->bDppEnable)
#endif /* DPP_SUPPORT */
		if (!GasEnable(pAd, Elem))
#endif
			if ((!VALID_UCAST_ENTRY_WCID(pAd, Elem->Wcid))
#ifdef FTM_SUPPORT
				&& (Action != ACTION_FTM_REQUEST)
#endif /* FTM_SUPPORT */
			)
				return;

	switch (Action) {
#ifdef DOT11_N_SUPPORT
#ifdef DOT11N_DRAFT3
	case ACTION_BSS_2040_COEXIST:
		PeerBss2040CoexistAction(pAd, Elem, cap, pStaCfg);
	break;
#endif /* DOT11N_DRAFT3 */
#endif /* DOT11_N_SUPPORT */

#ifdef CONFIG_AP_SUPPORT
#ifdef WAPP_SUPPORT
#ifdef CONFIG_DOT11U_INTERWORKING
	case ACTION_GAS_INIT_REQ:
		if (GasEnable(pAd, Elem)
#ifdef DPP_SUPPORT
		    || pAd->bDppEnable			/* Bypassing Gas Enable Check for DPP Gas Frames */
#endif /* DPP_SUPPORT */
		   )
			ReceiveGASInitReq(pAd, Elem);

		break;

#ifdef DPP_SUPPORT
	case ACTION_GAS_INIT_RSP:
		DPP_ReceiveGASInitRsp(pAd, Elem);
		break;
	case ACTION_GAS_CB_RSP:
		DPP_ReceiveGASCBResp(pAd, Elem);
		break;
#endif /* DPP_SUPPORT */

	case ACTION_GAS_CB_REQ:
#ifdef DPP_SUPPORT
			DPP_ReceiveGASCBReq(pAd, Elem);
#endif /* DPP_SUPPORT */
		if (GasEnable(pAd, Elem)
#ifdef MAP_R3
		&& ((IS_MAP_ENABLE(pAd) && !IS_MAP_CERT_ENABLE(pAd))
		|| !IS_MAP_ENABLE(pAd))
#endif /* MAP_R3 */
		)
			ReceiveGASCBReq(pAd, Elem);

		break;
#endif /* CONFIG_DOT11U_INTERWORKING */
#endif /* WAPP_SUPPORT */
#endif /* CONFIG_AP_SUPPORT */

	case ACTION_WIFI_DIRECT:
#ifdef DPP_SUPPORT
		if (NdisEqualMemory(&(Elem->Msg[LENGTH_802_11 + 2]), DPP_OUI, OUI_LEN) &&
			Elem->Msg[LENGTH_802_11 + 5] == WFA_DPP_SUBTYPE) {
			if (pAd->bDppEnable) {
				wext_send_dpp_action_frame(pAd, Elem->wdev, &Elem->Msg[10], Elem->Channel,
							  Elem->Msg, Elem->MsgLen, 0);
				MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_DPP, DBG_LVL_INFO,
					"got one DPP puplic action frame\n");
			} else
				MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_DPP, DBG_LVL_INFO,
					"DPP Disabled DPP puplic action frame not sent to WAPP\n");
			break;
		}
#endif /* DPP_SUPPORT */
#ifdef RT_CFG80211_SUPPORT
#endif

		break;

#ifdef FTM_SUPPORT
	case ACTION_FTM_REQUEST:
	{
		if (Elem->wdev->FtmCtrl.FtmEnable & ENABLE_MC_RSTA)
			ReceiveFTMReq(pAd, Elem);
		else
			MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_FTM, DBG_LVL_ERROR,
				"haven't enable FTM responder: mwctl dev <devname> set ftm enable=1\n");
		break;
	}
#endif /* FTM_SUPPORT */

	default:
		break;
	}
}


static VOID ReservedAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	UCHAR Category;

	if (Elem->MsgLen <= LENGTH_802_11)
		return;

	Category = Elem->Msg[LENGTH_802_11];
	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_ACTION, DBG_LVL_INFO,
		"Rcv reserved category(%d) Action Frame\n", Category);
	hex_dump("Reserved Action Frame", &Elem->Msg[0], Elem->MsgLen);
}


VOID PeerRMAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
#ifdef DOT11K_RRM_SUPPORT
	UCHAR Action = Elem->Msg[LENGTH_802_11 + 1];
	MAC_TABLE_ENTRY *pEntry = NULL;

	if (VALID_UCAST_ENTRY_WCID(pAd, Elem->Wcid))
		pEntry = entry_get(pAd, Elem->Wcid);
	else
		return;

	if (!pEntry || !(pEntry->wdev))
		return;

	if (!IS_RRM_ENABLE(pEntry->wdev))
		return;

	switch (Action) {
#ifdef CONFIG_AP_SUPPORT
	case RRM_MEASURE_REP:
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_RRM, DBG_LVL_INFO,
			"Get RRM Measure report.\n");
		RRM_PeerMeasureRepAction(pAd, Elem);
		break;

	case RRM_NEIGHTBOR_REQ:
		RRM_PeerNeighborReqAction(pAd, Elem);
		break;
#endif /* CONFIG_AP_SUPPORT */
#ifdef CONFIG_STA_SUPPORT
	case RRM_MEASURE_REQ:
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_RRM, DBG_LVL_INFO,
			"Get RRM Measure request.\n");
		RRM_PeerMeasureReqAction(pAd, Elem);
		break;
#endif /* CONFIG_STA_SUPPORT */
	}

#endif /* DOT11K_RRM_SUPPORT */
	return;
}


#ifdef DOT11_N_SUPPORT

#ifdef CONFIG_AP_SUPPORT
#ifdef DOT11N_DRAFT3
VOID SendNotifyBWActionFrame(RTMP_ADAPTER *pAd, UINT16 Wcid, UCHAR apidx)
{
	UCHAR *pOutBuffer = NULL, *pAddr1;
	NDIS_STATUS NStatus;
	FRAME_ACTION_HDR Frame;
	ULONG FrameLen;
	struct wifi_dev *wdev;
	UCHAR op_ht_bw;

	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);  /* Get an unused nonpaged memory */

	if (NStatus != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_ERROR,
			"ACT - SendNotifyBWAction() allocate memory failed\n");
		return;
	}

	pAddr1 = entry_addr_get(pAd, Wcid);
	wdev = &pAd->ApCfg.MBSSID[apidx].wdev;
	op_ht_bw = wlan_operate_get_ht_bw(wdev);
	ActHeaderInit(pAd, &Frame.Hdr, pAddr1, wdev->if_addr, wdev->bssid);
	Frame.Category = CATEGORY_HT;
	Frame.Action = NOTIFY_BW_ACTION;
	MakeOutgoingFrame(pOutBuffer, &FrameLen,
					  sizeof(FRAME_ACTION_HDR), &Frame,
					  END_OF_ARGS);
	*(pOutBuffer + FrameLen) = op_ht_bw;
	FrameLen++;
	MiniportMMRequest(pAd, QID_AC_BE, pOutBuffer, FrameLen, NULL);
	MlmeFreeMemory(pOutBuffer);
	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
		"ACT - SendNotifyBWAction(NotifyBW= %d)!\n", op_ht_bw);
}
#endif /* DOT11N_DRAFT3 */
#endif /* CONFIG_AP_SUPPORT */


VOID PeerHTAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	UCHAR Action = Elem->Msg[LENGTH_802_11 + 1];
	MAC_TABLE_ENTRY *pEntry;
	UCHAR oldMmpsMode;
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);

	if (!VALID_UCAST_ENTRY_WCID(pAd, Elem->Wcid))
		return;

	pEntry = entry_get(pAd, Elem->Wcid);
	if (!pEntry) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_ERROR,
			"Abnormal: pEntry is NULL.\n");
		return;
	}

	switch (Action) {
	case NOTIFY_BW_ACTION:
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_DEBUG,
			"ACTION - HT Notify Channel bandwidth action---->\n");
#ifdef CONFIG_STA_SUPPORT
		IF_DEV_CONFIG_OPMODE_ON_STA(pAd) {
			PSTA_ADMIN_CONFIG pStaCfg = GetStaCfgByWdev(pAd, pEntry->wdev);

			if (!pStaCfg || pStaCfg->StaActive.SupportedPhyInfo.bHtEnable == FALSE) {
				/* Note, this is to patch DIR-1353 AP. When the AP set to Wep, it will use legacy mode. But AP still keeps */
				/* sending BW_Notify Action frame, and cause us to linkup and linkdown. */
				/* In legacy mode, don't need to parse HT action frame.*/
				MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
				"ACTION -Ignore HT Notify Channel BW when link as legacy mode. BW = %d--->\n",
				Elem->Msg[LENGTH_802_11 + 2]);
				break;
			}
		}
#endif /* CONFIG_STA_SUPPORT */

		if (Elem->Msg[LENGTH_802_11 + 2] == 0)	/* 7.4.8.2. if value is 1, keep the same as supported channel bandwidth. */
			pEntry->HTPhyMode.field.BW = HT_BW_20;
		else {
			pEntry->HTPhyMode.field.BW = (pEntry->wdev) ? (pEntry->MaxHTPhyMode.field.BW &
										 (wlan_config_get_ht_bw(pEntry->wdev))) : (pEntry->MaxHTPhyMode.field.BW);
		}

		break;

	case SMPS_ACTION:
		/* 7.3.1.25*/
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
			"ACTION - SMPS action---->\n");
		oldMmpsMode = pEntry->MmpsMode;

		if (((Elem->Msg[LENGTH_802_11 + 2] & 0x1) == 0))
			pEntry->MmpsMode = MMPS_DISABLE;
		else if (((Elem->Msg[LENGTH_802_11 + 2] & 0x2) == 0))
			pEntry->MmpsMode = MMPS_STATIC;
		else
			pEntry->MmpsMode = MMPS_DYNAMIC;

		if (oldMmpsMode != pEntry->MmpsMode) {
			if (pEntry->MmpsMode == MMPS_DYNAMIC) {
#ifdef MT_MAC
				AsicSetSMPS(pAd, pEntry->wcid, 1);
#endif /* MT_MAC */
			} else {
#ifdef MT_MAC
				AsicSetSMPS(pAd, pEntry->wcid, 0);
#endif /* MT_MAC */
			}

#ifdef CONFIG_AP_SUPPORT
#ifdef RACTRL_FW_OFFLOAD_SUPPORT

			if (cap->fgRateAdaptFWOffload == TRUE) {
				CMD_STAREC_AUTO_RATE_UPDATE_T rRaParam;

				NdisZeroMemory(&rRaParam, sizeof(CMD_STAREC_AUTO_RATE_UPDATE_T));
				rRaParam.u4Field = RA_PARAM_MMPS_UPDATE;
				RAParamUpdate(pAd, pEntry, &rRaParam);
			} else
#endif /* RACTRL_FW_OFFLOAD_SUPPORT */
			{
				IF_DEV_CONFIG_OPMODE_ON_AP(pAd) {
					APMlmeDynamicTxRateSwitching(pAd);
				}
			}

#endif /* CONFIG_AP_SUPPORT */
		}

		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_INFO,
				 "Wcid(%d) MIMO PS = %d, fgRateAdaptFWOffload=%d\n",
				  Elem->Wcid, pEntry->MmpsMode, cap->fgRateAdaptFWOffload);
		break;

	case SETPCO_ACTION:
		break;

	case MIMO_CHA_MEASURE_ACTION:
		break;

	default:
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_HT, DBG_LVL_WARN,
			"Unknown HT Action:%d\n", Action);
		break;
	}
}


#ifdef DOT11_VHT_AC
VOID PeerVHTAction(RTMP_ADAPTER *pAd, MLME_QUEUE_ELEM *Elem)
{
	UCHAR Action = Elem->Msg[LENGTH_802_11 + 1];
#ifdef ZERO_PKT_LOSS_SUPPORT
	UINT i = 0;
	INT ZeroLossStaIndex = -1;
	struct DOT11_H *pDot11h = NULL;
#endif /*ZERO_PKT_LOSS_SUPPORT*/

	if (!VALID_UCAST_ENTRY_WCID(pAd, Elem->Wcid))
		return;

	switch (Action) {
	case ACT_VHT_OPMODE_NOTIFY: {
		OPERATING_MODE *op_mode = (OPERATING_MODE *)&Elem->Msg[LENGTH_802_11 + 2];
		MAC_TABLE_ENTRY *pEntry;
		CMD_STAREC_AUTO_RATE_UPDATE_T rRaParam;

		pEntry = entry_get(pAd, Elem->Wcid);
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_VHT, DBG_LVL_NOTICE,
			"Wcid is %d, pad band is %d\n",
			Elem->Wcid, pAd->BandSel);
		if (pEntry == NULL) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_VHT, DBG_LVL_WARN,
			"pEntry is NULL!!\n");
			return;
		}
		if (pEntry->wdev == NULL) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_VHT, DBG_LVL_WARN,
			"pEntry is %p, pEntry->wdev is NULL!!\n",
			pEntry);
			return;
		}

		if (WMODE_CAP_AX_6G(pEntry->wdev->PhyMode)) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_VHT, DBG_LVL_WARN,
				"ACTION - Operating Mode Notification at invalid band\n");
			return;
		}

		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_VHT, DBG_LVL_INFO,
			"ACTION - Operating Mode Notification action---->\n");
		hex_dump("OperatingModeNotify", &Elem->Msg[0], Elem->MsgLen);
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_VHT, DBG_LVL_INFO,
			"\t RxNssType=%d, RxNss=%d, ChBW=%d, BW160/8080=%d\n",
				 op_mode->rx_nss_type, op_mode->rx_nss, op_mode->ch_width, op_mode->bw160_bw8080);
#ifdef ZERO_PKT_LOSS_SUPPORT
		/*Handle: some sta send VHT action frame after switching channel due to CSA*/
		if (pAd->Zero_Loss_Enable == 1) {
			if (pEntry) {
				for (i = 0; i < 3; i++) {
					if (pAd->ZeroLossSta[i].wcid == pEntry->wcid) {
						ZeroLossStaIndex = i;
						break;
					}
				}
			}

			pDot11h = (struct DOT11_H *)pEntry->wdev->pDot11_H;
			if (ZeroLossStaIndex >= 0) {
				if ((pAd->ZeroLossSta[ZeroLossStaIndex].ChnlSwitchSkipTx)
					&& (pDot11h->ChnlSwitchState >= ASIC_CHANNEL_SWITCH_COMMAND_ISSUED)) {
					MAC_TABLE_ENTRY *pEntry = NULL;

					pAd->ZeroLossSta[ZeroLossStaIndex].SendNullFrame = 0;
					pAd->ZeroLossSta[ZeroLossStaIndex].ChnlSwitchSkipTx = 0;
					AsicUpdateSkipTx(pAd, pEntry->wcid, 0); /*reset skip tx*/
					pAd->ZeroLossSta[ZeroLossStaIndex].resume_time = jiffies_to_msecs(jiffies);
					pAd->chan_switch_time[15] = jiffies_to_msecs(jiffies);
					MTWF_DBG(pAd, DBG_CAT_CHN, CATCHN_SCS, DBG_LVL_WARN,
						"Tx Enabled for wcid %d\n", pEntry->wcid);
					return;
				}
			}
		}
#endif /*ZERO_PKT_LOSS_SUPPORT*/

		if (op_mode->rx_nss_type == 0) {
			pEntry->force_op_mode = TRUE;
			NdisMoveMemory(&pEntry->operating_mode, op_mode, 1);
		}

		NdisZeroMemory(&rRaParam, sizeof(CMD_STAREC_AUTO_RATE_UPDATE_T));
		rRaParam.u4Field = RA_PARAM_VHT_OPERATING_MODE;
		RAParamUpdate(pAd, pEntry, &rRaParam);
	}
	break;
#ifdef VHT_TXBF_SUPPORT

	case ACT_VHT_COMPRESS_BF: {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_VHT, DBG_LVL_INFO,
			"ACTION - VHT Compressed Beamforming action---->\n");
		hex_dump("VHT Compressed BF", &Elem->Msg[0], Elem->MsgLen);
		break;
	}

#endif /* VHT_TXBF_SUPPORT */

	default:
		break;
	}
}
#endif /* DOT11_VHT_AC */

VOID SendRefreshBAR(RTMP_ADAPTER *pAd, MAC_TABLE_ENTRY *pEntry, UCHAR TID)
{
	FRAME_BAR FrameBar;
	ULONG FrameLen;
	NDIS_STATUS NStatus;
	UCHAR *pOutBuffer;
	USHORT Sequence = 0;
	struct tr_counter *tr_cnt = &pAd->tr_ctl.tr_cnt;

	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);  /*Get an unused nonpaged memory*/
	if (NStatus != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR,
			"BA - MlmeADDBAAction() allocate memory failed\n");
		return;
	}


	BarHeaderInit(pAd, &FrameBar, pEntry->Addr, pEntry->wdev->if_addr);
	FrameBar.StartingSeq.field.FragNum = 0;
	/* make sure sequence not clear in DEL function.*/
	FrameBar.StartingSeq.field.StartSeq = Sequence;
	FrameBar.BarControl.TID = TID;
	MakeOutgoingFrame(pOutBuffer, &FrameLen, sizeof(FRAME_BAR), &FrameBar, END_OF_ARGS);
	MiniportMMRequest(pAd, (MGMT_USE_QUEUE_FLAG | WMM_UP2AC_MAP[TID]), pOutBuffer, FrameLen, NULL);
	MlmeFreeMemory(pOutBuffer);
	tr_cnt->ba_tx_bar_cnt++;
}
#endif /* DOT11_N_SUPPORT */


VOID ActHeaderInit(
	IN RTMP_ADAPTER *pAd,
	IN OUT PHEADER_802_11 pHdr80211,
	IN UCHAR *da,
	IN UCHAR *sa,
	IN UCHAR *bssid)
{
	NdisZeroMemory(pHdr80211, sizeof(HEADER_802_11));
	pHdr80211->FC.Type = FC_TYPE_MGMT;
	pHdr80211->FC.SubType = SUBTYPE_ACTION;
	COPY_MAC_ADDR(pHdr80211->Addr1, da);
	COPY_MAC_ADDR(pHdr80211->Addr2, sa);
	COPY_MAC_ADDR(pHdr80211->Addr3, bssid);
}


VOID BarHeaderInit(
	IN RTMP_ADAPTER *pAd,
	IN OUT PFRAME_BAR pCntlBar,
	IN PUCHAR pDA,
	IN PUCHAR pSA)
{
	/*	USHORT	Duration;*/
	NdisZeroMemory(pCntlBar, sizeof(FRAME_BAR));
	pCntlBar->FC.Type = FC_TYPE_CNTL;
	pCntlBar->FC.SubType = SUBTYPE_BLOCK_ACK_REQ;
	pCntlBar->BarControl.MTID = 0;
	pCntlBar->BarControl.Compressed = 1;
	pCntlBar->BarControl.ACKPolicy = 0;
	pCntlBar->Duration = 16 + RTMPCalcDuration(pAd, RATE_1, sizeof(FRAME_BAR));
	COPY_MAC_ADDR(pCntlBar->Addr1, pDA);
	COPY_MAC_ADDR(pCntlBar->Addr2, pSA);
}


/*
	==========================================================================
	Description:
		Insert Category and action code into the action frame.

	Parametrs:
		1. frame buffer pointer.
		2. frame length.
		3. category code of the frame.
		4. action code of the frame.

	Return	: None.
	==========================================================================
 */
VOID InsertActField(
	IN PRTMP_ADAPTER pAd,
	OUT PUCHAR pFrameBuf,
	OUT PULONG pFrameLen,
	IN UINT8 Category,
	IN UINT8 ActCode)
{
	ULONG TempLen;

	MakeOutgoingFrame(pFrameBuf,		&TempLen,
					  1,				&Category,
					  1,				&ActCode,
					  END_OF_ARGS);
	*pFrameLen = *pFrameLen + TempLen;
	return;
}

/* Description : Send SMPS Action frame If SMPS mode switches. */
VOID SendSMPSAction(RTMP_ADAPTER *pAd, UINT16 Wcid, UCHAR smps)
{
	struct wifi_dev *wdev;
	MAC_TABLE_ENTRY *pEntry;
	UCHAR *pOutBuffer = NULL;
	NDIS_STATUS NStatus;
	FRAME_SMPS_ACTION Frame;
	ULONG FrameLen;

	if (!VALID_UCAST_ENTRY_WCID(pAd, Wcid)) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR,
			"BA - Invalid WCID(%d)\n",  Wcid);
		return;
	}
	pEntry = entry_get(pAd, Wcid);
	if (!pEntry) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR,
			"Abnormal: pEntry is NULL.\n");
		return;
	}

	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);	 /*Get an unused nonpaged memory*/

	if (NStatus != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR, "BA - MlmeADDBAAction() allocate memory failed\n");
		return;
	}

	wdev = pEntry->wdev;
	if (!wdev) {
		MlmeFreeMemory(pOutBuffer);
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR, "BA - wdev is null\n");
		return;
	}

	ActHeaderInit(pAd, &Frame.Hdr, pEntry->Addr, wdev->if_addr, wdev->bssid);

	Frame.Category = CATEGORY_HT;
	Frame.Action = SMPS_ACTION;

	switch (smps) {
	case MMPS_DISABLE:
		Frame.smps = 0;
		break;

	case MMPS_DYNAMIC:
		Frame.smps = 3;
		break;

	case MMPS_STATIC:
		Frame.smps = 1;
		break;
	}

	MakeOutgoingFrame(pOutBuffer, &FrameLen,
					  sizeof(FRAME_SMPS_ACTION), &Frame,
					  END_OF_ARGS);
	MiniportMMRequest(pAd, QID_AC_BE, pOutBuffer, FrameLen, NULL);
	MlmeFreeMemory(pOutBuffer);
	MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_INFO, "HT - ( %d )\n", Frame.smps);
}


#define RADIO_MEASUREMENT_REQUEST_ACTION	0

typedef struct GNU_PACKED _BEACON_REQUEST {
	UCHAR	RegulatoryClass;
	UCHAR	ChannelNumber;
	USHORT	RandomInterval;
	USHORT	MeasurementDuration;
	UCHAR	MeasurementMode;
	UCHAR   BSSID[MAC_ADDR_LEN];
	UCHAR	ReportingCondition;
	UCHAR	Threshold;
	UCHAR   SSIDIE[2];			/* 2 byte*/
} BEACON_REQUEST;


#ifdef CONFIG_AP_SUPPORT
VOID SendBeaconRequest(RTMP_ADAPTER *pAd, UINT16 Wcid)
{
	UCHAR *pOutBuffer = NULL;
	NDIS_STATUS NStatus;
	FRAME_RM_REQ_ACTION Frame;
	ULONG FrameLen;
	BEACON_REQUEST BeaconReq;
	MEASUREMENT_REQ MeasureReg;
	UCHAR apidx;
	struct _MAC_TABLE_ENTRY *entry;

	entry = entry_get(pAd, Wcid);
	if (!entry || IS_ENTRY_PEER_AP(entry) || IS_ENTRY_REPEATER(entry))
		return;

	NStatus = MlmeAllocateMemory(pAd, &pOutBuffer);	 /*Get an unused nonpaged memory*/

	if (NStatus != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_ERROR, "Radio - SendBeaconRequest() allocate memory failed\n");
		return;
	}

	apidx = entry->apidx;
	ActHeaderInit(pAd, &Frame.Hdr, entry->Addr, pAd->ApCfg.MBSSID[apidx].wdev.if_addr, pAd->ApCfg.MBSSID[apidx].wdev.bssid);
	Frame.Category = CATEGORY_RM;
	Frame.Action = RADIO_MEASUREMENT_REQUEST_ACTION;
	Frame.Token = 1;
	Frame.Repetition = 0;	/* executed once*/
	BeaconReq.RegulatoryClass = 32;		/* ?????*/
	BeaconReq.ChannelNumber = 255;		/* all channels*/
	BeaconReq.RandomInterval = 0;
	BeaconReq.MeasurementDuration = 10;	/* 10 TU*/
	BeaconReq.MeasurementMode = 1;		/* Active mode */
	COPY_MAC_ADDR(BeaconReq.BSSID,	BROADCAST_ADDR);
	BeaconReq.ReportingCondition = 254;	/* report not necesssary*/
	BeaconReq.Threshold = 0;			/* minimum RCPI*/
	BeaconReq.SSIDIE[0] = 0;
	BeaconReq.SSIDIE[1] = 0;			/* wildcard SSID zero length */
	MeasureReg.ID = IE_MEASUREMENT_REQUEST;
	MeasureReg.Token = 0;
	MeasureReg.RequestMode = 0;
	MeasureReg.Type = 5;				/* Beacon Request*/
	MeasureReg.Length = sizeof(MEASUREMENT_REQ) + sizeof(BEACON_REQUEST) - 2;
	MakeOutgoingFrame(pOutBuffer,               &FrameLen,
					  sizeof(FRAME_RM_REQ_ACTION),      &Frame,
					  sizeof(MEASUREMENT_REQ),			&MeasureReg,
					  sizeof(BEACON_REQUEST),			&BeaconReq,
					  END_OF_ARGS);
	MiniportMMRequest(pAd, QID_AC_BE, pOutBuffer, FrameLen, NULL);
	MlmeFreeMemory(pOutBuffer);
	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_BA, DBG_LVL_INFO, "Radio - SendBeaconRequest\n");
}
#endif /* CONFIG_AP_SUPPORT */


#ifdef DOT11_HE_AX
void sta_send_event_report(struct _RTMP_ADAPTER *pAd, struct _MLME_QUEUE_ELEM *Elem)
{
#ifdef CONFIG_DOT11V_WNM
	struct _MLME_WNM_EVT_REPORT_STRUCT *report;
	struct _FRAME_WNM_EVT_REPORT frame;
	struct wifi_dev *wdev;
	UCHAR *buffer = NULL;
	NDIS_STATUS status;
	ULONG frame_len;

	report = (struct _MLME_WNM_EVT_REPORT_STRUCT *)Elem->Msg;
	wdev = report->wdev;

	status = MlmeAllocateMemory(pAd, &buffer);
	if (status != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_WNM, DBG_LVL_ERROR, "WNM event report allocate memory failed\n");
		return;
	}

	os_zero_mem(&frame, sizeof(frame));
	ActHeaderInit(pAd, &frame.Hdr, wdev->bssid, wdev->if_addr, wdev->bssid);
	frame.Category = CATEGORY_WNM;
	frame.Action = EVENT_REPORT;
	frame.Token = report->diag_token;
	frame.Element_ID = report->element_id;
	frame.Length = sizeof(struct _FRAME_WNM_EVT_REPORT) - sizeof(HEADER_802_11) - 5;
	frame.EvtToken = report->token;
	frame.EvtType = report->type;
	frame.EvtStatus = report->status;
	os_move_mem(&frame.EvtReport, report->report, 8);

	MakeOutgoingFrame(buffer, &frame_len,
			sizeof(struct _FRAME_WNM_EVT_REPORT), &frame,
			END_OF_ARGS);
	MiniportMMRequest(pAd, QID_AC_BE, buffer, frame_len, NULL);
	MlmeFreeMemory(buffer);

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_WNM, DBG_LVL_INFO, "WNM event report\n");
#endif
}
#endif

#ifdef DOT11_EHT_BE
/**
 * @brief used to handle peer mld Link Reconfiguration action frame
 *
 * @param ad PRTMP_ADAPTER
 * @param *Elem MLME_QUEUE_ELEM
 */
static void eht_peer_mld_link_reconfig_action(
	IN PRTMP_ADAPTER ad,
	IN MLME_QUEUE_ELEM * Elem
)
{
	struct eht_prot_action_frame *eht_prot_act = (struct eht_prot_action_frame *)Elem->Msg;
	uint8_t action = eht_prot_act->prot_eht_action;

	switch (action) {
	case EHT_PROT_ACT_LINK_RECONFIG_NTFY:
		/* non-AP MLD receive and handle */
		break;
	case EHT_PROT_ACT_LINK_RECONFIG_REQ:
		/* AP MLD receive and handle */
		eht_peer_mld_link_reconfig_request_action(ad, Elem);
		break;
	case EHT_PROT_ACT_LINK_RECONFIG_RESP:
		/* non-AP MLD receive and handle */
		break;
	default:
		break;
	}
}

VOID PeerProtectEHTAction(PRTMP_ADAPTER pAd, MLME_QUEUE_ELEM *Elem)
{
	struct eht_prot_action_frame *eht_prot_act = (struct eht_prot_action_frame *)Elem->Msg;
	UINT8 Action = eht_prot_act->prot_eht_action, *pos;
	struct wifi_dev *wdev = Elem->wdev;
	MAC_TABLE_ENTRY *pEntry = NULL;
	struct mld_entry_t *mld_entry = NULL;
	uint16_t mld_sta_idx, mld_link_num;

	if (!VALID_UCAST_ENTRY_WCID(pAd, Elem->Wcid) || !wdev)
		return;

	switch (Action) {
	case EHT_PROT_ACT_T2LM_REQUEST:
	case EHT_PROT_ACT_T2LM_RESPONSE:
	case EHT_PROT_ACT_T2LM_TEARDOWN:
		nt2lm_peer_t2lm_req_action(pAd, Elem);
		break;
#ifdef EPCS_SUPPORT
	case EHT_PROT_ACT_EPCS_REQUEST:
	case EHT_PROT_ACT_EPCS_RESPONSE:
	case EHT_PROT_ACT_EPCS_TEARDOWN:
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_EHT, DBG_LVL_NOTICE,
			"received EPCS Action(%d) Frame.\n", Action);

		pEntry = entry_get(pAd, Elem->Wcid);
		if (!pEntry) {
			MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_EHT, DBG_LVL_ERROR,
				"can't find pEntry\n");
			return;
		}
#ifdef DOT11_EHT_BE
		MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_EHT, DBG_LVL_NOTICE,
			"pEntry->Addr:%pM, &Elem->Msg[10]:%pM, pEntry->mlo.mld_addr:%pM\n",
			pEntry->Addr, &Elem->Msg[10], pEntry->mlo.mld_addr);
		if (pEntry->mlo.mlo_en && !MAC_ADDR_EQUAL(pEntry->Addr, pEntry->mlo.mld_addr)) {
			MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_EHT, DBG_LVL_NOTICE,
				"Replace mac to mld mac for action frame.\n");
			NdisCopyMemory(&Elem->Msg[10], pEntry->mlo.mld_addr, MAC_ADDR_LEN);
		}
#endif

		receive_qos_action_frame(pAd, Elem->wdev, &Elem->Msg[10],
			Elem->Channel, Elem->Msg, Elem->MsgLen);
		break;
#endif
	case EHT_PROT_ACT_EML_OP_NOTIF:
		{
			UINT32 eml_mode_bmap = 0;
			struct mld_eml_op eml_op = {0};

			pEntry = entry_get(pAd, Elem->Wcid);
			if (!pEntry) {
				MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_EHT, DBG_LVL_ERROR,
					"can't find pEntry\n");
				return;
			}

			mt_os_lockless_enter(os_lockless_ctx_get());
			if (pEntry->mlo.mlo_en)
				mld_entry = mt_os_lockless_access_pointer(os_lockless_ctx_get(), pEntry->mld_entry);
			if (!mld_entry) {
				MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_EHT, DBG_LVL_ERROR,
					"[EML Op Notif] mld_entry=NULL\n");
				mt_os_lockless_exit(os_lockless_ctx_get());
				break;
			}

			mld_link_num = mld_entry->link_num;
			mld_sta_idx = mld_entry->mld_sta_idx;
			mt_os_lockless_exit(os_lockless_ctx_get());

			MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_EHT, DBG_LVL_INFO,
				"[EML Op Notif] MsgLen=%ld, wcid=%d, wdev=%s, assoc_link_num=%d\n",
				Elem->MsgLen, Elem->Wcid, wdev->if_dev->name,
				mld_link_num);

			pos = eht_prot_act->data;

			NdisMoveMemory(&eml_op.dialog_token, pos, sizeof(eml_op.dialog_token));
			pos += sizeof(eml_op.dialog_token);

			NdisMoveMemory(&eml_mode_bmap, pos, sizeof(eml_mode_bmap));

			eml_op.mld_sta_idx = mld_sta_idx;
			eml_op.emlsr_en = GET_DOT11BE_EML_CTRL_EMLSR_MODE(eml_mode_bmap);
			eml_op.emlmr_en = GET_DOT11BE_EML_CTRL_EMLMR_MODE(eml_mode_bmap);
			eml_op.emlsr_param_upd_ctrl = GET_DOT11BE_EML_CTRL_EMLSR_PARAM_UPD_CTRL(eml_mode_bmap);
			if (eml_op.emlsr_en || eml_op.emlmr_en) { /* D3.0 */
				eml_op.eml_link_bmap = GET_DOT11BE_EML_CTRL_EMLSR_LINK_BMAP(eml_mode_bmap);
				eml_op.eml_link_bmap = cpu_to_le16(eml_op.eml_link_bmap);
			}
			eml_op.priv_ptr = (void *)pEntry;

			MTWF_DBG(pAd, DBG_CAT_PROTO, CATPROTO_EHT, DBG_LVL_ERROR,
				"[EML Op Notif] mld_sta_idx=%d, EMLSR_en=%d, EMLSR_bmap=0x%x, token=%d\n",
				eml_op.mld_sta_idx, eml_op.emlsr_en, eml_op.eml_link_bmap,
				eml_op.dialog_token);

			if (wdev->wdev_type == WDEV_TYPE_AP)
				bss_mngr_mld_eml_op_update(wdev, &eml_op);
		}
		break;

	case EHT_PROT_ACT_LINK_RECONFIG_NTFY:
	case EHT_PROT_ACT_LINK_RECONFIG_REQ:
	case EHT_PROT_ACT_LINK_RECONFIG_RESP:
		eht_peer_mld_link_reconfig_action(pAd, Elem);
		break;
	default:
		break;
	}
}
#endif /* DOT11_EHT_BE */
