/*
 ***************************************************************************
 * MediaTek Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 1997-2019, MediaTek, Inc.
 *
 * All rights reserved. MediaTek source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attempt
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek Technology, Inc. is obtained.
 ***************************************************************************

*/
#include "rt_config.h"
#include "bss_mngr.h"
#include "action.h"

extern struct bss_mngr_ops bmgr_ops;

NDIS_STATUS bss_mngr_event_bcn_update(
	struct wifi_dev *wdev)
{
	struct _RTMP_ADAPTER *ad = NULL;

	if (wdev && WDEV_BSS_STATE(wdev) == BSS_READY && WDEV_WITH_BCN_ABILITY(wdev)) {
		ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"wdev(%d)\n", wdev->wdev_idx);

		/* re-sync beacon */
		UpdateBeaconHandler(ad, wdev, BCN_REASON(BCN_UPDATE_BMGR));

		return NDIS_STATUS_SUCCESS;
	}
	return NDIS_STATUS_FAILURE;
}

NDIS_STATUS bss_mngr_event_bss_attr_update(
	IN struct wifi_dev *wdev,
	IN struct bmgr_update_info *update_info,
	IN bool update_bcn
)
{
	if (wdev) {
		struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"===> %s\n", RtmpOsGetNetDevName(wdev->if_dev));

		wlan_config_set_t2lm_nego_support(
			wdev, update_info->mld_attr.mld_caps.t2l_nego_supp);
		wlan_config_set_link_reconfig_op_support(wdev,
			update_info->mld_attr.mld_caps.link_reconfig_op_sup);

		/* EML Capabilities */
		if (update_info->mld_attr.eml_caps.emlsr_supp)
			wlan_config_set_emlsr_mr(wdev, EMLSR);
		else if (update_info->mld_attr.eml_caps.emlmr_supp)
			wlan_config_set_emlsr_mr(wdev, EMLMR);
		else
			wlan_config_set_emlsr_mr(wdev, EML_DISABLE);

		wlan_config_set_trans_to(wdev, update_info->mld_attr.eml_caps.trans_to);
		wlan_config_set_eml_omn_en(wdev, update_info->mld_attr.eml_caps.eml_omn_en);

		if (update_bcn) {
			/* Update beacons for new IEs */
			UpdateBeaconHandler(ad, wdev, BCN_REASON(BCN_UPDATE_BMGR));
		}

		return NDIS_STATUS_SUCCESS;
	}
	return NDIS_STATUS_FAILURE;
}

u8 *bss_mngr_event_ie_fragment(
	u8 *ie_buf, u16 *buf_len)
{
	u8 *pos = NULL;

	pos = fragment_information_element(ie_buf, buf_len);
	return pos;
}

#ifdef CONFIG_6G_SUPPORT
u8 bss_mngr_event_update_iob_disc(
	struct wifi_dev *wdev, struct bmgr_disc_param *disc_param)
{
	if (!wdev)
		return NDIS_STATUS_FAILURE;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
		"iob type %d, interval %d, mode %d\n",
		disc_param->iob_type, disc_param->iob_interval, disc_param->iob_mode);
	return in_band_discovery_update_oper(wdev,
		disc_param->iob_type, disc_param->iob_interval, disc_param->iob_mode);
}
#endif /* CONFIG_6G_SUPPORT */

#ifdef DOT11_EHT_BE
NDIS_STATUS bss_mngr_event_add_mld(
	IN struct wifi_dev *wdev,
	IN u8 mld_grp,
	IN u8 *mld_addr,
	IN u8 mld_type
)
{
	if (wdev) {
		struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;

		mld_type = ap_mld_type_trans(mld_type);

		if (HcAcquireMldRsc(ad, mld_type, mld_grp, mld_addr) != HC_STATUS_OK) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: acquire hw rsc failed (type:%d, grp:%d, addr:%pM)\n",
				mld_type, mld_grp, mld_addr);

			return NDIS_STATUS_FAILURE;
		}

		return NDIS_STATUS_SUCCESS;
	}
	return NDIS_STATUS_FAILURE;
}

NDIS_STATUS bss_mngr_event_del_mld(
	IN struct wifi_dev *wdev,
	IN u8 mld_grp
)
{
	if (wdev) {
		struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;

		if (HcReleaseMldRsc(ad, mld_grp) != HC_STATUS_OK) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: release hw rsc failed (grp:%d)\n", mld_grp);

			return NDIS_STATUS_FAILURE;
		}

		return NDIS_STATUS_SUCCESS;
	}
	return NDIS_STATUS_FAILURE;
}

NDIS_STATUS bss_mngr_event_mld_add_link(
	IN struct wifi_dev *wdev,
	IN u8 mld_grp
)
{
	if (wdev) {
		struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;

		if (HcAcquireMldLinkRsc(ad, wdev, mld_grp) != HC_STATUS_OK) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: acquire hw rsc failed (if:%s, grp:%d)\n",
				RtmpOsGetNetDevName(wdev->if_dev), mld_grp);

			return NDIS_STATUS_FAILURE;
		}

		return NDIS_STATUS_SUCCESS;
	}
	return NDIS_STATUS_FAILURE;
}

NDIS_STATUS bss_mngr_event_mld_del_link(
	IN struct wifi_dev *wdev
)
{
	if (wdev) {
		struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;

		if (HcReleaseMldLinkRsc(ad, wdev) != HC_STATUS_OK) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: release hw rsc failed (if:%s)\n",
				RtmpOsGetNetDevName(wdev->if_dev));

			return NDIS_STATUS_FAILURE;
		}

		return NDIS_STATUS_SUCCESS;
	}
	return NDIS_STATUS_FAILURE;
}

int bss_mngr_fill_peer_mlo_info(
	IN struct mld_sta_add *add_sta,
	OUT struct eht_mlo_t *mlo
)
{
	struct mld_link_add *add_link = NULL;
	struct eht_link_t *link_info = NULL;
	u8 link_id = 0;
	int ret = 0;

	if (!add_sta || !mlo) {
		ret = -EINVAL;
		goto err;
	}

	if (add_sta->mld_sta_idx == MLD_STA_NONE) {
		ret = -EPERM;
		goto err;
	}

	link_id = add_sta->link_id;
	if (link_id >= MLD_LINK_MAX) {
		ret = -ELNRNG;
		goto err;
	}

	add_link = &add_sta->add_link[link_id];
	if (!add_link->active) {
		ret = -ENOENT;
		goto err;
	}

	mlo->mlo_en = 1;
	mlo->is_setup_link_entry = add_link->is_setup_link;
	COPY_MAC_ADDR(mlo->mld_addr, add_sta->mld_addr);

	/* link_info: per link info and this link info */
	link_info = &mlo->link_info;
	link_info->link_id = add_sta->link_id;
	link_info->tid_map_dl = 0xff; /*default mapping*/
	link_info->tid_map_ul = 0xff; /*default mapping*/
	link_info->link_sts = tid_2_link_sts(link_info->tid_map_dl, link_info->tid_map_ul);

	return ret;
err:
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_ENTRY, DBG_LVL_ERROR,
		"ret=%d\n", ret);
	return ret;
}

NDIS_STATUS bss_mngr_event_add_mld_sta(
	IN struct wifi_dev *wdev,
	IN struct mld_sta_para_t *para
)
{
	struct _RTMP_ADAPTER *ad = NULL;
	struct mld_entry_para_t mld_entry_para = {0};

	if (!wdev)
		return NDIS_STATUS_FAILURE;

	ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
	if (!ad)
		return NDIS_STATUS_FAILURE;

	mld_entry_para.mld_sta_idx = para->mld_sta_idx;
	mld_entry_para.mld_addr = para->mld_addr;

	if (mld_entry_add(ad, &mld_entry_para))
		return NDIS_STATUS_FAILURE;

	return NDIS_STATUS_SUCCESS;
}

NDIS_STATUS bss_mngr_event_del_mld_sta(
	IN struct wifi_dev *wdev,
	IN u16 mld_sta_idx,
	IN u8 *mld_addr
)
{
	struct _RTMP_ADAPTER *ad = NULL;
	struct mld_entry_para_t mld_entry_para = {0};

	if (!wdev)
		return NDIS_STATUS_FAILURE;

	ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
	if (!ad)
		return NDIS_STATUS_FAILURE;

	mld_entry_para.mld_sta_idx = mld_sta_idx;
	mld_entry_para.mld_addr = mld_addr;

	if (mld_entry_del(ad, &mld_entry_para))
		return NDIS_STATUS_FAILURE;

	return NDIS_STATUS_SUCCESS;
}

NDIS_STATUS bss_mngr_event_mld_sta_add_link(
	IN struct wifi_dev *wdev,
	IN struct mld_sta_add *add_sta
)
{
	struct _RTMP_ADAPTER *ad = NULL;
	struct mld_link_add *add_link;
	MAC_TABLE_ENTRY *pEntry = NULL;

	if (!wdev)
		return NDIS_STATUS_FAILURE;

	ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
	if (!ad)
		return NDIS_STATUS_FAILURE;

	add_link = &add_sta->add_link[add_sta->link_id];

	/* add station */
	if (add_link->active) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"wdev(%d), mld_sta_idx(%d), aid(%d), MldAddr %pM\n",
				wdev->wdev_idx, add_sta->mld_sta_idx, add_sta->aid, add_sta->mld_addr);
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"\tL%d: %pM, isSetup(%d), STR(0x%x), LinkCnt=%d\n",
				 add_sta->link_id, add_link->sta_addr, add_link->is_setup_link,
				 add_link->str_map, add_sta->total_link_cnt);
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"\tEMLCap(0x%x)\n",
				 add_sta->eml_caps);

		/* if FULL, return */
		if (ad->MacTab->Size >= GET_MAX_UCAST_NUM(ad))
			return NDIS_STATUS_FAILURE;

		pEntry = MacTableLookup(ad, add_link->sta_addr);
		if (pEntry == NULL) {
			/* allocate one MAC entry */
			pEntry = MacTableInsertEntry(ad,
				add_link->sta_addr,
				wdev, ENTRY_CLIENT,
				OPMODE_AP,
				TRUE,
				add_sta->mld_sta_idx,
				NO_INSERT_FLAG);
			if (pEntry) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_ASSOC, DBG_LVL_NOTICE,
					"pEntry(%p): wcid(%d) mac=%pM, mld(sta_idx=%d,addr=%pM) acquired!!\n",
					pEntry, pEntry->wcid, pEntry->Addr, add_sta->mld_sta_idx, add_sta->mld_addr);
			} else {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"pEntry: acquire failed!!\n");
				return NDIS_STATUS_FAILURE;
			}
		} else {
			/* cover non-setup link mlo-capability changed */
			if (!IS_ENTRY_MLO(pEntry)) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Fail:pEntry=%p wcid=%d midx=%d, occupied by non-mlo peer\n",
					pEntry, pEntry->wcid, add_sta->mld_sta_idx);
				return NDIS_STATUS_FAILURE;
			}

			/* same link addr, different mld addr */
			if (!MAC_ADDR_EQUAL(pEntry->mlo.mld_addr, add_sta->mld_addr)) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Fail:pEntry=%p wcid=%d midx=%d, maddr=%pM,%pM\n",
					pEntry, pEntry->wcid, add_sta->mld_sta_idx,
					pEntry->mlo.mld_addr, add_sta->mld_addr);
				return NDIS_STATUS_FAILURE;
			}

			/* same link addr, different link_id */
			if (pEntry->mlo.link_info.link_id != add_sta->link_id) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Fail:pEntry=%p wcid=%d midx=%d, lkid=%d,%d\n",
					pEntry, pEntry->wcid, add_sta->mld_sta_idx,
					pEntry->mlo.link_info.link_id, add_sta->link_id);
				return NDIS_STATUS_FAILURE;
			}

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_ASSOC, DBG_LVL_NOTICE,
				"pEntry(%p): wcid(%d) mac=%pM, mld(sta_idx=%d,addr=%pM) allocated!!\n",
				pEntry, pEntry->wcid, pEntry->Addr, add_sta->mld_sta_idx, add_sta->mld_addr);
		}

		if (pEntry) {
			struct mld_entry_add_link_para_t link_para = {0};

			add_link->priv_ptr = (void *)pEntry;
			link_para.mld_sta_idx = add_sta->mld_sta_idx;
			link_para.mld_addr = add_sta->mld_addr;
			link_para.link_id = add_sta->link_id;
			link_para.str_map = add_link->str_map;
			link_para.pEntry = pEntry;

			if (mld_entry_add_link(&link_para) == NDIS_STATUS_SUCCESS)
				bss_mngr_fill_peer_mlo_info(add_sta, &pEntry->mlo);
			else {
				_MacTableDeleteEntry(ad, pEntry->wcid, pEntry->Addr, NO_FLAG);
				return NDIS_STATUS_FAILURE;
			}
		}
	}

	return NDIS_STATUS_SUCCESS;
}

NDIS_STATUS bss_mngr_event_mld_sta_del_link(
	IN struct mld_link_del *del_link
)
{
	struct _RTMP_ADAPTER *ad;
	MAC_TABLE_ENTRY *pEntry = del_link->priv_ptr;
	u32 fDelete;
	int ret = NDIS_STATUS_FAILURE;

	if (pEntry) {
		ad = pEntry->pAd;
		if (ad) {
			if (del_link->op != MLD_DISC_OP_LR_DEL_TEMP_LINK_ENTRY) {
				ret = mld_entry_del_link(pEntry);
				if (ret != NDIS_STATUS_SUCCESS)
					return ret;
			}

			switch (del_link->op) {
			case MLD_DISC_OP_LR_DEL_LINK:
			case MLD_DISC_OP_LR_DEL_TEMP_LINK_ENTRY:
				fDelete = MLO_LR_DEL_LINK_FLAG | MLO_NO_CFG80211_EVENT_FLAG;
				break;

			case MLD_DISC_OP_DEL_STA_N_ACT:
			case MLD_DISC_OP_DEL_STA_LINK:
			default:
				fDelete = NO_FLAG;
				break;
			}
			_MacTableDeleteEntry(ad, pEntry->wcid, pEntry->Addr, fDelete);
			/* init mlo_en */
			pEntry->mlo.mlo_en = 0;
			pEntry->mlo.is_link_adding = FALSE;

			ret = NDIS_STATUS_SUCCESS;
		} else {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: ad is NULL. (%pM)\n", del_link->sta_addr);
		}
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: entry (%pM) is NULL\n", del_link->sta_addr);
	}

	return ret;
}

NDIS_STATUS bss_mngr_event_mld_sta_notify(
	IN struct wifi_dev *wdev,
	IN struct mld_sta_notify_para_t *para
)
{
	struct _RTMP_ADAPTER *ad = NULL;
	struct mld_entry_notify_para_t notify_para = {0};


	if (!para) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_ENTRY, DBG_LVL_ERROR,
			"Error: para is NULL\n");
		return NDIS_STATUS_FAILURE;
	}

	if (!wdev) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_ENTRY, DBG_LVL_ERROR,
			"Error: wdev is NULL\n");
		return NDIS_STATUS_FAILURE;
	}

	ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
	if (!ad) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_ENTRY, DBG_LVL_ERROR,
			"Error: ad is NULL\n");
		return NDIS_STATUS_FAILURE;
	}

	notify_para.mld_sta_idx = para->mld_sta_idx;
	notify_para.mld_addr = para->mld_addr;
	notify_para.eml_caps = para->eml_caps;
	notify_para.setup_link_link_id = para->setup_link_link_id;
	notify_para.lrr = para->lrr;

	return mld_entry_notify(ad, &notify_para);
}

NDIS_STATUS bss_mngr_event_conn_act(
	IN struct wifi_dev *wdev,
	IN struct mld_link_add *add_link
)
{
	if (wdev) {
		MAC_TABLE_ENTRY *pEntry = NULL;

		/* do conn action */
		if (add_link->active) {
			pEntry = add_link->priv_ptr;
			if (pEntry) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"update link%d (%pM) starec\n",
					pEntry->mlo.link_info.link_id, pEntry->Addr);
				wdev->wdev_ops->conn_act(wdev, pEntry);
			}
		}

		return NDIS_STATUS_SUCCESS;
	}
	return NDIS_STATUS_FAILURE;
}

NDIS_STATUS bss_mngr_event_disconn_mld_sta(
	IN struct mld_link_del *del_link
)
{
	struct _RTMP_ADAPTER *ad;
	MAC_TABLE_ENTRY *pEntry = del_link->priv_ptr;

	if (pEntry) {
		ad = pEntry->pAd;
		if (ad) {
			MTWF_DBG(ad, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"Disassoc STA("MACSTR")\n", MAC2STR(pEntry->Addr));

			APMlmeKickOutSta(ad, pEntry->Addr, pEntry->wcid, REASON_DISASSOC_INACTIVE);

			return NDIS_STATUS_SUCCESS;
		}
	}

	return NDIS_STATUS_FAILURE;
}

NDIS_STATUS bss_mngr_event_disconn_act(
	IN struct mld_link_del *del_link
)
{
	struct wifi_dev *wdev;
	MAC_TABLE_ENTRY *pEntry = del_link->priv_ptr;

	if (pEntry) {
		wdev = pEntry->wdev;
		if (wdev)
			wdev->wdev_ops->disconn_act(wdev, pEntry);
	}

	return NDIS_STATUS_SUCCESS;
}

void bss_mngr_event_query_probe_rsp_frame(
	IN struct wifi_dev *wdev,
	OUT struct ie *rsp_frm
)
{
	struct buffer_wrapper rsp_buf = {0};

	if (wdev)
		eht_mlo_query_link_probe_rsp_frame(wdev, &rsp_buf);
	rsp_frm->buf = rsp_buf.buf;
	rsp_frm->len = rsp_buf.buf_len;

}

void bss_mngr_event_form_ml_probe_rsp_sta_pf(
	IN struct wifi_dev *wdev,
	IN struct ie *repting_rsp_frm,
	IN u8 repting_link_id
)
{
	NDIS_STATUS status;
	struct buffer_wrapper repting_rsp_buf = {0}, repted_rsp_buf = {0};

	if (!wdev)
		return;
	/* get the probe response frame of reported link */
	eht_mlo_query_link_probe_rsp_frame(wdev, &repted_rsp_buf);

	/* There are two probe response frames now, perform post-process & inheritance rule */
	if (repted_rsp_buf.buf_len == 0) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: fail to query probe response frame!\n");
		goto err;
	} else {
		WRAP_BUFFER(repting_rsp_buf, repting_rsp_frm->buf, repting_rsp_frm->len);
		status = eht_ap_mlo_postprocess_reported_link_probe_rsp(
					&repted_rsp_buf,
					&repting_rsp_buf);
		if (status != NDIS_STATUS_SUCCESS) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_ERROR,
				"Error: fail to form STA Profile\n");
			goto err;
		}
	}

	/* deliver STA Profile to BSS Manager (reported link) */
	if (repted_rsp_buf.buf_len < BSS_MNGR_MAX_STA_PROFILE_LEN)
		bss_mngr_mld_add_sta_profile(
			wdev, BMGR_MAX_MLD_STA_CNT,
			repting_link_id, BMGR_MLD_PROBE_RSP_COMPLETE_PROFILE,
			repted_rsp_buf.buf, repted_rsp_buf.buf_len);
	else
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_ERROR,
			"Error!!!: wdev[%d] After postprocessing, size of STA Profile > %d, drop it\n",
			BSS_MNGR_MAX_STA_PROFILE_LEN, wdev->wdev_idx);

err:
	if (repted_rsp_buf.buf)
		MlmeFreeMemory(repted_rsp_buf.buf);

}

void bss_mngr_event_ba_add_to_asic(
	IN struct wifi_dev *wdev,
	IN struct mld_ba_info *ba_info
)
{
	struct _RTMP_ADAPTER *pAd = NULL;
	MAC_TABLE_ENTRY *pEntry = ba_info->priv_ptr;

	if (wdev)
		pAd = (struct _RTMP_ADAPTER *)wdev->sys_handle;
	if (!pAd)
		return;

	if (ba_info->by_mld) {
		struct MT_PEER_MLD_BA_UPDATE info = {0};
		struct _MT_BA_CTRL_T *ba_ctrl;

		COPY_MAC_ADDR(info.peer_mld_addr, ba_info->peer_mld_addr);
		ba_ctrl = &info.ba_ctrl;
		ba_ctrl->Tid = ba_info->TID;
		ba_ctrl->BaSessionType = ba_info->type;
		ba_ctrl->isAdd = 1;
		ba_ctrl->Sn = ba_info->Seq;
		ba_ctrl->BaWinSize = ba_info->BAWinSize;
		ba_ctrl->amsdu = ba_info->amsdu_en;

		HW_PEER_MLD_BA_UPDATE(pAd, &info);
	} else {
		if (pEntry)
			RTMP_ADD_BA_SESSION_TO_ASIC(pAd, pEntry->wcid, ba_info->TID,
				ba_info->Seq, ba_info->BAWinSize, ba_info->type, ba_info->amsdu_en);
	}
}

void bss_mngr_event_ba_del_from_asic(
	IN struct wifi_dev *wdev,
	IN struct mld_ba_info *ba_info
)
{
	struct _RTMP_ADAPTER *pAd = NULL;
	MAC_TABLE_ENTRY *pEntry = ba_info->priv_ptr;

	if (wdev)
		pAd = (struct _RTMP_ADAPTER *)wdev->sys_handle;
	if (!pAd)
		return;

	if (ba_info->by_mld) {
		struct MT_PEER_MLD_BA_UPDATE info = {0};
		struct _MT_BA_CTRL_T *ba_ctrl;

		COPY_MAC_ADDR(info.peer_mld_addr, ba_info->peer_mld_addr);
		ba_ctrl = &info.ba_ctrl;
		ba_ctrl->Tid = ba_info->TID;
		ba_ctrl->BaSessionType = ba_info->type;
		ba_ctrl->isAdd = 0;
		ba_ctrl->amsdu = ba_info->amsdu_en;

		HW_PEER_MLD_BA_UPDATE(pAd, &info);
	} else {
		if (pEntry)
			RTMP_DEL_BA_SESSION_FROM_ASIC(pAd, pEntry->wcid, ba_info->TID, ba_info->type, ba_info->amsdu_en);
	}
}

void bss_mngr_event_twt_action_frm_forward(
	IN struct _MLME_QUEUE_ELEM *elem,
	IN struct _MAC_TABLE_ENTRY *peer_entry
)
{
	struct wifi_dev *wdev = NULL;
	struct _RTMP_ADAPTER *ad = NULL;
	struct MLO_TWT_PRIV_T *mlo_twt_priv = NULL;
	u8 *ie_ptr = NULL;
	struct mlo_itwt_ie *mlo_twt_ie = NULL;
	u8 linkid_bitmap_present = 0;

	if (!elem || !peer_entry)
		return;

	wdev = peer_entry->wdev;
	ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;

	MTWF_DBG(ad, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
		"action link=%s\n", wdev->if_dev->name);

	/* breakdown twt action frame if link_id_bitmap_present=1 or
	   consider it as legacy itwt request format */
	os_alloc_mem(ad, (UCHAR **)&mlo_twt_priv, sizeof(struct MLO_TWT_PRIV_T));

	if (!mlo_twt_priv) {
		MTWF_DBG(ad, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
			"mlo_twt_priv alloc mem fail!!!\n");
		return;
	}

	os_zero_mem(mlo_twt_priv, sizeof(struct MLO_TWT_PRIV_T));

	/* get all_linkid_bitmap */
	ie_ptr = (u8 *)(elem->Msg + LENGTH_802_11 + 3);
	mlo_twt_ie = (struct mlo_itwt_ie *)ie_ptr;
	linkid_bitmap_present = (u8)GET_TWT_CTRL_LINKID_BITMAP_PRESENT(mlo_twt_ie->control);

	/* assign next state */
	mlo_twt_priv->state = linkid_bitmap_present ?
		STATE_BREAKDOWN_ACTION_FRAME : STATE_NO_LINKID_BITMAP_PRESENT;

	/* forward action frame to action link MLME */
	REPORT_MGMT_FRAME_TO_MLME(ad, peer_entry->wcid, &elem->Msg, elem->MsgLen, 0, 0, 0, 0,
		0, 0, OPMODE_AP, wdev, 0, mlo_twt_priv, 0);
}

u8 bss_mngr_event_twt_action_frm_breadown(
	IN PNET_DEV da_net_dev,
	IN PNET_DEV sa_net_dev,
	IN u8 da_linkid,
	IN u8 sa_linkid,
	IN u16 mld_sta_idx,
	IN u8 action_linkid,
	IN u16 linkid_bitmap,
	IN u16 all_linkid_bitmap,
	IN struct _MLME_QUEUE_ELEM *elem,
	IN struct mlo_itwt_ie *twt_ie,
	IN struct _MAC_TABLE_ENTRY *peer_entry
)
{
	NDIS_STATUS status = 0;
	u8 breakdown = 0;
	struct MLO_TWT_PRIV_T *mlo_twt_priv = NULL;
	struct frame_itwt_setup *in_action_frame = (struct frame_itwt_setup *)&elem->Msg;
	struct frame_itwt_setup out_action_frame = {0};

	if (!da_net_dev || !sa_net_dev || !elem || !twt_ie || !peer_entry)
		return breakdown;

	/* adujst A1=RA=DA, A2=TA=SA, A3=BSSID with link related information */
	ActHeaderInit(NULL, &out_action_frame.hdr, peer_entry->bssid, peer_entry->Addr, peer_entry->bssid);

	/* S1G action: twt setup frame action hdr */
	out_action_frame.category = in_action_frame->category;
	out_action_frame.s1g_action = in_action_frame->s1g_action;
	out_action_frame.token = in_action_frame->token;

	/* remove mlo itwt linkid_bitmap 2B and let legacy twt MLME can handle it directly */
	os_move_mem(&out_action_frame.twt_ie, twt_ie, sizeof(struct itwt_ie_t));
	out_action_frame.twt_ie.len = sizeof(struct itwt_ie_t) - 2;

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
		"A1=%pM,A2=%pM,A3=%pM,len=%d,wcid=%d, and be forwarded to\n",
		out_action_frame.hdr.Addr1,
		out_action_frame.hdr.Addr2,
		out_action_frame.hdr.Addr3,
		out_action_frame.twt_ie.len,
		peer_entry->wcid);

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
		"da/sa=%s,%s, da/sa=%d,%d, mld_sta_idx=%d, action_linkid=%d, linkid_bitmap=0x%x, all_linkid_bitmap=0x%x\n",
		da_net_dev->name, sa_net_dev->name,
		da_linkid, sa_linkid,
		mld_sta_idx,
		action_linkid,
		linkid_bitmap,
		all_linkid_bitmap);
	/* mlo itwt ctrl parameters */
	status = os_alloc_mem(NULL, (UCHAR **)&mlo_twt_priv, sizeof(struct MLO_TWT_PRIV_T));
	if (status == NDIS_STATUS_SUCCESS) {
		u16 wcid = peer_entry->wcid;
		struct wifi_dev *wdev = peer_entry->wdev;
		struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;

		/* assign next state */
		os_zero_mem(mlo_twt_priv, sizeof(struct MLO_TWT_PRIV_T));
		mlo_twt_priv->da_net_dev = da_net_dev;
		mlo_twt_priv->sa_net_dev = sa_net_dev;
		mlo_twt_priv->da_linkid = da_linkid;
		mlo_twt_priv->sa_linkid = sa_linkid;
		mlo_twt_priv->mld_sta_idx = mld_sta_idx;
		mlo_twt_priv->action_linkid = action_linkid;
		mlo_twt_priv->linkid_bitmap = linkid_bitmap;
		mlo_twt_priv->all_linkid_bitmap = all_linkid_bitmap;
		mlo_twt_priv->state = STATE_ACTION_FRAME_HANDLE;

		/* forward N of "1->N" action frame to MLME */
		/*dump_hex_content((UINT8 *)&out_action_frame, sizeof(out_action_frame));*/
		REPORT_MGMT_FRAME_TO_MLME(ad, wcid, &out_action_frame, sizeof(out_action_frame), 0, 0, 0, 0,
			0, 0, OPMODE_AP, wdev, 0, mlo_twt_priv, 0);
		breakdown = 1;
	} else
		breakdown = 0;

	return breakdown;
}

void bss_mngr_event_twt_action_frm_agg(
	IN struct wifi_dev *wdev_,
	IN u8 *out_buffer,
	IN u16 len,
	IN struct _MAC_TABLE_ENTRY *peer_entry,
	IN u16 mld_sta_idx,
	IN u8 action_linkid,
	IN u16 all_linkid_bitmap
)
{
	/* pNetDev = action link */
	if (peer_entry) {
		struct MLO_TWT_PRIV_T *mlo_twt_priv = NULL;
		struct wifi_dev *wdev = peer_entry->wdev;
		struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
		u16 wcid = peer_entry->wcid;

		if (os_alloc_mem(NULL, (UCHAR **)&mlo_twt_priv, sizeof(struct MLO_TWT_PRIV_T))
			== NDIS_STATUS_SUCCESS) {
			os_zero_mem(mlo_twt_priv, sizeof(struct MLO_TWT_PRIV_T));
			/* da/sa net_dev, da/sa linkid, linkid_bitmap are not needed in tx phase */
			mlo_twt_priv->mld_sta_idx = mld_sta_idx;
			mlo_twt_priv->action_linkid = action_linkid;
			mlo_twt_priv->all_linkid_bitmap = all_linkid_bitmap;
			mlo_twt_priv->state = STATE_TX_AGGREGATE_ACTION_FRAME;
			/* forward 1 of "N->1" to action link */
			REPORT_MGMT_FRAME_TO_MLME(ad, wcid, out_buffer, len, 0, 0, 0, 0,
				0, 0, OPMODE_AP, wdev, 0, mlo_twt_priv, 0);
		} else
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
				"fail. os_alloc_mem\n");
	} else
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
			"fail. peer_entry=NULL\n");
}


void bss_mngr_event_mld_twt_wait_ack_inform(
	IN struct wifi_dev *wdev_,
	IN struct _MAC_TABLE_ENTRY *peer_entry,
	IN u8 wait_ack_sts
)
{
	if (wdev_ && peer_entry) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
			"IF=%s,wdev_idx=%d,wcid=%d,wait_ack_sts=%d\n",
			mt_os_net_dev_get_name(wdev_->if_dev),
			peer_entry->wdev->wdev_idx,
			peer_entry->wcid, wait_ack_sts);
		twt_wait_ack_inform(peer_entry->wdev, peer_entry->wcid, wait_ack_sts);
	}
}

#ifdef MWDS
int bss_mbgr_event_mld_mwds_enable(
	IN struct wifi_dev *wdev,
	u8 enable
)
{
	struct _RTMP_ADAPTER *ad;
	u8 if_idx = 0;

	if (!wdev)
		return FALSE;

	ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
	if (!ad)
		return FALSE;

	if_idx = wdev->func_idx;
	if (enable)
		return MWDSEnable(ad, if_idx, TRUE, FALSE);
	else
		return MWDSDisable(ad, if_idx, TRUE, FALSE);
}
#endif

void bss_mngr_event_mld_critical_update_bcn(
	IN struct wifi_dev *wdev,
	IN struct mld_crit_upd_info *info,
	IN u8 reason)
{
	if (wdev) {
		struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;

		MTWF_DBG(ad, DBG_CAT_AP, CATAP_BPCC, DBG_LVL_INFO,
			"[%s] bitmap: 0x%x, bypass_bmap: 0x%x, reason=0x%x\n",
			wdev->if_dev->name, info->bitmap, info->bypass_bcn_seq_bmap, reason);

		wdev->bcn_buf.cu_info.crit_upd_bitmap = info->bitmap;
		wdev->bcn_buf.cu_info.bypass_bcn_seq_bmap = info->bypass_bcn_seq_bmap;
		wdev->bcn_buf.cu_info.crit_upd_flag = TRUE;

		/* Set Critical update Flag (high bit[6]) + Original reason (Low bits[5:0]) */
		UpdateBeaconHandler(ad, wdev, (BCN_UPDATE_REASON)BCN_SET_CRIT_UPD(reason));
	}
}

u8 bss_mngr_event_mld_critical_update_op_lock(
	IN PNET_DEV pNetDev,
	IN u8 lock,
	IN u8 mld_id)
{
	u8 status = 1;
	struct wifi_dev *wdev = mt_os_net_dev_get_wdev(pNetDev);
	struct _RTMP_ADAPTER *ad;

	if (!wdev) {
		status = 0;
		return status;
	}
	ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
	MTWF_DBG(ad, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_DEBUG,
		"[%s] lock: 0x%x\n", wdev->if_dev->name, lock);

	if (lock == BMGR_BPCC_OP_GET_LOCK)
		status = bcn_bpcc_op_lock_by_bssmngr(ad, wdev) ? 1 : 0;
	else if (lock == BMGR_BPCC_OP_RELEASE_LOCK)
		bcn_bpcc_op_unlock_by_bssmngr(ad, wdev);
	else if (lock == BMGR_BPCC_OP_RESET_LOCK_TIMER)
		bcn_bpcc_op_lock_set_timer_by_bssmngr(ad, wdev);
	else if (lock == BMGR_BPCC_OP_MLD_ID_LOG_ON)
		bcn_bpcc_mld_id_log_sync(ad, wdev, mld_id, TRUE);
	else if (lock == BMGR_BPCC_OP_MLD_ID_LOG_OFF)
		bcn_bpcc_mld_id_log_sync(ad, wdev, mld_id, FALSE);

	return status;
}

void bss_mngr_event_mld_eml_op_update(
	IN struct wifi_dev *wdev,
	IN struct mld_eml_op *eml_op)
{
	if (wdev) {
		struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
		struct _RTMP_ARCH_OP *arch_ops = hc_get_arch_ops(ad->hdev_ctrl);
		struct _MAC_TABLE_ENTRY *pEntry = eml_op->priv_ptr;
		struct mld_entry_t mld_entry = {0};
		struct _STA_REC_CTRL_T sta_rec_ctrl = {0};

		if (arch_ops->archUpdateEMLOp) {
			u8 *pOutBuffer = NULL;
			u32 eml_control = 0, eml_ctrl_len = 1;
			ULONG FrameLen;
			struct eht_prot_action_frame eml_op_act;

			if (!pEntry)
				return;

			/* update values */
			if (pEntry->mlo.mlo_en) {
				mld_entry.emlsr = eml_op->eml_link_bmap;
				mld_entry_fill_fields(pEntry->mlo.mld_addr, &mld_entry,
					MLD_ENTRY_FIELD_FLAG_EMLSR);
			}

			pEntry->EmlsrBitmap = eml_op->eml_link_bmap;

			/* update StaRec */
			sta_rec_ctrl.WlanIdx = pEntry->wcid;
			arch_ops->archUpdateEMLOp(ad, &sta_rec_ctrl);

			/* send response */
			if (eml_op->eml_omn_en) {
				if (MlmeAllocateMemory(ad, &pOutBuffer) != NDIS_STATUS_SUCCESS) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"Error: allocate memory failed\n");
					return;
				}

				ActHeaderInit(ad, &(eml_op_act.Hdr),
					pEntry->Addr, wdev->if_addr, wdev->bssid);
				eml_op_act.category = CATEGORY_PROTECTED_EHT;
				eml_op_act.prot_eht_action = EHT_PROT_ACT_EML_OP_NOTIF;

				if (pOutBuffer) {
					SET_DOT11BE_EML_CTRL_EMLSR_MODE(
						eml_control, eml_op->emlsr_en);
					SET_DOT11BE_EML_CTRL_EMLMR_MODE(
						eml_control, eml_op->emlmr_en);
					if (eml_op->emlsr_en || eml_op->emlmr_en) {
						SET_DOT11BE_EML_CTRL_EMLSR_LINK_BMAP(eml_control,
							cpu_to_le16(eml_op->eml_link_bmap));

						eml_ctrl_len += sizeof(eml_op->eml_link_bmap);
					}

					MakeOutgoingFrame(pOutBuffer, &FrameLen,
						sizeof(struct eht_prot_action_frame), &eml_op_act,
						sizeof(eml_op->dialog_token), &eml_op->dialog_token,
						eml_ctrl_len, &eml_control,
						END_OF_ARGS);

					MiniportMMRequest(ad, QID_AC_BE, pOutBuffer, FrameLen, NULL);

					MlmeFreeMemory(pOutBuffer);

					MTWF_DBG(ad, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"Response EML OMN w/ token(%d) en(%d), bmap(0x%x) len(%d)\n",
					eml_op->dialog_token, eml_op->emlsr_en,
					eml_op->eml_link_bmap, eml_ctrl_len);
				}
			} else {
				MTWF_DBG(ad, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"Do not Response EML OMN\n");
			}
		} else {
			MTWF_DBG(ad, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"UpdateEMLOp not supported\n");
		}
	}
}

void bss_mngr_event_tx_link_recomm(
	IN struct wifi_dev *wdev,
	IN u16 reason_code,
	IN u8 *buf,
	IN u16 buf_len)
{
	if (wdev) {
		struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;

		u8 *pOutBuffer = NULL;
		ULONG FrameLen;
		struct eht_prot_action_frame link_recomm_act;
		PHEADER_802_11 pHdr80211;

		if (!buf || !buf_len) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"(Error) empty buffer %d\n", buf_len);
			return;
		}

		if (MlmeAllocateMemory(ad, &pOutBuffer) != NDIS_STATUS_SUCCESS) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"(Error) allocate memory failed\n");
			return;
		}

		if (pOutBuffer) {
			pHdr80211 = &(link_recomm_act.Hdr);
			NdisZeroMemory(pHdr80211, sizeof(HEADER_802_11));
			pHdr80211->FC.Type = FC_TYPE_MGMT;
			pHdr80211->FC.SubType = SUBTYPE_ACTION_NO_ACK;
			COPY_MAC_ADDR(pHdr80211->Addr1, BROADCAST_ADDR);
			COPY_MAC_ADDR(pHdr80211->Addr2, wdev->if_addr);
			COPY_MAC_ADDR(pHdr80211->Addr3, wdev->bssid);

			link_recomm_act.category = CATEGORY_PROTECTED_EHT;
			link_recomm_act.prot_eht_action = EHT_PROT_ACT_LINK_RECOMM;
			reason_code = cpu_to_le16(reason_code);

			MakeOutgoingFrame(pOutBuffer, &FrameLen,
				sizeof(struct eht_prot_action_frame), &link_recomm_act,
				sizeof(reason_code), &reason_code,
				buf_len, buf,
				END_OF_ARGS);

			hex_dump_always("LR Frame", pOutBuffer, FrameLen);

			MiniportMMRequest(ad, QID_AC_BE, pOutBuffer, FrameLen, NULL);

			MlmeFreeMemory(pOutBuffer);

			MTWF_DBG(ad, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"(%s) TX Link Recomm w/ reason(%d) buf_len(%d)\n",
				RtmpOsGetNetDevName(wdev->if_dev),
				cpu_to_le16(reason_code), buf_len);
		}
	}
}

/**
 * @ML reconfiguration: update mld sta new data link
 *
 * @param *mld_addr mld addr of non-ap mld
 * @param new_data_link_id
 */
static int bss_mngr_reconfig_peer_update_data_link(
	IN u8 *mld_addr,
	IN u8 new_data_link_id
)
{
	int ret = 0;
	struct mld_entry_t *mld_entry = NULL;
	struct mld_entry_t temp_mld_entry = {0};
	struct _MAC_TABLE_ENTRY *old_data_link_entry = NULL;
	struct _MAC_TABLE_ENTRY *new_data_link_entry = NULL;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
		 "mld_sta=%pM\n", mld_addr);

	if (MAC_ADDR_EQUAL(mld_addr, ZERO_MAC_ADDR)) {
		ret = -EINVAL;
		goto err;
	}

	if (new_data_link_id >= MLD_LINK_MAX) {
		ret = -ELNRNG;
		goto err;
	}

	mt_os_lockless_enter(os_lockless_ctx_get());
	mld_entry = get_mld_entry_by_mac(mld_addr);
	if (!mld_entry) {
		ret = -EINVAL;
		mt_os_lockless_exit(os_lockless_ctx_get());
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
			"mld_entry is NULL\n");
		goto err;
	}
	old_data_link_entry = (struct _MAC_TABLE_ENTRY *)
		mld_entry->link_entry[mld_entry->setup_link_link_id];
	new_data_link_entry = (struct _MAC_TABLE_ENTRY *)
		mld_entry->link_entry[new_data_link_id];
	mt_os_lockless_exit(os_lockless_ctx_get());

	if (!new_data_link_entry) {
		ret = -ENOENT;
		goto err;
	}

	/*logan driver*/
	temp_mld_entry.setup_link_wcid = new_data_link_entry->wcid;
	temp_mld_entry.setup_link_link_id = new_data_link_id;

	ret = mld_entry_fill_fields(mld_addr, &temp_mld_entry,
		MLD_ENTRY_FIELD_FLAG_SETUP_LINK);
	if (ret) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
			"Fail: mld_entry_fill_fields ret=%d\n", ret);
		goto err;
	}

	/*hwifi driver*/
	ret = HcChangeSetupLink(new_data_link_entry->pAd, new_data_link_entry->wcid);
	if (ret) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
			"Fail: HcChangeSetupLink ret=%d\n", ret);
		goto err;
	}

	/* Link data structure */
	if (old_data_link_entry)
		old_data_link_entry->mlo.is_setup_link_entry = 0;

	new_data_link_entry->mlo.is_setup_link_entry = 1;

	/*IAPP*/
	IAPP_L2_Update_Frame_Send(new_data_link_entry->pAd, mld_addr,
		new_data_link_entry->wdev->wdev_idx);

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
		 "change new data link to wcid=%d, link=%d\n",
		 new_data_link_entry->wcid, new_data_link_id);

	return ret;
err:
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
		 "err=%d\n", ret);
	return ret;
}

/**
 * @ML reconfiguration: update mld sta new setup link
 *
 * @param *mld_addr mld addr of non-ap mld
 * @param available_link_id_bmap available link id bitmap
 * @param new_setup_link_id
 */
int bss_mngr_reconfig_sta_setup_link_set(
	IN u8 *mld_addr,
	IN u16 available_link_id_bmap,
	OUT u8 *new_setup_link_id
)
{
	int ret = 0;
	u8 link_id = 0;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
		 "mld_sta=%pM, available_link_id_bmap=0x%x\n", mld_addr, available_link_id_bmap);

	if (MAC_ADDR_EQUAL(mld_addr, ZERO_MAC_ADDR)) {
		ret = -EINVAL;
		goto err;
	}

	if (!available_link_id_bmap) {
		ret = -EINVAL;
		goto err;
	}

	/*assign new setup link by link_id*/
	link_id = ffs(available_link_id_bmap) - 1;

	ret = bss_mngr_reconfig_peer_update_data_link(mld_addr, link_id);
	if (ret)
		goto err;

	*new_setup_link_id = link_id;

	return ret;
err:
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
		 "err=%d\n", ret);
	return ret;
}

/**
 * @ML reconfiguration: find available setup link
 *
 * @param *mld_addr non-AP mld addr
 * @param rm_link_id_bitmap link id bitmap of remove link
 * @param *available_link_id_bitmap availavle link id bitmap
 * @param is_rm_link_on_setup_link check if rm link=setup link
 * @param **lastt_setup_link_entry last setup link
 */
int bss_mngr_reconfig_available_link_find(
	IN u8 *mld_addr,
	IN u16 rm_link_id_bitmap,
	OUT u16 *available_link_id_bitmap,
	OUT u8 *is_rm_link_on_setup_link,
	OUT struct _MAC_TABLE_ENTRY **last_setup_link_entry
)
{
	int ret = 0;
	u8 link_id = 0;
	struct _MAC_TABLE_ENTRY *entry = NULL;
	struct eht_mlo_t *mlo_info = NULL;
	struct eht_link_t *link_info = NULL;
	struct mld_entry_t *mld_entry = NULL;

	mt_os_lockless_enter(os_lockless_ctx_get());
	mld_entry = get_mld_entry_by_mac(mld_addr);
	if (!mld_entry) {
		mt_os_lockless_exit(os_lockless_ctx_get());
		ret = -EEXIST;
		goto err;
	}

	for (link_id = 0; link_id < BSS_MNGR_MAX_BAND_NUM; link_id++) {
		entry = (struct _MAC_TABLE_ENTRY *)mld_entry->link_entry[link_id];
		if (!IS_ENTRY_MLO(entry))
			continue;

		mlo_info = &entry->mlo;
		link_info = &entry->mlo.link_info;
		if (mlo_info->is_setup_link_entry)
			*last_setup_link_entry = entry;
		if (rm_link_id_bitmap & BIT(link_id)) {
			link_info->link_sts = LINK_STS_REMOVE;
			if (mlo_info->is_setup_link_entry) {
				mlo_info->is_setup_link_entry = 0;
				*is_rm_link_on_setup_link = 1;
			}
		}
		if (link_info->link_sts != LINK_STS_REMOVE)
			*available_link_id_bitmap |= BIT(link_id);
	}

	mt_os_lockless_exit(os_lockless_ctx_get());
	return ret;
err:
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
		 "err=%d\n", ret);
	return ret;
}

/**
 * @ML reconfiguration: handle peer mld sta including signle link mld sta case
 *
 * @param *mld_addr mld addr of non-ap mld
 * @param available_link_id_bitmap available link id bitmap
 * @param new_data_link_id
 */
int bss_mngr_event_mld_reconfig(
	IN u8 *mld_addr,
	IN u16 rm_link_id_bitmap,
	OUT u8 *new_data_link_id
)
{
	int ret = 0;
	u8 is_rm_link_on_setup_link = 0;
	u16 available_link_id_bitmap = 0;
	struct _MAC_TABLE_ENTRY *last_setup_link_entry = NULL;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
		 "mld_sta=%pM\n", mld_addr);

	ret = bss_mngr_reconfig_available_link_find(mld_addr,
		rm_link_id_bitmap,
		&available_link_id_bitmap,
		&is_rm_link_on_setup_link,
		&last_setup_link_entry);

	if (ret) {
		ret = -ENXIO;
		goto err;
	}

	if (!last_setup_link_entry) {
		ret = -ENXIO;
		goto err;
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
		 "rm_link_id=0x%.2x, ava_link_id=0x%.2x, rm_link_on_setup_link=%d, last_setup_link=%pM\n",
		 rm_link_id_bitmap,
		 available_link_id_bitmap,
		 is_rm_link_on_setup_link,
		 last_setup_link_entry->Addr);

	if (is_rm_link_on_setup_link) {
		if (available_link_id_bitmap) {
			/*select a new setup link*/
			ret = bss_mngr_reconfig_sta_setup_link_set(mld_addr, available_link_id_bitmap,
				new_data_link_id);
		} else {
			/*disassoc non-AP MLD*/
			cntl_disconnect_request(last_setup_link_entry->wdev,
				CNTL_DEAUTH,
				last_setup_link_entry->Addr,
				REASON_DEAUTH_STA_LEAVING);
		}
	}

	return ret;
err:
	return ret;
}

/**
 * @brief Execute a bmgr event related to Link Reconfig
 *
 * This function handles a bmgr event related to Link Reconfig.
 *
 * @param lr_event struct to handle Link Reconfiguration Event to Logan
 * @return int: Returns 0 on success, otherwise an error codes.
 */
int bss_mngr_event_mld_peer_link_reconfig(
	IN struct bmgr_lr_event *lr_event
)
{
	int ret = 0;
	UCHAR HashIdx;
	struct _RTMP_ADAPTER *ad;
	struct wifi_dev	*wdev;
	struct _MAC_TABLE_ENTRY *pEntry = NULL, *pCurrEntry;
	struct _STA_TR_ENTRY *tr_entry;
	struct MT_PEER_MLD_DELETE_LINKS info = {0};
	struct mld_entry_add_link_para_t link_para = {0};

	switch (lr_event->event) {
	case BMGR_LR_EVENT_ADD_LINK_DECISION:
		ret = eht_ap_mlo_link_reconfig_add_link_decision(lr_event);
		break;

	case BMGR_LR_EVENT_HW_DEL_LINKS:
		pEntry = lr_event->hw_del_links.lr_frm_link_ptr;

		COPY_MAC_ADDR(info.peer_mld_addr, lr_event->peer_mld_addr);
		info.del_link_id_bmap = lr_event->hw_del_links.del_link_id_bmap;

		if (HW_PEER_MLD_DELETE_LINKS(pEntry->pAd, &info) != NDIS_STATUS_SUCCESS) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
				"Error: hw delete links fail: %pM\n", info.peer_mld_addr);
			ret = -EBUSY;
			goto err;
		}
		break;

	case BMGR_LR_EVENT_APPLY_ADD_LINK:
	case BMGR_LR_EVENT_APPLY_ADD_UPDATE_DATA_LINK:
		pEntry = lr_event->link_entry.add_link_ptr;

		if (!pEntry || !pEntry->mlo.is_link_adding) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
				"Error: adding link done or priv_ptr is NULL(%p)\n", pEntry);
			ret = -EINVAL;
			goto err;
		}

		ad = pEntry->pAd;
		wdev = pEntry->wdev;

		/* Part 1. Mac Entry Hash Table */
		NdisAcquireSpinLock(ad->MacTabLock);
		pCurrEntry = MacTableLookup(ad, pEntry->Addr);
		if (pCurrEntry) {
			MTWF_DBG(ad, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
				"Addr=%pM (wcid=%d) exists in hash table, wcid=%d, exist_entry=%p\n",
				pEntry->Addr, pEntry->wcid, pCurrEntry->wcid, pCurrEntry);
			NdisReleaseSpinLock(ad->MacTabLock);
			ret = -EPERM;
			goto err;
		}

		/* insert to hash table before adding link to mld_entry */
		HashIdx = MAC_ADDR_HASH_INDEX(pEntry->Addr);

		if (ad->MacTab->Hash[HashIdx] == NULL)
			ad->MacTab->Hash[HashIdx] = pEntry;
		else {
			pCurrEntry = ad->MacTab->Hash[HashIdx];

			while (pCurrEntry->pNext != NULL)
				pCurrEntry = pCurrEntry->pNext;

			pCurrEntry->pNext = pEntry;
		}
		NdisReleaseSpinLock(ad->MacTabLock);

		/* Part 2. add link to mld_entry of peer MLD */
		link_para.mld_sta_idx = lr_event->mld_sta_idx;
		link_para.mld_addr = lr_event->peer_mld_addr;
		link_para.link_id = pEntry->mlo.link_info.link_id;
		/* TBD: based on Per-STA Profile - NSTR Bmap to set Str Bmap */
		link_para.str_map = BITS(0, BSS_MNGR_MAX_BAND_NUM - 1);
		link_para.pEntry = pEntry;

		MTWF_DBG(ad, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_DEBUG,
			"msta_idx=%d,addr=%pM,lk=%d,str=0x%x,pEntry=%p\n",
			link_para.mld_sta_idx, link_para.mld_addr, link_para.link_id,
			link_para.str_map, link_para.pEntry);

		if (mld_entry_add_link(&link_para) != NDIS_STATUS_SUCCESS) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
				"Error: mld_entry_add_link fail, Addr=%pM (wcid=%d)\n",
				pEntry->Addr, pEntry->wcid);
			ret = -ENODEV;
			goto err;
		}

		/* Part 3. add link w/ update data link if needed,
		 * before update FW/HW for added link */
		if (lr_event->event == BMGR_LR_EVENT_APPLY_ADD_UPDATE_DATA_LINK) {
			ret = bss_mngr_reconfig_peer_update_data_link(
				lr_event->peer_mld_addr,
				pEntry->mlo.link_info.link_id);
			if (ret) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
					"Error: update data link fail ret=%d,addr=%pM,new_data_link=%d\n",
					ret, lr_event->peer_mld_addr,
					pEntry->mlo.link_info.link_id);
				goto err;
			}
		}

		/* Part 4. update FW/HW by StaRec in-band command */
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
			"update link%d (%pM) starec\n",
			pEntry->mlo.link_info.link_id, pEntry->Addr);

		wdev->wdev_ops->conn_act(wdev, pEntry);

		/* Part 5. set Port-Secure procedure */
		WifiSysUpdatePortSecurPostProcess(ad, pEntry);
		tr_entry = tr_entry_get(ad, pEntry->wcid);
		tr_entry->PortSecured = WPA_802_1X_PORT_SECURED;

		/* Part 6. apply add link done */
		/* Link Reconfiguration Add Link Done */
		pEntry->mlo.is_link_adding = FALSE;

		break;

	case BMGR_LR_EVENT_UPDATE_DATA_LINK:
		ret = bss_mngr_reconfig_peer_update_data_link(
			lr_event->peer_mld_addr,
			lr_event->update_data_link.new_data_link_id);
		if (ret) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
				"Error: update data link fail ret=%d,addr=%pM,new_data_link=%d\n",
				ret, lr_event->peer_mld_addr,
				lr_event->update_data_link.new_data_link_id);
			goto err;
		}
		break;

	case BMGR_LR_EVENT_START_DATA:

		break;

	case BMGR_LR_EVENT_STOP_DATA:

		break;

	default:
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
			"Error: unknown event %d\n", lr_event->event);
		ret = -EBADRQC;
		goto err;
	}

err:
	return ret;
}
#endif /* DOT11_EHT_BE */

struct bss_mngr_event_ops bmgr_event_ops = {
	.bmgr_event_bcn_update = bss_mngr_event_bcn_update,
	.bmgr_event_bss_attr_update = bss_mngr_event_bss_attr_update,
	.bmgr_event_ie_fragment = bss_mngr_event_ie_fragment,
#ifdef CONFIG_6G_SUPPORT
	.bmgr_event_update_iob_disc = bss_mngr_event_update_iob_disc,
#endif
#ifdef DOT11_EHT_BE
	.bmgr_event_add_mld = bss_mngr_event_add_mld,
	.bmgr_event_del_mld = bss_mngr_event_del_mld,
	.bmgr_event_mld_add_link = bss_mngr_event_mld_add_link,
	.bmgr_event_mld_del_link = bss_mngr_event_mld_del_link,
	.bmgr_event_add_mld_sta = bss_mngr_event_add_mld_sta,
	.bmgr_event_del_mld_sta = bss_mngr_event_del_mld_sta,
	.bmgr_event_mld_sta_add_link = bss_mngr_event_mld_sta_add_link,
	.bmgr_event_mld_sta_del_link = bss_mngr_event_mld_sta_del_link,
	.bmgr_event_mld_sta_notify = bss_mngr_event_mld_sta_notify,
	.bmgr_event_mld_conn_act = bss_mngr_event_conn_act,
	.bmgr_event_mld_disconn_mld_sta = bss_mngr_event_disconn_mld_sta,
	.bmgr_event_mld_disconn_act = bss_mngr_event_disconn_act,
	.bmgr_event_mld_query_probe_rsp_frame = bss_mngr_event_query_probe_rsp_frame,
	.bmgr_event_mld_form_ml_probe_rsp_sta_pf = bss_mngr_event_form_ml_probe_rsp_sta_pf,
	.bmgr_event_mld_ba_add_to_asic = bss_mngr_event_ba_add_to_asic,
	.bmgr_event_mld_ba_del_from_asic = bss_mngr_event_ba_del_from_asic,
	.bmgr_event_mld_twt_action_frm_forward = bss_mngr_event_twt_action_frm_forward,
	.bmgr_event_mld_twt_action_frm_breadown = bss_mngr_event_twt_action_frm_breadown,
	.bmgr_event_mld_twt_action_frm_agg = bss_mngr_event_twt_action_frm_agg,
	.bmgr_event_mld_twt_wait_ack_inform = bss_mngr_event_mld_twt_wait_ack_inform,
#ifdef MWDS
	.bmgr_event_mld_mwds_enable = bss_mbgr_event_mld_mwds_enable,
#endif
	.bmgr_event_mld_critical_update_bcn = bss_mngr_event_mld_critical_update_bcn,
	.bmgr_event_mld_critical_update_op_lock = bss_mngr_event_mld_critical_update_op_lock,
	.bmgr_event_mld_eml_op_update = bss_mngr_event_mld_eml_op_update,
	.bmgr_event_mld_tx_link_recomm = bss_mngr_event_tx_link_recomm,
	.bmgr_event_mld_reconfig = bss_mngr_event_mld_reconfig,
	.bmgr_event_mld_peer_link_reconfig = bss_mngr_event_mld_peer_link_reconfig,
#endif
};

static UCHAR get_opclass_for_rnr(struct _RTMP_ADAPTER *pAd, IN struct wifi_dev *wdev)
{
	UCHAR op_class = get_regulatory_class(pAd,
		wdev->channel, wdev->PhyMode, wdev);

	/* From Cert7 test plan v1.0 4.20:			*/
	/* NOTE: Operating Class 137 is not indicated in RNR,	*/
	/* for back-compatibility with Wi-Fi 6E STAs.			*/
	/* Operating Class subfield set to 131, 132, 133 or 134 */
	/* when operating Class is 137 on 6G band.				*/
	if (op_class == 137)
		op_class = 134;

	return op_class;
}

NDIS_STATUS bss_mngr_fill_bss_info(
	IN struct wifi_dev		*wdev,
	OUT struct bmgr_reg_info	*reg_info
)
{
	struct _RTMP_ADAPTER *ad = NULL;
#ifdef CONFIG_AP_SUPPORT
	BSS_STRUCT *pMbss = NULL;
#endif
	PSECURITY_CONFIG pSecConfig = &wdev->SecConfig;
	u8 band_idx = 0;
	u8 dot11v_mbssid_idx = 0;
	if (wdev) {
#ifdef CONFIG_AP_SUPPORT
		if (wdev->wdev_type == WDEV_TYPE_AP)
			pMbss = wdev->func_dev;
#endif
	} else {
		return NDIS_STATUS_FAILURE;
	}
	ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
	if (ad == NULL)
		return NDIS_STATUS_FAILURE;
	band_idx = HcGetBandByWdev(wdev);
	reg_info->t_bss = NULL;
#if defined(CONFIG_AP_SUPPORT) && defined(DOT11V_MBSSID_SUPPORT)
	if (pMbss) {
		struct mbss_11v_ctrl *bss_11v_ctrl = &pMbss->mbss_11v;
		struct _BSS_STRUCT *t_bss = pMbss;
		dot11v_mbssid_idx = mbss_11v_group_add(ad, wdev);

		if (IS_BSSID_11V_TRANSMITTED(bss_11v_ctrl))
			reg_info->dev_type = DEV_TYPE_AP_11VT;
		else if (IS_BSSID_11V_NON_TRANS(bss_11v_ctrl)) {
			reg_info->dev_type = DEV_TYPE_AP_11VNT;
			t_bss = bss_11v_ctrl->mbss_11v_t_bss;
		} else if (IS_BSSID_11V_CO_HOSTED(bss_11v_ctrl))
			reg_info->dev_type = DEV_TYPE_AP_COH;
		else {
			reg_info->dev_type = DEV_TYPE_AP_LEGACY;
		}

		reg_info->max_bssid_indicator =
			ad->ApCfg.dot11v_max_indicator[bss_11v_ctrl->mbss_11v_grp_idx];

		reg_info->t_bss = t_bss;
	} else
#endif
		reg_info->dev_type = DEV_TYPE_AP_LEGACY;

	reg_info->phy_mode				= wdev->PhyMode;
	reg_info->hw_bss_index			= wdev->bss_info_argument.ucBssIndex;
#ifdef CONFIG_AP_SUPPORT
#ifdef CONFIG_6G_SUPPORT
	reg_info->disc_param.iob_by_cfg = wlan_config_get_unsolicit_tx_by_cfg(wdev);
	reg_info->disc_param.iob_type = wlan_operate_get_unsolicit_tx_type(wdev);
	reg_info->disc_param.iob_interval = wlan_operate_get_unsolicit_tx_tu(wdev);
	reg_info->disc_param.iob_mode = wlan_operate_get_unsolicit_tx_mode(wdev);
	reg_info->disc_param.rnr_6g_rule = wlan_config_get_rnr_in_probe_rsp(wdev);
#endif /* CONFIG_6G_SUPPORT */
	reg_info->single_rnr			= ad->CommonCfg.single_rnr;
	reg_info->bcn_interval			= ad->CommonCfg.BeaconPeriod;
#endif /* CONFIG_AP_SUPPORT */
	reg_info->channel				= wdev->channel;

#ifdef CONFIG_AP_SUPPORT
	if (pMbss) {
		reg_info->dot11v_mbssid_idx	= dot11v_mbssid_idx;
		reg_info->dtim_period		= pMbss->DtimPeriod;
		reg_info->cap_info			= cpu2le16(pMbss->CapabilityInfo);

		/* ssid bssid */
		reg_info->ssid_len			= pMbss->SsidLen;
		reg_info->is_hide_ssid		= pMbss->bHideSsid;
		NdisMoveMemory(reg_info->ssid, pMbss->Ssid, (MAX_LEN_OF_SSID + 1));

#ifdef DOT11_EHT_BE
		reg_info->mld_grp			= pMbss->mld_grp_idx;
		reg_info->tid_map			= pMbss->tid_mapping;
		reg_info->dev_cfg_idx		= get_dev_config_idx(ad);
#endif
	}
#endif

	reg_info->op_class = get_opclass_for_rnr(ad, wdev);

	NdisMoveMemory(reg_info->bssid, wdev->bssid, MAC_ADDR_LEN);

	/* security */
	reg_info->auth_mode			= GET_SEC_AKM(pSecConfig);
	reg_info->PairwiseCipher	= GET_PAIRWISE_CIPHER(pSecConfig);
	reg_info->GroupCipher		= GET_GROUP_CIPHER(pSecConfig);
	/* pmf & RsnCap */
#ifdef DOT11W_PMF_SUPPORT
	reg_info->MFPC			= pSecConfig->PmfCfg.MFPC;
	reg_info->MFPR			= pSecConfig->PmfCfg.MFPR;
#endif
#ifdef DISABLE_HOSTAPD_BEACON
	reg_info->RsnCap[0]		= pSecConfig->RsnCap[0];
	reg_info->RsnCap[1]		= pSecConfig->RsnCap[1];
#endif /* DISABLE_HOSTAPD_BEACON */

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"phymode=%d, mld_grp=%d\n", reg_info->phy_mode, reg_info->mld_grp);

	/* event handler (bmgr->drv) */
	reg_info->event_ops			= &bmgr_event_ops;

	return NDIS_STATUS_SUCCESS;
}

NDIS_STATUS bss_mngr_init(void)
{
	return bmgr_ops.bmgr_init();
}

NDIS_STATUS bss_mngr_deinit(void)
{
	return bmgr_ops.bmgr_deinit();
}

NDIS_STATUS bss_mngr_show_info(u8 type)
{
	return bmgr_ops.bmgr_show_info(type);
}

NDIS_STATUS bss_mngr_dev_reg(
	IN struct wifi_dev	*wdev
)
{
	int ret = NDIS_STATUS_FAILURE;
	struct bmgr_reg_info dev_reg_info;

	NdisZeroMemory(&dev_reg_info, sizeof(dev_reg_info));

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"wdev(%d)\n", wdev->wdev_idx);
			bss_mngr_fill_bss_info(wdev, &dev_reg_info);
			ret = bmgr_ops.bmgr_bss_reg(wdev, &dev_reg_info);
		}
	}

	return ret;
}

NDIS_STATUS bss_mngr_dev_dereg(
	IN struct wifi_dev	*wdev
)
{
	int ret = NDIS_STATUS_FAILURE;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"wdev(%d)\n", wdev->wdev_idx);
#ifdef DOT11V_MBSSID_SUPPORT
			mbss_11v_group_remove((struct _RTMP_ADAPTER *)wdev->sys_handle, wdev);
#endif /* DOT11V_MBSSID_SUPPORT */
			ret = bmgr_ops.bmgr_bss_dereg(wdev);
		}
	}

	return ret;
}

NDIS_STATUS bss_mngr_dev_update(struct wifi_dev *wdev)
{
	int ret = NDIS_STATUS_FAILURE;
	struct bmgr_reg_info dev_reg_info;

	NdisZeroMemory(&dev_reg_info, sizeof(dev_reg_info));

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP &&
			WDEV_BSS_STATE(wdev) >= BSS_READY) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"wdev(%d)\n", wdev->wdev_idx);
			bss_mngr_fill_bss_info(wdev, &dev_reg_info);
			ret = bmgr_ops.bmgr_bss_update(wdev, &dev_reg_info);
		}
	}

	return ret;

}

NDIS_STATUS bss_mngr_ie_update(struct wifi_dev *wdev)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);

			return bmgr_ops.bmgr_ie_update(wdev);
		}
	}
	return NDIS_STATUS_FAILURE;
}

void bss_mngr_sync_bcn_update(struct wifi_dev *wdev)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"wdev(%d)\n", wdev->wdev_idx);

			bmgr_ops.bmgr_sync_bcn_update(wdev);
		}
	}
}
struct _RTMP_ADAPTER *bss_mngr_mld_get_pad_by_band(struct wifi_dev *wdev, UCHAR band_idx)
{
	struct _RTMP_ADAPTER *pad = NULL;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);
			pad = (struct _RTMP_ADAPTER *)bmgr_ops.bmgr_mld_get_pad_by_band_idx(band_idx);
		}
	}
	return pad;
}

#ifdef DOT11V_MBSSID_SUPPORT
u16 bss_mngr_query_mbssid_ie(struct wifi_dev *wdev, struct mbss_query_info *mbss_info)
{
	int ret = NDIS_STATUS_FAILURE;
	u16 f_len = 0;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
					"wdev(%d), is_probe(%d)\n",
					wdev->wdev_idx, mbss_info->is_probe_rsp);
			ret = bmgr_ops.bmgr_query_mbss_info(wdev, mbss_info);
		}
	}

	if (ret != NDIS_STATUS_SUCCESS)
		return 0;

	f_len = mbss_info->f_len;
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
			"\tie len = %d, f_buf = %p\n", f_len, mbss_info->f_buf);

	hex_dump_with_cat_and_lvl("MBSS_IE:", mbss_info->f_buf, f_len,
		DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG);

	return f_len;
}
#endif

u16 bss_mngr_query_rnr_ie(struct wifi_dev *wdev, u8 *f_buf)
{
	int ret = NDIS_STATUS_FAILURE;
	u16 f_len;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
					"wdev(%d)\n", wdev->wdev_idx);
			ret = bmgr_ops.bmgr_query_rnr_info(wdev, f_buf, &f_len);
		}
	}

	if (ret != NDIS_STATUS_SUCCESS)
		return 0;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
			"\tie len = %d, f_buf = %p\n", f_len, f_buf);

	hex_dump_with_cat_and_lvl("RNR_IE:", f_buf, f_len,
		DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG);

	return f_len;
}

bool bss_mngr_query_is_repted_ssid(struct wifi_dev *wdev, u32 short_ssid, u8 *ssid, u8 ssid_len)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
					"wdev(%d)\n", wdev->wdev_idx);
			return bmgr_ops.bmgr_query_is_repted_ssid(wdev, short_ssid, ssid, ssid_len);
		}
	}

	return FALSE;
}

#ifdef CONFIG_6G_SUPPORT
/**
 * API that update the parameters of in-of-band/out-of-band discovery for HE-capable BSS.
 *
 * @wdev: HE-capable BSS
 * @update_type: indicate iob (BSS_IOB_DISCOV_UPDATE) or oob (BSS_OOB_DISCOV_UPDATE)
 */
NDIS_STATUS bss_mngr_update_he_bss_discov(struct wifi_dev *wdev, u8 update_type)
{
	int ret = NDIS_STATUS_FAILURE;
	struct bmgr_disc_param disc_param = {0};

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d), update %d\n", wdev->wdev_idx, update_type);

			disc_param.iob_by_cfg = wlan_config_get_unsolicit_tx_by_cfg(wdev);
			disc_param.iob_type = wlan_operate_get_unsolicit_tx_type(wdev);
			disc_param.iob_interval = wlan_operate_get_unsolicit_tx_tu(wdev);
			disc_param.iob_mode = wlan_operate_get_unsolicit_tx_mode(wdev);
			disc_param.rnr_6g_rule = wlan_config_get_rnr_in_probe_rsp(wdev);

			ret = bmgr_ops.bmgr_update_he_bss_discov(wdev, update_type, &disc_param);
		}
	}

	return ret;
}
#endif /* CONFIG_6G_SUPPORT */

struct wifi_dev *bss_mngr_query_wdev_by_band(u8 band)
{
	struct query_band_netdev query_info = {0};

	/* BAND_24G / BAND_5G / BAND_6G */
	query_info.band = band;
	bmgr_ops.bmgr_query_netdev_by_band(&query_info);

	if (query_info.pNetDev)
		return mt_os_net_dev_get_wdev(query_info.pNetDev);

	return NULL;
}

#ifdef DOT11_EHT_BE
NDIS_STATUS bss_mngr_fill_mld_attr(
	IN struct eht_mld_param *mld_param,
	OUT struct bmgr_mld_attr *mld_attr
)
{

	if (!mld_param || !mld_attr) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Invalid input param(%p), mld_attr(%p)\n",
			mld_param, mld_attr);
		return NDIS_STATUS_INVALID_DATA;
	}

	/* Medium Synchronization Delay */
	mld_attr->med_sync.en = mld_param->msd_en;
	mld_attr->med_sync.dur = mld_param->msd_dur;
	mld_attr->med_sync.ofdm_ed_thr = mld_param->msd_ofdm_ed_thr;
	mld_attr->med_sync.max_txop = mld_param->msd_max_txop;

	/* EML Capabilities */
	switch (mld_param->eml_mode) {
	case EML_DISABLE:
		mld_attr->eml_caps.emlsr_supp = FALSE;
		mld_attr->eml_caps.emlmr_supp = FALSE;
		mld_attr->eml_caps.en = FALSE;
		break;

	case EMLSR:
		mld_attr->eml_caps.emlsr_supp = TRUE;
		mld_attr->eml_caps.emlmr_supp = FALSE;
		mld_attr->eml_caps.en = TRUE;
		break;

	case EMLMR:
		mld_attr->eml_caps.emlsr_supp = FALSE;
		mld_attr->eml_caps.emlmr_supp = TRUE;
		mld_attr->eml_caps.en = TRUE;
		break;

	default:
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"eml_mode %d is invalid\n", mld_param->eml_mode);
		mld_attr->eml_caps.emlsr_supp = FALSE;
		mld_attr->eml_caps.emlmr_supp = FALSE;
		mld_attr->eml_caps.en = FALSE;
	}

	mld_attr->eml_caps.trans_to = mld_param->eml_trans_to;
	mld_attr->eml_caps.eml_omn_en = mld_param->eml_omn;

	/* MLD Capabilities */
	mld_attr->mld_caps.en = TRUE;
	mld_attr->mld_caps.t2l_nego_supp = mld_param->t2lm_nego_supp;
	mld_attr->mld_caps.link_reconfig_op_sup = mld_param->link_reconfig_op_sup;

	return NDIS_STATUS_SUCCESS;
}

/**
 * Core API that create struct bmgr_mlo_dev in bssmngr.
 *
 * @mld_grp: MLD group index for which the MLD is to be created (unique among all MLD)
 * @mld_addr: MLD MAC address (unique among all MLD)
 * @mld_param: MLD attributes of the MLD to be created
 * @mld_type: MLD type, single or multi.
 */
NDIS_STATUS bss_mngr_mld_group_create(
	struct wifi_dev *wdev,
	u8 *mld_grp,
	u8 *mld_addr,
	struct eht_mld_param *mld_param,
	u8 mld_type
)
{
	int ret;
	struct bmgr_mld_attr mld_attr = {0};

	bss_mngr_fill_mld_attr(mld_param, &mld_attr);
	ret = bmgr_ops.bmgr_mld_group_create(wdev, mld_grp, mld_addr, &mld_attr, mld_type);

	return ret;
}

NDIS_STATUS bss_mngr_mld_group_addr_set(
	struct wifi_dev *wdev,
	u8 mld_grp,
	u8 *mld_addr)
{
	return bmgr_ops.bmgr_mld_group_addr_set(wdev, mld_grp, mld_addr);
}

/**
 * API that delete struct bmgr_mlo_dev in bssmngr.
 *
 * @mld_grp: MLD group index for which the MLD is to be deleted (unique among all MLD)
 */
NDIS_STATUS bss_mngr_mld_group_destroy(
	struct wifi_dev *wdev,
	u8 mld_grp)
{
	int ret;

	ret = bmgr_ops.bmgr_mld_group_destroy(wdev, mld_grp);

	return ret;
}

/**
 * API that set/update the attributes of AP MLD (struct bmgr_mlo_dev in bssmngr).
 *
 * @mld_grp: MLD group index for which the MLD is to be set (unique among all MLD)
 */
NDIS_STATUS bss_mngr_mld_group_attr_set(
	u8 mld_grp,
	struct eht_mld_op_ctrl *op_ctrl)
{
	int ret;
	struct bmgr_mld_attr mld_attr = {0};

	bss_mngr_fill_mld_attr(&op_ctrl->mld_param, &mld_attr);
	ret = bmgr_ops.bmgr_mld_group_attr_set(mld_grp,
		op_ctrl->pres_bmap, &mld_attr, op_ctrl->cfg_disconn);

	return ret;
}

/**
 * API that add BSS/Link to the MLD (identified by mld_grp) in bssmngr.
 *
 * @wdev: BSS that is going to join MLD.
 * @mld_grp: MLD group index of MLD to which the BSS requests to join
 */
NDIS_STATUS bss_mngr_mld_group_add_link(struct wifi_dev *wdev, u8 mld_grp)
{
	int ret = NDIS_STATUS_FAILURE;

	if (mld_grp) {
		if (wdev) {
			if (wdev->wdev_type == WDEV_TYPE_AP)
				ret = bmgr_ops.bmgr_mld_group_add_link(wdev, mld_grp);
		}
	} else
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"mld_grp(%d) shall be non-zero\n", mld_grp);

	return ret;
}

/**
 * API that delete BSS/Link in the MLD in bssmngr.
 *
 * @wdev: BSS that is going to leave MLD.
 */
NDIS_STATUS bss_mngr_mld_group_del_link(struct wifi_dev *wdev)
{
	int ret = NDIS_STATUS_FAILURE;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP)
			ret = bmgr_ops.bmgr_mld_group_del_link(wdev);
	}

	return ret;
}

u16 bss_mngr_query_mld_info(struct wifi_dev *wdev, struct query_mld_info *mld_query)
{
	int ret = NDIS_STATUS_FAILURE;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP)
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
					"wdev(%d)\n", wdev->wdev_idx);
		ret = bmgr_ops.bmgr_query_mld_info(wdev, mld_query);
	} else {
		/* queries that do not need dev */
		switch (mld_query->query_type) {
		case BMGR_QUERY_MLD:
		case BMGR_QUERY_BSSID_ML_INFO:
		case BMGR_QUERY_MLD_CONN:
			ret = bmgr_ops.bmgr_query_mld_info(NULL, mld_query);
			break;
		default:
			break;
		}
	}

	if ((mld_query->query_type == BMGR_QUERY_ML_IE_BCN) ||
		(mld_query->query_type == BMGR_QUERY_ML_IE_PROBE_RSP) ||
		(mld_query->query_type == BMGR_QUERY_ML_IE_AUTH_RSP) ||
		(mld_query->query_type == BMGR_QUERY_ML_IE_ASSOC_RSP) ||
		(mld_query->query_type == BMGR_QUERY_ML_IE_LINK_RECONFIG_RSP)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
				"\tIE: Type = %d, ie len = %d, ret=%d\n",
				mld_query->query_type,
				mld_query->ie.f_len,
				ret);

		hex_dump_with_cat_and_lvl("ML_IE:", mld_query->ie.f_buf, mld_query->ie.f_len,
			DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG);

		return mld_query->ie.f_len;
	}

	return ret;
}

u16 bss_mngr_query_tid_to_link_ie(struct wifi_dev *wdev, u8 *f_buf)
{
	int ret = NDIS_STATUS_FAILURE;
	u16 f_len;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
					"wdev(%d)\n", wdev->wdev_idx);
			ret = bmgr_ops.bmgr_query_tid_to_link_info(wdev, f_buf, &f_len);
		}
	}

	if (ret != NDIS_STATUS_SUCCESS)
		return 0;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
			"\tie len = %d, f_buf = %p\n", f_len, f_buf);

	hex_dump_with_cat_and_lvl("T2L_IE:", f_buf, f_len,
		DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG);

	return f_len;
}

u16 bss_mngr_query_multi_link_traffic_ie(struct wifi_dev *wdev, u8 *f_buf)
{
	int ret = NDIS_STATUS_FAILURE;
	u16 f_len;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP)
			ret = bmgr_ops.bmgr_query_multi_link_traffic_ie(wdev, f_buf, &f_len);
	}

	if (ret != NDIS_STATUS_SUCCESS)
		return 0;

	hex_dump_with_cat_and_lvl("MLT_IE:", f_buf, f_len,
		DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG);

	return f_len;
}

NDIS_STATUS bss_mngr_mld_reconfig_ie_op(struct mld_reconfig_ie_op *ie_op)
{
	if (ie_op)
		return bmgr_ops.bmgr_mld_reconfig_ie_op(ie_op);

	return NDIS_STATUS_FAILURE;
}

int bss_mngr_mld_reconfig_ie_build(u8 mld_grp_idx, struct mld_reconfig_ie_build_t *build)
{
	int ret;
	struct mld_reconfig_ie_op ie_op = {0};

	ie_op.op = BMGR_RECONFIG_IE_OP_BUILD;
	ie_op.mld_grp_idx = mld_grp_idx;
	ie_op.reconf_build = build;

	ret = bss_mngr_mld_reconfig_ie_op(&ie_op);

	return ret;
}

int bss_mngr_mld_reconfig_ie_clean(u8 mld_grp_idx)
{
	int ret;
	struct mld_reconfig_ie_op ie_op = {0};

	ie_op.op = BMGR_RECONFIG_IE_OP_CLEAN;
	ie_op.mld_grp_idx = mld_grp_idx;

	ret = bss_mngr_mld_reconfig_ie_op(&ie_op);

	return ret;
}

int bss_mngr_mld_reconfig_ie_clean_link(u8 mld_grp_idx, struct mld_reconfig_ie_clean_t *clean)
{
	int ret;
	struct mld_reconfig_ie_op ie_op = {0};

	ie_op.op = BMGR_RECONFIG_IE_OP_CLEAN_LINK;
	ie_op.mld_grp_idx = mld_grp_idx;
	ie_op.reconf_clean = clean;

	ret = bss_mngr_mld_reconfig_ie_op(&ie_op);

	return ret;
}

u16 bss_mngr_mld_reconfig_ie_query(u8 mld_grp_idx, struct mld_reconfig_ie_query_t *query)
{
	int ret;
	struct mld_reconfig_ie_op ie_op = {0};

	ie_op.op = BMGR_RECONFIG_IE_OP_QUERY;
	ie_op.mld_grp_idx = mld_grp_idx;
	ie_op.reconf_query = query;

	ret = bss_mngr_mld_reconfig_ie_op(&ie_op);

	return (ret == NDIS_STATUS_SUCCESS) ? query->f_len : 0;
}

struct wifi_dev *bss_mngr_query_group_wdev_by_link(u8 group_id, u8 link_id)
{
	struct query_group_link_netdev query_info = {0};

	query_info.group_id = group_id;
	query_info.link_id = link_id;
	query_info.pNetDev = NULL;
	bmgr_ops.bmgr_mld_query_netdev_by_link(&query_info);

	if (query_info.pNetDev)
		return mt_os_net_dev_get_wdev(query_info.pNetDev);
	else
		return NULL;
}

bool bss_mngr_is_wdev_in_mlo_group(struct wifi_dev *wdev)
{

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP)
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);

		return bmgr_ops.bmgr_query_is_mld_wdev(wdev);
	}

	return FALSE;
}

bool bss_mngr_is_in_mlo_csa(struct wifi_dev *wdev)
{

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP)
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);

		return bmgr_ops.bmgr_query_is_in_mlo_csa(wdev);
	}

	return FALSE;
}

u16 bss_mngr_mld_bss_linkup(
	struct wifi_dev *wdev)
{
	int ret = NDIS_STATUS_FAILURE;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);

			ret = bmgr_ops.bmgr_mld_bss_linkup(wdev);
		}
	}

	return ret;
}

u16 bss_mngr_mld_bss_linkdown(
	struct wifi_dev *wdev)
{
	int ret = NDIS_STATUS_FAILURE;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);

			ret = bmgr_ops.bmgr_mld_bss_linkdown(wdev);
		}
	}

	return ret;
}

u16 bss_mngr_mld_bmc_sn_qry(
	struct wifi_dev *wdev,
	u8 *mld,
	u8 *agent_bss,
	u16 *sn,
	struct wifi_dev **wdev_list)
{
	int ret = NDIS_STATUS_FAILURE;
	u8 i = 0;
	PNET_DEV if_dev_list[BSS_MNGR_MAX_BAND_NUM] = {NULL};

	if (wdev && wdev->wdev_type == WDEV_TYPE_AP) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"wdev(%d)\n", wdev->wdev_idx);

		ret = bmgr_ops.bmgr_mld_bmc_sn_qry(wdev, mld, agent_bss, sn, if_dev_list);
		if (ret == NDIS_STATUS_SUCCESS) {
			if (*agent_bss) {
				for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++) {
					wdev_list[i] = NULL;
					if (!if_dev_list[i])
						continue;
					wdev_list[i] =  mt_os_net_dev_get_wdev(if_dev_list[i]);
				}
			}
		}
	}

	return ret;
}

u16 bss_mngr_mld_conn_req(struct wifi_dev *wdev, struct mld_conn_req *mld_conn)
{
	int ret = NDIS_STATUS_FAILURE;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);

			ret = bmgr_ops.bmgr_mld_conn_req(wdev, mld_conn);
		}
	}

	return ret;
}

u16 bss_mngr_mld_conn_act(struct wifi_dev *wdev, u16 mld_sta_idx)
{
	int ret = NDIS_STATUS_FAILURE;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);

			ret = bmgr_ops.bmgr_mld_conn_act(wdev, mld_sta_idx);
		}
	}

	return ret;
}

u16 bss_mngr_mld_disconn_op(struct wifi_dev *wdev, u16 mld_sta_idx, u8 op)
{
	int ret = NDIS_STATUS_FAILURE;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d), op(%d)\n", wdev->wdev_idx, op);

			ret = bmgr_ops.bmgr_mld_disconn_op(wdev, mld_sta_idx, op);
		}
	}

	return ret;
}

u16 bss_mngr_mld_sta_notify(struct wifi_dev *wdev, u16 mld_sta_idx)
{
	int ret = NDIS_STATUS_SUCCESS;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);

			ret = bmgr_ops.bmgr_mld_sta_notify(wdev, mld_sta_idx);
		}
	}

	return ret;
}

int bss_mngr_query_mld_basic(struct query_mld_basic *mld_basic)
{
	int ret;
	struct query_mld_info mld_query = {0};

	mld_query.query_type	= BMGR_QUERY_MLD;
	mld_query.mld_basic		= mld_basic;

	ret = bss_mngr_query_mld_info(NULL, &mld_query);

	if (ret == NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"Addr(%pM) grp(%d) type(%d) link_cnt(%d)\n",
				mld_basic->addr, mld_basic->mld_grp_idx,
				mld_basic->mld_type, mld_basic->link_cnt);
	}
	return ret;
}

int bss_mngr_query_mld_ap_basic(struct wifi_dev *wdev, struct query_mld_ap_basic *basic)
{
	int ret = NDIS_STATUS_FAILURE;
	struct query_mld_info mld_query = {0};

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			mld_query.query_type	= BMGR_QUERY_ML_AP_BASIC;
			mld_query.basic			= basic;

			ret = bss_mngr_query_mld_info(wdev, &mld_query);

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"Basic link_cnt = %d, link_id = %d, %pM\n",
					basic->link_cnt, basic->link_id, basic->addr);
		}
	}
	return ret;
}

int bss_mngr_query_mld_by_bssid(struct query_mld_ap_basic *basic)
{
	int ret;
	struct query_mld_info mld_query = {0};

	mld_query.query_type = BMGR_QUERY_BSSID_ML_INFO;
	mld_query.basic = basic;

	ret = bss_mngr_query_mld_info(NULL, &mld_query);

	if (ret == NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"Basic link_cnt = %d, link_id = %d, %pM\n",
			basic->link_cnt, basic->link_id, basic->addr);
	}
	return ret;
}

u16 bss_mngr_query_mld_sta_aid(struct wifi_dev *wdev, u16 mld_sta_idx)
{
	int ret;
	struct query_mld_info mld_query = {0};
	struct query_mld_sta sta;
	u16 mld_aid = INVALID_AID;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			sta.mld_sta_idx         = mld_sta_idx;

			mld_query.query_type	= BMGR_QUERY_ML_STA;
			mld_query.sta			= &sta;

			ret = bss_mngr_query_mld_info(wdev, &mld_query);

			if (ret == NDIS_STATUS_SUCCESS) {
				mld_aid = sta.aid;
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"mld_sta_idx = %d, aid = %d, addr %pM\n",
						sta.mld_sta_idx, sta.aid, sta.mld_addr);
			}
		}
	}

	return mld_aid;
}

int bss_mngr_query_mld_conn(struct query_mld_conn *mld_conn)
{
	int ret;
	struct query_mld_info mld_query = {0};

	mld_query.query_type = BMGR_QUERY_MLD_CONN;
	mld_query.mld_conn = mld_conn;

	ret = bss_mngr_query_mld_info(NULL, &mld_query);

	if (ret == NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"MLD %d, Num of associated MLD STA = %d\n",
			mld_conn->mld_group_idx, mld_conn->mld_sta_num);
	}

	return ret;
}

int bss_mngr_mld_add_sta_profile(
	struct wifi_dev *wdev,
	u16 mld_sta_idx,
	u8 link_id,
	u8 frame_mld_type,
	u8 *buf,
	u16 buf_len
)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);

			return bmgr_ops.bmgr_mld_add_sta_profile(wdev,
				mld_sta_idx, link_id, frame_mld_type, buf, buf_len);
		}
	}

	return NDIS_STATUS_FAILURE;
}

bool bss_mngr_mld_remove_sta_profile(
	struct wifi_dev *wdev,
	u8 frame_mld_type,
	u8 *elmt_id_arr,
	u16 id_arr_len
)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);

			return bmgr_ops.bmgr_mld_remove_sta_profile(wdev,
				frame_mld_type, elmt_id_arr, id_arr_len);
		}
	}

	return FALSE;
}

void bss_mngr_mld_sync_ml_probe_rsp(struct wifi_dev *wdev)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);

			bmgr_ops.bmgr_mld_sync_ml_probe_rsp_per_sta_profile(wdev);
		}
	}
}

void bss_mngr_mld_ba_add_to_asic(
	struct wifi_dev *wdev,
	u16 mld_sta_idx,
	u8 TID,
	u16 Seq,
	u16 BAWinSize,
	int type,
	u8 amsdu_en
)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);
			bmgr_ops.bmgr_mld_ba_add_to_asic(wdev, mld_sta_idx, TID, Seq, BAWinSize, type, amsdu_en);
		}
	}
}

void bss_mngr_mld_ba_del_from_asic(
	struct wifi_dev *wdev,
	u16 mld_sta_idx,
	u8 TID,
	int type,
	u8 amsdu_en
)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);
			bmgr_ops.bmgr_mld_ba_del_from_asic(wdev, mld_sta_idx, TID, type, amsdu_en);
		}
	}
}

void bss_mngr_mld_twt_action_frm_forward(
	struct _RTMP_ADAPTER *ad,
	struct _MLME_QUEUE_ELEM *elem
)
{
	struct _MAC_TABLE_ENTRY *peer_entry = NULL;
	struct wifi_dev *wdev = NULL;

	peer_entry = entry_get(ad, elem->Wcid);
	wdev = peer_entry->wdev;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(ad, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
				"master link=%s\n", wdev->if_dev->name);
			bmgr_ops.bmgr_mld_forward_action_to_link(wdev, elem);
		}
	}
}

u8 bss_mngr_mld_twt_action_frm_breadown(
	struct _RTMP_ADAPTER *ad,
	struct _MLME_QUEUE_ELEM *elem
)
{
	u8 breakdown = 0;
	u16 mld_sta_idx = 0;
	struct _MAC_TABLE_ENTRY *peer_entry = NULL;
	struct wifi_dev *wdev = NULL;
	struct mld_entry_t *mld_entry;
	int mlo_entry_exist = FALSE;

	peer_entry = entry_get(ad, elem->Wcid);
	wdev = peer_entry->wdev;

	if (peer_entry->mlo.mlo_en) {
		mt_os_lockless_enter(os_lockless_ctx_get());
		mld_entry = get_mld_entry_by_mac(peer_entry->mlo.mld_addr);
		if (mld_entry) {
			mlo_entry_exist = TRUE;
			mld_sta_idx = mld_entry->mld_sta_idx;
		}
		mt_os_lockless_exit(os_lockless_ctx_get());

		if (mlo_entry_exist && wdev) {
			if (wdev->wdev_type == WDEV_TYPE_AP) {
				MTWF_DBG(ad, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
					"IF=%s,wdev_idx=%d\n", wdev->if_dev->name, wdev->wdev_idx);
				breakdown = bmgr_ops.bmgr_mld_breakdown_action_frame(
							wdev, mld_sta_idx, elem);
			}
		}
	}

	MTWF_DBG(ad, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
		"breakdown=%d\n", breakdown);

	return breakdown;
}

void bss_mngr_mld_twt_action_frm_agg(
	struct wifi_dev *wdev,
	struct frame_itwt_setup *itwt_setup_frame,
	struct MLO_TWT_PRIV_T *priv
)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
				"IF=%s,wdev_idx=%d\n", wdev->if_dev->name, wdev->wdev_idx);
			bmgr_ops.bmgr_mld_aggregate_action_frame(wdev, itwt_setup_frame, priv);
		}
	}
}

void bss_mngr_mld_twt_wait_ack_inform(
	struct wifi_dev *wdev,
	u16 mld_sta_idx,
	u8 action_linkid,
	u16 all_linkid_bitmap,
	u8 wait_ack_sts
)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
				"IF=%s,wdev_idx=%d,mld_sta_idx=%d,action_linkid=%d,all_linkid_bitmap=0x%x,wait_ack_sts=%d\n",
				wdev->if_dev->name, wdev->wdev_idx, mld_sta_idx,
				action_linkid, all_linkid_bitmap, wait_ack_sts);
			bmgr_ops.bmgr_mld_twt_wait_ack_inform(wdev,
				mld_sta_idx, action_linkid, all_linkid_bitmap, wait_ack_sts);
		}
	}
}

#ifdef MWDS
u8 bss_mngr_mld_mwds_enable(struct wifi_dev *wdev, u8 enable)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
				"IF=%s,wdev_idx=%d\n",
				wdev->if_dev->name, wdev->wdev_idx);
			return bmgr_ops.bmgr_mld_mwds_cap_sync(wdev, enable);
		}
	}

	return FALSE;
}
#endif

/* bcn_reason is original reason w/o Critical Update high bit[6] set */
void bss_mngr_mld_critical_update_trigger(struct wifi_dev *wdev, u8 upd_scope, u8 bcn_reason)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_AP, CATAP_BCN, DBG_LVL_INFO,
				"(caller:%pS), wdev_idx:%d , bcn_reason=%x\n", OS_TRACE, wdev->wdev_idx, bcn_reason);
			bmgr_ops.bmgr_mld_critical_update_trigger(wdev, upd_scope, bcn_reason);
		}
	}
}

BOOLEAN bss_mngr_mld_critical_update_op_lock(struct wifi_dev *wdev, u8 lock_flag)
{
	BOOLEAN status = FALSE;

	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_INFO,
				"wdev_idx:%d lock_flag:%d,(caller:%pS\n", wdev->wdev_idx, lock_flag, OS_TRACE);
			status = bmgr_ops.bmgr_mld_critical_update_op_lock(wdev, lock_flag);
		}
	}
	return status;
}


void bss_mngr_mld_eml_op_update(struct wifi_dev *wdev, struct mld_eml_op *eml_op)
{
	if (wdev) {
		if (wdev->wdev_type == WDEV_TYPE_AP) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"wdev(%d)\n", wdev->wdev_idx);
			bmgr_ops.bmgr_mld_eml_op_update(wdev, eml_op);
		}
	}
}

void bss_mngr_mld_tx_link_recomm(u8 mld_grp_idx, u16 tx_link_bmap, struct mld_link_recomm *link_recomm)
{
	if (BMGR_VALID_MLD_GRP_IDX(mld_grp_idx) && tx_link_bmap && link_recomm)
		bmgr_ops.bmgr_mld_tx_link_recomm(mld_grp_idx, tx_link_bmap, link_recomm);
}

void bss_mngr_mld_reconfig_peer_mld(u8 mld_grp_idx, u16 rm_link_id_bitmap)
{
	if (BMGR_VALID_MLD_GRP_IDX(mld_grp_idx))
		bmgr_ops.bmgr_mld_reconfig_peer_mld(mld_grp_idx, rm_link_id_bitmap);
}

int bss_mngr_mld_peer_link_reconf_req(struct mld_link_reconfig_req *lr_req, enum _BMGR_LINK_RECONFIG_REQ_OP op)
{
	if (lr_req && BMGR_VALID_MLD_STA(lr_req->mld_sta_idx))
		return bmgr_ops.bmgr_mld_peer_link_reconf_req(lr_req, op);

	return NDIS_STATUS_FAILURE;
}

#endif
