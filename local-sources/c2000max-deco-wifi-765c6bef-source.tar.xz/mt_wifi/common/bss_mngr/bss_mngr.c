/*
 ***************************************************************************
 * MediaTek Inc.
 * 4F, No. 2 Technology 5th Rd.
 * Science-based Industrial Park
 * Hsin-chu, Taiwan, R.O.C.
 *
 * (c) Copyright 1997-2019, MediaTek, Inc.
 *
 * All rights reserved. MediaTek source code is an unpublished work and the
 * use of a copyright notice does not imply otherwise. This source code
 * contains confidential trade secret material of MediaTek. Any attempt
 * or participation in deciphering, decoding, reverse engineering or in any
 * way altering the source code is stricitly prohibited, unless the prior
 * written consent of MediaTek Technology, Inc. is obtained.
 ***************************************************************************

*/
#include "rt_config.h"
#include "bss_mngr.h"
#include "mlo_mgr.h"
#include "common/static_id.h"

struct bss_manager bss_mngr;

static const char * const dev_type_str[] = {
	"Legacy",
	"11vT",
	"11vNT",
	"CoH"
};

static const char * const rnr_rule_str[] = {
	"None",
	"All",
};

static bool bss_idx_assigned(u8 idx)
{
	if (bss_mngr.bss_idx_bitmap) {
		if (bss_mngr.bss_idx_bitmap[idx / 32] & (1 << (idx % 32)))
			return TRUE;
	}

	return FALSE;
}

static void bss_idx_set(u8 idx)
{
	if (bss_mngr.bss_idx_bitmap)
		bss_mngr.bss_idx_bitmap[idx / 32] |= (1 << (idx % 32));
}

static void bss_idx_clear(u8 idx)
{
	if (bss_mngr.bss_idx_bitmap)
		bss_mngr.bss_idx_bitmap[idx / 32]  &= ~(1 << (idx % 32));
}

static u8 bss_idx_acquire(void)
{
	u16 bssidx;

	for (bssidx = 0; bssidx < BMGR_MAX_BSS_CNT; bssidx++) {
		if (!bss_idx_assigned(bssidx)) {
			bss_idx_set(bssidx);
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					 "found non-occupied bssidx:%d\n",
					  bssidx);
			break;
		}
	}

	if (!BMGR_VALID_BSS_IDX(bssidx))
		bssidx = BMGR_INVALID_BSS_IDX;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE, ": bssidx [%d]\n", bssidx);

	return bssidx;
}

static void bss_idx_bitmap_init(void)
{
	u32 *bss_idx_bitmap = NULL;
	u32 map_size = 0;

	/* allocate up to can contain BMGR_MAX_BSS_CNT */
	map_size = ((BMGR_MAX_BSS_CNT + 31) / 32) * sizeof(u32);

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"map_size=%d\n", map_size);

	os_alloc_mem(NULL, (u8 **)&bss_idx_bitmap, map_size);
	if (bss_idx_bitmap == NULL) {
		dump_stack();
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				 "Allocate memory size:%d for bss_idx_bitmap failed!\n",
				  map_size);
		return;
	}

	os_zero_mem(bss_idx_bitmap, map_size);
	bss_mngr.bss_idx_bitmap = bss_idx_bitmap;
}

static void bss_idx_bitmap_deinit(void)
{
	u32 *bss_idx_bitmap = bss_mngr.bss_idx_bitmap;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE, "--->\n");

	if (bss_idx_bitmap)
		os_free_mem(bss_idx_bitmap);

	bss_mngr.bss_idx_bitmap = NULL;
}


/*
 * get tx-bss index of nt-bss
 */
static u8 get_tx_bss_idx(IN struct bmgr_entry *entry)
{
	struct bmgr_entry *bmg_entry = NULL;
	u8 dev_type = entry->entry_info.dev_type;
	int i;
	u8 bss_idx_tx = entry->bss_idx;

	if (IS_DEV_TYPE_11V_NT(dev_type)) {
		for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
			bmg_entry = GET_BSS_ENTRY_BY_IDX(i);
			/* search 1st tx-bss on the same band */
			if (bmg_entry
				&& (bmg_entry->entry_info.dev_type == DEV_TYPE_AP_11VT)
				&& (bmg_entry->entry_info.t_bss == entry->entry_info.t_bss)) {
				bss_idx_tx = i;
				break;
			}
		}
	}

	return bss_idx_tx;
}

#ifdef DOT11_EHT_BE
#ifdef MLD_GROUP_ID_REMAPPING_V1
#define MAX_MLD_GRP_NUM 128

static int mld_idx_mapping_v1_init(void)
{
	if (bss_mngr.mld_grp_idx_mapping_v1) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"mld_grp_idx_mapping_v1 already initialized\n");
		return -EFAULT;
	}

	bss_mngr.mld_grp_idx_mapping_v1 = static_id_alloc(0);
	if (!bss_mngr.mld_grp_idx_mapping_v1) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"mld_grp_idx_mapping_v1 initialized failed\n");
		return -EFAULT;
	}

	return NDIS_STATUS_SUCCESS;
}

static void mld_idx_mapping_v1_deinit(void)
{
	if (bss_mngr.mld_grp_idx_mapping_v1) {
		static_id_free(bss_mngr.mld_grp_idx_mapping_v1);
		bss_mngr.mld_grp_idx_mapping_v1 = NULL;
	}
}

int mld_idx_mapping_v1_store(unsigned long id, void *data, void (*data_free_fn)(void *))
{
	int ret;

	if (!bss_mngr.mld_grp_idx_mapping_v1) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"mld_grp_idx_mapping_v1 not initialized, id:%lu data:%p\n", id, data);
		return -EFAULT;
	}

	ret = static_id_store(bss_mngr.mld_grp_idx_mapping_v1, id, data, data_free_fn);
	if (ret != 0) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"id:%lu already has data\n", id);
	}

	return ret;
}

void *mld_idx_mapping_v1_load(unsigned long id)
{
	if (!bss_mngr.mld_grp_idx_mapping_v1) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"mld_grp_idx_mapping_v1 not initialized, id:%lu\n", id);
		return NULL;
	}
	return static_id_load(bss_mngr.mld_grp_idx_mapping_v1, id);
}

int mld_idx_mapping_v1_erase(unsigned long id)
{
	if (!bss_mngr.mld_grp_idx_mapping_v1) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"mld_grp_idx_mapping_v1 not initialized, id:%lu\n", id);
		return -EINVAL;
	}
	return static_id_erase(bss_mngr.mld_grp_idx_mapping_v1, id);
}
#endif /* MLD_GROUP_ID_REMAPPING_V1 */


static struct bss_mngr_event_ops *bmgr_event_ops_get(void)
{
	return bss_mngr.event_ops;
}

static void mld_sta_idx_release(u16 mld_sta_idx)
{
	struct bmgr_mld_sta *mld_sta = NULL;

	if (BMGR_VALID_MLD_STA(mld_sta_idx)) {
		mld_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);
		os_zero_mem(mld_sta, sizeof(struct bmgr_mld_sta));

		/* init setting */
		mld_sta->idx = mld_sta_idx;
		mld_sta->aid = INVALID_AID;
	}
}

static void mld_sta_init(void)
{
	u16 idx;

	for (idx = 0; BMGR_VALID_MLD_STA(idx); idx++)
		mld_sta_idx_release(idx);
}

static void mld_twt_init(struct bss_mlo_twt *mlo_twt_ctrl)
{
	if (!mlo_twt_ctrl)
		return;

	NdisAllocateSpinLock(NULL, &mlo_twt_ctrl->lock);
	INIT_LIST_HEAD(&mlo_twt_ctrl->breakdown_action_frame_list);
}

static void mld_twt_deinit(struct bss_mlo_twt *mlo_twt_ctrl)
{
	BOOLEAN cancelled;
	RALINK_TIMER_STRUCT *timer = NULL;

	if (!mlo_twt_ctrl)
		return;

	timer = &mlo_twt_ctrl->agg_action_frame_timer;
	RTMPCancelTimer(timer, &cancelled);
	RTMPReleaseTimer(timer, &cancelled);

	NdisFreeSpinLock(&mlo_twt_ctrl->lock);
	INIT_LIST_HEAD(&mlo_twt_ctrl->breakdown_action_frame_list);
}

static void mld_sta_destroy(struct bmgr_entry *entry, u16 mld_sta_idx, u8 *mld_addr)
{
	if (BMGR_VALID_MLD_STA(mld_sta_idx)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"(%pS): mld_sta_idx(%d), mld_addr %pM\n",
			OS_TRACE, mld_sta_idx, mld_addr);

		bss_mngr_con_mld_sta_del(entry->pwdev, mld_sta_idx, mld_addr);

		/* clear mld station entry */
		mld_sta_idx_release(mld_sta_idx);
	}
}

static u16 mld_sta_idx_acquire(struct bmgr_entry *entry, u8 *mld_addr, u8 frm_subtype, u8 *setup_link_addr)
{
	u16 idx;
	u16 first_unused_idx = BMGR_MAX_MLD_STA_CNT;
	struct bmgr_mld_sta *mld_sta = NULL;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			": mld_addr %pM\n", mld_addr);

	for (idx = 0; BMGR_VALID_MLD_STA(idx); idx++) {
		mld_sta = GET_MLD_STA_BY_IDX(idx);
		if ((mld_sta->valid == 0) && (first_unused_idx == BMGR_MAX_MLD_STA_CNT)) {
			first_unused_idx = idx;
		} else if (mld_sta->valid && NdisEqualMemory(mld_sta->mld_addr, mld_addr, MAC_ADDR_LEN)) {
			if (frm_subtype == SUBTYPE_AUTH) {
				/* clear mld_sta and all pEntry if receive
					Auth.Req again from the same MLD */
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
					"Auth same MLD peer(%d)(%pM), clear peer MLD entries\n", idx, mld_addr);

				bss_mngr_con_mld_sta_del_links(mld_sta, MLD_DISC_OP_DEL_STA_N_ACT);

				mld_sta_destroy(entry, idx, mld_addr);
			} else if (frm_subtype == SUBTYPE_ASSOC_REQ) {
				u8 link_id;

				/* setup link shall be one of link of existing MLD STA */
				for (link_id = 0; link_id < BSS_MNGR_MAX_BAND_NUM; link_id++) {
					if (mld_sta->mld_link[link_id].active &&
						MAC_ADDR_EQUAL(mld_sta->mld_link[link_id].link_addr, setup_link_addr)) {
						MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
							"Assoc same MLD peer(%d)(%pM), it's valid (re)assoc: %pM\n",
							idx, mld_addr, setup_link_addr);
						return idx;
					}
				}

				/* unknown setup link addr with existing mld addr */
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Assoc same MLD peer(%d)(%pM), but unknown setup link addr: %pM\n",
					idx, mld_addr, setup_link_addr);
				return BMGR_MAX_MLD_STA_CNT;
			} else
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"\tre-use mld_sta_idx:%d\n", idx);
			return idx;
		}
	}

	if (BMGR_VALID_MLD_STA(first_unused_idx)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"\tun-used mld_sta_idx:%d\n", first_unused_idx);
		return first_unused_idx;
	}

	return BMGR_MAX_MLD_STA_CNT;
}

static bool bss_idx_mld_inited(IN struct bmgr_entry *entry)
{
	/* mld buffer allocated */
	if (entry->mld_cmm.buf) {
		/* entry is mlo_en and MLD exists */
		if (BMGR_VALID_MLO_BSS_ENTRY(entry) && BMGR_VALID_MLO_DEV(entry->mld_ptr))
			return true;
	}

	return false;
}

static void bmgr_mld_reset(IN struct bmgr_mlo_dev *mld)
{
	u8 i;

	mld->mld_link_cnt = 0;
	for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++)
		mld->bss_idx_mld[i] = BMGR_INVALID_BSS_IDX;

	at2lm_contract_reset(mld);
}

static bool alloc_bcn_appl_elem_per_sta_pf(struct bmgr_entry *entry)
{
	u8 repting_link;
	struct ie *per_sta_pf = NULL;
	u8 bss_idx_mld;
	struct bmgr_mlo_dev *mld = NULL;

	mld = entry->mld_ptr;
	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error, bss_idx (%d) in mld (%d) is invalid\n",
			entry->bss_idx, entry->entry_info.mld_grp);
		return FALSE;
	}

	for (repting_link = 0; repting_link < BSS_MNGR_MAX_BAND_NUM; repting_link++) {
		bss_idx_mld = mld->bss_idx_mld[repting_link];

		if (!BMGR_VALID_BSS_IDX(bss_idx_mld))
			continue;

		per_sta_pf = &entry->bcn_appl_elem_per_sta_pf[repting_link];
		if (!per_sta_pf->buf) {
			os_alloc_mem(NULL, (UCHAR **)&per_sta_pf->buf, BSS_MNGR_MAX_PER_STA_PROFILE_LEN);
			if (!per_sta_pf->buf) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Alloc buf for bcn_appl_elem_per_sta_pf failed.\n");
				return FALSE;
			}
		} else
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"The per-sta profile buffer(%p) not NULL!\n", per_sta_pf->buf);

		os_zero_mem(per_sta_pf->buf, BSS_MNGR_MAX_PER_STA_PROFILE_LEN);
		per_sta_pf->len = 0;
		entry->csa.repted_csa_offset_in_per_sta_pf[repting_link] = 0;
		entry->csa.repting_csa_offset_in_per_sta_pf[repting_link] = 0;

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"Allocate the per-sta-prf buffer[%p] for repted_link[%d] entry repting_link[%d]!\n",
			per_sta_pf->buf, entry->link_id, repting_link);
	}

	return TRUE;
}

static void free_bcn_appl_elem_per_sta_pf(struct bmgr_entry *entry)
{
	u8 link;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR, "\n");

	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		if (entry->bcn_appl_elem_per_sta_pf[link].buf) {
			os_free_mem(entry->bcn_appl_elem_per_sta_pf[link].buf);
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"free (bcn_per_sta_pf[%d]:%p)\n",
				link, entry->bcn_appl_elem_per_sta_pf[link].buf);

			entry->bcn_appl_elem_per_sta_pf[link].buf = NULL;
			entry->bcn_appl_elem_per_sta_pf[link].len = 0;
			entry->csa.repted_csa_offset_in_per_sta_pf[link] = 0;
			entry->csa.repted_csa_bss_idx[link] = 0;

			entry->csa.repting_csa_offset_in_per_sta_pf[link] = 0;
			entry->csa.repting_csa_bss_idx[link] = 0;
		}
	}
}

static void clean_bcn_appl_elem_per_sta_pf(struct bmgr_entry *entry)
{
	u8 link;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE, "\n");

	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		if (entry->bcn_appl_elem_per_sta_pf[link].buf) {
			os_zero_mem(entry->bcn_appl_elem_per_sta_pf[link].buf,
				BSS_MNGR_MAX_PER_STA_PROFILE_LEN);
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"Clean (bcn_per_sta_pf[%d]:%p)\n",
				link, entry->bcn_appl_elem_per_sta_pf[link].buf);

			entry->bcn_appl_elem_per_sta_pf[link].len = 0;
			entry->csa.repted_csa_offset_in_per_sta_pf[link] = 0;
			entry->csa.repted_csa_bss_idx[link] = 0;
		}
	}
}

/* add appl_elem into per_sta_profile buf for mlo reporting links,
	the buf will be used in bcn/probe_rsp composing */
static void mld_add_appl_elem(
	struct bmgr_entry *repted_entry,
	IN u8 *buf,
	IN u16 buf_len
)
{
	u8 repted_link, repting_link;
	u8 repted_bss_idx;
	u8 *f_buf, *pos, *tmp_buf;
	u16 cap_ie, ie_len;
	struct bmgr_mlo_dev *mld = NULL;
	struct ie *per_sta_pf = NULL;
	struct ie *tmp_per_sta_pf = NULL;

	if (!repted_entry) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: repted_entry is NULL!\n");
		return;
	}

	if (!buf) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: buf is NULL!\n");
		return;
	}

	mld = repted_entry->mld_ptr;
	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"bss_idx (%d) is not in mld (%d)\n",
			repted_entry->bss_idx, repted_entry->entry_info.mld_grp);
		return;
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE, "\n");

	/* if true => do not need Per-STA Profile */
	if (!BMGR_VALID_MLO_BSS_ENTRY(repted_entry) || mld->mld_link_cnt < 2)
		return;

	if (!alloc_bcn_appl_elem_per_sta_pf(repted_entry))
		return;

	{
		u8 link_id;

		for (link_id = 0; link_id < BSS_MNGR_MAX_BAND_NUM; link_id++) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"per-sta-prf buffer[%p-%d] for repted_link[%d] entry repting_link[%d].\n",
				repted_entry->bcn_appl_elem_per_sta_pf[link_id].buf,
				repted_entry->bcn_appl_elem_per_sta_pf[link_id].len, repted_entry->link_id, link_id);
		}
	}

	/* Loop each link to append element */

	/* repted_link: the link that is reported in Per-STA Profile in ML IE */
	repted_bss_idx = repted_entry->bss_idx;
	repted_link = repted_entry->link_id;
	tmp_per_sta_pf = &repted_entry->bcn_appl_elem_per_sta_pf[repted_link];
	tmp_buf = tmp_per_sta_pf->buf;

	/* build cap ie */
	ie_len = PER_STA_PROILE_CAP_INFO_SIZE;
	cap_ie = cpu2le16(repted_entry->entry_info.cap_info);
	NdisMoveMemory(tmp_buf, &cap_ie, ie_len);
	tmp_per_sta_pf->len += ie_len;
	tmp_buf += tmp_per_sta_pf->len;

	/* append input buf (IEs) */
	NdisMoveMemory(tmp_buf, buf, buf_len);
	tmp_per_sta_pf->len += buf_len;

	/* repting_link: the link that will tx the frm */
	for (repting_link = 0; repting_link < BSS_MNGR_MAX_BAND_NUM; repting_link++) {
		if (repted_link == repting_link)
			continue;

		/*
		 *  Ex. repted entry [if link 0]
		 *    bcn_appl_elem_per_sta_pf
		 *      [0]: Per-STA Profile of repted [link 0] for repting [link 0]
		 *            -> (used for tmp buf)
		 *      [1]: Per-STA Profile of repted [link 0] for repting [link 1]
		 *      [2]: Per-STA Profile of repted [link 0] for repting [link 2]
		 *
		 *  if peer transmits bcn by link 1:
		 *     - [link 0 entry] deliver bcn_appl_elem_per_sta_pf[1] to [link 1].
		 *     - [link 1 entry] skip.
		 *     - [link 2 entry] deliver bcn_appl_elem_per_sta_pf[1] to [link 1].
		 */
		per_sta_pf = &repted_entry->bcn_appl_elem_per_sta_pf[repting_link];

		if (per_sta_pf->buf) {
			f_buf = pos = per_sta_pf->buf;
			pos = build_multi_link_per_sta_profile(
					repted_entry,
					f_buf,
					BMGR_MLD_APPL_ELEM_STA_PROFILE,
					BMGR_MAX_MLD_STA_CNT,
					repting_link);
			per_sta_pf->len = pos - f_buf;
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"[%p] repted link %d, per-sta profile len %d for repting link %d!\n",
				per_sta_pf, repted_link, per_sta_pf->len, repting_link);
		}
	}
}

/* remove appl_elem from per_sta_profile buf for mlo reporting links,
	the buf will be used in bcn/probe_rsp composing */
static void mld_remove_appl_elem(struct bmgr_entry *repted_entry)
{
	if (!repted_entry) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: repted_entry is NULL!\n");
		return;
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE, "\n");
	clean_bcn_appl_elem_per_sta_pf(repted_entry);
}

static void mld_free_reconfig_ml_ie(struct bmgr_mlo_dev *mld)
{
	struct reconfig_ml_ie_t *reconf_ie;
	u8 link;

	if (!mld) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error, mld (%d) is null\n",
			mld ? mld->mld_grp : BMGR_INVALID_MLD_GRP);
		return;
	}

	reconf_ie = &mld->reconf_ie;
	if (reconf_ie->ie_status < BUF_STAT_ALLOCED)
		return;

	reconf_ie->ie_status = BUF_STAT_NULL;

	reconf_ie->common_info.len = 0;
	if (reconf_ie->common_info.buf) {
		os_free_mem(reconf_ie->common_info.buf);
		reconf_ie->common_info.buf = NULL;
	}

	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		reconf_ie->link_info[link].len = 0;
		if (reconf_ie->link_info[link].buf) {
			os_free_mem(reconf_ie->link_info[link].buf);
			reconf_ie->link_info[link].buf = NULL;
		}
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_DEBUG,
		"Free success, ie status %d\n", reconf_ie->ie_status);
}

static void mld_clean_reconfig_ml_ie(struct bmgr_mlo_dev *mld)
{
	struct reconfig_ml_ie_t *reconf_ie;
	u8 link;

	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error, mld (%d) is invalid\n",
			mld ? mld->mld_grp : BMGR_INVALID_MLD_GRP);
		return;
	}

	reconf_ie = &mld->reconf_ie;
	if (reconf_ie->ie_status < BUF_STAT_ALLOCED)
		return;

	reconf_ie->ie_status = BUF_STAT_ALLOCED;

	reconf_ie->common_info.len = 0;
	if (reconf_ie->common_info.buf)
		NdisZeroMemory(reconf_ie->common_info.buf, MAX_RECONFIG_ML_IE_COMMON_LEN);

	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		reconf_ie->fw_bss_idx[link] = 0; /* TBD */
		reconf_ie->tmr_offset[link] = 0;
		reconf_ie->link_info[link].len = 0;
		if (reconf_ie->link_info[link].buf)
			NdisZeroMemory(reconf_ie->link_info[link].buf,
				MAX_RECONFIG_ML_IE_PER_LINK_INFO_LEN);
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_DEBUG,
		"Clean success, ie status %d\n", reconf_ie->ie_status);
}

static bool mld_alloc_reconfig_ml_ie(struct bmgr_mlo_dev *mld)
{
	struct reconfig_ml_ie_t *reconf_ie;
	u8 *buf, link;

	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error, mld (%d) is invalid\n",
			mld ? mld->mld_grp : BMGR_INVALID_MLD_GRP);
		return FALSE;
	}

	reconf_ie = &mld->reconf_ie;
	if (reconf_ie->ie_status >= BUF_STAT_ALLOCED)
		return TRUE;

	/* alloc common part */
	reconf_ie->common_info.len = 0;
	if (!reconf_ie->common_info.buf) {
		os_alloc_mem(NULL, &buf, MAX_RECONFIG_ML_IE_COMMON_LEN);
		if (!buf)
			goto err;
		reconf_ie->common_info.buf = buf;
	}

	/* alloc per-link part */
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		reconf_ie->link_info[link].len = 0;
		if (!reconf_ie->link_info[link].buf) {
			os_alloc_mem(NULL, &buf, MAX_RECONFIG_ML_IE_PER_LINK_INFO_LEN);
			if (!buf)
				goto err;
			reconf_ie->link_info[link].buf = buf;
		}
	}

	reconf_ie->ie_status = BUF_STAT_ALLOCED;

	mld_clean_reconfig_ml_ie(mld);

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
		"Alloc success, ie status %d\n", reconf_ie->ie_status);

	return TRUE;
err:
	mld_free_reconfig_ml_ie(mld);

	return FALSE;
}
#endif

#ifdef MLD_GROUP_ID_REMAPPING_V1
static void bss_mngr_con_mld_free(void *data)
{
	struct bmgr_mlo_dev *mld = data;

	ASSERT(mld);

	mld_free_reconfig_ml_ie(mld);
	os_free_mem(mld);
}
#endif

static struct bmgr_entry *get_bss_entry_by_wdev(
	struct wifi_dev *wdev)
{
	struct bmgr_entry *entry = NULL;
	int i;

	if (!wdev)
		return NULL;

	for (i = 0; BMGR_VALID_BSS_IDX(i); i++) {
		entry = bss_mngr.entry[i];

		if (entry && (entry->pwdev == wdev))
			return entry;
	}

	return NULL;
}

#ifdef DOT11V_MBSSID_SUPPORT
int bss_mngr_con_ie_update_mbss(struct bmgr_entry *entry)
{
	u8 dev_type = entry->entry_info.dev_type;
	u8 bss_idx = entry->bss_idx;
	u8 bss_idx_tx = entry->bss_idx_tx;
	struct bmgr_entry *tx_entry = NULL, *mbss_entry = NULL;
	int i, j;
	u8 *f_buf_bcn = NULL, *pos_bcn = NULL;
	u16 ies_len_bcn = 0;
	u8 *f_buf_probe = NULL, *pos_probe = NULL;
	u16 ies_len_probe = 0;
	u8 *f_buf_probe_cmm = NULL, *pos_probe_cmm = NULL;
	u16 ies_len_probe_cmm = 0;
	u8 *tim_ie_ptr;
	u8 *mlt_ie_ptr;
	u8 *cap_info_ptr;
	u8 *at2lm_ie_ptr[BSS_MNGR_MAX_AT2LM_SET_NUM];
	u8 mbssid_idx = 0;
	u8 probe_mbssie_cnt = 0;
	u8 probe_cmm_mbssie_cnt = 0;
	struct mbssie_info *probe_mbssie_info;
	struct mbssie_info *probe_cmm_mbssie_info;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
		"[%d]'s tx-bss is [%d]\n", bss_idx, bss_idx_tx);

	if (IS_DEV_TYPE_11V(dev_type)) {
		if (BMGR_VALID_BSS_IDX(bss_idx_tx))
			tx_entry = GET_BSS_ENTRY_BY_IDX(bss_idx_tx);
		else {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"\t[%d] TX-BSS undefined\n", bss_idx);
			return NDIS_STATUS_FAILURE;
		}
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"\t[%d] no MBSS_IE required\n", bss_idx);
		return NDIS_STATUS_SUCCESS;
	}

	f_buf_bcn = pos_bcn = tx_entry->mbss.tx_bcn.buf;
	tx_entry->mbss.tx_bcn.len = 0;
	f_buf_probe = pos_probe = tx_entry->mbss.tx_probe.buf;
	tx_entry->mbss.tx_probe.len = 0;
	f_buf_probe_cmm = pos_probe_cmm = tx_entry->mbss.tx_probe_cmm.buf;
	tx_entry->mbss.tx_probe_cmm.len = 0;

	/*store per entry mbss ie info*/
	probe_mbssie_info = &tx_entry->mbss.tx_probe_mbssie;
	probe_cmm_mbssie_info = &tx_entry->mbss.tx_probe_cmm_mbssie;

	tim_ie_ptr = f_buf_bcn;
	mlt_ie_ptr = f_buf_bcn;
	cap_info_ptr = f_buf_bcn;
	for (i = 0; i < BSS_MNGR_MAX_AT2LM_SET_NUM; i++) {
		at2lm_ie_ptr[i] = f_buf_bcn;
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_T2LM, DBG_LVL_DEBUG,
			"\tT: wdev(%s), org at2lm_ie_ptr[%d]=%p\n",
			tx_entry->pNetDev->name, i, at2lm_ie_ptr[i]);
	}
	/* mbssid ie */
	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		mbss_entry = GET_BSS_ENTRY_BY_IDX(i);
		if (BMGR_VALID_BSS_ENTRY(mbss_entry)) {
			if (IS_DEV_TYPE_11V_NT(mbss_entry->entry_info.dev_type) && (mbss_entry->bss_idx_tx == bss_idx_tx)) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"\tbuild ie for ntx-bss[%d]\n", i);

				/* build beacon ie(s) for non-tx bss */
				mbssid_idx = mbss_entry->entry_info.dot11v_mbssid_idx;

				/* build ie(s) for beacon */
				/* mbss ie w/ ml ie */
				pos_bcn = build_multi_bssid_ie(mbss_entry, f_buf_bcn, FALSE, TRUE, &tim_ie_ptr, &mlt_ie_ptr, &cap_info_ptr, at2lm_ie_ptr);

				ies_len_bcn = pos_bcn - f_buf_bcn;
				tx_entry->mbss.tx_bcn.len += ies_len_bcn;
				f_buf_bcn = pos_bcn;

				/* beacon tim ie offset */
				tx_entry->mbss.bcn_tim_offset[mbssid_idx] =
					(u16)(tim_ie_ptr - tx_entry->mbss.tx_bcn.buf);
				/* beacon cap info offset */
				tx_entry->mbss.bcn_cap_info_offset[mbssid_idx] =
					(u16)(cap_info_ptr - tx_entry->mbss.tx_bcn.buf);

				/* beacon multi link traffic ie offset */
				tx_entry->mbss.bcn_mlt_offset[mbssid_idx] = entry->mlo_en ?
					(u16)(mlt_ie_ptr - tx_entry->mbss.tx_bcn.buf) : 0;

				/* beacon at2lm ie ie offset */
				for (j = 0; j < BSS_MNGR_MAX_AT2LM_SET_NUM; j++) {
					tx_entry->mbss.bcn_at2lm_offset[mbssid_idx][j] =
						(u16)(at2lm_ie_ptr[j] - tx_entry->mbss.tx_bcn.buf);
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_T2LM, DBG_LVL_DEBUG,
						"\tNT: wdev(%s), mbssid_idx=%d, at2lm offset[%d]=%d, new at2lm_ie_ptr[%d]=%p, tx_entry_bcn_buf=%p\n",
						mbss_entry->pNetDev->name, mbssid_idx,
						j, tx_entry->mbss.bcn_at2lm_offset[mbssid_idx][j],
						j, at2lm_ie_ptr[j],
						tx_entry->mbss.tx_bcn.buf);
				}

				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"\ttim offset(%d), mlt offset(%d), cap info offset(%d)\n",
						tx_entry->mbss.bcn_tim_offset[mbssid_idx],
						tx_entry->mbss.bcn_mlt_offset[mbssid_idx],
						tx_entry->mbss.bcn_cap_info_offset[mbssid_idx]);

				/* build ie(s) for probe.rsp, w/o ml ie */
				pos_probe = build_multi_bssid_ie(mbss_entry, f_buf_probe, TRUE, FALSE, NULL, NULL, NULL, NULL);
				ies_len_probe = pos_probe - f_buf_probe;

				/*store per entry mbss ie info*/
				probe_mbssie_info->mbssid_idx[probe_mbssie_cnt] = mbssid_idx;
				probe_mbssie_info->mbssie_offset[probe_mbssie_cnt]
					= f_buf_probe - tx_entry->mbss.tx_probe.buf;
				probe_mbssie_info->mbssie_len[probe_mbssie_cnt] = ies_len_probe;
				probe_mbssie_info->mbssie_num = (++probe_mbssie_cnt);
				tx_entry->mbss.tx_probe.len += ies_len_probe;
				f_buf_probe = pos_probe;

				/* build ie(s) for probe.rsp, w/ ml ie cmm part */
				pos_probe_cmm = build_multi_bssid_ie(mbss_entry, f_buf_probe_cmm, TRUE, TRUE, NULL, NULL, NULL, NULL);
				ies_len_probe_cmm = pos_probe_cmm - f_buf_probe_cmm;
				/*store per entry mbss ie info*/
				probe_cmm_mbssie_info->mbssid_idx[probe_cmm_mbssie_cnt] = mbssid_idx;
				probe_cmm_mbssie_info->mbssie_offset[probe_cmm_mbssie_cnt]
					= f_buf_probe_cmm - tx_entry->mbss.tx_probe_cmm.buf;
				probe_cmm_mbssie_info->mbssie_len[probe_cmm_mbssie_cnt] = ies_len_probe_cmm;
				probe_cmm_mbssie_info->mbssie_num = (++probe_cmm_mbssie_cnt);
				tx_entry->mbss.tx_probe_cmm.len += ies_len_probe_cmm;
				f_buf_probe_cmm = pos_probe_cmm;

				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"\tEND: add NT[%d] to T[%d], Len(IE/Total)=B(%d/%d) P(%d/%d) P-C(%d/%d)\n",
						i, bss_idx_tx,
						ies_len_bcn, tx_entry->mbss.tx_bcn.len,
						ies_len_probe, tx_entry->mbss.tx_probe.len,
						ies_len_probe_cmm, tx_entry->mbss.tx_probe_cmm.len);
			}
		}
	}

	return NDIS_STATUS_SUCCESS;
}
#endif

static bool is_6g_rnr_required(
	struct bmgr_entry *repting_entry, struct bmgr_entry *repted_entry)
{
	if (!BMGR_VALID_BSS_ENTRY(repting_entry) || !BMGR_VALID_BSS_ENTRY(repted_entry))
		return FALSE;

	if (!IS_DEV_TYPE_W_BCN(repting_entry->entry_info.dev_type)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"[repting:%d, repted:%d] FALSE, repting do not tx bcn\n",
			repting_entry->bss_idx, repted_entry->bss_idx);
		return FALSE;
	}

	/* RNR IE appeared after WiFi 6E */
	if (!WMODE_CAP_AX(repting_entry->entry_info.phy_mode)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"[repting:%d, repted:%d] FALSE, repting is before 6E\n",
			repting_entry->bss_idx, repted_entry->bss_idx);
		return FALSE;
	}

#ifdef CONFIG_6G_SUPPORT
	if (repting_entry->entry_info.disc_param.rnr_6g_rule == RNR_REPORTING_NONE) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"[repting:%d, repted:%d] FALSE, config RNR NONE\n",
			repting_entry->bss_idx, repted_entry->bss_idx);
		return FALSE;
	}
#endif

	/* restricted to only 6G RNR appearing (in 2G/5G) */
	/* reporting AP shall be 2G/5G, reported AP shall be 6G */
	if (WMODE_CAP_6G(repting_entry->entry_info.phy_mode) ||
		!WMODE_CAP_6G(repted_entry->entry_info.phy_mode)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"[repting:%d, repted:%d] FALSE, only 6G RNR in 2G/5G possible [6G(%d,%d)]\n",
			repting_entry->bss_idx, repted_entry->bss_idx,
			WMODE_CAP_6G(repting_entry->entry_info.phy_mode),
			WMODE_CAP_6G(repted_entry->entry_info.phy_mode));
		return FALSE;
	}

#ifdef DOT11_EHT_BE
	if (repting_entry->mlo_en && repted_entry->mlo_en) {
		u8 mld_bss_idx;
		struct bmgr_mlo_dev *mld = NULL;
		struct bmgr_entry *mld_entry = NULL;

		/* same MLD */
		if (repting_entry->entry_info.mld_grp == repted_entry->entry_info.mld_grp) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"[repting:%d, repted:%d] FALSE, the same MLD group: (%d, %d)\n",
				repting_entry->bss_idx, repted_entry->bss_idx,
				repting_entry->entry_info.mld_grp,
				repted_entry->entry_info.mld_grp);
			return FALSE;
		}

		mld = repted_entry->mld_ptr;
		if (!BMGR_VALID_MLO_DEV(mld)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"mld is null or not valid\n");
			return FALSE;
		}

		mld_bss_idx = mld->bss_idx_mld[repting_entry->link_id];
		mld_entry = BMGR_VALID_BSS_IDX(mld_bss_idx) ? GET_BSS_ENTRY_BY_IDX(mld_bss_idx) : NULL;
		/* same 11v BSSID set */
		if (BMGR_VALID_MLO_BSS_ENTRY(mld_entry) &&
			mld_entry->bss_idx_tx == repting_entry->bss_idx_tx) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"[repting:%d, repted:%d] FALSE, the same 11v MBSSID set: (%d, %d)\n",
				repting_entry->bss_idx, repted_entry->bss_idx,
				repting_entry->bss_idx_tx,
				mld_entry->bss_idx_tx);
			return FALSE;
		}

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"[repting:%d, repted:%d] TRUE, not the same MLD and 11v_tx (%d,%d) (%d,%d)\n",
			repting_entry->bss_idx, repted_entry->bss_idx,
			repting_entry->entry_info.mld_grp,
			repted_entry->entry_info.mld_grp,
			repting_entry->bss_idx_tx,
			BMGR_VALID_BSS_ENTRY(mld_entry) ? mld_entry->bss_idx_tx : BMGR_INVALID_BSS_IDX);
		return TRUE;
	}
#endif
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
		"[repting:%d, repted:%d] TRUE, valid pair, [MLO(%d,%d)]\n",
		repting_entry->bss_idx, repted_entry->bss_idx,
		repting_entry->mlo_en, repted_entry->mlo_en);
	return TRUE;

}

static NDIS_STATUS bss_mngr_con_build_rnr_for_6g(struct bmgr_entry *repting_entry)
{
	u8 i;
	u8 *f_buf = NULL, *pos = NULL;
	u16 ie_len = 0;
	u8 mld_id = 0xff; /* no info now */
	struct repting_rnr_info *rept = &repting_entry->rnr_info;

	u8 repted_bss_idx;
	struct bmgr_entry *repted_entry = NULL;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
		"===> [bss_idx %d] w/ bcn: %d\n",
		repting_entry->bss_idx,
		IS_DEV_TYPE_W_BCN(repting_entry->entry_info.dev_type));
	hex_dump_with_cat_and_lvl("repting_bitmap", (u8 *)rept->bss_idx_bitmap,
		BMGR_U32_BSS_BITMAP_NUM * (sizeof(rept->bss_idx_bitmap[0]) / sizeof(u8)),
		DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO);

	rept->repting_cnt = 0;
	if (IS_DEV_TYPE_W_BCN(repting_entry->entry_info.dev_type)) {
		/* build repting_list */
		for (i = 0; i < BMGR_MAX_BSS_CNT; i++) {
			if (BMGR_U32_BITMAP_IS_ASSIGNED(rept->bss_idx_bitmap, i)) {
				rept->repting_bss_idx[rept->repting_cnt] = i;
				rept->repting_cnt++;
			}
		}

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"\trepting_cnt: %d ", rept->repting_cnt);
		hex_dump_with_cat_and_lvl("repting_bss_idx", rept->repting_bss_idx, rept->repting_cnt,
			DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO);

		/* build repting_rnr */
		rept->repting_rnr.len = 0;
		f_buf = pos = rept->repting_rnr.buf;

		if (rept->repting_cnt) {
			for (i = 0; i < rept->repting_cnt; i++) {
				repted_bss_idx = rept->repting_bss_idx[i];
				repted_entry = GET_BSS_ENTRY_BY_IDX(repted_bss_idx);

				if (BMGR_VALID_BSS_ENTRY(repted_entry)) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"\ttx bss[%d] add rnr[%d] mld_id(%d), f_buf = %p\n",
						repting_entry->bss_idx, repted_bss_idx, mld_id, f_buf);

					pos = build_rnr_ie(repting_entry, repted_entry, f_buf, mld_id);
					ie_len = pos - f_buf;
					rept->repting_rnr.len += ie_len;
					f_buf = pos;
				} else {
					if (repted_entry && repting_entry->entry_info.single_rnr) {
						TBTT_BITMAP_CLEAR(repting_entry->rnr_nap->tbtt_bitmap, repted_entry->pwdev->func_idx);
						repting_entry->rnr_nap->tbtt_cnt--;
					}
				}
			}
		}
	}

	return NDIS_STATUS_SUCCESS;
}

NDIS_STATUS bss_mngr_con_ie_update_rnr_for_6g(struct bmgr_entry *entry)
{
	struct bmgr_entry *other_entry = NULL;
	struct repting_rnr_info *rept = &entry->rnr_info;
	struct repting_rnr_info *other_rept = NULL;
	u8 i;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
		"===> [bss_idx %d]\n", entry->bss_idx);

	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		other_entry = GET_BSS_ENTRY_BY_IDX(i);
		/* skip invalid entry and self */
		if (!BMGR_VALID_BSS_ENTRY(other_entry) || (other_entry->bss_idx == entry->bss_idx))
			continue;

		/* self RNR reported by other */
		other_rept = &other_entry->rnr_info;
		if (is_6g_rnr_required(other_entry, entry))
			BMGR_U32_BITMAP_SET(other_rept->bss_idx_bitmap, entry->bss_idx);
		else
			BMGR_U32_BITMAP_CLEAR(other_rept->bss_idx_bitmap, entry->bss_idx);

		bss_mngr_con_build_rnr_for_6g(other_entry);

		/* other RNR reported by self */
		if (is_6g_rnr_required(entry, other_entry))
			BMGR_U32_BITMAP_SET(rept->bss_idx_bitmap, other_entry->bss_idx);
		else
			BMGR_U32_BITMAP_CLEAR(rept->bss_idx_bitmap, other_entry->bss_idx);
	}

	bss_mngr_con_build_rnr_for_6g(entry);

	return NDIS_STATUS_SUCCESS;
}

#ifdef DOT11_EHT_BE
/*
 * build rnr of bss within the same mld w/o self
 */
int bss_mngr_con_build_rnr_for_mld(struct bmgr_entry *entry)
{
	bool mld_en = false;
	u8 bss_idx = entry->bss_idx;
	u8 bss_idx_tx = entry->bss_idx_tx;
	u8 *f_buf = NULL, *pos = NULL;
	u16 ie_len = 0;
	u8 link;
	u8 dot11be_mld_id = 0;
	struct bmgr_mlo_dev *mld = NULL;

	mld = entry->mld_ptr;
	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"bss_idx (%d) is not in mld (%d)\n",
			entry->bss_idx, entry->entry_info.mld_grp);
		return NDIS_STATUS_FAILURE;
	}

	if (entry->mlo_en)
		mld_en = true;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"[%d], mld_en = %d\n", bss_idx, mld_en);

	if (mld_en) {
		struct bmgr_entry *tx_entry = NULL;

		/* get tx bss */
		if (BMGR_VALID_BSS_IDX(bss_idx_tx)) {
			tx_entry = GET_BSS_ENTRY_BY_IDX(bss_idx_tx);

			/*
			 * If the reported AP is affiliated to the same MLD as a nontransmitted
			 * BSSID that is in the same multiple BSSID set as the reporting AP, the
			 * MLD ID subfield is set to the same value as in the BSSID Index field
			 * in the Multiple BSSID-Index element in the nontransmitted BSSID profile
			 * corresponding to the nontransmitted BSSID.
			 */
			if (IS_DEV_TYPE_11V_NT(entry->entry_info.dev_type))
				dot11be_mld_id = entry->dot11be_mld_id;

		} else {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				": [%d] tx bss (%d) undefined\n",
				bss_idx, bss_idx_tx);
			return NDIS_STATUS_FAILURE;
		}

		/* ie buf under tx bss */
		f_buf = pos = tx_entry->rnr.buf + tx_entry->rnr.len;

		/* mld group member, exclude self */
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			u8 bss_idx_mld = mld->bss_idx_mld[link];
			struct bmgr_entry *mld_entry = NULL;

			if (BMGR_VALID_BSS_IDX(bss_idx_mld) && (bss_idx_mld != bss_idx)) {
				mld_entry = GET_BSS_ENTRY_BY_IDX(bss_idx_mld);
				if (BMGR_VALID_MLO_BSS_ENTRY(mld_entry)) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
							"\ttx bss[%d] add rnr[%d] 11be_mld_id(%d), f_buf = %p\n",
							bss_idx_tx, bss_idx_mld, dot11be_mld_id, f_buf);

					pos = build_rnr_ie(tx_entry, mld_entry, f_buf, dot11be_mld_id);
					ie_len = pos - f_buf;
					tx_entry->rnr.len += ie_len;
					f_buf = pos;
				} else {
					if (mld_entry && tx_entry->entry_info.single_rnr) {
						TBTT_BITMAP_CLEAR(tx_entry->rnr_nap->tbtt_bitmap, mld_entry->pwdev->func_idx);
						tx_entry->rnr_nap->tbtt_cnt--;
					}
				}
			}
		}
	}

	return NDIS_STATUS_SUCCESS;
}

int bss_mngr_con_ie_update_rnr_for_mld(struct bmgr_entry *entry)
{
	u8 dev_type = entry->entry_info.dev_type;
	u8 bss_idx = entry->bss_idx;
	u8 bss_idx_tx = entry->bss_idx_tx;
	struct bmgr_entry *tx_entry = NULL;
	int i;
	u8 *f_buf = NULL, *pos = NULL;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			": [%d], dev_type(%s)\n",
			bss_idx, dev_type_str[dev_type]);

	if (BMGR_VALID_BSS_IDX(bss_idx_tx))
		tx_entry = GET_BSS_ENTRY_BY_IDX(bss_idx_tx);
	else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"[%d] TX-BSS undefined\n", bss_idx);
		return NDIS_STATUS_FAILURE;
	}

	f_buf = pos = tx_entry->rnr.buf;
	tx_entry->rnr.len = 0;

	switch (dev_type) {
	case DEV_TYPE_AP_LEGACY:
	case DEV_TYPE_AP_COH:
		/* rnr of self mld */
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"\tupdate rnr of self mld\n");

		bss_mngr_con_build_rnr_for_mld(entry);
		break;
	case DEV_TYPE_AP_11VT:
	case DEV_TYPE_AP_11VNT:
		/* traverse all mbss members and add members' mlo oob bss */
		for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
			struct bmgr_entry *mbss_entry = GET_BSS_ENTRY_BY_IDX(i);

			if (BMGR_VALID_BSS_ENTRY(mbss_entry)) {
				u8 entry_dev_type = mbss_entry->entry_info.dev_type;

				/* tx/ntx bss */
				if (IS_DEV_TYPE_11V(entry_dev_type) &&
					(mbss_entry->bss_idx_tx == bss_idx_tx)) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
							"\t[%d] update to mbss [%d](%s)\n",
							bss_idx, i, dev_type_str[entry_dev_type]);

					bss_mngr_con_build_rnr_for_mld(mbss_entry);
				}
			}
		}
		break;
	default:
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"[%d] unknown dev_type(%d)\n", bss_idx, dev_type);
		break;
	}

	return NDIS_STATUS_SUCCESS;
}

/*
 * update self mld ie
 */
int bss_mngr_con_ie_update_mld(struct bmgr_entry *entry)
{
	bool mld_en = false;
	u8 *f_buf = NULL, *pos = NULL;
	u16 ie_len = 0;

	if (!entry)
		return NDIS_STATUS_FAILURE;

	if (entry->mlo_en && BMGR_VALID_MLO_DEV(entry->mld_ptr))
		mld_en = true;

	entry->mld_cmm.len = 0;
	if (mld_en) {
		/* build mld ie */
		/* w/o link info, common info only */
		f_buf = pos = entry->mld_cmm.buf;
		pos = build_multi_link_ie(
				entry, f_buf, BMGR_MLD_BCN_COMMON, BMGR_MAX_MLD_STA_CNT);
		ie_len = pos - f_buf;
		entry->mld_cmm.len += ie_len;
		f_buf = pos;

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"\tMLIE-C: Len = %d, Total = %d\n", ie_len, entry->mld_cmm.len);
	}

	return NDIS_STATUS_SUCCESS;
}

/*
 * update tid-to-link mapping for group members
 */
int bss_mngr_con_ie_update_tid_to_link_map(struct bmgr_entry *entry)
{
	bool mld_en = false;
	struct bmgr_entry *mld_entry = NULL;
	u8 *f_buf = NULL, *pos = NULL;
	u16 ie_len = 0;

	if (entry->mlo_en && BMGR_VALID_MLO_DEV(entry->mld_ptr))
		mld_en = true;

	entry->tid2lnk.len = 0;
	if (mld_en) {
		f_buf = pos = entry->tid2lnk.buf;

		/* tid-to-link mapping ie */
		mld_entry = entry;
		if (mld_entry) {
			pos = build_tid_to_link_map_ie(mld_entry, f_buf);
			ie_len = pos - f_buf;
			mld_entry->tid2lnk.len += ie_len;
			f_buf = pos;

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"\tLen = %d, Total = %d\n", ie_len, mld_entry->tid2lnk.len);
		}
	}

	return NDIS_STATUS_SUCCESS;
}
#endif

static int bss_mngr_con_sync_ie(struct bmgr_entry *entry)
{
	u8 link = 0;
	struct bmgr_entry *mld_entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;
	u8 bss_idx = entry->bss_idx;
	u8 mld_grp = entry->entry_info.mld_grp;
	u8 str[4] = {0};

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			": [%d]\n", bss_idx);

	/* re-build ie for mlo group (always do update for parameter 'entry') */

	/* When interface down, entry has left MLD. Shall use mld_grp to access MLD */
#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(mld_grp);
#else
	mld = BMGR_VALID_MLD_GRP_IDX(mld_grp) ? GET_MLD_BY_GRP_IDX(mld_grp) : NULL;
#endif
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		u8 bss_idx_mld = BMGR_VALID_MLO_DEV(mld) ? mld->bss_idx_mld[link] : BMGR_INVALID_BSS_IDX;

		/* always do iob update */
		if (link == entry->link_id)
			bss_idx_mld = entry->bss_idx;

		if (BMGR_VALID_BSS_IDX(bss_idx_mld)) {
			mld_entry = GET_BSS_ENTRY_BY_IDX(bss_idx_mld);
			if (mld_entry) {
				strlcpy(str, (bss_idx_mld == bss_idx) ? "iob" : "oob", sizeof(str));
				str[sizeof(str) - 1] = '\0';
#ifdef DOT11V_MBSSID_SUPPORT
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"\t1. L%d[%d] sync %s mbss ie\n", link, bss_idx_mld, str);
				bss_mngr_con_ie_update_mbss(mld_entry);
#endif
#ifdef DOT11_EHT_BE
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"\t2. L%d[%d] sync %s rnr ie\n", link, bss_idx_mld, str);
				bss_mngr_con_ie_update_rnr_for_mld(mld_entry);
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"\t3. L%d[%d] sync %s ml ie\n", link, bss_idx_mld, str);
				bss_mngr_con_ie_update_mld(mld_entry);

				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"\t4. L%d[%d] sync %s t2l ie\n", link, bss_idx_mld, str);
				bss_mngr_con_ie_update_tid_to_link_map(mld_entry);
#endif
			}
		}
	}

	/* update out-of-band (or 6G) RNR */
	bss_mngr_con_ie_update_rnr_for_6g(entry);

	return NDIS_STATUS_SUCCESS;
}

static int bss_mngr_con_ie_update(
	struct wifi_dev *wdev)
{
	struct bmgr_entry *entry = NULL;

	if (wdev)
		entry = get_bss_entry_by_wdev(wdev);
	if (entry) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"if=%s, link_id=%d\n", RtmpOsGetNetDevName(wdev->if_dev), entry->link_id);
		return bss_mngr_con_sync_ie(entry);
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
		"Error: entry not found\n");
	return NDIS_STATUS_FAILURE;
}

int bss_mngr_con_ie_buf_alloc(struct bmgr_entry *entry)
{
	u8 dev_type = entry->entry_info.dev_type;
	u8 *mbss_bcn = NULL;
	u8 *mbss_probe = NULL;
	u8 *mbss_probe_cmm = NULL;
	u8 *rnr = NULL;
	u8 *oob_rnr = NULL;
	u8 *mld_cmm = NULL;
	u8 *tid2lnk = NULL;
	u8 *tbtt = NULL;
	u8 tbtt_idx, link_id;

	if (IS_DEV_TYPE_W_BCN(dev_type)) {
		/* rnr ie: legacy/11vT/11vCoH */
		if (!entry->rnr.buf) {
			os_alloc_mem(NULL, (u8 **)&rnr, BSS_MNGR_MAX_INFO_LEN);
			if (rnr) {
				NdisZeroMemory(rnr, BSS_MNGR_MAX_INFO_LEN);
				entry->rnr.buf = rnr;
			} else {
				goto err;
			}
		} else {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
					"allocated (RNR-M:%p)\n", entry->rnr.buf);
		}

		/* rnr ie: for WiFi6 out-of-band reporting */
		if (!entry->rnr_info.repting_rnr.buf) {
			os_alloc_mem(NULL, (u8 **)&oob_rnr, BSS_MNGR_MAX_INFO_LEN);
			if (oob_rnr) {
				NdisZeroMemory(oob_rnr, BSS_MNGR_MAX_INFO_LEN);
				entry->rnr_info.repting_rnr.buf = oob_rnr;
			} else {
				goto err;
			}
		} else {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
				"allocated (RNR-O:%p)\n", entry->rnr_info.repting_rnr.buf);
		}

		if (entry->entry_info.single_rnr) {
			for (link_id = 0; link_id < BSS_MNGR_MAX_BAND_NUM; link_id++) {
				for (tbtt_idx = 0; tbtt_idx < 16; tbtt_idx++) {
					tbtt = entry->rnr_nap[link_id].tbtt[tbtt_idx].buf;
					if (!tbtt) {
						os_alloc_mem(NULL, (u8 **)&tbtt, 32);
						if (tbtt) {
							NdisZeroMemory(tbtt, 32);
							entry->rnr_nap[link_id].tbtt[tbtt_idx].buf = tbtt;
						} else {
							goto err;
						}
					}
				}
			}
		}

		/* mbssid ie: 11vT */
		if (IS_DEV_TYPE_11V_T(dev_type)) {
			if (!entry->mbss.tx_bcn.buf) {
				os_alloc_mem(NULL, (u8 **)&mbss_bcn, BSS_MNGR_MAX_MBSSID_IE_LEN);
				if (mbss_bcn) {
					NdisZeroMemory(mbss_bcn, BSS_MNGR_MAX_MBSSID_IE_LEN);
					entry->mbss.tx_bcn.buf = mbss_bcn;
				} else {
					goto err;
				}
			} else {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
						"allocated (MBSS-B:%p)\n", entry->mbss.tx_bcn.buf);
			}

			if (!entry->mbss.tx_probe.buf) {
				os_alloc_mem(NULL, (u8 **)&mbss_probe, BSS_MNGR_MAX_MBSSID_IE_LEN);
				if (mbss_probe) {
					NdisZeroMemory(mbss_probe, BSS_MNGR_MAX_MBSSID_IE_LEN);
					entry->mbss.tx_probe.buf = mbss_probe;
				} else {
					goto err;
				}
			} else {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
						"allocated (MBSS-P:%p)\n", entry->mbss.tx_probe.buf);
			}

			if (!entry->mbss.tx_probe_cmm.buf) {
				os_alloc_mem(NULL, (u8 **)&mbss_probe_cmm, BSS_MNGR_MAX_MBSSID_IE_LEN);
				if (mbss_probe_cmm) {
					NdisZeroMemory(mbss_probe_cmm, BSS_MNGR_MAX_MBSSID_IE_LEN);
					entry->mbss.tx_probe_cmm.buf = mbss_probe_cmm;
				} else {
					goto err;
				}
			} else {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
						"allocated (MBSS-P-C:%p)\n", entry->mbss.tx_probe_cmm.buf);
			}
		}

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
				"allocated (MBSS-B:%p, MBSS-P: %p, MBSS-P-C: %p)\n",
				entry->mbss.tx_bcn.buf,
				entry->mbss.tx_probe.buf,
				entry->mbss.tx_probe_cmm.buf);
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
				"allocated (RNR-M:%p, RNR-O:%p)\n",
				entry->rnr.buf,
				entry->rnr_info.repting_rnr.buf);
	}

	if (WMODE_CAP_BE(entry->entry_info.phy_mode)) {
		u8 link;
		struct ie *per_sta_pf;

		/* mld ie: common info field only */
		if (!entry->mld_cmm.buf) {
			os_alloc_mem(NULL, (u8 **)&mld_cmm, BSS_MNGR_MAX_INFO_LEN);
			if (mld_cmm) {
				NdisZeroMemory(mld_cmm, BSS_MNGR_MAX_INFO_LEN);
				entry->mld_cmm.buf = mld_cmm;
			} else {
				goto err;
			}
		} else {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
					"allocated (MLD-C:%p)\n", entry->mld_cmm.buf);
		}

		/* tid-to-link ie: legacy/11vT/11vCoH */
		if (!entry->tid2lnk.buf) {
			os_alloc_mem(NULL, (u8 **)&tid2lnk, BSS_MNGR_MAX_INFO_LEN);
			if (tid2lnk) {
				NdisZeroMemory(tid2lnk, BSS_MNGR_MAX_INFO_LEN);
				entry->tid2lnk.buf = tid2lnk;
			} else {
				goto err;
			}
		} else {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
					"allocated (T2L:%p)\n", entry->tid2lnk.buf);
		}
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
				"allocated (MLD-C:%p, T2L:%p)\n",
				entry->mld_cmm.buf,
				entry->tid2lnk.buf);

		if (at2lm_ie_buf_alloc(entry))
			goto err;

		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			per_sta_pf = &entry->ml_probe_rsp_per_sta_pf[link];
			if (!per_sta_pf->buf) {
				os_alloc_mem(NULL, (UCHAR **)&per_sta_pf->buf, BSS_MNGR_MAX_PER_STA_PROFILE_LEN);
				if (per_sta_pf->buf)
					NdisZeroMemory(per_sta_pf->buf, BSS_MNGR_MAX_PER_STA_PROFILE_LEN);
				else
					goto err;
			}
		}
	}

	return NDIS_STATUS_SUCCESS;
err:
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"alloc failed (MBSS-B:%p, MBSS-P: %p, MBSS-P-C: %p)\n",
			entry->mbss.tx_bcn.buf,
			entry->mbss.tx_probe.buf,
			entry->mbss.tx_probe_cmm.buf);
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"alloc failed (RNR:%p, MLD-C:%p, T2L:%p)\n",
			entry->rnr.buf,
			entry->mld_cmm.buf,
			entry->tid2lnk.buf);

	bss_mngr_con_ie_buf_free(entry);

	return NDIS_STATUS_RESOURCES;
}

int bss_mngr_con_ie_buf_free(struct bmgr_entry *entry)
{
	u8 link, tbtt_idx;
	u8 *mbss_bcn = entry->mbss.tx_bcn.buf;
	u8 *mbss_probe = entry->mbss.tx_probe.buf;
	u8 *mbss_probe_cmm = entry->mbss.tx_probe_cmm.buf;
	u8 *rnr = entry->rnr.buf;
	u8 *oob_rnr = entry->rnr_info.repting_rnr.buf;
	u8 *mld_cmm = entry->mld_cmm.buf;
	u8 *tid2lnk = entry->tid2lnk.buf;
	u8 *probe_rsp_sta_pf;
	u8 *probe_rsp_per_sta_pf;
	u8 *tbtt;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"freed (RNR:%p, MBSS-B:%p, MBSS-P: %p, MBSS-P-C: %p, MLD-C:%p, T2L:%p)\n",
			rnr, mbss_bcn, mbss_probe, mbss_probe_cmm, mld_cmm, tid2lnk);

	if (mbss_bcn)
		os_free_mem(mbss_bcn);

	if (mbss_probe)
		os_free_mem(mbss_probe);

	if (mbss_probe_cmm)
		os_free_mem(mbss_probe_cmm);

	if (rnr)
		os_free_mem(rnr);

	if (oob_rnr)
		os_free_mem(oob_rnr);

	if (mld_cmm)
		os_free_mem(mld_cmm);

	if (tid2lnk)
		os_free_mem(tid2lnk);

	at2lm_ie_buf_free(entry);

	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		entry->ml_probe_rsp_per_sta_pf[link].len = 0;
		probe_rsp_per_sta_pf = entry->ml_probe_rsp_per_sta_pf[link].buf;
		if (probe_rsp_per_sta_pf) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"free (ProbePerStaPf[%d]:%p)\n",
				link, probe_rsp_per_sta_pf);
			os_free_mem(probe_rsp_per_sta_pf);
		}
		entry->ml_probe_rsp_sta_pf[link].len = 0;
		probe_rsp_sta_pf = entry->ml_probe_rsp_sta_pf[link].buf;
		if (probe_rsp_sta_pf) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"free (ProbeStaPf[%d]:%p)\n",
				link, probe_rsp_sta_pf);
			os_free_mem(probe_rsp_sta_pf);
		}
	}

	if (entry->entry_info.single_rnr) {
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			for (tbtt_idx = 0; tbtt_idx < 16; tbtt_idx++) {
				tbtt = entry->rnr_nap[link].tbtt[tbtt_idx].buf;
				if (tbtt)
					os_free_mem(tbtt);
			}
		}
	}

#ifdef DOT11_EHT_BE
	free_bcn_appl_elem_per_sta_pf(entry);
#endif

	return NDIS_STATUS_SUCCESS;
}

int bss_mngr_con_ie_buf_clean(struct bmgr_entry *entry)
{
	u8 *mbss_bcn = entry->mbss.tx_bcn.buf;
	u8 *mbss_probe = entry->mbss.tx_probe.buf;
	u8 *mbss_probe_cmm = entry->mbss.tx_probe_cmm.buf;
	u8 *rnr = entry->rnr.buf;
	u8 *oob_rnr = entry->rnr_info.repting_rnr.buf;
	u8 *mld_cmm = entry->mld_cmm.buf;
	u8 *tid2lnk = entry->tid2lnk.buf;
	u8 link, tbtt_idx;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"clear (RNR-O:%p, MBSS-B:%p, MBSS-P: %p, MBSS-P-C: %p)\n",
			oob_rnr, mbss_bcn, mbss_probe, mbss_probe_cmm);
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"clear (RNR-M:%p, MLD-C:%p, T2L:%p)\n",
			rnr, mld_cmm, tid2lnk);

	entry->mbss.tx_bcn.len = 0;
	if (mbss_bcn)
		NdisZeroMemory(mbss_bcn, BSS_MNGR_MAX_MBSSID_IE_LEN);

	entry->mbss.tx_probe.len = 0;
	if (mbss_probe)
		NdisZeroMemory(mbss_probe, BSS_MNGR_MAX_MBSSID_IE_LEN);

	entry->mbss.tx_probe_cmm.len = 0;
	if (mbss_probe_cmm)
		NdisZeroMemory(mbss_probe_cmm, BSS_MNGR_MAX_MBSSID_IE_LEN);

	entry->rnr.len = 0;
	if (rnr)
		NdisZeroMemory(rnr, BSS_MNGR_MAX_INFO_LEN);

	entry->rnr_info.repting_rnr.len = 0;
	if (oob_rnr)
		NdisZeroMemory(oob_rnr, BSS_MNGR_MAX_INFO_LEN);

	entry->mld_cmm.len = 0;
	if (mld_cmm)
		NdisZeroMemory(mld_cmm, BSS_MNGR_MAX_INFO_LEN);

	entry->tid2lnk.len = 0;
	if (tid2lnk)
		NdisZeroMemory(tid2lnk, BSS_MNGR_MAX_INFO_LEN);

	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		entry->ml_probe_rsp_per_sta_pf[link].len = 0;
		if (entry->ml_probe_rsp_per_sta_pf[link].buf)
			NdisZeroMemory(entry->ml_probe_rsp_per_sta_pf[link].buf,
				BSS_MNGR_MAX_PER_STA_PROFILE_LEN);

		entry->ml_probe_rsp_sta_pf[link].len = 0;
		if (entry->ml_probe_rsp_sta_pf[link].buf) {
			NdisZeroMemory(entry->ml_probe_rsp_sta_pf[link].buf,
				BSS_MNGR_MAX_STA_PROFILE_LEN);
		}
	}

	if (entry->entry_info.single_rnr) {
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			for (tbtt_idx = 0; tbtt_idx < 16; tbtt_idx++) {
				TBTT_BITMAP_CLEAR(entry->rnr_nap[link].tbtt_bitmap, tbtt_idx);
				entry->rnr_nap[link].tbtt[tbtt_idx].len = 0;

				if (entry->rnr_nap[link].tbtt[tbtt_idx].buf)
					NdisZeroMemory(entry->rnr_nap[link].tbtt[tbtt_idx].buf, 32);
			}
			entry->rnr_nap[link].tbtt_cnt = 0;
		}
	}

	return NDIS_STATUS_SUCCESS;
}

#ifdef DOT11_EHT_BE
/* tid shall always be mapped to at least one setup link */
static int tid_map_sanity(
	IN struct bmgr_entry *entry
)
{
	u8 i;
	struct bmgr_entry *mld_entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;
	u8 mld_grp = entry->entry_info.mld_grp;
	u8 mld_bss_idx;
	u8 mapped_tid = 0;
	u8 unmapped_tid = 0;

	/* When interface down, entry has left MLD. Shall use mld_grp to access MLD */
#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(mld_grp);
#else
	mld = BMGR_VALID_MLD_GRP_IDX(mld_grp) ? GET_MLD_BY_GRP_IDX(mld_grp) : NULL;
#endif

	/* mapped tid for mld group */
	for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++) {
		mld_bss_idx = BMGR_VALID_MLO_DEV(mld) ? mld->bss_idx_mld[i] : BMGR_INVALID_BSS_IDX;
		if (BMGR_VALID_BSS_IDX(mld_bss_idx)) {
			mld_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);
			if (BMGR_VALID_MLO_BSS_ENTRY(mld_entry))
				mapped_tid |= mld_entry->entry_info.tid_map;
		}
	}
	unmapped_tid = ~(mapped_tid);
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"[%d] unmapped_tid(0x%x)\n", entry->bss_idx, unmapped_tid);

	/* apply non-mapped TID to all links */
	for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++) {
		mld_bss_idx = BMGR_VALID_MLO_DEV(mld) ? mld->bss_idx_mld[i] : BMGR_INVALID_BSS_IDX;
		if (BMGR_VALID_BSS_IDX(mld_bss_idx)) {
			mld_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);
			if (BMGR_VALID_MLO_BSS_ENTRY(mld_entry)) {
				if (unmapped_tid) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
							"[%d] tid_remap (0x%x)->(0x%x)\n", mld_entry->bss_idx,
							mld_entry->entry_info.tid_map,
							(mld_entry->entry_info.tid_map | unmapped_tid));
				}
				mld_entry->tid_map = (mld_entry->entry_info.tid_map | unmapped_tid);
			}
		}
	}

	return 0;
}

/**
 * @brief Sanity the mld attribute
 *
 * This function do sanity to the MLD Attribute based on the definition
 * of 802.11 spec.
 *
 * @param mld_attr MLD Attributes to be did sanity.
 * @return Boolean: sanity success or failed.
 */
static bool mld_attr_sanity(
	IN struct bmgr_mld_attr *mld_attr
)
{
	if (!mld_attr) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"False: attr is null\n");
		return FALSE;
	}

	if (mld_attr->med_sync.ofdm_ed_thr > MLD_MAX_MSD_OFDM_ED_THR) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"False: msd OFDM ED Threshold > %d\n", MLD_MAX_MSD_OFDM_ED_THR);
		return FALSE;
	}

	if (mld_attr->eml_caps.emlsr_supp && mld_attr->eml_caps.emlmr_supp) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"False: shall only one of emlsr/emlmr enabled at a time\n");
		return FALSE;
	}

	if (mld_attr->eml_caps.trans_to > MLD_MAX_EML_TRANS_TO) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"False: eml transition timeout > %d\n", MLD_MAX_EML_TRANS_TO);
		return FALSE;
	}

	return TRUE;
}

static bool bss_mngr_is_mld_addr_used(
	IN u8 *addr
)
{
	u8 i;

	if (!addr) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: address is NULL\n");
		return TRUE;
	}

	for (i = 0; i < BMGR_MAX_MLD_GRP_CNT; i++) {
#ifdef MLD_GROUP_ID_REMAPPING_V1
		struct bmgr_mlo_dev *mld = mld_idx_mapping_v1_load(i);
#else
		struct bmgr_mlo_dev *mld = GET_MLD_BY_GRP_IDX(i);
#endif
		if (BMGR_VALID_MLO_DEV(mld) && MAC_ADDR_EQUAL(mld->mld_addr, addr)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"T: addr(%pM) is the same as mld %d\n",
				addr, i);
			return TRUE;
		}
	}

	return FALSE;
}

static bool bss_mngr_is_link_addr_used(
	IN u8 *addr
)
{
	u8 i;

	if (!addr) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: address is NULL\n");
		return TRUE;
	}

	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		struct bmgr_entry *entry = GET_BSS_ENTRY_BY_IDX(i);
		struct bmgr_reg_info *reg_info;

		if (BMGR_VALID_BSS_ENTRY(entry)) {
			reg_info = &entry->entry_info;
			if (MAC_ADDR_EQUAL(reg_info->bssid, addr)) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
					"T: addr(%pM) is the same as bss%d(%s) BSSID\n",
					addr, entry->bss_idx, RtmpOsGetNetDevName(entry->pNetDev));
				return TRUE;
			}
		}
	}

	return FALSE;
}

/**
 * @brief Fill MLD Attr. to an MLD
 *
 * This function fill the MLD attributes to an MLD.
 * It could be based on the memory move or direct assignment.
 *
 * @param mld MLD.
 * @param mld_attr MLD Attributes.
 */
static int bss_mngr_con_fill_attr_to_mld(
	IN struct bmgr_mlo_dev *mld,
	IN struct bmgr_mld_attr *mld_attr
)
{
	if (!mld || !mld_attr) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Invalid input mld(%p), mld_attr(%p)\n",
			mld, mld_attr);
		return NDIS_STATUS_INVALID_DATA;
	}

	NdisMoveMemory(&mld->attr, mld_attr, sizeof(struct bmgr_mld_attr));

	return NDIS_STATUS_SUCCESS;
}

/**
 * @brief Fill update info for a BSS
 *
 * This function fill the Update Info for a BSS.
 * The Update Info is used to deliver the BSS update information from an MLD
 * which BSS is affiliated with from BSS/MLD Manager to Logan.
 *
 * @param mld MLD, source of the update information.
 * @param bmgr_update_info struct that maintains the update information.
 */
static int bss_mngr_con_fill_update_info(
	IN struct bmgr_mlo_dev *mld,
	OUT struct bmgr_update_info *update_info
)
{
	if (!mld || !update_info) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Invalid input mld(%p), update_info(%p)\n",
			mld, update_info);
		return NDIS_STATUS_INVALID_DATA;
	}

	NdisMoveMemory(&update_info->mld_attr, &mld->attr, sizeof(struct bmgr_mld_attr));

	return NDIS_STATUS_SUCCESS;
}

/**
 * @brief Update IEs if any change of MLD
 *
 * This function update the IEs of all links affiliated with MLD.
 *
 * @param mld_grp MLD index
 */
static int bss_mngr_con_mld_sync_ie(u8 mld_grp)
{
	u8 link_id;
	struct bmgr_entry *entry;
	struct bmgr_mlo_dev *mld;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			": [%d]\n", mld_grp);

#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(mld_grp);
#else
	mld = BMGR_VALID_MLD_GRP_IDX(mld_grp) ? GET_MLD_BY_GRP_IDX(mld_grp) : NULL;
#endif
	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Fail: mld_grp %d invalid\n", mld_grp);
		return NDIS_STATUS_INVALID_DATA;
	}

	for (link_id = 0; link_id < BSS_MNGR_MAX_BAND_NUM; link_id++) {
		u8 bss_idx = mld->bss_idx_mld[link_id];

		if (!BMGR_VALID_BSS_IDX(bss_idx))
			continue;

		entry = GET_BSS_ENTRY_BY_IDX(bss_idx);
		if (!BMGR_VALID_MLO_BSS_ENTRY(entry))
			continue;

		/* pick a valid entry to do IE update */
		bss_mngr_con_sync_ie(entry);

		return NDIS_STATUS_SUCCESS;
	}

	return NDIS_STATUS_FAILURE;
}

static int bss_mngr_con_mld_group_create(
	IN struct wifi_dev *wdev,
	INOUT u8 *mld_grp,
	IN u8 *mld_addr,
	IN struct bmgr_mld_attr *mld_attr,
	IN u8 mld_type
)
{
	int ret = NDIS_STATUS_FAILURE;
	u8 new_grp, old_grp = *mld_grp;
	struct bmgr_mlo_dev *mld = NULL;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();

	if (!wdev)
		return NDIS_STATUS_FAILURE;
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"===> mld_grp(%d), mld_addr(%pM)\n", old_grp, mld_addr);

	if (!mld_addr) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"Error: MLD address is NULL\n");
		return NDIS_STATUS_FAILURE;
	}

	if (!mld_attr_sanity(mld_attr)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"Fail: MLD attr sanity fail\n");
		return NDIS_STATUS_INVALID_DATA;
	}

	mutex_lock(&bss_mngr.op_mutex);

#ifdef MLD_GROUP_ID_REMAPPING_V1
	if (old_grp != 0) {
		mld = mld_idx_mapping_v1_load(old_grp);
		if (BMGR_VALID_MLO_DEV(mld)) {
			switch (mld->mld_type) {
			case BMGR_MLD_TYPE_MULTI:
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"multi-link mld_grp(%d)(addr=%pM) already exists\n",
					old_grp, mld->mld_addr);
				/* set output mld_grp index */
				*mld_grp = old_grp;
				mutex_unlock(&bss_mngr.op_mutex);
				return NDIS_STATUS_SUCCESS;
			case BMGR_MLD_TYPE_SINGLE:
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
					"Error: single-link group %u existed\n",
					old_grp);
				ret = NDIS_STATUS_FAILURE;
				goto err_index;
			default:
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"unknown MLD type %d\n", mld->mld_type);
				ret = NDIS_STATUS_INVALID_DATA;
				goto err_index;
			}
		}
		new_grp = old_grp;
	} else {
		mld = NULL;
		for (new_grp = MAX_MLD_NUM + 1;
		     new_grp <= MAX_MLD_GRP_NUM;
		     new_grp++) {
			mld = mld_idx_mapping_v1_load(new_grp);
			if (!mld)
				break;
		}
		if (new_grp > MAX_MLD_GRP_NUM) {
			ret = NDIS_STATUS_FAILURE;
			goto err_index;
		}
	}
#else
	new_grp = mld_idx_mapping_acquire(old_grp);
	if (!BMGR_VALID_MLD_GRP_IDX(new_grp)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Fail: acquire index fail\n");
		ret = NDIS_STATUS_FAILURE;
		goto err_index;
	}

	/* MLD Group existed */
	mld = GET_MLD_BY_GRP_IDX(new_grp);
	if (BMGR_VALID_MLO_DEV(mld)) {
		switch (mld->mld_type) {
		case BMGR_MLD_TYPE_MULTI:
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"multi-link mld_grp(%d->%d)(addr=%pM) already exists\n",
				old_grp, new_grp, mld->mld_addr);
			/* set output mld_grp index */
			*mld_grp = new_grp;
			mutex_unlock(&bss_mngr.op_mutex);
			return NDIS_STATUS_SUCCESS;

		case BMGR_MLD_TYPE_SINGLE:
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: input(%d) an existed single-link group %d\n",
				old_grp, new_grp);
			ret = NDIS_STATUS_FAILURE;
			goto err_index;

		default:
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"unknown MLD type %d\n", mld->mld_type);
			ret = NDIS_STATUS_INVALID_DATA;
			goto err_index;
		}
	}
#endif /* MLD_GROUP_ID_REMAPPING_V1 */

	/* spec sanity: MLD MAC address shall be unique among MLDs */
	if (bss_mngr_is_mld_addr_used(mld_addr))
		goto err;

	/* design sanity: ML MLD MAC address is unique to any BSSIDs */
	if ((mld_type == BMGR_MLD_TYPE_MULTI) && bss_mngr_is_link_addr_used(mld_addr))
		goto err;

	/* if mld is NULL, allocate new mld */
#ifdef MLD_GROUP_ID_REMAPPING_V1
	os_alloc_mem(NULL, (u8 **)&mld, sizeof(struct bmgr_mlo_dev));
	if (!mld) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: mld alloc failed!!\n");
		goto err;
	}

	mld_idx_mapping_v1_store(new_grp, mld, bss_mngr_con_mld_free);
#else
	if (!mld) {
		os_alloc_mem(NULL, (u8 **)&mld, sizeof(struct bmgr_mlo_dev));

		if (!mld) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Error: mld alloc failed!!\n");
			goto err;
		}

		bss_mngr.mld[new_grp] = mld;
	}
#endif

	/* init mld */
	NdisZeroMemory(mld, sizeof(struct bmgr_mlo_dev));

	/* acquire hw resources */
	if (event_ops->bmgr_event_add_mld(wdev, new_grp,
			mld_addr, mld_type) != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"Error: acquire hw rsc for mld failed (type:%d, grp:%d, addr:%pM)\n",
			mld_type, new_grp, mld_addr);
		goto err;
	}

	mld->mld_grp = new_grp;
	mld->mld_type = mld_type;
	COPY_MAC_ADDR(mld->mld_addr, mld_addr);
	bmgr_mld_reset(mld);
	atomic_set(&mld->bmc_sn, 0);
	bss_mngr_con_fill_attr_to_mld(mld, mld_attr);
	mld->valid = TRUE;

	*mld_grp = mld->mld_grp;

#ifdef MLD_GROUP_ID_REMAPPING_V1
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"Create mld_grp(%d) w/ type(%d) addr(%pM) success\n",
		new_grp, mld->mld_type, mld_addr);
#else
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"Create mld_grp(%d->%d) w/ type(%d) addr(%pM) success\n",
		old_grp, new_grp, mld->mld_type, mld_addr);
#endif

	mutex_unlock(&bss_mngr.op_mutex);

	return NDIS_STATUS_SUCCESS;

err:
#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld_idx_mapping_v1_erase(new_grp);
#else
	mld_idx_mapping_release(new_grp);
#endif
err_index:
	mutex_unlock(&bss_mngr.op_mutex);
	return ret;
}

static int bss_mngr_con_mld_group_destroy(
	IN struct wifi_dev *wdev,
	IN u8 mld_grp
)
{
	struct bmgr_mlo_dev *mld = NULL;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();

	if (!wdev)
		return NDIS_STATUS_FAILURE;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"===> mld_grp(%d)\n", mld_grp);

#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(mld_grp);
#else
	if (BMGR_VALID_MLD_GRP_IDX(mld_grp))
		mld = GET_MLD_BY_GRP_IDX(mld_grp);
#endif /* MLD_GROUP_ID_REMAPPING_V1 */
	if (BMGR_VALID_MLO_DEV(mld)) {
		mutex_lock(&bss_mngr.op_mutex);

		if (mld->mld_link_cnt != 0) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"mld_grp(%d) is not empty (link_cnt=%d), can not destroy.\n",
				mld_grp, mld->mld_link_cnt);
			mutex_unlock(&bss_mngr.op_mutex);
			return NDIS_STATUS_FAILURE;
		}

		mld->valid = FALSE;

		/* release hw resources */
		if (event_ops->bmgr_event_del_mld(wdev, mld_grp) != NDIS_STATUS_SUCCESS) {
			/* error if there is link in MLD */
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: release hw rsc of mld failed (grp:%d)\n",
				mld_grp);
		}

		/* free buffer before zero memory to avoid memory leakage */
		mld_free_reconfig_ml_ie(mld);

		NdisZeroMemory(mld, sizeof(struct bmgr_mlo_dev));
		bmgr_mld_reset(mld);
#ifdef MLD_GROUP_ID_REMAPPING_V1
		mld_idx_mapping_v1_erase(mld_grp);
#else
		mld_idx_mapping_release(mld_grp);
		mld->mld_type = BMGR_MLD_TYPE_NONE;
		/* set mld_grp index back after reset to zero */
		mld->mld_grp = mld_grp;
#endif
		mutex_unlock(&bss_mngr.op_mutex);

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"Destroy mld_grp(%d) success\n", mld_grp);
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"mld_grp(%d) is not valid\n", mld_grp);
		return NDIS_STATUS_FAILURE;
	}

	return NDIS_STATUS_SUCCESS;

}

/**
 * @brief Merge two MLD attributes based on the presence bitmap
 *
 * This function merges two MLD attributes, source and target.
 * The target attr. might be the original attr. of MLD and
 * combines the source attr. based on the presence bitmap
 * into it.
 *
 * @param target_attr Target MLD attr. Save the output attr.
 * @param source_attr Source MLD attr. Attributes to be written into target attr.
 * @param attr_pres_bmap Indicate which attributes to be overwritten in target attr.
 */
static int bss_mngr_con_mld_attr_merge(
	INOUT struct bmgr_mld_attr *target_attr,
	IN struct bmgr_mld_attr *source_attr,
	IN u32 attr_pres_bmap
)
{
	if (!source_attr || !target_attr) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"Invalid input source_attr(%p), target_attr(%p)\n",
			source_attr, target_attr);
		return NDIS_STATUS_INVALID_DATA;
	}

	if (attr_pres_bmap & MLD_OP_PARAM_PRES_EML_MODE) {
		target_attr->eml_caps.emlsr_supp = source_attr->eml_caps.emlsr_supp;
		target_attr->eml_caps.emlmr_supp = source_attr->eml_caps.emlmr_supp;
		target_attr->eml_caps.en = (target_attr->eml_caps.emlsr_supp ||
			target_attr->eml_caps.emlmr_supp) ? TRUE : FALSE;
	}

	if (attr_pres_bmap & MLD_OP_PARAM_PRES_EML_TRANS_TO)
		target_attr->eml_caps.trans_to = source_attr->eml_caps.trans_to;

	if (attr_pres_bmap & MLD_OP_PARAM_PRES_EML_OMN)
		target_attr->eml_caps.eml_omn_en = source_attr->eml_caps.eml_omn_en;

	if (attr_pres_bmap & MLD_OP_PARAM_PRES_T2LM_NEGO)
		target_attr->mld_caps.t2l_nego_supp = source_attr->mld_caps.t2l_nego_supp;

	if (attr_pres_bmap & MLD_OP_PARAM_PRES_LINK_RECONFIG_OP_SUP)
		target_attr->mld_caps.link_reconfig_op_sup = source_attr->mld_caps.link_reconfig_op_sup;

	return NDIS_STATUS_SUCCESS;
}

/**
 * @brief Core API to update the attribute of MLD
 *
 * This function updates the attributes of MLD maintained in BSS/MLD Manager.
 *
 * @param mld_grp MLD index in BSS/MLD Manager
 * @param attr_pres_bmap Indicate which attributes to be updated.
 * @param mld_attr the to be updated attributes of MLD.
 * @param cfg_disconn Indicate whether disconnect all MLD Peer before update attributes.
 */
static int bss_mngr_con_mld_group_attr_set(
	IN u8 mld_grp,
	IN u32 attr_pres_bmap,
	IN struct bmgr_mld_attr *mld_attr,
	IN u8 cfg_disconn
)
{
	u8 link_id, bss_idx;
	struct bmgr_mlo_dev *mld = NULL;
	struct bmgr_mld_attr target_attr = {0};
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();

	if (!mld_attr) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"Fail: mld_attr is null\n");
		return NDIS_STATUS_INVALID_DATA;
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"===> mld_grp(%d), pres_bmap(%d)\n", mld_grp, attr_pres_bmap);

	if (!attr_pres_bmap) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"Fail: pres_bmap (%d) should be non-zero\n", attr_pres_bmap);
		return NDIS_STATUS_INVALID_DATA;
	}

#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(mld_grp);
#else
	if (BMGR_VALID_MLD_GRP_IDX(mld_grp))
		mld = GET_MLD_BY_GRP_IDX(mld_grp);
#endif

	if (BMGR_VALID_MLO_DEV(mld)) {
		struct bmgr_entry *entry;
		struct bmgr_update_info update_info = {0};

		if (!mld_attr_sanity(mld_attr))
			return NDIS_STATUS_INVALID_DATA;

		NdisMoveMemory(&target_attr, &mld->attr, sizeof(struct bmgr_mld_attr));
		if (bss_mngr_con_mld_attr_merge(&target_attr, mld_attr,
				attr_pres_bmap) != NDIS_STATUS_SUCCESS) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"Fail: attr sync\n");
			return NDIS_STATUS_FAILURE;
		}

		/* TBD: pre-op bcn/assoc/disconn if any link */

		/* disconnect MLO-capable peer */
		if (cfg_disconn)
			bss_mngr_con_mld_disconn_all_mld_sta(mld->mld_grp);

		mutex_lock(&bss_mngr.op_mutex);

		/* update attr in mld */
		bss_mngr_con_fill_attr_to_mld(mld, &target_attr);

		if (mld->mld_link_cnt > 0) {
			/* update IEs */
			bss_mngr_con_mld_sync_ie(mld->mld_grp);

			/* update to logan bss (per link) */
			bss_mngr_con_fill_update_info(mld, &update_info);

			for (link_id = 0; link_id < BSS_MNGR_MAX_BAND_NUM; link_id++) {
				bss_idx = mld->bss_idx_mld[link_id];
				if (!BMGR_VALID_BSS_IDX(bss_idx))
					continue;

				entry = GET_BSS_ENTRY_BY_IDX(bss_idx);
				if (!BMGR_VALID_MLO_BSS_ENTRY(entry))
					continue;

				if (event_ops->bmgr_event_bss_attr_update(entry->pwdev,
					&update_info, TRUE) != NDIS_STATUS_SUCCESS) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
						"Fail: update bss %s failed\n", RtmpOsGetNetDevName(entry->pNetDev));
				}
			}
		}

		mutex_unlock(&bss_mngr.op_mutex);

		/* TBD: post-op bcn/assoc if any link // link */

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"Set attr of MLD(%d) success\n", mld_grp);
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"mld_grp(%d) is not valid\n", mld_grp);
		return NDIS_STATUS_FAILURE;
	}

	return NDIS_STATUS_SUCCESS;

}

static void bss_mngr_con_mld_get_tsf_offset(
	IN struct bmgr_mlo_dev *mld
)
{
	u8 repted_link, repting_link;
	u8 repted_bss_idx, repting_bss_idx;
	struct bmgr_entry *repted_entry, *repting_entry;
	struct wifi_dev *wdev = NULL;
	UINT32 tsf_diff[4];
	INT64 tsf_0, tsf_1;
	INT64 tsf_offset;

	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: mld is NULL!\n");
		return;
	}

	/* get the Per-STA Profile tsf offset */
	/* repted_link: the link that is reported in Per-STA Profile in ML IE */
	for (repted_link = 0; repted_link < BSS_MNGR_MAX_BAND_NUM; repted_link++) {
		repted_bss_idx = mld->bss_idx_mld[repted_link];
		if (!BMGR_VALID_BSS_IDX(repted_bss_idx))
			continue;

		repted_entry = GET_BSS_ENTRY_BY_IDX(repted_bss_idx);
		if (!BMGR_VALID_MLO_BSS_ENTRY(repted_entry))
			continue;

		for (repting_link = 0; repting_link < BSS_MNGR_MAX_BAND_NUM; repting_link++) {
			if (repted_link == repting_link)
				continue;

			repting_bss_idx = mld->bss_idx_mld[repting_link];
			if (!BMGR_VALID_BSS_IDX(repting_bss_idx))
				continue;

			repting_entry = GET_BSS_ENTRY_BY_IDX(repting_bss_idx);
			if (!BMGR_VALID_MLO_BSS_ENTRY(repting_entry))
				continue;

			os_zero_mem(tsf_diff, sizeof(tsf_diff));

			wdev = mt_os_net_dev_get_wdev(repted_entry->pNetDev);
			if (!wdev)
				continue;

			AsicGetTsfDiffTime(wdev->sys_handle,
				repted_entry->entry_info.hw_bss_index,
				repting_entry->entry_info.hw_bss_index,
				&tsf_diff[0],
				&tsf_diff[1],
				&tsf_diff[2],
				&tsf_diff[3]);

			tsf_0 = (INT64)tsf_diff[0] + ((INT64)tsf_diff[1] << 32);
			tsf_1 = (INT64)tsf_diff[2] + ((INT64)tsf_diff[3] << 32);
			tsf_offset = (tsf_0 - tsf_1) / 2;

			repted_entry->tsf_offset[repting_link] = tsf_offset;

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"\tbss[%02d,%d]=%lld, bss[%02d,%d]=%lld, tsf_offset(%lld)(0x%llx), unit:2us\n",
				repted_entry->bss_idx, repted_entry->entry_info.hw_bss_index, tsf_0,
				repting_entry->bss_idx, repting_entry->entry_info.hw_bss_index, tsf_1,
				tsf_offset, tsf_offset);
		}
	}
}

static int bss_mngr_con_mld_group_add_link(
	IN struct wifi_dev *wdev,
	IN u8 mld_grp
)
{
	u8 bss_idx;
	u8 link_id;
	struct bmgr_entry *entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;
	struct bmgr_update_info update_info;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();

	if (!wdev)
		return NDIS_STATUS_FAILURE;
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"===> wdev(%s) requests to join mld_grp(%d)\n",
		RtmpOsGetNetDevName(wdev->if_dev), mld_grp);

	/* check mld exists */
#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(mld_grp);
	if (!mld) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"mld(%d) do not exist!\n", mld_grp);
		return NDIS_STATUS_FAILURE;
	}
#else
	if (!BMGR_VALID_MLD_GRP_IDX(mld_grp) ||
		!BMGR_VALID_MLO_DEV(GET_MLD_BY_GRP_IDX(mld_grp))) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"mld(%d) do not exist!\n", mld_grp);
		return NDIS_STATUS_FAILURE;
	}
#endif

	entry = get_bss_entry_by_wdev(wdev);
	if (BMGR_VALID_BSS_ENTRY(entry)) {
		/* sanity check: entry is not affiliated with any mld */
		if (BMGR_VALID_MLO_DEV(entry->mld_ptr)) {
			if (entry->entry_info.mld_grp == mld_grp) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"entry(%s) is already affiliated with mld(%d)\n",
					RtmpOsGetNetDevName(wdev->if_dev),
					entry->entry_info.mld_grp);
				return NDIS_STATUS_SUCCESS;
			}

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"Error: entry(%s) already in mld(%d), can not add to mld(%d)\n",
				RtmpOsGetNetDevName(wdev->if_dev),
				entry->entry_info.mld_grp, mld_grp);
			return NDIS_STATUS_FAILURE;
		}

		/* sanity check: entry w/ link_id do not collide in MLD */
		bss_idx = entry->bss_idx;
		link_id = entry->link_id;
#ifndef MLD_GROUP_ID_REMAPPING_V1
		mld = GET_MLD_BY_GRP_IDX(mld_grp);
#endif
		if (BMGR_VALID_BSS_IDX(mld->bss_idx_mld[link_id])) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"bss_idx(%d) can not join mld, which is occupied by bss_idx(%d)\n",
				bss_idx, mld->bss_idx_mld[link_id]);
			return NDIS_STATUS_FAILURE;
		}

		mutex_lock(&bss_mngr.op_mutex);
		/* sanity check: single link MLD can only have one link */
		if ((mld->mld_type == BMGR_MLD_TYPE_SINGLE) && (mld->mld_link_cnt == 1)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"Error: single-link MLD (%d) can not be joined anymore.\n",
				mld->mld_grp);
			mutex_unlock(&bss_mngr.op_mutex);
			return NDIS_STATUS_FAILURE;
		}

		/* sanity check: the same BSSID as MLD addr of single link MLD */
		if ((mld->mld_type == BMGR_MLD_TYPE_SINGLE) &&
			(!MAC_ADDR_EQUAL(entry->entry_info.bssid, mld->mld_addr))) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"Error: (single-link MLD) link addr(%pM) shall same as mld addr(%pM)\n",
				entry->entry_info.bssid, mld->mld_addr);
			mutex_unlock(&bss_mngr.op_mutex);
			return NDIS_STATUS_FAILURE;
		}

		/* MLD attribute and link attr. sanity */
		if (mld->mld_link_cnt > 0) {
			/* entry has the same SSID as MLD's SSID */
			if ((mld->mld_ssid_len != entry->entry_info.ssid_len) ||
				!NdisEqualMemory(mld->mld_ssid, entry->entry_info.ssid, mld->mld_ssid_len)) {
				/* TODO: */
				/*
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"Notice: SSID(%s) of BSS is different from MLD SSID(%s)\n",
					entry->entry_info.ssid, mld->mld_ssid);
				mutex_unlock(&bss_mngr.op_mutex);
				return NDIS_STATUS_FAILURE;
				*/
			}
		}

		/* acquire hw resources */
		if (event_ops->bmgr_event_mld_add_link(
			wdev, mld_grp) != NDIS_STATUS_SUCCESS) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: acquire hw rsc for link failed (grp:%d)\n", mld_grp);
			mutex_unlock(&bss_mngr.op_mutex);
			return NDIS_STATUS_FAILURE;
		}

		/* Update MLD attr. by attr. of first joined BSS */
		if (mld->mld_link_cnt == 0) {
			/* SSID */
			NdisMoveMemory(mld->mld_ssid, entry->entry_info.ssid, entry->entry_info.ssid_len);
			mld->mld_ssid_len = entry->entry_info.ssid_len;
			mld->bmc_bss_idx = bss_idx;
		}

		/* join mld: update entry info in mld */
		mld->bss_idx_mld[link_id] = bss_idx;
		mld->mld_link_cnt++;

		/* join mld: update mld info in entry */
		entry->entry_info.mld_grp = mld_grp;
		entry->mld_ptr = mld;
		entry->bss_chg_cnt = 0;
		entry->mlo_en = TRUE;
		tid_map_sanity(entry);
		mutex_unlock(&bss_mngr.op_mutex);

		/* update to outside of BSS/MLD Manager */
		bss_mngr_con_fill_update_info(mld, &update_info);
		if (event_ops->bmgr_event_bss_attr_update(entry->pwdev,
			&update_info, FALSE) != NDIS_STATUS_SUCCESS) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"Fail: update bss %s in addlink failed\n",
				RtmpOsGetNetDevName(entry->pNetDev));
		}

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"bss_idx(%d,%s) join mld_grp(%d) success\n",
			bss_idx, RtmpOsGetNetDevName(wdev->if_dev),
			entry->entry_info.mld_grp);
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"invalid entry!\n");
		return NDIS_STATUS_FAILURE;
	}

	return NDIS_STATUS_SUCCESS;

}

static int bss_mngr_con_mld_group_del_link(
	struct wifi_dev *wdev)
{
	u8 mld_grp;
	u8 bss_idx;
	u8 link_id;
	struct bmgr_entry *entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();

	if (!wdev)
		return NDIS_STATUS_FAILURE;
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"===> wdev(%s) requests to leave mld_grp\n",
		RtmpOsGetNetDevName(wdev->if_dev));

	entry = get_bss_entry_by_wdev(wdev);
	if (entry) {
		/* sanity check: entry is affiliated with a mld */
		if (!BMGR_VALID_MLO_DEV(entry->mld_ptr)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"entry(%s) is not in any mld, (grp_idx:%d)\n",
				RtmpOsGetNetDevName(wdev->if_dev), entry->entry_info.mld_grp);
			return NDIS_STATUS_SUCCESS;
		}

		mld_grp = entry->entry_info.mld_grp;
#ifdef MLD_GROUP_ID_REMAPPING_V1
		mld = mld_idx_mapping_v1_load(mld_grp);
#else
		if (BMGR_VALID_MLD_GRP_IDX(mld_grp))
			mld = GET_MLD_BY_GRP_IDX(mld_grp);
#endif

		if (BMGR_VALID_MLO_DEV(mld)) {
			bss_idx = entry->bss_idx;
			link_id = entry->link_id;

			/* sanity check */
			if (mld->bss_idx_mld[link_id] != bss_idx) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
					"Error: link(%d) in mld(%d) is %d, not %d\n",
					link_id, mld_grp, mld->bss_idx_mld[link_id], bss_idx);
				return NDIS_STATUS_FAILURE;
			}

			mutex_lock(&bss_mngr.op_mutex);
			/* leave mld: update entry info in mld */
			mld->bss_idx_mld[link_id] = BMGR_INVALID_BSS_IDX;
			mld->mld_link_cnt--;

			/* leave mld: update mld info in entry */
#ifdef MLD_GROUP_ID_REMAPPING_V1
			entry->mld_ptr = NULL;
#else
			entry->mld_ptr = GET_MLD_BY_GRP_IDX(BMGR_INVALID_MLD_GRP);
#endif
			entry->mlo_en = FALSE;
			tid_map_sanity(entry);

			/* release hw resources */
			if (event_ops->bmgr_event_mld_del_link(wdev) != NDIS_STATUS_SUCCESS) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Error: release hw rsc for link failed (grp:%d)\n", mld_grp);
				mutex_unlock(&bss_mngr.op_mutex);
				return NDIS_STATUS_FAILURE;
			}
			/* handle non-AP STAs */
			if (mld->bmc_bss_idx == bss_idx) {
				for (link_id = 0; link_id < BSS_MNGR_MAX_BAND_NUM; link_id++) {
					if (BMGR_VALID_BSS_IDX(mld->bss_idx_mld[link_id])) {
						mld->bmc_bss_idx = mld->bss_idx_mld[link_id];
						MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
							"set bmc_bss=%d\n", mld->bmc_bss_idx);
						break;
					}
				}
			}
			mutex_unlock(&bss_mngr.op_mutex);

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"bss_idx(%d,%s) leave mld_grp(%d) success\n",
				bss_idx, RtmpOsGetNetDevName(wdev->if_dev),
				entry->entry_info.mld_grp);
		} else {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"mld(%d) not inited!\n", mld_grp);
			return NDIS_STATUS_FAILURE;
		}

	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"entry not inited!\n");
		return NDIS_STATUS_FAILURE;
	}

	return NDIS_STATUS_SUCCESS;

}

int bss_mngr_con_sync_mld_relation(struct bmgr_entry *entry)
{
	int ret = NDIS_STATUS_SUCCESS;
	u8 bss_idx = entry->bss_idx;
	u8 link_id = entry->link_id;
	u8 mlo_en = entry->mlo_en;
	struct bmgr_reg_info *reg_info = &entry->entry_info;

	u8 mld_grp = reg_info->mld_grp;
#ifdef MLD_GROUP_ID_REMAPPING_V1
	struct bmgr_mlo_dev *mld = mld_idx_mapping_v1_load(mld_grp);
#else
	struct bmgr_mlo_dev *mld = BMGR_VALID_MLD_GRP_IDX(mld_grp) ?
		GET_MLD_BY_GRP_IDX(mld_grp) : NULL;
#endif

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"[%d] link(%d), mlo_en(%d)\n",
			bss_idx, link_id, mlo_en);

	if (BMGR_VALID_BSS_ENTRY(entry)) {
		/* mld exists, entry joins to mld */
		ret = bss_mngr_con_mld_group_add_link(entry->pwdev, mld_grp);
	} else {
		ret = bss_mngr_con_mld_group_del_link(entry->pwdev);

		/* if there is no entry in mld, destroy mld */
		if (mld && mld->mld_link_cnt == 0)
			ret = bss_mngr_con_mld_group_destroy(entry->pwdev, mld_grp);
	}

	if (ret != NDIS_STATUS_SUCCESS)
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"Error: fail to sync mld relation!!!\n");

	return ret;
}

static int bss_mngr_con_mld_reconfig_ie_op(
	IN struct mld_reconfig_ie_op *ie_op)
{
	struct mld_reconfig_ie_build_t *reconf_build;
	struct mld_reconfig_ie_clean_t *reconf_clean;
	struct mld_reconfig_ie_query_t *reconf_query;
	struct reconfig_ml_ie_t *reconf_ie;
	struct _EID_STRUCT *eid;
	int ret = NDIS_STATUS_FAILURE;
	u8 *f_buf, *pos, link;
	u16 link_info_len;
#ifdef MLD_GROUP_ID_REMAPPING_V1
	struct bmgr_mlo_dev *mld = mld_idx_mapping_v1_load(ie_op->mld_grp_idx);
#else
	struct bmgr_mlo_dev *mld = BMGR_VALID_MLD_GRP_IDX(ie_op->mld_grp_idx) ?
		GET_MLD_BY_GRP_IDX(ie_op->mld_grp_idx) : NULL;
#endif

	if (!BMGR_VALID_MLO_DEV(mld))
		return ret;

	switch (ie_op->op) {
	case BMGR_RECONFIG_IE_OP_BUILD:
		reconf_build = ie_op->reconf_build;
		if (!reconf_build)
			return ret;

		if (!mld_alloc_reconfig_ml_ie(mld))
			return ret;

		if (!build_ap_removal_reconfig_multi_link_ie(mld, reconf_build)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
				"build Reconfiguration multi-link IE failed\n");
			return ret;
		}

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
			"build ie done status(%d), cmm(%d)\n",
			mld->reconf_ie.ie_status,
			mld->reconf_ie.common_info.len);

		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_DEBUG,
				"link%d(%d), offset(%d), bss_idx(%d)\n", link,
				mld->reconf_ie.link_info[link].len,
				mld->reconf_ie.tmr_offset[link],
				mld->reconf_ie.fw_bss_idx[link]);
		}

		mld->reconf_ie.ie_status = BUF_STAT_IE_READY;

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_DEBUG,
			"update ie status done %d\n", mld->reconf_ie.ie_status);

		break;
	case BMGR_RECONFIG_IE_OP_CLEAN:
		mld_clean_reconfig_ml_ie(mld);
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_DEBUG,
			"clean done, ie status %d\n", mld->reconf_ie.ie_status);
		break;
	case BMGR_RECONFIG_IE_OP_CLEAN_LINK: /* TODO */
		reconf_clean = ie_op->reconf_clean;
		if (!reconf_clean)
			return ret;

		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			if (reconf_clean->clean_links[link]) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_INFO,
					"link%d(%d), offset(%d), bss_idx(%d)\n", link,
					mld->reconf_ie.link_info[link].len,
					mld->reconf_ie.tmr_offset[link],
					mld->reconf_ie.fw_bss_idx[link]);
			}
		}
		break;
	case BMGR_RECONFIG_IE_OP_QUERY:
		reconf_query = ie_op->reconf_query;
		if (!reconf_query)
			return ret;

		reconf_query->f_len = 0;

		reconf_ie = &mld->reconf_ie;
		if (!(reconf_ie->ie_status == BUF_STAT_IE_READY)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_DEBUG,
				"Reconfig IE not ready %d\n", mld->reconf_ie.ie_status);
			return ret;
		}

		/* common info */
		if (reconf_ie->common_info.buf) {
			NdisMoveMemory(reconf_query->f_buf,
				reconf_ie->common_info.buf, reconf_ie->common_info.len);
			reconf_query->f_len = reconf_ie->common_info.len;
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_DEBUG,
				"RMLIE Common: len=%d, f_buf=%p\n", reconf_query->f_len, reconf_query->f_buf);
		}

		if (!reconf_query->f_len)
			return ret;

		/* link info */
		f_buf = pos = reconf_query->f_buf + reconf_query->f_len;
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			if (reconf_ie->link_info[link].buf && reconf_ie->link_info[link].len) {
				reconf_query->tmr_offset[link] = reconf_query->f_len
					+ (pos - f_buf) + reconf_ie->tmr_offset[link];

				NdisMoveMemory(pos, reconf_ie->link_info[link].buf,
					reconf_ie->link_info[link].len);
				pos += reconf_ie->link_info[link].len;

				reconf_query->fw_bss_idx[link] = reconf_ie->fw_bss_idx[link];

				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_DEBUG,
					"LinkInfo: offset=%d, fw_bss=%d, len=%d\n", reconf_query->tmr_offset[link],
					reconf_query->fw_bss_idx[link], reconf_ie->link_info[link].len);
			}
		}

		/* length of all Per-STA Profile(s) */
		link_info_len = pos - f_buf;
		reconf_query->f_len += link_info_len;

		eid = (struct _EID_STRUCT *)reconf_query->f_buf;
		eid->Len = reconf_query->f_len - 2;

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_DEBUG,
			"ReconfigIE: len=%d, len in tlv=%d\n", reconf_query->f_len, eid->Len);

		break;
	default:
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
			"Unknown Op %d\n", ie_op->op);
		return ret;
	}

	return NDIS_STATUS_SUCCESS;
}



/**
 * @ML reconfiguration: handle peer mld_sta when MLR
 *
 * @param mld_grp_idx ap mld group index
 * @param rm_link_id_bitmap link id bitmap of remove link
 * @param *link_id_bss_info_idx bss_info_indx of respect link id
 */
int bss_mngr_con_mld_reconfig_peer_mld(
	IN u8 mld_grp_idx,
	IN u16 rm_link_id_bitmap)
{
	int ret = 0;
	u16 i = 0;
	u8 new_data_link_id;
	struct bmgr_mlo_dev *mld = NULL;
	struct bmgr_mld_sta *mld_sta = NULL;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();

#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(mld_grp_idx);
#else
	mld = BMGR_VALID_MLD_GRP_IDX(mld_grp_idx) ? GET_MLD_BY_GRP_IDX(mld_grp_idx) : NULL;
#endif
	if (!BMGR_VALID_MLO_DEV(mld)) {
		ret = -EINVAL;
		goto err;
	}

	/*non-AP MLD*/
	for (i = 0; BMGR_VALID_MLD_STA(i); i++) {
		mld_sta = GET_MLD_STA_BY_IDX(i);
		if (!mld_sta || !mld_sta->valid)
			continue;
		if (mld_sta->mld_grp_idx != mld->mld_grp)
			continue;
		new_data_link_id = MLD_LINK_MAX;
		ret = event_ops->bmgr_event_mld_reconfig(mld_sta->mld_addr, rm_link_id_bitmap,
			&new_data_link_id);
		if (ret) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
				"Error: mld_sta=%pM (%d) ret=%d\n",
				mld_sta->mld_addr, mld_sta->idx, ret);
		} else {
			if (new_data_link_id != MLD_LINK_MAX)
				mld_sta->data_link_id = new_data_link_id;
		}
	}

	return ret;
err:
	return ret;
}

int bss_mngr_con_mld_group_addr_set(
	struct wifi_dev *wdev,
	IN u8 mld_grp_idx,
	IN u8 *mld_addr)
{
	int ret = 0;
	u16 i = 0;
	struct bmgr_mlo_dev *mld = NULL;
	struct bmgr_mlo_dev mld2;
	struct bmgr_entry *mbss_entry;
	u8 bss_idx_mld;
	u8 mld_grp_idx2;

#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(mld_grp_idx);
#else
	mld = BMGR_VALID_MLD_GRP_IDX(mld_grp_idx) ? GET_MLD_BY_GRP_IDX(mld_grp_idx) : NULL;
#endif
	if (!BMGR_VALID_MLO_DEV(mld)) {
		ret = -EINVAL;
		goto err;
	}

	if (mld->mld_type != BMGR_MLD_TYPE_MULTI) {
		ret = -EINVAL;
		goto err;
	}

	memcpy(&mld2, mld, sizeof(mld2));

	for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++) {
		bss_idx_mld = mld2.bss_idx_mld[i];

		mbss_entry = GET_BSS_ENTRY_BY_IDX(bss_idx_mld);
		if (!BMGR_VALID_BSS_ENTRY(mbss_entry))
			continue;

		ret = bss_mngr_con_mld_group_del_link(mbss_entry->pwdev);
		if (ret != NDIS_STATUS_SUCCESS) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: del link failed, mld_grp_idx:%u wdev:%p\n",
				mld_grp_idx, mbss_entry->pwdev);
			return ret;
		}
	}
	ret = bss_mngr_con_mld_group_destroy(wdev, mld_grp_idx);
	if (ret != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: destroy mld group failed, mld_grp_idx:%u\n",
			mld_grp_idx);
		return ret;
	}

	mld_grp_idx2 = mld_grp_idx;
	ret = bss_mngr_con_mld_group_create(wdev, &mld_grp_idx2, mld_addr, &mld2.attr, BMGR_MLD_TYPE_MULTI);
	if (ret != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: create mld group failed, mld_grp_idx:%u\n",
			mld_grp_idx2);
		return ret;
	}

	for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++) {
		bss_idx_mld = mld2.bss_idx_mld[i];

		mbss_entry = GET_BSS_ENTRY_BY_IDX(bss_idx_mld);
		if (!BMGR_VALID_BSS_ENTRY(mbss_entry))
			continue;

		ret = bss_mngr_con_mld_group_add_link(mbss_entry->pwdev, mld_grp_idx);
		if (ret != NDIS_STATUS_SUCCESS) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: add link failed, mld_grp_idx:%u wdev:%p\n",
				mld_grp_idx, mbss_entry->pwdev);
			return ret;
		}
	}

	return 0;
err:
	return ret;
}
#endif /* DOT11_EHT_BE */

#define BCN_UPDATE_IOB_TX_BSS 1
#define BCN_UPDATE_OOB_TX_BSS 2
#define BCN_UPDATE_OOB_NTX_BSS 3

static u8 is_peer_bcn_update_require(
	IN struct bmgr_entry *peer_entry,
	IN struct bmgr_entry *entry
)
{
	u8 bss_idx_tx = entry->bss_idx_tx;
	u8 mld_grp = entry->entry_info.mld_grp;
	u8 band_idx = entry->entry_info.dev_cfg_idx;
	u8 peer_bss_idx = peer_entry->bss_idx;
	u8 peer_bss_idx_tx = peer_entry->bss_idx_tx;
	u8 peer_mld_grp = peer_entry->entry_info.mld_grp;
	u8 peer_band_idx = peer_entry->entry_info.dev_cfg_idx;
	u8 peer_dev_type = peer_entry->entry_info.dev_type;
	u8 up_type = 0;

	if (peer_band_idx == band_idx) {
		/* inband: update self or tx-bss */
		if (peer_bss_idx == bss_idx_tx)
			up_type = BCN_UPDATE_IOB_TX_BSS;
	} else {
		/* outband: mld member or all(for 6G) */
		if ((mld_grp != 0) && (peer_mld_grp == mld_grp)) {
			/* mld group member */
			if (IS_DEV_TYPE_W_BCN(peer_dev_type)) {
				up_type = BCN_UPDATE_OOB_TX_BSS;
			} else if (IS_DEV_TYPE_11V_NT(peer_dev_type)) {
				if (BMGR_VALID_BSS_IDX(peer_bss_idx_tx))
					up_type = BCN_UPDATE_OOB_NTX_BSS;
			}
		}
		/*
		 * TBD: outband rnr required for 6G devices
		 */
	}
	return up_type;
}

int bss_mngr_con_bcn_update(IN struct bmgr_entry *entry)
{
	u8 bss_idx = entry->bss_idx;
	int ret = NDIS_STATUS_FAILURE;
	struct bss_mngr_event_ops *event_ops;
	struct bmgr_entry *peer_entry = NULL;
	u8 peer_bss_idx;
	u8 up_type = 0;
	static const char * const type_str[] = {
		"None",
		"IoB-TxBss",
		"OoB-TxBss",
		"OoB-NTxBss"
	};

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"[%d]\n", bss_idx);

	/* traverse bss be updated */
	for (peer_bss_idx = 0; peer_bss_idx < BSS_MNGR_ENTRY_CNT; peer_bss_idx++) {
		peer_entry = GET_BSS_ENTRY_BY_IDX(peer_bss_idx);

		up_type = 0;
		if (BMGR_VALID_BSS_ENTRY(peer_entry))
			up_type = is_peer_bcn_update_require(peer_entry, entry);

		/* patch peer_entry to oob tx-bss */
		if (up_type == BCN_UPDATE_OOB_NTX_BSS)
			peer_entry = GET_BSS_ENTRY_BY_IDX(peer_entry->bss_idx_tx);

		if (up_type) {
			event_ops = peer_entry->entry_info.event_ops;
			if (event_ops) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"\t->[%d]: %s\n", peer_entry->bss_idx, type_str[up_type]);
				event_ops->bmgr_event_bcn_update(peer_entry->pwdev);
				ret = NDIS_STATUS_SUCCESS;
			}
		}
	}

	return ret;
}

int bss_mngr_con_sync_bcn_update(
	struct wifi_dev *wdev)
{
	struct bmgr_entry *entry;

	if (wdev == NULL) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"null invalid param\n");
		return NDIS_STATUS_FAILURE;
	}

	entry = get_bss_entry_by_wdev(wdev);
	if (entry == NULL) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"bss not found\n");
		return NDIS_STATUS_FAILURE;
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATAP_BCN, DBG_LVL_NOTICE, "link_id=%d\n", entry->link_id);

	return bss_mngr_con_bcn_update(entry);
}

int bss_mngr_con_sync_entry(IN struct bmgr_entry *entry)
{
	int ret = NDIS_STATUS_FAILURE;

	if (entry) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE, "[%d]\n",
				 entry->bss_idx);

#ifdef DOT11_EHT_BE
		/* sync mld relation */
		if (entry->entry_info.mld_grp && WMODE_CAP_BE(entry->entry_info.phy_mode))
			bss_mngr_con_sync_mld_relation(entry);
#endif
		/* re-build ie(s) */
		bss_mngr_con_sync_ie(entry);

		/* re-sync beacon */
		bss_mngr_con_bcn_update(entry);
	}

	return ret;
}
void *bss_mngr_get_pad_by_band_idx(u8 band_idx)
{
	u8 i;
	struct bmgr_entry *entry = NULL;
	void *tmp_pad = NULL;

	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		entry = GET_BSS_ENTRY_BY_IDX(i);
		if (entry && entry->valid &&
			entry->entry_info.dev_cfg_idx == band_idx) {
			if (entry->pNetDev)
				tmp_pad = mt_os_net_dev_get_priv(entry->pNetDev);
		}
	}

	return tmp_pad;
}

#ifdef CONFIG_6G_SUPPORT
static bool bss_mngr_is_ap_6g_only(void)
{
	u8 i;
	u16 phy_mode;
	struct bmgr_entry *entry = NULL;
	bool is_6g_only = TRUE;

	/* traverse all BSS members and check whether 2G or 5G exists */
	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		entry = GET_BSS_ENTRY_BY_IDX(i);
		if (BMGR_VALID_BSS_ENTRY(entry)) {
			phy_mode = entry->entry_info.phy_mode;
			if (!WMODE_CAP_6G(phy_mode)) {
				is_6g_only = FALSE;
				break;
			}
		}
	}

	return is_6g_only;
}

static int bss_mngr_update_iob_disc(void)
{
	u8 i;
	u8 by_cfg, iob_type, iob_interval, iob_mode;
	u16 phy_mode;
	struct bmgr_entry *entry = NULL;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();

	/*
	 * 1. AP is operating in 6 GHz only
	 *	- allowed to transmit either UPR or FD frames
	 *
	 * 2. AP is operating in multiple bands (including 6 GHz)
	 *	- Disable transmission of UPR and FD frames
	 */

	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		entry = GET_BSS_ENTRY_BY_IDX(i);
		if (BMGR_VALID_BSS_ENTRY(entry)) {

			/* ignore non-tx BSSID */
			if (entry->entry_info.dev_type == DEV_TYPE_AP_11VNT) {
				MTWF_DBG(NULL, DBG_CAT_AP, CATAP_MBSS, DBG_LVL_INFO,
					"\t[%s] iob dsc ignored due to 11v non-tx\n",
					RtmpOsGetNetDevName(entry->pNetDev));
				continue;
			}

			/* ignore when configured by profile or user commands */
			by_cfg = entry->entry_info.disc_param.iob_by_cfg;
			if (by_cfg) {
				MTWF_DBG(NULL, DBG_CAT_AP, CATAP_MBSS, DBG_LVL_INFO,
					"\t[%s] iob dsc ignored by cfg\n", RtmpOsGetNetDevName(entry->pNetDev));
				continue;
			}

			/* set 2G/5G/6G iob discovery rule (based on SPEC) */
			phy_mode = entry->entry_info.phy_mode;
			if (WMODE_CAP_6G(phy_mode)) {
				if (bss_mngr_is_ap_6g_only()) {
					/* single 6G: enable 6G iob discovery frame offload */
					iob_type = UNSOLICIT_TX_PROBE_RSP;
				} else {
					/* multi-band: disable 6G iob discovery frame offload */
					iob_type = UNSOLICIT_TX_DISABLE;
				}

				/* value from rtmp_read_6g_discov_cfg_from_file or user commands */
				iob_interval = entry->entry_info.disc_param.iob_interval;
				iob_mode = entry->entry_info.disc_param.iob_mode;
				MTWF_DBG(NULL, DBG_CAT_AP, CATAP_MBSS, DBG_LVL_DEBUG,
					"\t[%s] 6G: only:%d iob\n", RtmpOsGetNetDevName(entry->pNetDev),
					bss_mngr_is_ap_6g_only());
			} else {
				/* 2g/5g: default config */
				iob_type = UNSOLICIT_TX_DISABLE;
				iob_interval = 0;
				iob_mode = UNSOLICIT_TXMODE_NON_HT;
				MTWF_DBG(NULL, DBG_CAT_AP, CATAP_MBSS, DBG_LVL_DEBUG,
					"\t[%s] 2G/5G iob\n", RtmpOsGetNetDevName(entry->pNetDev));
			}

			MTWF_DBG(NULL, DBG_CAT_AP, CATAP_MBSS, DBG_LVL_DEBUG,
					"\t[%s] iob type=%d, interval=%d, rate mode=%d\n",
					RtmpOsGetNetDevName(entry->pNetDev),
					iob_type, iob_interval, iob_mode);

			entry->entry_info.disc_param.iob_type = iob_type;
			entry->entry_info.disc_param.iob_interval = iob_interval;
			entry->entry_info.disc_param.iob_mode = iob_mode;

			event_ops->bmgr_event_update_iob_disc(entry->pwdev,
				&entry->entry_info.disc_param);
		}
	}

	return NDIS_STATUS_SUCCESS;
}

NDIS_STATUS bss_mngr_con_update_he_bss_discov(
	IN struct wifi_dev *wdev,
	IN u8 update_type,
	IN struct bmgr_disc_param *disc_param)
{
	struct bmgr_entry *entry = NULL;
	bool is_updated;

	if (!wdev)
		return NDIS_STATUS_FAILURE;
	entry = get_bss_entry_by_wdev(wdev);
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
		"===> netdev(%s)\n", RtmpOsGetNetDevName(wdev->if_dev));

	if (BMGR_VALID_BSS_ENTRY(entry)) {
		switch (update_type) {
		case BSS_IOB_DISCOV_UPDATE:
			is_updated = (entry->entry_info.disc_param.iob_type
				!= disc_param->iob_type) ? TRUE : FALSE;

			entry->entry_info.disc_param.iob_by_cfg = disc_param->iob_by_cfg;
			entry->entry_info.disc_param.iob_type = disc_param->iob_type;
			entry->entry_info.disc_param.iob_interval = disc_param->iob_interval;
			entry->entry_info.disc_param.iob_mode = disc_param->iob_mode;

			if (is_updated) {
				bss_mngr_con_sync_ie(entry);
				return bss_mngr_con_bcn_update(entry);
			}

			return NDIS_STATUS_SUCCESS;

		case BSS_OOB_DISCOV_UPDATE:
			is_updated = (entry->entry_info.disc_param.rnr_6g_rule
				!= disc_param->rnr_6g_rule) ? TRUE : FALSE;

			entry->entry_info.disc_param.rnr_6g_rule = disc_param->rnr_6g_rule;

			if (is_updated) {
				bss_mngr_con_ie_update_rnr_for_6g(entry);
				return bss_mngr_con_bcn_update(entry);
			}

			return NDIS_STATUS_SUCCESS;

		default:
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Unknown update type %d\n", update_type);
			return NDIS_STATUS_FAILURE;
		}
	}

	return NDIS_STATUS_FAILURE;
}
#endif
static int bss_mngr_con_dev_reg(
	IN struct wifi_dev *wdev,
	IN struct bmgr_reg_info *reg_info
)
{
	bool is_exist = FALSE;
	struct bmgr_entry *entry = NULL;
	struct repting_rnr_info *rnr_info = NULL;
	u8 bss_idx = BMGR_INVALID_BSS_IDX;

	if (!wdev)
		return NDIS_STATUS_FAILURE;
	entry = get_bss_entry_by_wdev(wdev);
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"===> netdev(%02d) (%s)\n",
			RtmpOsGetNetIfIndex(wdev->if_dev), RtmpOsGetNetDevName(wdev->if_dev));

	if (entry) {
		is_exist = TRUE;
		bss_idx = entry->bss_idx;
		entry->pNetDev = wdev->if_dev;
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN, "\tentry exist!!\n");
	}

	if (!is_exist) {
		/* assign new */
		bss_idx = bss_idx_acquire();
		if (BMGR_VALID_BSS_IDX(bss_idx)) {
			os_alloc_mem(NULL, (u8 **)&entry, sizeof(struct bmgr_entry));

			if (entry) {
				NdisZeroMemory(entry, sizeof(struct bmgr_entry));
				entry->pNetDev = wdev->if_dev;
				entry->bss_idx = bss_idx;
				entry->pwdev = wdev;
				mutex_lock(&bss_mngr.op_mutex);
				bss_mngr.entry[bss_idx] = entry;
				BSS_MNGR_ENTRY_CNT++;
				mutex_unlock(&bss_mngr.op_mutex);
			} else {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"\tentry alloc failed!!\n");
				goto err;
			}
		} else {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"\tentry invalid(%d)!!\n", bss_idx);
			goto err;
		}
	}

	/* fill entry info */
	entry->valid = TRUE;
	NdisMoveMemory(&entry->entry_info, reg_info, sizeof(struct bmgr_reg_info));
	entry->bss_idx_tx = get_tx_bss_idx(entry);
	entry->dot11be_mld_id = IS_DEV_TYPE_11V_NT(entry->entry_info.dev_type) ?
		entry->entry_info.dot11v_mbssid_idx : 0;
	entry->link_id = entry->entry_info.dev_cfg_idx;
	entry->tid_map = entry->entry_info.tid_map;
	entry->bss_chg_cnt = 0;

	rnr_info = &entry->rnr_info;
	rnr_info->repting_cnt = 0;
	NdisZeroMemory(rnr_info->repting_bss_idx, sizeof(rnr_info->repting_bss_idx));
	NdisZeroMemory(rnr_info->bss_idx_bitmap, sizeof(rnr_info->bss_idx_bitmap));

	/* alloc ie(s) buffer */
	if (bss_mngr_con_ie_buf_alloc(entry) != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"\tie buf alloc failed!!\n");
		goto err;
	}

	/* clean ie buffer */
	bss_mngr_con_ie_buf_clean(entry);

	/* sync entry for any change */
	bss_mngr_con_sync_entry(entry);

#ifdef CONFIG_6G_SUPPORT
	/* update iob discovery rule for any interface up */
	bss_mngr_update_iob_disc();
#endif

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"<=== entry = %p(bss_idx_tx = %d) (dev_cnt = %d)\n",
			entry, entry->bss_idx_tx, BSS_MNGR_ENTRY_CNT);

	return NDIS_STATUS_SUCCESS;

err:
	if (entry) {
		bss_mngr_con_ie_buf_free(entry);
		os_free_mem(entry);
	}
	if (BMGR_VALID_BSS_IDX(bss_idx)) {
		mutex_lock(&bss_mngr.op_mutex);
		bss_mngr.entry[bss_idx] = NULL;
		bss_idx_clear(bss_idx);
		mutex_unlock(&bss_mngr.op_mutex);
	}
	return NDIS_STATUS_FAILURE;
}

static int bss_mngr_con_dev_dereg(
	struct wifi_dev *wdev)
{
	struct bmgr_entry *entry = NULL;

	if (!wdev)
		return NDIS_STATUS_FAILURE;
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"===> netdev(%02d) (%s)\n",
			RtmpOsGetNetIfIndex(wdev->if_dev), RtmpOsGetNetDevName(wdev->if_dev));

	entry = get_bss_entry_by_wdev(wdev);
	if (entry) {
		entry->valid = FALSE;

		/* sync entry for any change */
		bss_mngr_con_sync_entry(entry);

#ifdef CONFIG_6G_SUPPORT
		/* update iob discovery rule for any interface down */
		bss_mngr_update_iob_disc();
#endif
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"\tentry not found!!\n");
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
			"<=== %s:\n", __func__);

	return NDIS_STATUS_SUCCESS;
}

int bss_mngr_con_dev_update(
	IN struct wifi_dev *wdev,
	IN struct bmgr_reg_info *reg_info
)
{
	struct bmgr_entry *entry = NULL;

	if (!wdev)
		return NDIS_STATUS_FAILURE;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"===> netdev(%02d) (%s)\n",
			RtmpOsGetNetIfIndex(wdev->if_dev), RtmpOsGetNetDevName(wdev->if_dev));

	entry = get_bss_entry_by_wdev(wdev);
	if (entry) {
		/* fill entry info */
		NdisMoveMemory(&entry->entry_info, reg_info, sizeof(struct bmgr_reg_info));
		entry->bss_idx_tx = get_tx_bss_idx(entry);
		entry->dot11be_mld_id = IS_DEV_TYPE_11V_NT(entry->entry_info.dev_type) ?
			entry->entry_info.dot11v_mbssid_idx : 0;
		entry->link_id = entry->entry_info.dev_cfg_idx;
		entry->tid_map = entry->entry_info.tid_map;

		/* re-build ie(s) */
		bss_mngr_con_sync_ie(entry);

		/* re-sync beacon */
		bss_mngr_con_bcn_update(entry);

	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"\tentry not found!!\n");
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
			"<=== %s:\n", __func__);

	return NDIS_STATUS_SUCCESS;
}

static int bss_mngr_ext_entry_init(void)
{
	struct bmgr_entry *entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;

	u8 bss_idx = BMGR_INVALID_BSS_IDX;
	u8 mld_grp_idx = BMGR_INVALID_MLD_GRP;

	bss_idx_set(bss_idx);
	os_alloc_mem(NULL, (u8 **)&entry, sizeof(struct bmgr_entry));
	if (entry) {
		/* valid/mlo_en=FALSE */
		NdisZeroMemory(entry, sizeof(struct bmgr_entry));
		entry->bss_idx = bss_idx;
		bss_mngr.entry[bss_idx] = entry;
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"\tentry alloc failed!!\n");
		goto err;
	}

#ifdef DOT11_EHT_BE
	os_alloc_mem(NULL, (u8 **)&mld, sizeof(struct bmgr_mlo_dev));
	if (mld) {
		/* valid=FALSE */
		NdisZeroMemory(mld, sizeof(struct bmgr_mlo_dev));
		mld->mld_grp = mld_grp_idx;
		bmgr_mld_reset(mld);
#ifdef MLD_GROUP_ID_REMAPPING_V1
		mld_idx_mapping_v1_store(mld_grp_idx, mld, bss_mngr_con_mld_free);
#else
		bss_mngr.mld[mld_grp_idx] = mld;
#endif

		entry->mld_ptr = mld;
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"\tmld alloc failed!!\n");
		goto err;
	}
#endif

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"bss(%d), grp(%d)\n", bss_idx, mld_grp_idx);

	return NDIS_STATUS_SUCCESS;

err:
	if (entry)
		os_free_mem(entry);

	/*
	if (mld)
		os_free_mem(mld);
	*/

	return NDIS_STATUS_FAILURE;
}

static int bss_mngr_con_init(void)
{
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"inited = %d\n", bss_mngr.inited);

	if (!bss_mngr.inited) {
		os_zero_mem(&bss_mngr, sizeof(bss_mngr));
		bss_idx_bitmap_init();
#ifdef DOT11_EHT_BE
#ifdef MLD_GROUP_ID_REMAPPING_V1
		mld_idx_mapping_v1_init();
#else
		mld_idx_mapping_init();
#endif /* MLD_GROUP_ID_REMAPPING_V1 */
		mld_sta_init();
		mld_twt_init(&bss_mngr.mlo_twt);
#endif
		mutex_init(&bss_mngr.op_mutex);
		bss_mngr_ext_entry_init();
		bss_mngr.event_ops = &bmgr_event_ops;

		bss_mngr.inited = TRUE;
	}

	return NDIS_STATUS_SUCCESS;
}

static int bss_mngr_con_deinit(void)
{
	struct bmgr_entry *entry = NULL;	/*, bmg_entry_tmp = NULL*/
#ifdef MLD_GROUP_ID_REMAPPING_V1
#else
	struct bmgr_mlo_dev *mld = NULL;
#endif
	struct bmgr_mld_sta *mld_sta = NULL;
	int i, j;
	u8 *sta_pf;
	int dev_cnt = BSS_MNGR_ENTRY_CNT;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"inited = %d, dev_cnt = %d\n",
			bss_mngr.inited, BSS_MNGR_ENTRY_CNT);

	if (bss_mngr.inited) {
		mutex_lock(&bss_mngr.op_mutex);

		/* free BSS entry */
		for (i = 0; i < dev_cnt; i++) {
			entry = GET_BSS_ENTRY_BY_IDX(i);
			if (entry) {
				if (entry->valid)
					bss_mngr_con_dev_dereg(entry->pwdev);
				bss_mngr_con_ie_buf_free(entry);
				os_free_mem(entry);
				BSS_MNGR_ENTRY_CNT--;
				bss_mngr.entry[i] = NULL;
			}
		}
		entry = GET_BSS_ENTRY_BY_IDX(BMGR_INVALID_BSS_IDX);
		if (entry) {
			os_free_mem(entry);
			bss_mngr.entry[BMGR_INVALID_BSS_IDX] = NULL;
		}

#ifdef MLD_GROUP_ID_REMAPPING_V1
		for (i = 0; i < MAX_MLD_GRP_NUM; i++)
			mld_idx_mapping_v1_erase(i);
#else
		/* free MLD */
		for (i = 0; i < BMGR_MAX_MLD_GRP_CNT; i++) {
			mld = GET_MLD_BY_GRP_IDX(i);

			if (mld) {
				//bss_mngr_con_mld_group_destroy(mld->mld_grp);
				mld_free_reconfig_ml_ie(mld);
				os_free_mem(mld);
				bss_mngr.mld[i] = NULL;
			}
		}
#endif
		/* free peer MLD */
		for (i = 0; BMGR_VALID_MLD_STA(i); i++) {
			mld_sta = GET_MLD_STA_BY_IDX(i);

			for (j = 0; j < BSS_MNGR_MAX_BAND_NUM; j++) {
				mld_sta->mld_link[j].assoc_rsp_sta_profile.len = 0;
				sta_pf = mld_sta->mld_link[j].assoc_rsp_sta_profile.buf;
				if (sta_pf)
					os_free_mem(sta_pf);
			}
		}

#ifdef DOT11_EHT_BE
				mld_twt_deinit(&bss_mngr.mlo_twt);
#endif /* DOT11_EHT_BE */

		if (BSS_MNGR_ENTRY_CNT == 0) {
			bss_idx_bitmap_deinit();
#ifdef DOT11_EHT_BE
#ifdef MLD_GROUP_ID_REMAPPING_V1
			mld_idx_mapping_v1_deinit();
#else
			mld_idx_mapping_deinit();
#endif /* MLD_GROUP_ID_REMAPPING_V1 */
#endif
			mutex_unlock(&bss_mngr.op_mutex);
			mutex_init(&bss_mngr.op_mutex);
			bss_mngr.inited = FALSE;
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"%s: de-init\n", __func__);
		} else
			mutex_unlock(&bss_mngr.op_mutex);
	}

	return NDIS_STATUS_SUCCESS;
}

#ifdef DOT11_EHT_BE
static u8 *bss_mngr_get_mld_type_str(enum bmgr_mld_type mld_type)
{
	switch (mld_type) {
	case BMGR_MLD_TYPE_NONE:
		return "None";
	case BMGR_MLD_TYPE_SINGLE:
		return "Single";
	case BMGR_MLD_TYPE_MULTI:
		return "Multi";
	default:
		return "Unknown";
	}
}
#endif /* DOT11_EHT_BE */

static int bss_mngr_con_info_show(u8 type)
{
	struct bmgr_entry *entry = NULL;
	struct bmgr_reg_info *reg_info = NULL;
	u8 *str = NULL;
	int i;

	MTWF_PRINT("%s: type = %d\n\n", __func__, type);

	switch (type) {
	case BMGR_INFO_MLD_IDX_MAPPING:
#ifdef DOT11_EHT_BE
		mld_idx_mapping_dump();
		return NDIS_STATUS_SUCCESS;
#endif
	case BMGR_INFO:
	default:
		break;
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
		"\tbmg_entry ptr = %p, sizeof = %d\n",
		bss_mngr.entry, (u32)sizeof(bss_mngr.entry));

#ifdef DOT11_EHT_BE
	/* MLD */
	MTWF_PRINT("%s: MLO Device, (%d)\n", __func__, BMGR_MAX_MLD_GRP_CNT);

	for (i = 0; i < BMGR_MAX_MLD_GRP_CNT; i++) {
		int j;
#ifdef MLD_GROUP_ID_REMAPPING_V1
		struct bmgr_mlo_dev *mld = mld_idx_mapping_v1_load(i);
#else
		struct bmgr_mlo_dev *mld = GET_MLD_BY_GRP_IDX(i);
#endif

		if (mld) {
			if (!mld->valid)
				continue;

			MTWF_PRINT(" - MLD[%02d] (%s), bmgr_mlo_dev ptr = %p\n",
				mld->mld_grp,
				mld->valid ? "active" : "inactive", mld);

			MTWF_PRINT("\t\tMLD Addr:(%pM) Type:(%s) link_cnt:(%d), bmc_bss_idx(%d)\n",
				mld->mld_addr, bss_mngr_get_mld_type_str(mld->mld_type),
				mld->mld_link_cnt,
				mld->bmc_bss_idx);

			MTWF_PRINT("\t\tEMLSR:En(%d)/To(%d)/OMN(%d), TTLM:Supp(%d)",
				mld->attr.eml_caps.emlsr_supp, mld->attr.eml_caps.trans_to,
				mld->attr.eml_caps.eml_omn_en,
				mld->attr.mld_caps.t2l_nego_supp);

			MTWF_PRINT(", LinkReconfigOp:Sup(%d)\n",
				mld->attr.mld_caps.link_reconfig_op_sup);

			MTWF_PRINT("\t\tMedSync:Pres(%d)/Dur(%d)/OfdmThr(%d)/MaxTxop(%d)\n",
				mld->attr.med_sync.en,
				mld->attr.med_sync.dur,
				mld->attr.med_sync.ofdm_ed_thr,
				mld->attr.med_sync.max_txop);

			if (mld->reconf_ie.ie_status >= BUF_STAT_ALLOCED) {
				MTWF_PRINT("\t\tReconfig:Sts(%d)/Len:Cmm(%d)",
					mld->reconf_ie.ie_status,
					mld->reconf_ie.common_info.len);

				for (j = 0; j < BSS_MNGR_MAX_BAND_NUM; j++) {
					if (mld->reconf_ie.link_info[j].len)
						MTWF_PRINT(",Link%d(%d)", j, mld->reconf_ie.link_info[j].len);
				}

				MTWF_PRINT("\n");
			}

			/* TODO:
			MTWF_PRINT("\t\tMLD SSID:(%s)\n", mld->mld_ssid);
			*/

			for (j = 0; j < BSS_MNGR_MAX_BAND_NUM; j++) {
				u8 bss_idx_mld = mld->bss_idx_mld[j];

				if (BMGR_VALID_BSS_IDX(bss_idx_mld)) {
					MTWF_PRINT("\t\t- Link%d: [%02d]\n",
						j, bss_idx_mld);
				}
			}
		}
	}

#endif /* DOT11_EHT_BE */

	/* MLD AP(BSS) */
	MTWF_PRINT("\n%s: Entry, dev_cnt = %d\n", __func__, BSS_MNGR_ENTRY_CNT);

	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		entry = GET_BSS_ENTRY_BY_IDX(i);

		if (!entry)
			continue;

		reg_info = &entry->entry_info;
		MTWF_PRINT(" - [%02d] %s (%s), bmg_entry ptr = %p\n",
			entry->bss_idx,
			entry->valid ? RtmpOsGetNetDevName(entry->pNetDev) : "n/a",
			entry->valid ? "active" : "inactive", entry);

		MTWF_PRINT("\t\tNetDev:%p(%d), Type: %s\n",
			entry->pNetDev,
			entry->valid ? RtmpOsGetNetIfIndex(entry->pNetDev) : 0,
			(reg_info->dev_type < DEV_TYPE_UNDEF) ?
				dev_type_str[reg_info->dev_type] : "INVLD");

		if (!entry->valid)
			continue;

		MTWF_PRINT("\t\t11vMbssIdx:%d, MaxIndicator:%d, BcnInt:%d, fw_idx:%d\n",
			reg_info->dot11v_mbssid_idx,
			reg_info->max_bssid_indicator,
			reg_info->bcn_interval,
			reg_info->hw_bss_index);
		MTWF_PRINT("\t\tSSID:%s (%08x)\t(%pM)\n",
			reg_info->ssid,
			(u32)Crcbitbybitfast(reg_info->ssid, reg_info->ssid_len),
			reg_info->bssid);

		str = wmode_2_str(reg_info->phy_mode);
		if (str) {
			MTWF_PRINT("\t\tPhymode:%s (0x%x), Ch=%3d, OpClass=%d\n",
				str, reg_info->phy_mode, reg_info->channel, reg_info->op_class);
			os_free_mem(str);
		}

		MTWF_PRINT("\t\tAuthMode:%s, Cipher(P:%s/G:%s), MFPC=%d/MFPR=%d/RsnCap=%02x%02x, 6G-RNR:(%s)",
			GetAuthModeStr(reg_info->auth_mode),
			GetEncryModeStr(reg_info->PairwiseCipher),
			GetEncryModeStr(reg_info->GroupCipher),
			reg_info->MFPC, reg_info->MFPR, reg_info->RsnCap[0], reg_info->RsnCap[1],
			(reg_info->disc_param.rnr_6g_rule < RNR_REPORTING_INVLD) ?
				rnr_rule_str[reg_info->disc_param.rnr_6g_rule] : "INVLD");

		MTWF_PRINT(", IOB:T(%d)/Tu(%d)/M(%d)\n",
			reg_info->disc_param.iob_type,
			reg_info->disc_param.iob_interval,
			reg_info->disc_param.iob_mode);

		MTWF_PRINT("\t\t[MNGR] TxIdx:[%d], 11beMldIdx:%d, LinkIdx:%d\n",
			entry->bss_idx_tx,
			entry->dot11be_mld_id,
			entry->link_id);

#ifdef DOT11_EHT_BE
		if (entry->mlo_en) {
			MTWF_PRINT("\t\t[MNGR] MldGrp:%d, TidMap:0x%x->0x%x\n",
				reg_info->mld_grp,
				reg_info->tid_map, entry->tid_map);

			MTWF_PRINT("\t\t[MNGR] MLD enabled:\t(chg_cnt:%d)\n",
				entry->bss_chg_cnt);
		}
#endif
		if (entry->mbss.tx_bcn.len || entry->mbss.tx_probe.len || entry->mbss.tx_probe_cmm.len) {
			MTWF_PRINT("\t\t[MNGR] IE Len (MBSS-BCN/PRB/PRB-C) = (%d/%d/%d)\n",
				entry->mbss.tx_bcn.len,
				entry->mbss.tx_probe.len,
				entry->mbss.tx_probe_cmm.len);
		}

		if (entry->rnr.len || entry->mld_cmm.len || entry->tid2lnk.len ||
			entry->rnr_info.repting_rnr.len) {
			MTWF_PRINT(
				"\t\t[MNGR] IE Len (RNR-O/RNR-M/MLD-C/T2L) = (%d/%d/%d/%d)\n",
				entry->rnr_info.repting_rnr.len,
				entry->rnr.len,
				entry->mld_cmm.len,
				entry->tid2lnk.len);
		}

#ifdef DOT11_EHT_BE
		if (entry->mlo_en) {
			int j;

			MTWF_PRINT("\t\t[MNGR] ML Probe Rsp PF:");
			for (j = 0; j < BSS_MNGR_MAX_BAND_NUM; j++) {
				if (entry->ml_probe_rsp_per_sta_pf[j].len)
					MTWF_PRINT(" Link%d(%d)", j, entry->ml_probe_rsp_per_sta_pf[j].len);
			}
			MTWF_PRINT("\n");

			MTWF_PRINT("\t\t[MNGR] ML Beacon Appl PF:");
			for (j = 0; j < BSS_MNGR_MAX_BAND_NUM; j++) {
				if (entry->bcn_appl_elem_per_sta_pf[j].len)
					MTWF_PRINT(" Link%d(%d)", j, entry->bcn_appl_elem_per_sta_pf[j].len);
			}
			MTWF_PRINT("\n");
		}
#endif
		if (entry->rnr.buf && entry->rnr.len)
			hex_dump_with_cat_and_lvl("RNR:", entry->rnr.buf, entry->rnr.len,
				DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG);
		if (entry->mbss.tx_bcn.buf && entry->mbss.tx_bcn.len)
			hex_dump_with_cat_and_lvl("MBSS-BCN:", entry->mbss.tx_bcn.buf, entry->mbss.tx_bcn.len,
				DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG);
		if (entry->mbss.tx_probe.buf && entry->mbss.tx_probe.len)
			hex_dump_with_cat_and_lvl("MBSS-PRB:", entry->mbss.tx_probe.buf, entry->mbss.tx_probe.len,
				DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG);
		if (entry->mbss.tx_probe_cmm.buf && entry->mbss.tx_probe_cmm.len)
			hex_dump_with_cat_and_lvl("MBSS-PRB-C:", entry->mbss.tx_probe_cmm.buf, entry->mbss.tx_probe_cmm.len,
				DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG);
		if (entry->mld_cmm.buf && entry->mld_cmm.len)
			hex_dump_with_cat_and_lvl("MLD-C:", entry->mld_cmm.buf, entry->mld_cmm.len,
				DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG);
		if (entry->tid2lnk.buf && entry->tid2lnk.len)
			hex_dump_with_cat_and_lvl("TID2LNK:", entry->tid2lnk.buf, entry->tid2lnk.len,
				DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG);
	}

#ifdef DOT11_EHT_BE
	/* MLD STA */
	MTWF_PRINT("\n\n");
	for (i = 0; BMGR_VALID_MLD_STA(i); i++) {
		struct bmgr_mld_sta *mld_sta = GET_MLD_STA_BY_IDX(i);
		struct bmgr_mld_link *mld_link;

		if (mld_sta->valid) {
			int j;

			MTWF_PRINT("MLD_STA(%d):\n", i);
			MTWF_PRINT("\tAssocToBSS[%02d] in MLD[%02d]: MldAddr(%pM), AID(%d)",
				mld_sta->bss_idx_setup,
				mld_sta->mld_grp_idx,
				mld_sta->mld_addr, mld_sta->aid);
			MTWF_PRINT(" DataLink(%d)\n",
				mld_sta->data_link_id);
			MTWF_PRINT("\t\t\tEMLCaps(0x%x), EMLSR_EN(%d), EMLSR_BMAP(0x%x)\n",
				mld_sta->eml_caps, mld_sta->emlsr_en, mld_sta->emlsr_link_bmap);
			MTWF_PRINT("\t\t\tMLDCaps(0x%x), LR_CAP(%d)\n",
				mld_sta->mld_caps, mld_sta->link_reconfig_cap);
			for (j = 0; j < BSS_MNGR_MAX_BAND_NUM; j++) {
				mld_link = &mld_sta->mld_link[j];
				if (mld_link->active) {
					MTWF_PRINT(
						"\t\tL(%d): Addr(%pM), STRBmap(0x%x), priv(%p)\n",
						j, mld_link->link_addr, mld_link->str_bmap,
						mld_link->priv_ptr);
				}

				if (mld_link->priv_temp_ptr) {
					MTWF_PRINT("\t\t\t%d_priv_temp(%p)",
						j, mld_link->priv_temp_ptr);
				}
			}
		}
	}
#endif

	return NDIS_STATUS_SUCCESS;
}

#ifdef DOT11V_MBSSID_SUPPORT
int bss_mngr_con_query_mbss_ie(
	IN struct wifi_dev *wdev,
	struct mbss_query_info *mbss_info
)
{
	int ret = NDIS_STATUS_FAILURE;
	struct bmgr_entry *entry = NULL;
	struct mbss_info *mbss = NULL;
	bool is_non_tx_ml_probe = FALSE;
#ifdef DOT11_EHT_BE
	struct ml_ie_info *ml_info = NULL;
#endif /* DOT11_EHT_BE */

	if (!wdev)
		return NDIS_STATUS_FAILURE;
	entry = get_bss_entry_by_wdev(wdev);
	if (entry)
		mbss = &entry->mbss;
#ifdef DOT11_EHT_BE
	if (mbss_info->ml_ie) {
		os_alloc_mem(NULL, (UCHAR **)&ml_info, sizeof(struct ml_ie_info));
		if (!ml_info) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"failed to allocate memory for parsing ML IE\n");
			ret = NDIS_STATUS_FAILURE;
			goto end;
		}
		NdisZeroMemory(ml_info, sizeof(struct ml_ie_info));
		if (parse_multi_link_ie(mbss_info->ml_ie, NULL, ml_info) < 0) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"failed to parse ML IE\n");
			ret = NDIS_STATUS_FAILURE;
			goto end;
		}

		if ((ml_info->type == ML_CTRL_TYPE_PROBE_REQ)
			&& (ml_info->pres_bmap & DOT11BE_ML_PROBE_REQ_PRESENCE_MLD_ID)
			&& (ml_info->mld_id != 0)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
				"ML Probe Req to non-tx BSS w/ MLD_ID %d\n", ml_info->mld_id);
			is_non_tx_ml_probe = TRUE;
		}
	}
#endif

	if (mbss_info->is_probe_rsp) {
		/* mbssie for probe rsp */
		u8 non_tx_entry_idx;
		u8 mbssid_idx;
		u16 mbssie_offset;
		u16 mbssie_len;
		/* ML probe request to a non-tx bss, which affiliated with a mld,
		 * the related mbssid ie can not contain ml ie */
		if (is_non_tx_ml_probe) {
			if (entry && entry->mbss.tx_probe.buf) {
				/* mbss ie w/o ml ie */
				u8 mbssie_num = mbss->tx_probe_mbssie.mbssie_num;

				for (non_tx_entry_idx = 0; non_tx_entry_idx < mbssie_num; non_tx_entry_idx++) {
					mbssid_idx = mbss->tx_probe_mbssie.mbssid_idx[non_tx_entry_idx];
					mbssie_offset = mbss->tx_probe_mbssie.mbssie_offset[non_tx_entry_idx];
					mbssie_len = mbss->tx_probe_mbssie.mbssie_len[non_tx_entry_idx];
					if (mbss_info->query_bitmap & BIT(mbssid_idx)) {
						NdisMoveMemory(mbss_info->f_buf + mbss_info->f_len,
							mbss->tx_probe.buf + mbssie_offset, mbssie_len);
						mbss_info->f_len += mbssie_len;
					}
				}
				ret = NDIS_STATUS_SUCCESS;
			}
		} else {
			if (entry && entry->mbss.tx_probe_cmm.buf) {
				/* mbss ie w/ ml ie common part */
				u8 mbssie_num = mbss->tx_probe_cmm_mbssie.mbssie_num;

				for (non_tx_entry_idx = 0; non_tx_entry_idx < mbssie_num; non_tx_entry_idx++) {
					mbssid_idx = mbss->tx_probe_cmm_mbssie.mbssid_idx[non_tx_entry_idx];
					mbssie_offset = mbss->tx_probe_cmm_mbssie.mbssie_offset[non_tx_entry_idx];
					mbssie_len = mbss->tx_probe_cmm_mbssie.mbssie_len[non_tx_entry_idx];
					if (mbss_info->query_bitmap & BIT(mbssid_idx)) {
						NdisMoveMemory(mbss_info->f_buf + mbss_info->f_len,
							mbss->tx_probe_cmm.buf + mbssie_offset, mbssie_len);
						mbss_info->f_len += mbssie_len;
					}
				}
				ret = NDIS_STATUS_SUCCESS;
			}
		}
	} else {
		if (entry && mbss->tx_bcn.buf) {
			/* mbssie for beacon */
			NdisMoveMemory(mbss_info->f_buf, mbss->tx_bcn.buf, mbss->tx_bcn.len);
			mbss_info->f_len = mbss->tx_bcn.len;
			/* tim ie offset */
			NdisMoveMemory(mbss_info->tim_ie_offset, mbss->bcn_tim_offset,
				sizeof(mbss->bcn_tim_offset));
#ifdef DOT11_EHT_BE
			/* mlt ie offset */
			NdisMoveMemory(mbss_info->mlt_ie_offset, mbss->bcn_mlt_offset,
				sizeof(mbss->bcn_mlt_offset));
			/* at2lm ie offset */
			NdisMoveMemory(mbss_info->at2lm_ie_offset, mbss->bcn_at2lm_offset,
				sizeof(mbss->bcn_at2lm_offset));
#endif /* DOT11_EHT_BE */
			/* cap info offset */
			NdisMoveMemory(mbss_info->cap_info_offset, mbss->bcn_cap_info_offset,
				sizeof(mbss->bcn_cap_info_offset));
			ret = NDIS_STATUS_SUCCESS;
		}
	}

#ifdef DOT11_EHT_BE
end:
	if (ml_info)
		os_free_mem(ml_info);
#endif /* DOT11_EHT_BE */

	return ret;
}
#endif

int bss_mngr_con_query_rnr_ie(
	IN struct wifi_dev *wdev,
	OUT u8 *f_buf,
	OUT u16 *f_len
)
{
	int ret = NDIS_STATUS_FAILURE;
	u16 ie_len = 0;
	struct bmgr_entry *entry = NULL;
	struct rnr_nap_info *rnr_nap = NULL;
	struct _EID_STRUCT *eid = NULL;
	u8 *pos = f_buf;
	u8 band_idx, tbtt_idx;
	u8 need_rnr_h, need_nap_h;
	u16 all_rnr_len = 0;
	u8 cur_nap_h_tbtt_cnt = 0;
	struct neighbor_ap_info *cur_nap_h = NULL;

	if (wdev)
		entry = get_bss_entry_by_wdev(wdev);
	if (entry) {
		if ((entry->rnr.len || entry->rnr_info.repting_rnr.len) &&
			entry->entry_info.single_rnr) {

			for (band_idx = 0; band_idx < MAX_BAND_NUM; band_idx++) {
				rnr_nap = &entry->rnr_nap[band_idx];

				if (!rnr_nap->tbtt_cnt)
					continue;

				/*switch band, add new nap*/
				need_nap_h = TRUE;

				for (tbtt_idx = 0; tbtt_idx < 16; tbtt_idx++) {

					if (!IS_TBTT_BITMAP_SET(rnr_nap->tbtt_bitmap, tbtt_idx))
						continue;

					/*start a new frame or rnr ie len is too big*/
					if (!ie_len ||
						(ie_len + sizeof(struct neighbor_ap_info) + rnr_nap->tbtt[tbtt_idx].len > 255)) {
						need_rnr_h = TRUE;
						need_nap_h = TRUE;

						/*finish last rnr ie, and cnt the new*/
						if (ie_len && eid) {
							eid->Len = ie_len;
							all_rnr_len += (ie_len + 2);
							ie_len = 0;
						}
					}

					/*add rnr header*/
					if (need_rnr_h) {
						eid = (struct _EID_STRUCT *)pos;
						eid->Eid = EID_REDUCED_NEIGHBOR_REPORT;
						pos = &eid->Octet[0];
						need_rnr_h = FALSE;
					}

					/*case 1: different nap header format in the same band*/
					/*case 2: different nap header format among different band*/
					if (cur_nap_h && memcmp(cur_nap_h, &rnr_nap->head[tbtt_idx], sizeof(struct neighbor_ap_info)))
						need_nap_h = TRUE;

					/*add tbtt info*/
					if (need_nap_h) {
						NdisMoveMemory(pos, (u8 *)&rnr_nap->head[tbtt_idx], sizeof(struct neighbor_ap_info));

						/*sync nap_h tbtt cnt */
						if (cur_nap_h) {
							SET_DOT11_RNR_TBTT_INFO_HDR_TBTTINFO_CNT(cur_nap_h->tbtt_info_hdr,
								(cur_nap_h_tbtt_cnt - 1));
							cur_nap_h_tbtt_cnt = 0;
						}
						cur_nap_h = (struct neighbor_ap_info *)pos;

						pos += sizeof(struct neighbor_ap_info);
						ie_len += sizeof(struct neighbor_ap_info);
						need_nap_h = FALSE;
					}

					/*add tbtt*/
					NdisMoveMemory(pos, rnr_nap->tbtt[tbtt_idx].buf, rnr_nap->tbtt[tbtt_idx].len);
					pos += rnr_nap->tbtt[tbtt_idx].len;
					ie_len += rnr_nap->tbtt[tbtt_idx].len;
					cur_nap_h_tbtt_cnt++;
				}
			}

			/*sync last nap_h tbtt cnt */
			if (cur_nap_h && cur_nap_h_tbtt_cnt)
				SET_DOT11_RNR_TBTT_INFO_HDR_TBTTINFO_CNT(cur_nap_h->tbtt_info_hdr,
					(cur_nap_h_tbtt_cnt - 1));

			if (eid && ie_len) {
				eid->Len = ie_len;
				all_rnr_len += (ie_len + 2);
				*f_len = all_rnr_len;
			} else
				*f_len = 0;
		} else {
			/* RNR from MLD */
			if (entry->rnr.buf) {
				NdisMoveMemory(f_buf, entry->rnr.buf, entry->rnr.len);
				ie_len += entry->rnr.len;
				f_buf += entry->rnr.len;
			}

			/* RNR from OOB 6G */
			if (entry->rnr_info.repting_rnr.buf) {
				struct ie *repting_rnr = &entry->rnr_info.repting_rnr;

				NdisMoveMemory(f_buf, repting_rnr->buf, repting_rnr->len);
				ie_len += repting_rnr->len;
			}

			*f_len = ie_len;
		}

		ret = NDIS_STATUS_SUCCESS;
	}

	return ret;
}

bool bss_mngr_con_query_is_repted_ssid(
	IN struct wifi_dev *wdev,
	IN u32 short_ssid,
	IN u8 *ssid,
	IN u8 ssid_len)
{
	struct bmgr_entry *entry = NULL;
	struct bmgr_entry *repted_entry = NULL;
	struct bmgr_reg_info *reg_info = NULL;
	struct repting_rnr_info *rept = NULL;
	bool ret = FALSE;
	u8 i, repted_bss_idx;
	u32 repted_short_ssid;

	if (wdev)
		entry = get_bss_entry_by_wdev(wdev);
	if (!BMGR_VALID_BSS_ENTRY(entry))
		return FALSE;

	rept = &entry->rnr_info;

	if (rept->repting_cnt) {
		for (i = 0; i < rept->repting_cnt; i++) {
			repted_bss_idx = rept->repting_bss_idx[i];
			repted_entry = GET_BSS_ENTRY_BY_IDX(repted_bss_idx);

			if (!BMGR_VALID_BSS_ENTRY(repted_entry))
				continue;

			reg_info = &repted_entry->entry_info;
			repted_short_ssid = Crcbitbybitfast(reg_info->ssid, reg_info->ssid_len);

			/* check SSID and short SSID */
			if ((short_ssid == repted_short_ssid) ||
				((ssid_len == reg_info->ssid_len) &&
				NdisEqualMemory(ssid, reg_info->ssid, (ULONG)ssid_len))) {
				ret = TRUE;
				break;
			}
		}
	}

	return ret;
}

bool bss_mngr_con_query_is_mld_enabled(
	struct wifi_dev *wdev)
{
	struct bmgr_entry *entry = NULL;

	if (wdev)
		entry = get_bss_entry_by_wdev(wdev);
	return BMGR_VALID_MLO_BSS_ENTRY(entry);
}

bool bss_mngr_con_query_is_in_mlo_csa(
	struct wifi_dev *wdev)
{
	u8 i;
	struct bmgr_entry *entry = NULL;
	struct bmgr_entry *iob_entry;
	struct wifi_dev *iob_wdev = NULL;
	struct DOT11_H *pDot11h = NULL;

	if (wdev)
		entry = get_bss_entry_by_wdev(wdev);
	if (!BMGR_VALID_BSS_ENTRY(entry)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: entry is NULL or invalid!\n");
		return FALSE;
	}

	/* skip the AP not affiliated in any AP MLD */
	if (!BMGR_VALID_MLO_BSS_ENTRY(entry)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"[%d(%s)] not affiliated in any AP MLD\n",
			entry->bss_idx, entry->pNetDev->name);
		return FALSE;
	}

	/* traverse all iob BSS and check csa bitmap */
	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		iob_entry = GET_BSS_ENTRY_BY_IDX(i);
		if (!BMGR_VALID_MLO_BSS_ENTRY(iob_entry))
			continue;

		iob_wdev = mt_os_net_dev_get_wdev(iob_entry->pNetDev);
		if (iob_wdev && iob_wdev->pDot11_H) {
			pDot11h = iob_wdev->pDot11_H;
			if (pDot11h->csa_ap_bitmap != 0) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"hw_bss(%d) in mlo_csa!\n", iob_entry->entry_info.hw_bss_index);
				return TRUE;
			}
		}
	}

	return FALSE;
}

int bss_mngr_con_query_netdev_by_band(
	struct query_band_netdev *query_info
)
{
	u8 i;
	struct bmgr_entry *entry = NULL;

	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		entry = GET_BSS_ENTRY_BY_IDX(i);

		if (!BMGR_VALID_BSS_ENTRY(entry))
			continue;

		if (query_info->band == BAND_24G) {
			/* 2.4G */
			if (!WMODE_CAP_6G(entry->entry_info.phy_mode) && (entry->entry_info.channel <= 14)) {
				query_info->pNetDev = entry->pNetDev;
				return NDIS_STATUS_SUCCESS;
			}
		} else if (query_info->band == BAND_5G) {
			/* 5G */
			if (!WMODE_CAP_6G(entry->entry_info.phy_mode) && (entry->entry_info.channel > 14)) {
				query_info->pNetDev = entry->pNetDev;
				return NDIS_STATUS_SUCCESS;
			}
		} else {
			/* 6G */
			if (WMODE_CAP_6G(entry->entry_info.phy_mode)) {
				query_info->pNetDev = entry->pNetDev;
				return NDIS_STATUS_SUCCESS;
			}
		}
	}

	query_info->pNetDev = NULL;
	return NDIS_STATUS_FAILURE;
}

#ifdef DOT11_EHT_BE
int bss_mngr_con_mld_query_netdev_by_link(
	struct query_group_link_netdev *query_info
)
{
	u8 bss_idx;
	struct bmgr_entry *entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;

#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(query_info->group_id);
#else
	if (!BMGR_VALID_MLD_GRP_IDX(query_info->group_id))
		return NDIS_STATUS_FAILURE;

	if (query_info->link_id >= BSS_MNGR_MAX_BAND_NUM)
		return NDIS_STATUS_FAILURE;

	mld = GET_MLD_BY_GRP_IDX(query_info->group_id);
#endif
	if (!BMGR_VALID_MLO_DEV(mld))
		return NDIS_STATUS_FAILURE;

	bss_idx = mld->bss_idx_mld[query_info->link_id];

	if (!BMGR_VALID_BSS_IDX(bss_idx))
		return NDIS_STATUS_FAILURE;

	entry = GET_BSS_ENTRY_BY_IDX(bss_idx);

	if (entry->pNetDev == NULL)
		return NDIS_STATUS_FAILURE;

	query_info->pNetDev = entry->pNetDev;

	return NDIS_STATUS_SUCCESS;
}
#endif

static struct bmgr_entry *bss_mngr_con_bss_lookup(
	u8 *link_addr
)
{
	u8 i;
	struct bmgr_entry *entry;

	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		entry = GET_BSS_ENTRY_BY_IDX(i);
		if (BMGR_VALID_BSS_ENTRY(entry) && MAC_ADDR_EQUAL(entry->entry_info.bssid, link_addr)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"BSS Found: %s bss_idx(%d)\n",
				RtmpOsGetNetDevName(entry->pNetDev), entry->bss_idx);
			return entry;
		}
	}
	return NULL;
}

#ifdef DOT11_EHT_BE
static struct bmgr_mlo_dev *bss_mngr_con_mld_lookup(
	u8 *mld_addr
)
{
	u8 i;
	struct bmgr_mlo_dev *mld;

	for (i = 0; i < BMGR_MAX_MLD_GRP_CNT; i++) {
#ifdef MLD_GROUP_ID_REMAPPING_V1
		mld = mld_idx_mapping_v1_load(i);
#else
		mld = GET_MLD_BY_GRP_IDX(i);
#endif
		if (BMGR_VALID_MLO_DEV(mld) && MAC_ADDR_EQUAL(mld->mld_addr, mld_addr)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"MLD Found: grp(%d) (%pM)\n", mld->mld_grp, mld->mld_addr);
			return mld;
		}
	}
	return NULL;
}

static int bss_mngr_con_mld_conn_query(
	INOUT struct query_mld_conn *mld_conn
)
{
	u8 mld_grp_idx = mld_conn->mld_group_idx;
	struct bmgr_mlo_dev *mld = NULL;
	struct bmgr_mld_sta *mld_sta;
	struct query_mld_sta *mld_sta_info;
	int i;

#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(mld_grp_idx);
#else
	if (BMGR_VALID_MLD_GRP_IDX(mld_grp_idx))
		mld = GET_MLD_BY_GRP_IDX(mld_grp_idx);
#endif

	if (!BMGR_VALID_MLO_DEV(mld))
		return NDIS_STATUS_INVALID_DATA;

	mld_conn->mld_sta_num = 0;
	mld_sta_info = (struct query_mld_sta *)mld_conn->mld_sta_info;
	for (i = 0; BMGR_VALID_MLD_STA(i); i++) {
		mld_sta = GET_MLD_STA_BY_IDX(i);

		if (mld_sta->valid && (mld_sta->mld_grp_idx == mld_grp_idx)) {
			mld_sta_info->mld_sta_idx = mld_sta->idx;
			mld_sta_info->aid = mld_sta->aid;
			COPY_MAC_ADDR(mld_sta_info->mld_addr, mld_sta->mld_addr);

			mld_conn->mld_sta_num++;
			mld_sta_info++;
		}
	}

	return NDIS_STATUS_SUCCESS;
}

static u8 get_bss_idx_by_requested_dot11be_mld_id(
	IN struct bmgr_entry *entry,
	IN u8 dot11be_mld_id
)
{
	u8 bss_idx;
	struct bmgr_entry *requested_entry;

	for (bss_idx = 0; bss_idx < BSS_MNGR_ENTRY_CNT; bss_idx++) {
		requested_entry = GET_BSS_ENTRY_BY_IDX(bss_idx);
		if (BMGR_VALID_MLO_BSS_ENTRY(requested_entry) &&
			(requested_entry->link_id == entry->link_id) &&
			(requested_entry->bss_idx_tx == entry->bss_idx_tx) &&
			(requested_entry->dot11be_mld_id == dot11be_mld_id))
			return bss_idx;
	}

	/* not found mld_id */
	return BMGR_INVALID_BSS_IDX;
}

int bss_mngr_con_query_mld_info(
	IN struct wifi_dev *wdev,
	OUT struct query_mld_info *mld_query
)
{
	int ret = NDIS_STATUS_FAILURE;
	struct bmgr_entry *entry = NULL;
	u8 query_type = mld_query->query_type, bss_idx, link_id;
	struct bmgr_mlo_dev *mld = NULL;
	struct ml_ie_info *ml_info = NULL;
	struct bmgr_mld_sta *bmgr_sta;
	u16 mld_sta_idx, ie_len = 0;
	u8 *f_buf = NULL, *pos = NULL;
	struct _EID_STRUCT *eid = NULL;
	bool is_ml_probe = FALSE, is_probe_mld_id = FALSE;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG, "query_type=%d\n", query_type);

	switch (query_type) {
	case BMGR_QUERY_MLD:
		mld = bss_mngr_con_mld_lookup(mld_query->mld_basic->addr);
		if (mld) {
			mld_query->mld_basic->mld_grp_idx = mld->mld_grp;
			mld_query->mld_basic->mld_type = mld->mld_type;
			mld_query->mld_basic->link_cnt = mld->mld_link_cnt;
			ret = NDIS_STATUS_SUCCESS;
		}
		return ret;
	case BMGR_QUERY_BSSID_ML_INFO:
		if (MAC_ADDR_EQUAL(mld_query->basic->bssid, ZERO_MAC_ADDR))
			goto end;

		entry = bss_mngr_con_bss_lookup(mld_query->basic->bssid);
		if (BMGR_VALID_MLO_BSS_ENTRY(entry)) {
			mld = entry->mld_ptr;
			if (BMGR_VALID_MLO_DEV(mld)) {
				mld_query->basic->mld_grp_idx = mld->mld_grp;
				mld_query->basic->mld_type = mld->mld_type;
				mld_query->basic->link_cnt = mld->mld_link_cnt;
				mld_query->basic->link_id = entry->link_id;
				COPY_MAC_ADDR(mld_query->basic->addr, mld->mld_addr);
				ret = NDIS_STATUS_SUCCESS;
			}
		}
		return ret;
	case BMGR_QUERY_MLD_CONN:
		ret = bss_mngr_con_mld_conn_query(mld_query->mld_conn);
		return ret;
	default:
		break;
	}

	if (wdev)
		entry = get_bss_entry_by_wdev(wdev);
	if (entry == NULL)
		goto end;

	switch (query_type) {
	case BMGR_QUERY_ML_AP_BASIC:
		mld = entry->mld_ptr;
		if (BMGR_VALID_MLO_DEV(mld)) {
			mld_query->basic->mld_grp_idx = mld->mld_grp;
			mld_query->basic->mld_type = mld->mld_type;
			mld_query->basic->link_cnt = mld->mld_link_cnt;
			mld_query->basic->link_id = entry->link_id;
			COPY_MAC_ADDR(mld_query->basic->addr, mld->mld_addr);
			bss_idx = mld->bmc_bss_idx;
			if (BMGR_VALID_BSS_IDX(bss_idx)) {
				entry = GET_BSS_ENTRY_BY_IDX(bss_idx);
				if (entry)
					mld_query->basic->agent_bss_wdev = entry->pwdev;
			}
			ret = NDIS_STATUS_SUCCESS;
		}
		break;

	case BMGR_QUERY_ML_IE_BCN:			/* mld common info */
		mld_query->ie.f_len = 0;
		if (entry && entry->mld_cmm.buf) {
			NdisMoveMemory(mld_query->ie.f_buf, entry->mld_cmm.buf, entry->mld_cmm.len);
			mld_query->ie.f_len = entry->mld_cmm.len;
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
					"\tMLIE-C: len=%d, f_buf=%p\n", mld_query->ie.f_len, mld_query->ie.f_buf);
		}

		eid = (struct _EID_STRUCT *)mld_query->ie.f_buf;

		f_buf = pos = mld_query->ie.f_buf + mld_query->ie.f_len;
		pos = build_multi_link_appl_elem_per_sta_pf(entry, query_type, f_buf);

		for (link_id = 0; link_id < BSS_MNGR_MAX_BAND_NUM; link_id++) {
			if (entry->csa.repting_csa_offset_in_per_sta_pf[link_id] != 0) {
				mld_query->ie.csa_ie.csa_offset_in_ml_ie[link_id] =
					entry->csa.repting_csa_offset_in_per_sta_pf[link_id] + mld_query->ie.f_len;
				mld_query->ie.csa_ie.csa_bss_idx[link_id] = entry->csa.repting_csa_bss_idx[link_id];
			}

			if (mld_query->ie.csa_ie.csa_offset_in_ml_ie[link_id] != 0)
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
					"\tlink_id=%d, reported link_id=%d, csa_offset_in_per_sta=%d, csa_offset_in_ml=%d\n",
					entry->link_id, link_id, entry->csa.repting_csa_offset_in_per_sta_pf[link_id],
					mld_query->ie.csa_ie.csa_offset_in_ml_ie[link_id]);
		}

		ie_len = pos - f_buf;
		mld_query->ie.f_len += ie_len;

		if (mld_query->ie.f_len > (2 + MAX_LEN_OF_IE_DATA)) {
			/* do IE fragmentation */
			struct bss_mngr_event_ops *event_ops = NULL;

			event_ops = entry->entry_info.event_ops;
			if (event_ops)
				event_ops->bmgr_event_ie_fragment((u8 *)eid, &mld_query->ie.f_len);
			else
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Error: event_ops is not inited, can't frag the ML IE!");
		} else {
			/* length after append Per-STA Profile */
			eid->Len += ie_len;
		}

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_INFO,
				"\tMLIE: len=%d, f_buf=%p\n", mld_query->ie.f_len, mld_query->ie.f_buf);

		ret = NDIS_STATUS_SUCCESS;

	break;

	case BMGR_QUERY_ML_IE_AUTH_RSP:
		mld_query->ie.f_len = 0;
		if (bss_idx_mld_inited(entry)) {
			f_buf = pos = mld_query->ie.f_buf;
			pos = build_multi_link_ie(entry, f_buf,
				BMGR_MLD_AUTH_COMMON, BMGR_MAX_MLD_STA_CNT);
			ie_len = pos - f_buf;
			mld_query->ie.f_len = ie_len;
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
					"\tMLIE-C: len=%d, f_buf=%p\n", mld_query->ie.f_len, mld_query->ie.f_buf);
			ret = NDIS_STATUS_SUCCESS;
		}
		break;

	case BMGR_QUERY_ML_IE_PROBE_RSP:	/* TBD: parse requested info */
		mld_query->ie.f_len = 0;
		if (!bss_idx_mld_inited(entry))
			break;

		if (mld_query->ie.ml_ie) {
			os_alloc_mem(NULL, (UCHAR **)&ml_info, sizeof(struct ml_ie_info));
			if (!ml_info) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"failed to allocate memory for parsing ML IE\n");
				ret = NDIS_STATUS_FAILURE;
				goto end;
			}
			NdisZeroMemory(ml_info, sizeof(struct ml_ie_info));
			if (parse_multi_link_ie(mld_query->ie.ml_ie, mld_query->ie.ml_frag_info, ml_info) < 0) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"failed to parse ML IE\n");
				ret = NDIS_STATUS_FAILURE;
				goto end;
			}
			if (ml_info->type == ML_CTRL_TYPE_PROBE_REQ) {
				is_ml_probe = TRUE;

				if ((ml_info->pres_bmap & DOT11BE_ML_PROBE_REQ_PRESENCE_MLD_ID)
					&& (ml_info->mld_id != 0)) {

					bss_idx = get_bss_idx_by_requested_dot11be_mld_id(entry, ml_info->mld_id);

					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
						"ML Probe Req to non-tx BSS %d w/ MLD_ID %d\n",
						bss_idx, ml_info->mld_id);

					if (!BMGR_VALID_BSS_IDX(bss_idx)) {
						MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
							"\tUnknown mld_id: %u\n", ml_info->mld_id);
						// break;
					} else {
						entry = GET_BSS_ENTRY_BY_IDX(bss_idx);
						is_probe_mld_id = TRUE;
					}
				}
			}
		}
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
				"\tis_ml_probe=%d, is_probe_mld_id=%d\n",
				is_ml_probe, is_probe_mld_id);

		eid = (struct _EID_STRUCT *)mld_query->ie.f_buf;
		NdisMoveMemory(mld_query->ie.f_buf, entry->mld_cmm.buf, entry->mld_cmm.len);
		mld_query->ie.f_len = entry->mld_cmm.len;

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
				"\tMLIE: len=%d, f_buf=%p\n", mld_query->ie.f_len, mld_query->ie.f_buf);

		f_buf = pos = mld_query->ie.f_buf + mld_query->ie.f_len;
		if (is_ml_probe)
			pos = build_multi_link_probe_rsp_complete_per_sta_pf(entry, ml_info, f_buf);
		else
			pos = build_multi_link_appl_elem_per_sta_pf(entry, query_type, f_buf);

		ie_len = pos - f_buf;
		mld_query->ie.f_len += ie_len;

		if (mld_query->ie.f_len > (2 + MAX_LEN_OF_IE_DATA)) {
			/* do IE fragmentation */
			struct bss_mngr_event_ops *event_ops = NULL;

			event_ops = entry->entry_info.event_ops;
			if (event_ops)
				event_ops->bmgr_event_ie_fragment((u8 *)eid, &mld_query->ie.f_len);
			else
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Error: event_ops is not inited, can't frag the ML IE!");
		} else {
			/* length after append Per-STA Profile */
			eid->Len += ie_len;
		}

		/* append another ML IE of MLD which transmitted BSSID is affiliated with
		 * when ML Probe Request with MLD_ID subfield is targeted to non-tx BSSID
		 */
		if (is_probe_mld_id) {
			struct bmgr_entry *tx_entry;

			bss_idx = entry->bss_idx_tx;

			if (!BMGR_VALID_BSS_IDX(bss_idx)) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"\tInvalid bss_idx_tx: %u\n", bss_idx);
			} else {
				tx_entry = GET_BSS_ENTRY_BY_IDX(bss_idx);

				pos = mld_query->ie.f_buf + mld_query->ie.f_len;
				NdisMoveMemory(pos, tx_entry->mld_cmm.buf, tx_entry->mld_cmm.len);
				mld_query->ie.f_len += tx_entry->mld_cmm.len;
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
					"Append second ML IE (bss_idx=%d, len=%d)\n",
					bss_idx, tx_entry->mld_cmm.len);
			}
		}

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_DEBUG,
				"\tMLIE: len=%d, f_buf=%p\n", mld_query->ie.f_len, mld_query->ie.f_buf);

		ret = NDIS_STATUS_SUCCESS;
		break;

	case BMGR_QUERY_ML_IE_ASSOC_RSP:	/* TBD: parse requested info */
		mld_query->ie.f_len = 0;
		/* the STA Profiles for peer are buffered in bmgr_sta[mld_sta_idx] */
		mld_sta_idx = mld_query->ie.mld_sta_idx;
		if (bss_idx_mld_inited(entry)) {
			f_buf = pos = mld_query->ie.f_buf;
			pos = build_multi_link_ie(entry, f_buf,
				BMGR_MLD_ASSOC_RSP_COMPLETE_PROFILE, mld_sta_idx);
			ie_len = pos - f_buf;
			mld_query->ie.f_len = ie_len;

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_INFO,
					"\tMLIE: len=%d, f_buf=%p\n", mld_query->ie.f_len, mld_query->ie.f_buf);
			ret = NDIS_STATUS_SUCCESS;
		}
		break;

	case BMGR_QUERY_ML_IE_LINK_RECONFIG_RSP:
		mld_query->ie.f_len = 0;
		/* the STA Profiles for peer are buffered in bmgr_sta[mld_sta_idx] */
		mld_sta_idx = mld_query->ie.mld_sta_idx;
		if (bss_idx_mld_inited(entry)) {
			f_buf = pos = mld_query->ie.f_buf;
			pos = build_multi_link_ie(entry, f_buf,
				BMGR_MLD_LINK_RECONFIG_RSP_COMPLETE_PROFILE, mld_sta_idx);
			ie_len = pos - f_buf;
			mld_query->ie.f_len = ie_len;

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_INFO,
				"MLIE: len=%d, f_buf=%p\n", mld_query->ie.f_len, mld_query->ie.f_buf);
			ret = NDIS_STATUS_SUCCESS;
		}
		break;

	case BMGR_QUERY_ML_STA:
		mld_sta_idx = mld_query->sta->mld_sta_idx;
		if (BMGR_VALID_MLD_STA(mld_sta_idx)) {
			bmgr_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);
			if (bmgr_sta && bmgr_sta->valid) {
				mld_query->sta->aid = bmgr_sta->aid;
				COPY_MAC_ADDR(mld_query->sta->mld_addr, bmgr_sta->mld_addr);
				ret = NDIS_STATUS_SUCCESS;
			}
		}
		break;

	case BMGR_QUERY_ML_PARSING_IE:
		if (mld_query->parse_ie.ml_ie && mld_query->parse_ie.ml_info) {
			if (parse_multi_link_ie(
				mld_query->parse_ie.ml_ie,
				mld_query->parse_ie.ml_frag_info,
				mld_query->parse_ie.ml_info) < 0) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"failed to parse ML IE\n");
					ret = NDIS_STATUS_FAILURE;
					goto end;
			}
			ret = NDIS_STATUS_SUCCESS;
		}
		break;

	default:
		ret = NDIS_STATUS_INVALID_DATA;
	}

end:
	if (ml_info)
		os_free_mem(ml_info);

	return ret;
}

int bss_mngr_con_query_tid_to_link_map_ie(
	IN struct wifi_dev *wdev,
	OUT u8 *f_buf,
	OUT u16 *f_len
)
{
	int ret = NDIS_STATUS_FAILURE;
	struct bmgr_entry *entry = NULL;

	if (wdev)
		entry = get_bss_entry_by_wdev(wdev);
	if (entry && entry->tid2lnk.buf) {
		NdisMoveMemory(f_buf, entry->tid2lnk.buf, entry->tid2lnk.len);
		*f_len = entry->tid2lnk.len;
		ret = NDIS_STATUS_SUCCESS;
	}

	return ret;
}

int bss_mngr_con_query_multi_link_traffic_ie(
	IN struct wifi_dev *wdev,
	OUT u8 *f_buf,
	OUT u16 *f_len
)
{
	struct bmgr_entry *entry = NULL;
	struct _EID_STRUCT *eid = (struct _EID_STRUCT *)f_buf;
	u8 *pos = f_buf;
	u8 ie_len = 0;

	if (!wdev)
		goto err;

	entry = get_bss_entry_by_wdev(wdev);
	if (!entry)
		goto err;

	if (entry->mlo_en) {
		eid->Eid = IE_WLAN_EXTENSION;
		eid->Octet[0] = EID_EXT_EHT_ML_TRAFFIC;
		pos += sizeof(struct _EID_STRUCT);

		/* control */
		*(pos) = 0x00;
		*(pos + 1) = 0x00;
		pos += 2;

		/* eid_length */
		ie_len = pos - (u8 *)eid;
		if (ie_len != 0)
			eid->Len = (ie_len - 2);

		*f_len = pos - f_buf;
	} else
		*f_len = 0;

	return NDIS_STATUS_SUCCESS;
err:
	*f_len = 0;
	return NDIS_STATUS_FAILURE;
}

/* create a MLD STA */
static int bss_mngr_con_mld_sta_add(
	IN struct wifi_dev *wdev,
	IN struct bmgr_mld_sta *bmgr_sta
)
{
	int ret = NDIS_STATUS_FAILURE;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();
	struct mld_sta_para_t para = {0};

	if (!wdev || !bmgr_sta) {
		ret = NDIS_STATUS_FAILURE;
		return ret;
	}

	if (event_ops && event_ops->bmgr_event_add_mld_sta) {
		para.mld_sta_idx = bmgr_sta->idx;
		para.mld_addr = bmgr_sta->mld_addr;
		ret = event_ops->bmgr_event_add_mld_sta(wdev, &para);
	}

	return ret;
}

/* destroy a MLD STA */
int bss_mngr_con_mld_sta_del(
	IN struct wifi_dev *wdev,
	IN u16 mld_sta_idx,
	IN u8 *mld_addr
)
{
	int ret = NDIS_STATUS_FAILURE;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();

	if (!wdev) {
		ret = NDIS_STATUS_FAILURE;
		return ret;
	}

	if (event_ops && event_ops->bmgr_event_del_mld_sta)
		ret = event_ops->bmgr_event_del_mld_sta(wdev, mld_sta_idx, mld_addr);

	return ret;
}

int bss_mngr_con_mld_sta_add_links(
	IN struct bmgr_entry	*entry,
	IN struct bmgr_mld_sta	*bmgr_sta
)
{
	int ret = NDIS_STATUS_SUCCESS;
	u8 link, mld_bss_idx;
	struct bmgr_entry *mld_entry = NULL;
	struct bmgr_mlo_dev *mld = entry->mld_ptr;
	struct bss_mngr_event_ops *event_ops;
	struct mld_sta_add add_sta;
	struct mld_link_add	*add_link;

	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error, bss_idx (%d) in mld (%d) is invalid\n",
			entry->bss_idx, entry->entry_info.mld_grp);
		return NDIS_STATUS_FAILURE;
	}

	os_zero_mem(&add_sta, sizeof(add_sta));

	if (bmgr_sta && bmgr_sta->valid) {
		/* common info */
		add_sta.mld_sta_idx = bmgr_sta->idx;
		add_sta.aid = bmgr_sta->aid;
		COPY_MAC_ADDR(add_sta.mld_addr, bmgr_sta->mld_addr);
		add_sta.eml_caps = bmgr_sta->eml_caps;

		/* build link info */
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			mld_bss_idx = mld->bss_idx_mld[link];
			if (BMGR_VALID_BSS_IDX(mld_bss_idx))
				mld_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);
			add_link = &add_sta.add_link[link];

			add_link->active = bmgr_sta->mld_link[link].active;
			if (add_link->active && mld_entry) {
				add_link->is_setup_link =
					(bmgr_sta->bss_idx_setup == mld_entry->bss_idx) ? TRUE : FALSE;
				COPY_MAC_ADDR(add_link->sta_addr, bmgr_sta->mld_link[link].link_addr);
				add_link->str_map	= bmgr_sta->mld_link[link].str_bmap;
				add_link->priv_ptr	= NULL;

				if (add_link->active)
					add_sta.total_link_cnt++;
			}
			mld_entry = NULL;
		}

		/*setuplink should be the first insert link as primary link in hwifi*/
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			if (bmgr_sta->mld_link[link].active &&  add_sta.add_link[link].is_setup_link) {
				add_sta.link_id = link;
				mld_bss_idx = mld->bss_idx_mld[link];
				/* setup link shall success */
				if (!BMGR_VALID_BSS_IDX(mld_bss_idx)) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"insert setup link failed, bss_idx(%d) link_id(%d)\n",
						mld_bss_idx, link);
					bmgr_sta->mld_link[link].active = FALSE;
					ret = NDIS_STATUS_FAILURE;
					goto err;
				}
				mld_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);

				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"[%d],first insert link_id(%d)\n",
						 mld_entry->bss_idx, add_sta.link_id);

				event_ops = mld_entry->entry_info.event_ops;
				if (event_ops) {
					ret = event_ops->bmgr_event_mld_sta_add_link(mld_entry->pwdev, &add_sta);
					if (ret == NDIS_STATUS_SUCCESS) {
						/* entry allocated success */
						bmgr_sta->mld_link[link].priv_ptr = add_sta.add_link[link].priv_ptr;
						MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
								"\tlink_id(%d), pEntry(%p)\n",
								 link, add_sta.add_link[link].priv_ptr);
					} else {
						/* entry allocated fail */
						bmgr_sta->mld_link[link].active = FALSE;
						/* bmgr_sta->mld_link[link].requested still TRUE */
						MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
							"mld_add_sta setup L%d fail, link_addr(%pM)\n",
							 link, bmgr_sta->mld_link[link].link_addr);
						/* setup link shall success */
						ret = NDIS_STATUS_FAILURE;
						goto err;
					}
				}
			}
		}

		/* send add_sta event to active link */
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			if (bmgr_sta->mld_link[link].active) {
				if (add_sta.add_link[link].is_setup_link)
					continue;

				add_sta.link_id = link;
				mld_bss_idx = mld->bss_idx_mld[link];
				if (!BMGR_VALID_BSS_IDX(mld_bss_idx)) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"insert link failed, bss_idx(%d) link_id(%d)\n",
						mld_bss_idx, link);
					bmgr_sta->mld_link[link].active = FALSE;
					continue;
				}
				mld_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);

				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"[%d], link_id(%d)\n",
						 mld_entry->bss_idx, add_sta.link_id);

				event_ops = mld_entry->entry_info.event_ops;
				if (event_ops) {
					ret = event_ops->bmgr_event_mld_sta_add_link(mld_entry->pwdev, &add_sta);
					if (ret == NDIS_STATUS_SUCCESS) {
						/* entry allocated success */
						bmgr_sta->mld_link[link].priv_ptr = add_sta.add_link[link].priv_ptr;
						MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
								"\tlink_id(%d), pEntry(%p)\n",
								 link, add_sta.add_link[link].priv_ptr);
					} else {
						/* entry allocated fail */
						bmgr_sta->mld_link[link].active = FALSE;
						/* bmgr_sta->mld_link[link].requested still TRUE */
						MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
							"mld_add_sta L%d fail, link_addr(%pM)\n",
							 link, bmgr_sta->mld_link[link].link_addr);
					}
				}
			}
		}

		/* if setup link success, add_mld_sta operation success */
		ret = NDIS_STATUS_SUCCESS;

		at2lm_update_peer_mld_t2lm_at_assoc(mld, bmgr_sta);
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"invalid mld_sta %pM\n", bmgr_sta ? bmgr_sta->mld_addr : ZERO_MAC_ADDR);
		ret = NDIS_STATUS_FAILURE;
	}

err:
	return ret;
}

/* sanity check: connect request (STA) and ML BSS (AP) */
static int mld_sta_create(
	IN struct bmgr_entry *entry,
	IN struct ml_ie_info *ml_info,
	OUT struct bmgr_mld_sta *bmgr_sta
)
{
	u8 i;
	struct bmgr_entry *mld_entry = NULL;
	struct bmgr_mlo_dev *mld = entry->mld_ptr;
	u8 mld_bss_idx;

	if ((entry->entry_info.mld_grp != 0) && entry->mlo_en && BMGR_VALID_MLO_DEV(mld)) {
		/* apply mld basic info */
		bmgr_sta->data_link_id = entry->link_id;
		bmgr_sta->bss_idx_setup = entry->bss_idx;
		bmgr_sta->mld_grp_idx = mld->mld_grp;
		COPY_MAC_ADDR(bmgr_sta->mld_addr, ml_info->mld_addr);
		if (!bmgr_sta->valid) {
			if (bss_mngr_con_mld_sta_add(entry->pwdev, bmgr_sta)) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_ENTRY, DBG_LVL_ERROR,
					"add mld_sta fail\n");
				return NDIS_STATUS_FAILURE;
			}
		}

		/* apply mld per-link info */
		for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++) {
			if (ml_info->link[i].active) {
				mld_bss_idx = BMGR_VALID_MLO_DEV(mld) ? mld->bss_idx_mld[i] : BMGR_INVALID_BSS_IDX;

				if (BMGR_VALID_BSS_IDX(mld_bss_idx)) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
							"Link(%d)'s BSS [%d]\n", i, mld_bss_idx);
					mld_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);
					bmgr_sta->mld_link[i].active = TRUE;
					bmgr_sta->mld_link[i].requested = TRUE;
					COPY_MAC_ADDR(bmgr_sta->mld_link[i].link_addr, ml_info->link[i].link_addr);
				} else {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
							"MLD [%d] not support Link(%d)\n", mld->mld_grp, i);
				}
			}
			mld_entry = NULL;
		}

		bmgr_sta->valid = TRUE;
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
				"[%d] is Non-MLD\n", entry->bss_idx);
		return NDIS_STATUS_FAILURE;
	}

	return NDIS_STATUS_SUCCESS;
}

/* Assign peer STR bitmap according to NSTR bitmap in Per-STA Profile (non-setup links) */
static int mld_assign_peer_str_bitmap(
	IN struct bmgr_entry *entry,
	IN struct ml_ie_info *ml_info,
	OUT struct bmgr_mld_sta *bmgr_sta
)
{
	u8 sta_link, link;

	for (sta_link = 0; sta_link < BSS_MNGR_MAX_BAND_NUM; sta_link++) {
		/* set STR by default */
		bmgr_sta->mld_link[sta_link].str_bmap = BITS(0, BSS_MNGR_MAX_BAND_NUM - 1);

		/* there is no Per-STA Profile for setup link */
		if ((sta_link != entry->link_id) && bmgr_sta->mld_link[sta_link].active) {
			for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
				if ((link != sta_link) &&
					(ml_info->link[sta_link].nstr_bmap & BIT(link)) &&
					bmgr_sta->mld_link[link].active) {
					/* reset str bitmap for NSTR pair */
					bmgr_sta->mld_link[sta_link].str_bmap &= ~(BIT(link));
					/* sync to link pair */
					bmgr_sta->mld_link[link].str_bmap &= ~(BIT(sta_link));
				}
			}
		}
	}

	return NDIS_STATUS_SUCCESS;
}

int bss_mngr_con_mld_bss_linkup(
	struct wifi_dev *wdev)
{
	struct bmgr_entry *entry = NULL;
	struct bmgr_mlo_dev *mlo_dev = NULL;

	if (!wdev)
		return NDIS_STATUS_FAILURE;

	entry = get_bss_entry_by_wdev(wdev);
	if (!entry)
		return NDIS_STATUS_FAILURE;

	if (!BMGR_VALID_BSS_ENTRY(entry))
		return NDIS_STATUS_FAILURE;

	mlo_dev = entry->mld_ptr;

	if (BMGR_VALID_MLO_BSS_ENTRY(entry) && BMGR_VALID_MLO_DEV(mlo_dev))
		bss_mngr_con_mld_get_tsf_offset(mlo_dev);

	return NDIS_STATUS_SUCCESS;
}

int bss_mngr_con_mld_bss_linkdown(
	struct wifi_dev *wdev)
{
	struct bmgr_entry *entry = NULL;
	struct bmgr_mlo_dev *mlo_dev = NULL;

	if (!wdev)
		return NDIS_STATUS_FAILURE;

	entry = get_bss_entry_by_wdev(wdev);
	if (!entry)
		return NDIS_STATUS_FAILURE;

	if (!BMGR_VALID_BSS_ENTRY(entry))
		return NDIS_STATUS_FAILURE;

	mlo_dev = entry->mld_ptr;
	if (BMGR_VALID_MLO_BSS_ENTRY(entry) && BMGR_VALID_MLO_DEV(mlo_dev))
		bss_mngr_con_mld_get_tsf_offset(mlo_dev);

	return NDIS_STATUS_SUCCESS;
}

int bss_mngr_con_mld_bmc_sn_qry(
	IN struct wifi_dev *wdev,
	OUT u8 *mld,
	OUT u8 *agent_bss,
	OUT u16 *sn,
	OUT PNET_DEV * if_dev_list
)
{
	u8 i = 0;
	u8 mld_bss_idx;
	struct bmgr_entry *entry = NULL;
	struct bmgr_mlo_dev *mlo_dev = NULL;

	if (!wdev)
		return NDIS_STATUS_FAILURE;

	entry = get_bss_entry_by_wdev(wdev);
	if (!entry)
		return NDIS_STATUS_FAILURE;

	if (!BMGR_VALID_BSS_ENTRY(entry))
		return NDIS_STATUS_FAILURE;

	mlo_dev = entry->mld_ptr;

	if (BMGR_VALID_MLO_BSS_ENTRY(entry) && BMGR_VALID_MLO_DEV(mlo_dev)) {
		*mld = 1;
		if (entry->bss_idx == mlo_dev->bmc_bss_idx) {
			*agent_bss = 1;
			*sn = atomic_read(&mlo_dev->bmc_sn);

			for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++) {
				if_dev_list[i] = NULL;
				mld_bss_idx = mlo_dev->bss_idx_mld[i];
				if (!BMGR_VALID_BSS_IDX(mld_bss_idx))
					continue;
				entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);
				if (!entry)
					continue;
				if_dev_list[i] = entry->pNetDev;
			}

			atomic_inc(&mlo_dev->bmc_sn);
			if (atomic_read(&mlo_dev->bmc_sn) > 4095)
				atomic_set(&mlo_dev->bmc_sn, 0);
		} else
			*agent_bss = 0;
	} else {
		*mld = 0;
		*agent_bss = 0;
	}

	return NDIS_STATUS_SUCCESS;
}

static int bss_mngr_mld_conn_nego(
	struct bmgr_mlo_dev *mld,
	struct bmgr_mld_sta *bmgr_sta,
	struct ml_ie_info *ml_info
)
{
	bmgr_sta->link_reconfig_cap =
		GET_DOT11BE_ML_BASIC_CMM_MLD_CAP_LINK_RECONFIG_OP_SUP(ml_info->mld_caps)
		& mld->attr.mld_caps.link_reconfig_op_sup;

	return NDIS_STATUS_SUCCESS;
}

int bss_mngr_con_mld_conn_req(
	IN struct wifi_dev *wdev,
	struct mld_conn_req *mld_conn
)
{
	int ret = NDIS_STATUS_FAILURE;
	struct bmgr_entry *entry = NULL;
	struct ml_ie_info *ml_info = NULL;
	struct bmgr_mld_sta *bmgr_sta;
	struct bmgr_mlo_dev *mld = NULL;
	u16 i, mld_sta_idx = 0;

	if (wdev)
		entry = get_bss_entry_by_wdev(wdev);
	if (entry) {
		if (!BMGR_VALID_MLO_BSS_ENTRY(entry)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
					"[%d] is invalid (vld=%d, ml=%d)\n",
					entry->bss_idx, entry->valid, entry->mlo_en);
			return ret;
		}

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"[%d] req_type(%d)\n", entry->bss_idx, mld_conn->req_type);

		if (!mld_conn->link_addr) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: link_addr is null, [%d] req_type(%d)\n",
				entry->bss_idx, mld_conn->req_type);
			return ret;
		}

		if (mld_conn->ml_ie) {
			os_alloc_mem(NULL, (UCHAR **)&ml_info, sizeof(struct ml_ie_info));
			if (!ml_info) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Error: failed to allocate memory for parsing ML IE\n");
				ret = NDIS_STATUS_FAILURE;
				goto end;
			}
			NdisZeroMemory(ml_info, sizeof(struct ml_ie_info));
			if (parse_multi_link_ie(mld_conn->ml_ie, mld_conn->ml_frag_info,
						ml_info) < 0) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
					"Error: failed to parse multi link ie\n");
				ret = NDIS_STATUS_FAILURE;
				goto end;
			}

			/* protect mld sta index acquire */
			mutex_lock(&bss_mngr.op_mutex);

			mld = entry->mld_ptr;
			if (!BMGR_VALID_MLO_DEV(mld)) {
				mutex_unlock(&bss_mngr.op_mutex);
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
					"Error: [%d] invalid mld\n", entry->bss_idx);
				ret = NDIS_STATUS_FAILURE;
				goto end;
			}

			/* acquire mld sta index */
			COPY_MAC_ADDR(mld_conn->mld_addr, ml_info->mld_addr);
			mld_sta_idx = mld_sta_idx_acquire(entry, ml_info->mld_addr,
				mld_conn->req_type, mld_conn->link_addr);
			if (BMGR_VALID_MLD_STA(mld_sta_idx)) {
				bmgr_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);
				mld_conn->mld_sta_idx = mld_sta_idx;
				ret = mld_sta_create(entry, ml_info, bmgr_sta);
				if (ret == NDIS_STATUS_SUCCESS) {
					/* 1. link request = assoc frame body(setup link) +
				      per sta profile (other links)
				       2. derive setup link from assoc req frame body */
					bmgr_sta->mld_link[entry->link_id].active = TRUE;
					bmgr_sta->mld_link[entry->link_id].requested = TRUE;
					COPY_MAC_ADDR(bmgr_sta->mld_link[entry->link_id].link_addr,
						mld_conn->link_addr);

					/* aid = mld_sta_idx + 1024 */
					bmgr_sta->aid = mld_sta_idx + START_MLD_STA_AID;
					bmgr_sta->BAOriTID = 0;
					bmgr_sta->BARecTID = 0;
					bmgr_sta->eml_caps = ml_info->eml_caps;
					bmgr_sta->mld_caps = ml_info->mld_caps;
					bmgr_sta->emlsr_sup = ml_info->emlsr_sup;
					mld_assign_peer_str_bitmap(entry, ml_info, bmgr_sta);
					bss_mngr_mld_conn_nego(mld, bmgr_sta, ml_info);

					/* log the state of peer */
					for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++)
						MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_ASSOC, DBG_LVL_INFO,
							"\tlink:%d, active:%d, MAC:%pM\n",
							i, bmgr_sta->mld_link[i].active,
							bmgr_sta->mld_link[i].link_addr);

					ret = bss_mngr_con_mld_sta_add_links(entry, bmgr_sta);
					if (ret != NDIS_STATUS_SUCCESS) {
						mld_conn->mld_sta_idx = MLD_STA_NONE;
						mld_sta_destroy(entry, mld_sta_idx, bmgr_sta->mld_addr);
						mutex_unlock(&bss_mngr.op_mutex);
						MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
							"mld_sta add links fail\n");
						goto end;
					}
				} else {
					mld_conn->mld_sta_idx = MLD_STA_NONE;
					mld_sta_idx_release(mld_sta_idx);
					mutex_unlock(&bss_mngr.op_mutex);
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
						"conn sanity fail midx=%d\n", mld_sta_idx);
					goto end;
				}
			} else {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
						"mld_sta acquire fail\n");
			}

			/* end of mld sta acquire */
			mutex_unlock(&bss_mngr.op_mutex);

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"idx(%d),mld(%pM),link(%pM)\n",
				mld_sta_idx, ml_info->mld_addr, mld_conn->link_addr);
		}
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR, "entry is NULL\n");
	}

end:
	if (ml_info)
		os_free_mem(ml_info);

	return ret;
}

int bss_mngr_con_mld_conn_act(
	IN struct wifi_dev *wdev,
	IN u16 mld_sta_idx
)
{
	INT ret = NDIS_STATUS_FAILURE;
	struct bmgr_entry *entry = NULL;
	struct bmgr_entry *mld_entry;
	struct bmgr_mlo_dev *mld = NULL;
	struct bmgr_mld_sta *bmgr_sta = NULL;
	struct bss_mngr_event_ops *event_ops;
	struct mld_link_add add_link;
	u8 link, mld_bss_idx;

	if (wdev)
		entry = get_bss_entry_by_wdev(wdev);
	if (!entry)
		goto end;

	if (BMGR_VALID_MLD_STA(mld_sta_idx))
		bmgr_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);

	if (bmgr_sta && bmgr_sta->valid) {
		mld = entry->mld_ptr;
		if (!BMGR_VALID_MLO_DEV(mld)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error, bss_idx (%d) in mld (%d) is invalid\n",
				entry->bss_idx, entry->entry_info.mld_grp);
			goto end;
		}

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"bmgr_sta[%d] (%pM) setup bss(%d=%d)\n",
			bmgr_sta->idx, bmgr_sta->mld_addr,
			bmgr_sta->bss_idx_setup, entry->bss_idx);

		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			mld_entry = NULL;
			mld_bss_idx = mld->bss_idx_mld[link];
			if (BMGR_VALID_BSS_IDX(mld_bss_idx))
				mld_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);

			add_link.active = bmgr_sta->mld_link[link].active;
			if (add_link.active && BMGR_VALID_MLO_BSS_ENTRY(mld_entry)) {
				add_link.priv_ptr = bmgr_sta->mld_link[link].priv_ptr;
				event_ops = bmgr_event_ops_get();
				if (event_ops) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
							"\tpEntry(%p)\n", add_link.priv_ptr);
					ret = event_ops->bmgr_event_mld_conn_act(
							mld_entry->pwdev, &add_link);
					if (ret != NDIS_STATUS_SUCCESS) {
						/* mld conn act fail */
						MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
								"mld link(%d) fail\n", link);
					}
				}
			}
		}
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Invalid mld_sta_idx (%d) or bmgr_sta\n", mld_sta_idx);
	}

end:
	if (ret != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"mld conn_act failed\n");
	}
	return ret;
}

int bss_mngr_con_mld_sta_notify(
	IN struct wifi_dev *wdev,
	IN u16 mld_sta_idx
)
{
	INT ret = NDIS_STATUS_FAILURE;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();
	struct mld_sta_notify_para_t para = {0};
	struct bmgr_mld_sta *bmgr_sta = NULL;

	if (!wdev || !event_ops)
		goto end;

	if (BMGR_VALID_MLD_STA(mld_sta_idx))
		bmgr_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);

	mutex_lock(&bss_mngr.op_mutex);
	if (bmgr_sta && bmgr_sta->valid) {
		para.mld_sta_idx = bmgr_sta->idx;
		para.mld_addr = bmgr_sta->mld_addr;
		para.eml_caps = bmgr_sta->eml_caps;
		para.setup_link_link_id = bmgr_sta->data_link_id;
		para.lrr = bmgr_sta->link_reconfig_cap;

		ret = event_ops->bmgr_event_mld_sta_notify(wdev, &para);
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Invalid bmgr_sta with mld_sta_idx=%d\n", mld_sta_idx);
	}
	mutex_unlock(&bss_mngr.op_mutex);

end:
	if (ret != NDIS_STATUS_SUCCESS) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"mld notify failed\n");
	}

	return ret;
}

/**
 * @brief Disconnect all peer MLD associated with the MLD
 *
 * This function disassociates the peer MLD which setup with the correpsonding MLD.
 *
 * @param mld_grp Indicate the MLD that all MLD assoicated with it should be disassociated.
 */
void bss_mngr_con_mld_disconn_all_mld_sta(
	IN u8 mld_grp
)
{
	u16 i, link_id;
	struct bmgr_mld_sta *mld_sta;
	struct bmgr_mld_link *mld_link;
	struct mld_link_del	del_link;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"Disassoc all peer mld associated with ap mld %d\n", mld_grp);

	for (i = 0; BMGR_VALID_MLD_STA(i); i++) {
		mld_sta = GET_MLD_STA_BY_IDX(i);

		if (mld_sta->valid && (mld_sta->mld_grp_idx == mld_grp)) {
			/* disconnect peer MLD on one of active link */
			for (link_id = 0; link_id < BSS_MNGR_MAX_BAND_NUM; link_id++) {
				mld_link = &mld_sta->mld_link[link_id];
				if (!mld_link->active)
					continue;

				/* build delete link info */
				COPY_MAC_ADDR(del_link.sta_addr, mld_link->link_addr);
				del_link.priv_ptr = mld_link->priv_ptr;

				if (event_ops->bmgr_event_mld_disconn_mld_sta(&del_link) != NDIS_STATUS_SUCCESS) {
					/* fail: find next active link */
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"Fail: disconn peer mld %d on link %d failed\n",
						mld_sta->idx, link_id);
					continue;
				}

				break;
			}
		}
	}
}

/* delete a link in a MLD STA */
static int bss_mngr_con_mld_sta_del_link(
	IN struct bmgr_mld_link *sta_mld_link,
	IN u8 op
)
{
	int ret = NDIS_STATUS_FAILURE;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();
	struct mld_link_del	del_link;
	bool delete_temp_ptr = FALSE;

	if (sta_mld_link->active || sta_mld_link->priv_ptr || sta_mld_link->priv_temp_ptr) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"addr(%pM), op(%d)\n", sta_mld_link->link_addr, op);

		/* build delete link info */
		del_link.op = op;
		COPY_MAC_ADDR(del_link.sta_addr, sta_mld_link->link_addr);
		del_link.priv_ptr = sta_mld_link->priv_ptr;
		if (!del_link.priv_ptr) {
			del_link.priv_ptr = sta_mld_link->priv_temp_ptr;
			delete_temp_ptr = TRUE;
		}

		if (event_ops) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"\tpEntry(%p)\n", del_link.priv_ptr);

			switch (op) {
			case MLD_DISC_OP_ACT_ONLY:
				ret = event_ops->bmgr_event_mld_disconn_act(&del_link);
				if (ret != NDIS_STATUS_SUCCESS) {
					/* mld link delete fail */
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"\tmld link(%pM) delete fail\n", sta_mld_link->link_addr);
				}
				break;
			case MLD_DISC_OP_DEL_STA_N_ACT:
			case MLD_DISC_OP_DEL_STA_LINK:
			case MLD_DISC_OP_LR_DEL_LINK:
			case MLD_DISC_OP_LR_DEL_TEMP_LINK_ENTRY:
				ret = event_ops->bmgr_event_mld_sta_del_link(&del_link);
				if (ret == NDIS_STATUS_SUCCESS) {
					/* mld link delete success */
					sta_mld_link->priv_ptr = NULL;
					sta_mld_link->active = FALSE;
					if (delete_temp_ptr)
						sta_mld_link->priv_temp_ptr = NULL;
				} else {
					/* mld link delete fail */
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"\tmld link(%pM) delete fail op=%d\n",
						sta_mld_link->link_addr, op);
				}
				break;
			default:
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"invalid op %d\n", op);
				break;
			}
		}
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"invalid link %pM\n", sta_mld_link->link_addr);
	}

	return ret;
}

/* delete a MLD STA */
int bss_mngr_con_mld_sta_del_links(
	IN struct bmgr_mld_sta	*bmgr_sta,
	IN u8 op
)
{
	int ret, Ret = NDIS_STATUS_SUCCESS;
	u8 link;
	struct bmgr_mld_link *mld_link = NULL;
	u8 request_link_deleted = FALSE;
	MAC_TABLE_ENTRY *pEntry = NULL, *setup_link_Entry = NULL;


	/* Delete requested link first */
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		ret = NDIS_STATUS_SUCCESS;
		mld_link = &bmgr_sta->mld_link[link];
		pEntry = (MAC_TABLE_ENTRY *)mld_link->priv_ptr;
		if (pEntry && !pEntry->mlo.is_setup_link_entry) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
			"Skip Non Setup Link (%pM) Del  temply (link idx: %d)\n", mld_link->link_addr, link);
			continue;
		}
		if (mld_link->active)
			ret = bss_mngr_con_mld_sta_del_link(mld_link, op);
		else {
			/* release resource if acquired previously */
			if (mld_link->priv_ptr) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"W: L%d, R%d, addr(M:%pM, L:%pM)\n",
					link, mld_link->requested, bmgr_sta->mld_addr, mld_link->link_addr);
				ret = bss_mngr_con_mld_sta_del_link(mld_link, op);
			}
		}

		if (ret == NDIS_STATUS_SUCCESS && request_link_deleted == FALSE) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
			"Setup Link %d (%pM) Del suc, start to del non-setup link\n", link, mld_link->link_addr);
			request_link_deleted = TRUE;
		}
	}

	/* send del_sta event to active link */
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		ret = NDIS_STATUS_SUCCESS;
		mld_link = &bmgr_sta->mld_link[link];

		setup_link_Entry = (MAC_TABLE_ENTRY *)mld_link->priv_ptr;
		if (setup_link_Entry && (setup_link_Entry->mlo.is_setup_link_entry)
			&& request_link_deleted) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
			"Skip Setup Link (%pM) Del (link idx: %d)\n", mld_link->link_addr, link);
			continue;
		}

		if (mld_link->active)
			ret = bss_mngr_con_mld_sta_del_link(mld_link, op);
		else {
			/* release resource if acquired previously */
			if (mld_link->priv_ptr) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
					"W: Link=%d,Req=%d,addr(M:%pM, L:%pM)\n",
					link, mld_link->requested, bmgr_sta->mld_addr, mld_link->link_addr);
				ret = bss_mngr_con_mld_sta_del_link(mld_link, op);
			}
		}

		if (ret != NDIS_STATUS_SUCCESS) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Fail Link=%d,Req=%d,addr(M=%pM, L=%pM)\n",
				link, mld_link->requested, bmgr_sta->mld_addr, mld_link->link_addr);
			Ret = NDIS_STATUS_FAILURE;
		}
	}

	/* Send del_sta event to temp link (during Link Reconfiguration) */
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		ret = NDIS_STATUS_SUCCESS;
		mld_link = &bmgr_sta->mld_link[link];

		/* release temp resource */
		if (mld_link->priv_temp_ptr) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
				"Notice: delete temp entry Link=%d,addr(MLD:%pM)\n",
				link, bmgr_sta->mld_addr);
			ret = bss_mngr_con_mld_sta_del_link(mld_link, MLD_DISC_OP_LR_DEL_TEMP_LINK_ENTRY);
			/* ignore return value */
		}
	}

	return Ret;
}

int bss_mngr_con_mld_disconn_op(
	IN struct wifi_dev *wdev,
	IN u16 mld_sta_idx,
	IN u8 op
)
{
	int ret = NDIS_STATUS_FAILURE;
	struct bmgr_entry *entry = NULL;
	struct bmgr_mld_sta *bmgr_sta;

	mutex_lock(&bss_mngr.op_mutex);
	if (wdev)
		entry = get_bss_entry_by_wdev(wdev);
	if (entry) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"[%d] mld_sta(%d), op(%d)\n",
				entry->bss_idx, mld_sta_idx, op);

		if (BMGR_VALID_MLD_STA(mld_sta_idx)) {
			bmgr_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);
			if (bmgr_sta && bmgr_sta->valid) {
				switch (op) {
				case MLD_DISC_OP_ACT_ONLY:
				case MLD_DISC_OP_DEL_STA_N_ACT:
					ret = bss_mngr_con_mld_sta_del_links(bmgr_sta, op);
					if ((ret == NDIS_STATUS_SUCCESS) &&
						(op == MLD_DISC_OP_DEL_STA_N_ACT)) {
						mld_sta_destroy(entry, mld_sta_idx, bmgr_sta->mld_addr);
					}
					break;
				case MLD_DISC_OP_DEL_STA_LINK:
					ret = bss_mngr_con_mld_sta_del_link(&bmgr_sta->mld_link[entry->link_id], op);
					break;
				default:
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"invalid op %d (mld_sta_idx %d)\n", op, mld_sta_idx);
					break;
				}
			}
		} else
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"invalid mld_sta_idx %d\n", mld_sta_idx);
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR, "entry is NULL\n");
	}

	mutex_unlock(&bss_mngr.op_mutex);
	return ret;
}

int bss_mngr_con_mld_add_sta_profile(
	IN struct wifi_dev *wdev,
	IN u16 mld_sta_idx,
	IN u8 link_id,
	IN u8 frame_mld_type,
	IN u8 *buf,
	IN u16 buf_len
)
{
	struct bmgr_entry *entry = NULL;

	struct ie *sta_pf = NULL;
	struct bmgr_mld_sta *bmgr_sta = NULL;
	struct bmgr_mld_link *mld_link = NULL;

	if (!wdev)
		return NDIS_STATUS_FAILURE;
	entry = get_bss_entry_by_wdev(wdev);
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_ASSOC, DBG_LVL_INFO,
		"wdev=%s, Pf(len=%d, lk=%d) for type (%d)\n",
		entry ? RtmpOsGetNetDevName(wdev->if_dev) : "N/A",
		buf_len, link_id, frame_mld_type);

	if ((buf_len != 0) && (buf_len < BSS_MNGR_MAX_STA_PROFILE_LEN)) {
		switch (frame_mld_type) {
		case BMGR_MLD_PROBE_RSP_COMPLETE_PROFILE:
			/* put the STA Profile to self bmgr_entry */
			if (BMGR_VALID_MLO_BSS_ENTRY(entry)) {
				sta_pf = &entry->ml_probe_rsp_sta_pf[link_id];
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_INFO,
					"Add STA Profile for Probe rsp [%d]\n", link_id);
			}
			break;
		case BMGR_MLD_PROBE_RSP_PARTIAL_PROFILE:
			/* TODO */
			break;
		case BMGR_MLD_ASSOC_RSP_COMPLETE_PROFILE:
			/* put the STA Profile to peer bmgr_sta */
			if (BMGR_VALID_MLD_STA(mld_sta_idx))
				bmgr_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);
			if (!bmgr_sta || !bmgr_sta->valid) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_ERROR,
					"Error: bmgr_sta(%d) is not valid!\n", mld_sta_idx);
				return NDIS_STATUS_FAILURE;
			}
			mld_link = &bmgr_sta->mld_link[link_id];
			if (!mld_link->requested) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_ERROR,
					"Error: peer MLD do not request link %d!\n", link_id);
				return NDIS_STATUS_FAILURE;
			}
			sta_pf = &mld_link->assoc_rsp_sta_profile;
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_INFO,
				"Add STA Profile for ASSOC rsp [%d]\n", link_id);
			break;
		case BMGR_MLD_APPL_ELEM_STA_PROFILE:
			/* Add appl_elem to reporting  */
			mld_add_appl_elem(entry, buf, buf_len);
			return NDIS_STATUS_SUCCESS;
		case BMGR_MLD_LINK_RECONFIG_RSP_COMPLETE_PROFILE:
			/* put the STA Profile to peer bmgr_sta,
			 * the same buffer as association response */
			if (BMGR_VALID_MLD_STA(mld_sta_idx))
				bmgr_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);
			if (!bmgr_sta || !bmgr_sta->valid) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_ERROR,
					"Error: bmgr_sta(%d) is not valid!\n", mld_sta_idx);
				return NDIS_STATUS_FAILURE;
			}
			mld_link = &bmgr_sta->mld_link[link_id];
			sta_pf = &mld_link->assoc_rsp_sta_profile;
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_INFO,
				"mld_sta_idx=%d, Add STA-PF for LR rsp link=%d\n", mld_sta_idx, link_id);
			break;
		default:
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_ERROR,
				"drop the add profile operation for frame_mld_type: %d\n", frame_mld_type);
			break;
		}

		/* move content to target STA Profile buffer */
		if (sta_pf) {
			if (!sta_pf->buf) {
				os_alloc_mem(NULL, (UCHAR **)&sta_pf->buf, BSS_MNGR_MAX_STA_PROFILE_LEN);
				if (!sta_pf->buf) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_ERROR,
						"Error: can not allocate memory!\n");
					return NDIS_STATUS_FAILURE;
				}
			} else
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_INFO,
					"Notice: reuse the allocated sta pf buffer!\n");

			sta_pf->len = 0;
			NdisMoveMemory(sta_pf->buf, buf, buf_len);
			sta_pf->len = buf_len;
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_INFO,
				"Add STA Profile result: %p, len=%d\n", sta_pf->buf, sta_pf->len);
		}
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_ERROR,
			"Error: [len=%d] Input STA Profile w/ Len=0 or Len>%d!\n",
			buf_len, BSS_MNGR_MAX_STA_PROFILE_LEN);

		return NDIS_STATUS_FAILURE;
	}

	return NDIS_STATUS_SUCCESS;
}

/* elmt_id_arr=NULL && id_arr_len==0 means remove the whole per_sta_prf */
bool bss_mngr_con_mld_remove_sta_profile(
	struct wifi_dev *wdev,
	u8 frame_mld_type,
	u8 *elmt_id_arr,
	u16 id_arr_len)
{
	struct bmgr_entry *entry = NULL;

	if (!wdev)
		return FALSE;
	entry = get_bss_entry_by_wdev(wdev);
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_NOTICE,
		"Remove elmt from STA Profile for %d type, bmgr_entry(%p).\n", frame_mld_type, entry);

	if (frame_mld_type == BMGR_MLD_APPL_ELEM_STA_PROFILE && id_arr_len == 0) {
		/* Remove appl_elem from each reporting link */
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_NOTICE,
			"Remove whole sta_prof for BMGR_MLD_APPL_ELEM_STA_PROFILE\n");

		mld_remove_appl_elem(entry);
		return TRUE;
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_CONN, DBG_LVL_NOTICE, "The process is TBD!\n");
	return FALSE;
}

void bss_mngr_con_sync_ml_probe_rsp_per_sta_profile(
	struct wifi_dev *wdev)
{
	u8 link, bss_idx, mld_grp;
	u8 repted_link, repting_link;
	u8 repted_bss_idx;
	u8 *f_buf, *pos;
	bool entry_rdy[BSS_MNGR_MAX_BAND_NUM] = {0};

	struct bmgr_entry *entry = NULL;
	struct bmgr_entry *repting_entry;
	struct bmgr_entry *repted_entry;
	struct bmgr_mlo_dev *mld = NULL;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();
	struct ie rsp_frm[BSS_MNGR_MAX_BAND_NUM];
	struct ie *per_sta_pf = NULL;

	if (wdev)
		entry = get_bss_entry_by_wdev(wdev);
	if (!entry) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: entry is NULL!\n");
		return;
	}

	mld_grp = entry->entry_info.mld_grp;
#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(mld_grp);
#else
	mld = BMGR_VALID_MLD_GRP_IDX(mld_grp) ? GET_MLD_BY_GRP_IDX(mld_grp) : NULL;
#endif
	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
			"bss_idx (%d), mld grp invalid(%d)\n",
			entry->bss_idx, entry->entry_info.mld_grp);
		return;
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"%s(%s) sync probe rsp STA-Pf, mlo:%d, cnt:%d\n",
		mt_os_net_dev_get_name(wdev->if_dev), entry->valid ? "active" : "inactive",
		entry->mlo_en, mld->mld_link_cnt);

	if (!BMGR_VALID_MLO_BSS_ENTRY(entry)) {
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			/* free non-MLO entry's buffer */
			per_sta_pf = &entry->ml_probe_rsp_per_sta_pf[link];
			per_sta_pf->len = 0;
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"zero len entry[link=%d].per_sta_pf[link=%d]\n",
				entry->link_id, link);

		}
	}

	/* query probe response frames to driver */
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		repting_entry = NULL;
		rsp_frm[link].buf = NULL;
		rsp_frm[link].len = 0;

		bss_idx = mld->bss_idx_mld[link];
		if (BMGR_VALID_BSS_IDX(bss_idx)) {
			repting_entry = GET_BSS_ENTRY_BY_IDX(bss_idx);
			if (BMGR_VALID_MLO_BSS_ENTRY(repting_entry)) {
#ifdef DOT11V_MBSSID_SUPPORT
				/*
				 * rsp_frm is used later as Probe Response of reporting AP.
				 *
				 * reporting AP shall be able to transmit Probe Response,
				 * e.g. Legacy BSS, co-hosted MBSS, 11v transmitted BSSID
				 * If the AP of this link in MLD is non-tx BSSID, we shall
				 * replace the Probe Response of this link with tx BSSID's
				 * Probe Response.
				 */
				if (IS_DEV_TYPE_11V_NT(repting_entry->entry_info.dev_type)) {
					bss_idx = repting_entry->bss_idx_tx;

					if (BMGR_VALID_BSS_IDX(bss_idx)
						&& BMGR_VALID_BSS_ENTRY(GET_BSS_ENTRY_BY_IDX(bss_idx)))
						repting_entry = GET_BSS_ENTRY_BY_IDX(bss_idx);
				}
#endif
				event_ops->bmgr_event_mld_query_probe_rsp_frame(
					repting_entry->pwdev, &rsp_frm[link]);

				if (rsp_frm[link].len == 0)
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"Error: link[%d] fail to query probe response frame!\n", link);
				entry_rdy[link] = TRUE;
			}
		}
	}

	/* form the Per-STA Profile for ML Probe response */
	/* repted_link: the link that is reported in Per-STA Profile in ML IE */
	for (repted_link = 0; repted_link < BSS_MNGR_MAX_BAND_NUM; repted_link++) {
		if (!entry_rdy[repted_link])
			continue;

		repted_bss_idx = mld->bss_idx_mld[repted_link];
		if (!BMGR_VALID_BSS_IDX(repted_bss_idx))
			continue;

		repted_entry = GET_BSS_ENTRY_BY_IDX(repted_bss_idx);

		/* repting_link: the link that receives the request frm */
		for (repting_link = 0; repting_link < BSS_MNGR_MAX_BAND_NUM; repting_link++) {
			if (repted_link == repting_link)
				continue;

			/*
			 *  repted entry [if link 0]
			 *    ml_probe_rsp_per_sta_pf
			 *      [0]: Per-STA Profile of repted [link 0] for repting [link 0]
			 *            -> (always empty because repting link is repted link)
			 *      [1]: Per-STA Profile of repted [link 0] for repting [link 1]
			 *      [2]: Per-STA Profile of repted [link 0] for repting [link 2]
			 *
			 *  if peer transmits ML Probe Request by link 1:
			 *     - [link 0 entry] deliver ml_probe_rsp_per_sta_pf[1] to [link 1].
			 *     - [link 1 entry] skip.
			 *     - [link 2 entry] deliver ml_probe_rsp_per_sta_pf[1] to [link 1].
			 */
			per_sta_pf = &repted_entry->ml_probe_rsp_per_sta_pf[repting_link];

			if (!entry_rdy[repting_link]) {
				/* free buffer for non-MLO entry */
				per_sta_pf->len = 0;
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"zero len entry[link=%d].per_sta_pf[link=%d]\n",
					repted_entry->link_id, repting_link);
				continue;
			}

			/*
			 * apply inheritance rule among reporting and reported links,
			 * and build Per-STA Profile in Basic Multi-link IE in ML Probe
			 * Response Frame.
			 */
			if (!per_sta_pf->buf)
				os_alloc_mem(NULL, (UCHAR **)&per_sta_pf->buf, BSS_MNGR_MAX_PER_STA_PROFILE_LEN);
			else {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"Notice: reuse the per-sta profile buffer!\n");
			}

			if (per_sta_pf->buf) {
				bool locked = FALSE;

				if (rsp_frm[repting_link].buf) {
					event_ops->bmgr_event_mld_form_ml_probe_rsp_sta_pf(
						repted_entry->pwdev,
						&rsp_frm[repting_link], repting_link);

					if (!in_interrupt()) {
						mutex_lock(&bss_mngr.op_mutex);
						locked = TRUE;
					} else {
						MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
							"In interrupt!\n");
					}

					f_buf = pos = per_sta_pf->buf;
					pos = build_multi_link_per_sta_profile(
							repted_entry,
							f_buf,
							BMGR_MLD_PROBE_RSP_COMPLETE_PROFILE,
							BMGR_MAX_MLD_STA_CNT,
							repting_link);
					per_sta_pf->len = pos - f_buf;

					if (locked)
						mutex_unlock(&bss_mngr.op_mutex);

					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
						"repted link %d, per-sta profile len %d for repting link %d!\n",
						repted_link, per_sta_pf->len, repting_link);
				}
			} else
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Error: can not alloc buffer for repted link %d for repting link %d!\n",
					repted_link, repting_link);
		}
	}

	/* free all buffer allocated by ap_probe_response_xmit() */
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		if (rsp_frm[link].buf)
			MlmeFreeMemory(rsp_frm[link].buf);
	}
}

void bss_mngr_con_mld_ba_add_to_asic(
	IN struct wifi_dev *wdev,
	IN u16 mld_sta_idx,
	IN u8 TID,
	IN u16 Seq,
	IN u16 BAWinSize,
	IN int type,
	IN u8 amsdu_en
)
{
	u8 link, mld_bss_idx, TID_is_map;
	struct bmgr_entry *entry = NULL;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();
	struct bmgr_mld_sta *bmgr_sta = NULL;
	struct bmgr_entry *mld_entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;
	struct bmgr_mld_link *mld_link = NULL;
	struct mld_ba_info ba_info = {0};

	if (!wdev)
		return;
	entry = get_bss_entry_by_wdev(wdev);
	if (BMGR_VALID_MLD_STA(mld_sta_idx))
		bmgr_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);

	if (!entry || !bmgr_sta || !bmgr_sta->valid)
		return;

#ifdef EHT_BE_LINK_RECONFIG_BUILD
	// LR-refine lr-sup -> new BA, not-sup -> old BA
#endif /* EHT_BE_LINK_RECONFIG_BUILD */
	if (bmgr_sta->link_reconfig_cap) {
		COPY_MAC_ADDR(ba_info.peer_mld_addr, bmgr_sta->mld_addr);
		ba_info.TID = TID;
		ba_info.Seq = Seq;
		ba_info.BAWinSize = BAWinSize;
		ba_info.type = type;
		ba_info.amsdu_en = amsdu_en;
		ba_info.by_mld = TRUE;
		event_ops->bmgr_event_mld_ba_add_to_asic(entry->pwdev, &ba_info);
	} else {
		mld = entry->mld_ptr;
		if (!BMGR_VALID_MLO_DEV(mld)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error, bss_idx (%d) in mld (%d) is invalid\n",
				entry->bss_idx, entry->entry_info.mld_grp);
			return;
		}
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			mld_link = &bmgr_sta->mld_link[link];
			mld_bss_idx = mld->bss_idx_mld[link];
			mld_entry = NULL;
			TID_is_map = 0;

			if (BMGR_VALID_BSS_IDX(mld_bss_idx))
				mld_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);

			if (mld_entry)
				/* TID-to-link mapping */
				TID_is_map = mld_entry->tid_map & (1 << TID);

			if (mld_link->active && TID_is_map) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"[%d] link_id(%d)\n", mld_entry->bss_idx, link);

				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"\tpEntry(%p)\n", mld_link->priv_ptr);

				ba_info.TID = TID;
				ba_info.Seq = Seq;
				ba_info.BAWinSize = BAWinSize;
				ba_info.type = type;
				ba_info.amsdu_en = amsdu_en;
				ba_info.priv_ptr = mld_link->priv_ptr;
				event_ops->bmgr_event_mld_ba_add_to_asic(mld_entry->pwdev, &ba_info);
			}
		}
	}
}

void bss_mngr_con_mld_ba_del_from_asic(
	IN struct wifi_dev *wdev,
	IN u16 mld_sta_idx,
	IN u8 TID,
	IN int type,
	IN u8 amsdu_en
)
{
	u8 link, mld_bss_idx, TID_is_map;
	struct bmgr_entry *entry = NULL;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();
	struct bmgr_mld_sta *bmgr_sta = NULL;
	struct bmgr_entry *mld_entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;
	struct bmgr_mld_link *mld_link = NULL;
	struct mld_ba_info ba_info = {0};

	if (!wdev)
		return;
	entry = get_bss_entry_by_wdev(wdev);
	if (BMGR_VALID_MLD_STA(mld_sta_idx))
		bmgr_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);

	if (!entry || !bmgr_sta || !bmgr_sta->valid)
		return;

#ifdef EHT_BE_LINK_RECONFIG_BUILD
	// LR-refine lr-sup -> new BA, not-sup -> old BA
#endif /* EHT_BE_LINK_RECONFIG_BUILD */
	if (bmgr_sta->link_reconfig_cap) {
		COPY_MAC_ADDR(ba_info.peer_mld_addr, bmgr_sta->mld_addr);
		ba_info.TID = TID;
		ba_info.type = type;
		ba_info.amsdu_en = amsdu_en;
		ba_info.by_mld = TRUE;
		event_ops->bmgr_event_mld_ba_del_from_asic(entry->pwdev, &ba_info);
	} else {
		mld = entry->mld_ptr;
		if (!BMGR_VALID_MLO_DEV(mld)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error, bss_idx (%d) in mld (%d) is invalid\n",
				entry->bss_idx, entry->entry_info.mld_grp);
			return;
		}

		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			mld_link = &bmgr_sta->mld_link[link];
			mld_bss_idx = mld->bss_idx_mld[link];
			mld_entry = NULL;
			TID_is_map = 0;

			if (BMGR_VALID_BSS_IDX(mld_bss_idx))
				mld_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);

			if (mld_entry)
				/* TID-to-link mapping */
				TID_is_map = mld_entry->tid_map & (1 << TID);

			if (mld_link->active && TID_is_map) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"[%d] link_id(%d)\n", mld_entry->bss_idx, link);

				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"\tpEntry(%p)\n", mld_link->priv_ptr);

				ba_info.TID = TID;
				ba_info.type = type;
				ba_info.amsdu_en = amsdu_en;
				ba_info.priv_ptr = mld_link->priv_ptr;
				event_ops->bmgr_event_mld_ba_del_from_asic(
							mld_entry->pwdev, &ba_info);
			}
		}
	}
}

void bss_mngr_con_twt_agg_timeout_fun(struct work_struct *work)
{
	struct bss_mlo_twt *mlo_twt = &bss_mngr.mlo_twt;
	struct MLO_ITWT_ELEMENT_T *temp_element = NULL;
	struct MLO_ITWT_ELEMENT_T *temp_element_next = NULL;
	struct MLO_TWT_PRIV_T *temp_priv = NULL;
	u8 empty_before, empty_after;
	u8 del_cnt = 0;

	OS_SEM_LOCK(&mlo_twt->lock);
	empty_before = list_empty(&mlo_twt->breakdown_action_frame_list);
	list_for_each_entry_safe(temp_element, temp_element_next, &mlo_twt->breakdown_action_frame_list, list) {
		temp_priv = &temp_element->priv;
		if (temp_priv->mld_sta_idx == mlo_twt->mld_sta_idx) {
			list_del(&temp_element->list);
			os_free_mem(temp_element);
			del_cnt++;
		}
	}
	empty_after = list_empty(&mlo_twt->breakdown_action_frame_list);
	OS_SEM_UNLOCK(&mlo_twt->lock);

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
		"empty=%d,%d, del_cnt=%d\n", empty_before, empty_after, del_cnt);
}

static void bss_mngr_con_twt_agg_timer_cancel(
	IN struct bss_mlo_twt *mlo_twt
)
{
	BOOLEAN cancelled;
	RALINK_TIMER_STRUCT *timer = &mlo_twt->agg_action_frame_timer;

	RTMPCancelTimer(timer, &cancelled);
	RTMPReleaseTimer(timer, &cancelled);
}

static void bss_mngr_con_twt_agg_timeout_exec(
	IN PVOID SystemSpecific1,
	IN PVOID FunctionContext,
	IN PVOID SystemSpecific2,
	IN PVOID SystemSpecific3)
{
	struct bss_mlo_twt *mlo_twt = (struct bss_mlo_twt *)FunctionContext;
	struct work_struct *agg_timeout_work = NULL;

	if (!mlo_twt) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
			"fail. mlo_twt=NULL\n");
		return;
	}

	agg_timeout_work = &mlo_twt->agg_timeout_work;
	INIT_WORK(agg_timeout_work, bss_mngr_con_twt_agg_timeout_fun);
	schedule_work(agg_timeout_work);
}

DECLARE_TIMER_FUNCTION(bss_mngr_con_twt_agg_timeout_exec);
BUILD_TIMER_FUNCTION(bss_mngr_con_twt_agg_timeout_exec);

void bss_mngr_con_mld_twt_action_frm_forward(
	IN struct wifi_dev *wdev,
	IN struct _MLME_QUEUE_ELEM *elem
)
{
	u8 link = 0;
	u8 mld_bss_idx = 0;
	struct bmgr_entry *master_bss_entry = NULL;
	struct bmgr_entry *expected_bss_entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;
	struct bss_mngr_event_ops *event_ops = NULL;
	struct _HEADER_802_11 *hdr = (struct _HEADER_802_11 *)&elem->Msg;

	if (!wdev || !elem || !hdr)
		return;
	master_bss_entry = get_bss_entry_by_wdev(wdev);
	if (!master_bss_entry)
		return;
	mld = master_bss_entry->mld_ptr;
	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error, bss_idx (%d) in mld (%d) is invalid\n",
			master_bss_entry->bss_idx, master_bss_entry->entry_info.mld_grp);
		return;
	}

	/* use A3 to find BSSID whom this action frame belongs to */
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		mld_bss_idx = mld->bss_idx_mld[link];
		expected_bss_entry = BMGR_VALID_BSS_IDX(mld_bss_idx) ? GET_BSS_ENTRY_BY_IDX(mld_bss_idx) : NULL;

		if (!expected_bss_entry)
			continue;
		if (MAC_ADDR_EQUAL(expected_bss_entry->entry_info.bssid, hdr->Addr3)) {
			struct wifi_dev *wdev;
			struct _RTMP_ADAPTER *ad;
			struct _MAC_TABLE_ENTRY *peer_entry;

			wdev = mt_os_net_dev_get_wdev(expected_bss_entry->pNetDev);
			if (!wdev) {
				MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
					"fail. fail to find wdev\n");
				continue;
			}

			ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
			if (!ad) {
				MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
					"fail. fail to find ad\n");
				continue;
			}

			peer_entry = MacTableLookup2(ad, hdr->Addr2, wdev);
			if (peer_entry) {
				if (peer_entry->wdev == wdev) {
					event_ops = expected_bss_entry->entry_info.event_ops;
					if (event_ops)
						event_ops->bmgr_event_mld_twt_action_frm_forward(elem, peer_entry);
				} else
					MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
						"fail. wdev mismatch, IF=%s,%s\n",
						peer_entry->wdev->if_dev->name, wdev->if_dev->name);
			} else
				MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
					"fail. fail to find peer_entry\n");
			break;
		}
	}

	if (link == BSS_MNGR_MAX_BAND_NUM)
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
			"fail. BSSID not found\n");
}

static void action_frame_breakdown_with_linkid(
	PNET_DEV pNetDev, /* sa */
	u16 mld_sta_idx,
	struct _MLME_QUEUE_ELEM *elem,
	struct bmgr_mld_sta *mld_sta,
	struct bmgr_entry *bss_entry, /* sa */
	struct mlo_itwt_ie *mlo_twt_ie,
	u8 action_linkid,
	u16 linkid_bitmap,
	u16 all_linkid_bitmap,
	u8 *breakdown
)
{
	u8 linkid = 0;
	struct bmgr_mld_link *mld_link = NULL;
	struct bmgr_mlo_dev *mld = NULL;
	struct _MAC_TABLE_ENTRY *peer_entry = NULL;
	u8 mld_bss_idx = 0;
	u8 *link_addr = NULL;
	struct bmgr_entry *mld_bss_entry = NULL;
	struct bss_mngr_event_ops *event_ops = NULL;

	if (!mlo_twt_ie) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
			"fail. twt_ie=NULL\n");
		return;
	}

	if (!(GET_TWT_CTRL_LINKID_BITMAP_PRESENT(mlo_twt_ie->control) && linkid_bitmap)) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
			"fail. linkid_bitmap_present=%d, linkid_bitmap=0x%x\n",
			(UINT8)GET_TWT_CTRL_LINKID_BITMAP_PRESENT(mlo_twt_ie->control),
			linkid_bitmap);
		return;
	}

	linkid = ffs(linkid_bitmap) - 1;
	mld_link = &mld_sta->mld_link[linkid];
	peer_entry = (struct _MAC_TABLE_ENTRY *)mld_link->priv_ptr;
	if (!peer_entry) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
			"fail. linkid=%d, peer_entry=NULL\n\n", linkid);
		return;
	}

	link_addr = mld_link->link_addr;
	if (!MAC_ADDR_EQUAL(peer_entry->Addr, link_addr)) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
			"fail. mac not equal. peer_entry->Addr=%pM, link_addr=%pM\n",
			peer_entry->Addr, link_addr);
		return;
	}

	mld = bss_entry->mld_ptr;
	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"fail, bss_idx (%d) in mld (%d) is invalid\n",
			bss_entry->bss_idx, bss_entry->entry_info.mld_grp);
		return;
	}

	mld_bss_idx = mld->bss_idx_mld[linkid];
	if (!BMGR_VALID_BSS_IDX(mld_bss_idx)) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
			"fail. invalid mld_bss_idx=%d\n", mld_bss_idx);
		return;
	}

	mld_bss_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);
	if (mld_bss_entry->link_id != linkid) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
			"fail. dest link id mismatch=%d,%d\n", mld_bss_entry->link_id, linkid);
		return;
	}

	event_ops = mld_bss_entry->entry_info.event_ops;
	if (!event_ops) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
			"fail. event_ops=NULL\n");
		return;
	}

	/* forward N of "1->N" berakdown action frame to correct link MLME */
	*breakdown |= event_ops->bmgr_event_mld_twt_action_frm_breadown(
		mld_bss_entry->pNetDev, /* da */
		pNetDev, /* sa */
		linkid, /* da */
		bss_entry->link_id, /* sa */
		mld_sta_idx,
		action_linkid,
		linkid_bitmap,
		all_linkid_bitmap,
		elem,
		mlo_twt_ie,
		peer_entry);
}

u8 bss_mngr_con_mld_twt_action_frm_breadown(
	IN struct wifi_dev *wdev,
	IN u16 mld_sta_idx,
	IN struct _MLME_QUEUE_ELEM *elem
)
{
	/* 1->N */
	struct bmgr_entry *bss_entry = NULL;
	struct bmgr_mld_sta *mld_sta = NULL;
	struct mlo_itwt_ie *mlo_twt_ie = NULL;
	struct _HEADER_802_11 *hdr = (struct _HEADER_802_11 *)&elem->Msg;
	struct bmgr_mld_link *mld_link = NULL;
	u8 link = 0;
	u8 *ie_ptr = NULL;
	EID_STRUCT *eid_ptr;
	u16 len = 0;
	u8 action_linkid = 0;
	u16 all_linkid_bitmap = 0;
	u8 breakdown = 0;
	u16 linkid_bitmap = 0;
	u8 linkid_bitmap_present = 0;

	if (wdev)
		bss_entry = get_bss_entry_by_wdev(wdev);
	/* get mld_sta */
	if (BMGR_VALID_MLD_STA(mld_sta_idx))
		mld_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);

	if (!bss_entry || !mld_sta || !mld_sta->valid)
		return breakdown;

	/* get action linkid */
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		mld_link = &mld_sta->mld_link[link];
		if (MAC_ADDR_EQUAL(mld_link->link_addr, hdr->Addr2)) {
			action_linkid = link;
			break;
		}
	}

	/* get all_linkid_bitmap */
	ie_ptr = (u8 *)(elem->Msg + LENGTH_802_11 + 3);
	len = elem->MsgLen - (LENGTH_802_11 + 3);
	/*dump_hex_content(elem->Msg, elem->MsgLen);*/
	while (len > 0) {
		eid_ptr = (EID_STRUCT *)ie_ptr;
		mlo_twt_ie = (struct mlo_itwt_ie *)eid_ptr;
		linkid_bitmap = mlo_twt_ie->linkid_bitmap;
		linkid_bitmap_present = (u8)GET_TWT_CTRL_LINKID_BITMAP_PRESENT(mlo_twt_ie->control);
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
			"len=%d,T=%d,L=%d,linkid_bitmap_present=%d,linkid_bitmap=0x%x\n",
			len, eid_ptr->Eid, eid_ptr->Len, linkid_bitmap_present, linkid_bitmap);
		if (linkid_bitmap_present && linkid_bitmap)
			all_linkid_bitmap |= linkid_bitmap;
		else
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
				"fail. linkid_bitmap_present=%d, linkid_bitmap=0x%x\n",
				linkid_bitmap_present, linkid_bitmap);

		ie_ptr += (eid_ptr->Len + 2);
		len -= (eid_ptr->Len + 2);
	};

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
		"all_linkid_bitmap=0x%x\n", all_linkid_bitmap);

	/* use twt ie linkid to find peer_entry from mld_sta */
	ie_ptr = (u8 *)(elem->Msg + LENGTH_802_11 + 3);
	len = elem->MsgLen - (LENGTH_802_11 + 3);
	while (len > 0) {
		eid_ptr = (EID_STRUCT *)ie_ptr;
		mlo_twt_ie = (struct mlo_itwt_ie *)eid_ptr;
		linkid_bitmap = mlo_twt_ie->linkid_bitmap;

		action_frame_breakdown_with_linkid(wdev->if_dev,
			mld_sta_idx,
			elem,
			mld_sta,
			bss_entry, /* sa */
			mlo_twt_ie,
			action_linkid,
			linkid_bitmap,
			all_linkid_bitmap,
			&breakdown);

		ie_ptr += (eid_ptr->Len + 2);
		len -= (eid_ptr->Len + 2);
	};

	/* start timer to check each breadown action frame form per MLME */
	if (breakdown) {
		struct _RTMP_ADAPTER *ad = (struct _RTMP_ADAPTER *)wdev->sys_handle;
		struct bss_mlo_twt *mlo_twt = &bss_mngr.mlo_twt;
		RALINK_TIMER_STRUCT *timer = &mlo_twt->agg_action_frame_timer;

		/* this ad = action link and only action link ad does breakdown */
		os_zero_mem(timer, sizeof(RALINK_TIMER_STRUCT));
		mlo_twt->mld_sta_idx = mld_sta_idx;
		RTMPInitTimer(ad, timer, GET_TIMER_FUNCTION(bss_mngr_con_twt_agg_timeout_exec), mlo_twt, FALSE);
		RTMPSetTimer(timer, TWT_ACT_FTM_AGG_TIME);
	}

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO, "breakdown=%d\n", breakdown);

	return breakdown;
}

void bss_mngr_con_mld_twt_action_frm_agg(
	IN struct wifi_dev *wdev,
	IN struct frame_itwt_setup *itwt_setup_frame,
	IN struct MLO_TWT_PRIV_T *priv
)
{
	/* N->1*/
	struct bss_mlo_twt *mlo_twt = &bss_mngr.mlo_twt;
	struct MLO_ITWT_ELEMENT_T *element = NULL;
	struct MLO_ITWT_ELEMENT_T *temp_element = NULL;
	struct MLO_TWT_PRIV_T *_priv = NULL;
	struct MLO_TWT_PRIV_T *temp_priv = NULL;
	struct bss_mngr_event_ops *event_ops = NULL;
	u16 all_linkid_bitmap = 0;
	u16 mld_sta_idx = 0;
	u8 action_linkid = 0;
	u8 all_arrive = 0;
	u8 *out_buffer = NULL;
	u8 cnt = 0;

	if (!wdev)
		return;

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
		"(IN)A1=%pM,A2=%pM,A3=%pM from IF=%s\n",
		itwt_setup_frame->hdr.Addr1,
		itwt_setup_frame->hdr.Addr2,
		itwt_setup_frame->hdr.Addr3,
		mt_os_net_dev_get_name(wdev->if_dev));

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
		"(IN)da/sa=%s,%s,da/sa=%d,%d,mld_sta_idx=%d,action_linkid=%d,linkid_bitmap=0x%x,all_linkid_bitmap=0x%x\n",
		priv->da_net_dev->name,
		priv->sa_net_dev->name,
		priv->da_linkid, priv->sa_linkid,
		priv->mld_sta_idx,
		priv->action_linkid,
		priv->linkid_bitmap,
		priv->all_linkid_bitmap);

	/* breakdown phase creates each link priv and DA=ohter links, SA=action link */
	if (os_alloc_mem(NULL, (UCHAR **)&element, sizeof(struct MLO_ITWT_ELEMENT_T)) == NDIS_STATUS_SUCCESS) {
		os_move_mem(&element->itwt_setup_frame, itwt_setup_frame, sizeof(struct frame_itwt_setup));
		_priv = &element->priv;
		/* _priv->da_net_dev = action link */
		_priv->da_net_dev = priv->sa_net_dev;
		_priv->sa_net_dev = priv->da_net_dev;
		_priv->da_linkid = priv->sa_linkid;
		_priv->sa_linkid = priv->da_linkid;
		_priv->mld_sta_idx = priv->mld_sta_idx;
		_priv->action_linkid = priv->action_linkid;
		_priv->linkid_bitmap = priv->linkid_bitmap;
		_priv->all_linkid_bitmap = priv->all_linkid_bitmap;
		_priv->state = STATE_AGGREGATE_ACTION_FRAME;
	} else
		return;

	mld_sta_idx = priv->mld_sta_idx;
	action_linkid = priv->action_linkid;


	OS_SEM_LOCK(&mlo_twt->lock);
	/* add element to pool */
	list_add_tail(&element->list, &mlo_twt->breakdown_action_frame_list);
	list_for_each_entry(temp_element, &mlo_twt->breakdown_action_frame_list, list) {
		cnt++;
		temp_priv = &temp_element->priv;
		if (temp_priv->mld_sta_idx == mld_sta_idx) {
			all_linkid_bitmap |= temp_priv->linkid_bitmap;
			if (all_linkid_bitmap == temp_priv->all_linkid_bitmap) {
				all_arrive = 1;
				break;
			}
		}
	}

	MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
		"cnt=%d,arrive=%d\n", cnt, all_arrive);

	/* aggregate from element pool */
	if (all_arrive) {
		struct bmgr_mld_sta *mld_sta = NULL;
		struct bmgr_mld_link *mld_link = NULL;
		struct _MAC_TABLE_ENTRY *peer_entry = NULL;
		struct wifi_dev *tmp_da_wifi_dev = NULL;
		struct MLO_ITWT_ELEMENT_T *temp_element_next = NULL;
		u16 temp_all_linkid_bitmap = 0;
		u16 temp_linkid_bitmap = 0;
		ULONG len = 0;
		ULONG temp_len = 0;

		/* get action link peer entry */
		if (BMGR_VALID_MLD_STA(mld_sta_idx))
			mld_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);

		if (!mld_sta || !mld_sta->valid) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
				"fail. mld_sta not found by mld_sta_idx=%d\n", mld_sta_idx);
			goto done;
		}

		mld_link = &mld_sta->mld_link[action_linkid];
		if (!mld_link->active) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
				"fail. mld_link is not active with action_linkid=%d\n", action_linkid);
			goto done;
		}

		peer_entry = (struct _MAC_TABLE_ENTRY *)mld_link->priv_ptr;
		if (!peer_entry) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
				"fail. action link peer entry not found\n");
			goto done;
		}

		/* start to agg */
		all_linkid_bitmap = 0;
		MlmeAllocateMemory(NULL, &out_buffer);
		if (!out_buffer) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
				"fail. out_buffer=NULL\n");
			goto done;
		}

		list_for_each_entry_safe(temp_element, temp_element_next, &mlo_twt->breakdown_action_frame_list, list) {
			temp_priv = &temp_element->priv;
			if (temp_priv->mld_sta_idx == mld_sta_idx) {
				list_del(&temp_element->list);
				all_linkid_bitmap |= temp_priv->linkid_bitmap;
				temp_all_linkid_bitmap = temp_priv->all_linkid_bitmap;
				temp_linkid_bitmap = temp_priv->linkid_bitmap;
				/* temp_da_net_dev = action link */
				tmp_da_wifi_dev = mt_os_net_dev_get_wdev(temp_priv->da_net_dev);
				MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
					"mld_sta_idx=%d, linkid_bitmap=0x%x, all_linkid_bitmap=0x%x, 0x%x\n",
					mld_sta_idx, temp_linkid_bitmap, all_linkid_bitmap, temp_all_linkid_bitmap);

				/* 802.11 hdr + cat + s1g + token */
				if (len == 0) {
					struct _HEADER_802_11 *hdr = NULL;

					MakeOutgoingFrame(out_buffer, &temp_len,
						(LENGTH_802_11 + 3), &temp_element->itwt_setup_frame,
						END_OF_ARGS);
					len += temp_len;
					/* adjust A1/A2/A3 to action link */
					hdr = (struct _HEADER_802_11 *)out_buffer;
					ActHeaderInit(NULL, hdr, peer_entry->Addr, peer_entry->bssid, peer_entry->bssid);
					MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
						"peer_link_addr=%pM\n", mld_link->link_addr);
					MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
						"(OUT)A1=%pM,A2=%pM,A3=%pM,wcid=%d\n",
						hdr->Addr1, hdr->Addr2, hdr->Addr3, peer_entry->wcid);
				}
				/* tlv: mlo_itwt_ie */
				temp_element->itwt_setup_frame.twt_ie.len = sizeof(struct mlo_itwt_ie) - 2;
				MakeOutgoingFrame(out_buffer + len, &temp_len,
					sizeof(struct itwt_ie_t), &temp_element->itwt_setup_frame.twt_ie,
					2, &temp_linkid_bitmap,
					END_OF_ARGS);
				len += temp_len;

				MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_INFO,
					"(OUT)da/sa=%s,%s,da/sa=%d,%d,mld_sta_idx=%d,action_linkid=%d,linkid_bitmap=0x%x,all_linkid_bitmap=0x%x\n",
					temp_priv->da_net_dev->name,
					temp_priv->sa_net_dev->name,
					temp_priv->da_linkid, temp_priv->sa_linkid,
					temp_priv->mld_sta_idx,
					temp_priv->action_linkid,
					temp_priv->linkid_bitmap,
					temp_priv->all_linkid_bitmap);

				/*dump_hex_content(out_buffer, len);*/

				/* forward to action link = temp_da_net_dev to tx */
				if (tmp_da_wifi_dev
					&& all_linkid_bitmap == temp_all_linkid_bitmap) {
					struct bmgr_entry *bss_entry = get_bss_entry_by_wdev(
										tmp_da_wifi_dev);

					/* A1=peer link addr in build_ie(peer_twt_setup_action) */
					if (bss_entry) {
						bss_mngr_con_twt_agg_timer_cancel(mlo_twt);
						event_ops = bss_entry->entry_info.event_ops;
					}

					if (event_ops) {
						event_ops->bmgr_event_mld_twt_action_frm_agg(
							tmp_da_wifi_dev,
							out_buffer,
							(u16)len,
							peer_entry,
							mld_sta_idx,
							action_linkid,
							temp_all_linkid_bitmap);
					}
				}

				os_free_mem(temp_element);

				if (all_linkid_bitmap == temp_all_linkid_bitmap)
					break;
			}
		}
		MlmeFreeMemory(out_buffer);
	}
done:
	OS_SEM_UNLOCK(&mlo_twt->lock);
}

void bss_mngr_con_mld_twt_wait_ack_inform(
	IN struct wifi_dev *wdev,
	IN u16 mld_sta_idx,
	IN u8 action_linkid,
	IN u16 all_linkid_bitmap,
	IN u8 wait_ack_sts
)
{
	u8 link = 0;
	u8 mld_bss_idx = 0;
	struct bmgr_entry *bss_entry = NULL;
	struct bmgr_mld_sta *mld_sta = NULL;
	struct bmgr_entry *mld_bss_entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;
	struct bmgr_mld_link *mld_link = NULL;
	struct bss_mngr_event_ops *event_ops = NULL;
	struct _MAC_TABLE_ENTRY *peer_entry = NULL;

	if (!wdev)
		return;
	bss_entry = get_bss_entry_by_wdev(wdev);
	if (BMGR_VALID_MLD_STA(mld_sta_idx))
		mld_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);

	if (!bss_entry || !mld_sta || !mld_sta->valid)
		return;

	mld = bss_entry->mld_ptr;
	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error, bss_idx (%d) in mld (%d) is invalid\n",
			bss_entry->bss_idx, bss_entry->entry_info.mld_grp);
		return;
	}

	/* action link first since timer concern */
	mld_link = &mld_sta->mld_link[action_linkid];
	if (mld_link->active && (all_linkid_bitmap & 1 << action_linkid)) {
		peer_entry = (struct _MAC_TABLE_ENTRY *)mld_link->priv_ptr;
		mld_bss_idx = mld->bss_idx_mld[action_linkid];
		mld_bss_entry = BMGR_VALID_BSS_IDX(mld_bss_idx) ? GET_BSS_ENTRY_BY_IDX(mld_bss_idx) : NULL;

		if (mld_bss_entry && peer_entry) {
			event_ops = mld_bss_entry->entry_info.event_ops;
			event_ops->bmgr_event_mld_twt_wait_ack_inform(peer_entry->wdev,
				peer_entry, wait_ack_sts);
		} else
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
				"link=%d,mld_bss_entry=%p,peer_entry=%p\n",
				action_linkid, mld_bss_entry, peer_entry);
	}

	/* non-action link later */
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		mld_link = &mld_sta->mld_link[link];
		peer_entry = (struct _MAC_TABLE_ENTRY *)mld_link->priv_ptr;
		mld_bss_idx = mld->bss_idx_mld[link];
		mld_bss_entry = BMGR_VALID_BSS_IDX(mld_bss_idx) ? GET_BSS_ENTRY_BY_IDX(mld_bss_idx) : NULL;

		if (mld_link->active && link != action_linkid && (all_linkid_bitmap & 1 << link)) {
			if (mld_bss_entry && peer_entry) {
				event_ops = mld_bss_entry->entry_info.event_ops;
				event_ops->bmgr_event_mld_twt_wait_ack_inform(peer_entry->wdev,
					peer_entry, wait_ack_sts);
			} else
				MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_TWT, DBG_LVL_ERROR,
					"link=%d,mld_bss_entry=%p,peer_entry=%p\n",
					link, mld_bss_entry, peer_entry);
		}
	}
}

#ifdef MWDS
u8 bss_mngr_con_mwds_cap_sync(
	struct wifi_dev *wdev,
	u8 enable
)
{
	struct bmgr_entry *bss_entry;
	struct bmgr_entry *peer_entry = NULL;
	struct bmgr_mlo_dev *mld = NULL;
	struct bss_mngr_event_ops *event_ops = NULL;
	u8 link = 0;
	u8 bss_mld[BSS_MNGR_MAX_BAND_NUM];
	u8 ret = 0;

	if (!wdev)
		return ret;
	bss_entry = get_bss_entry_by_wdev(wdev);
	if (!bss_entry)
		return ret;

	if (BMGR_VALID_MLO_BSS_ENTRY(bss_entry)) {
		mld = bss_entry->mld_ptr;
		if (!BMGR_VALID_MLO_DEV(mld)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error, bss_idx (%d) in mld (%d) is invalid\n",
				bss_entry->bss_idx, bss_entry->entry_info.mld_grp);
			return ret;
		}
		NdisMoveMemory(bss_mld, mld->bss_idx_mld, sizeof(mld->bss_idx_mld));
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			u8 bss_idx_mld = bss_mld[link];

			if (!BMGR_VALID_BSS_IDX(bss_idx_mld))
				continue;

			peer_entry = GET_BSS_ENTRY_BY_IDX(bss_idx_mld);
			if (peer_entry) {
				event_ops = peer_entry->entry_info.event_ops;
				if (event_ops)
					ret += event_ops->bmgr_event_mld_mwds_enable(
						peer_entry->pwdev, enable);

			}
		}
	} else {
		event_ops = bss_entry->entry_info.event_ops;
		if (event_ops)
			ret = event_ops->bmgr_event_mld_mwds_enable(
							wdev, enable);
	}

	return ret;
}
#endif

void bss_mngr_con_mld_critical_update(
	IN struct wifi_dev *wdev, IN u8 upd_scope, IN u8 reason)
{
	u8 i, link, iob_upd_num = 0;
	u8 peer_bss_idx;
	u8 dev_type;
	struct bmgr_entry *entry = NULL;
	struct bmgr_entry *peer_entry, *iob_entry;
	struct bmgr_entry *updated_entry[32] = {NULL};
	struct bmgr_mlo_dev *mld = NULL;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();
	struct mld_crit_upd_info crit_upd_info;

	if (!wdev)
		return;
	entry = get_bss_entry_by_wdev(wdev);
	MTWF_DBG(NULL, DBG_CAT_AP, CATAP_BPCC, DBG_LVL_INFO,
		"upd_scope=%d, reason:%d\n", upd_scope, reason);

	if (!BMGR_VALID_BSS_ENTRY(entry)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: entry is NULL or invalid!\n");
		return;
	}

	/* skip the AP not affiliated in any AP MLD */
	if (!BMGR_VALID_MLO_BSS_ENTRY(entry)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"[%d(%s)] not affiliated in any AP MLD\n",
			entry->bss_idx, entry->pNetDev->name);
		return;
	}

	/* step 1.
	 *	increment bss_chg_cnt (depends on scope) &
	 *	re-build ie(s) in BSS mngr to sync bss_chg_cnt */
	switch (upd_scope) {
	case BMGR_CRITICAL_UPDATE_ALL:
		// traverse all iob BSS and increment the cnt
		for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
			iob_entry = GET_BSS_ENTRY_BY_IDX(i);
			if (!BMGR_VALID_MLO_BSS_ENTRY(iob_entry))
				continue;

			/* skip BSSs that in different band */
			if (iob_entry->link_id != entry->link_id)
				continue;

			iob_entry->bss_chg_cnt = (iob_entry->bss_chg_cnt + 1) % 256;
			/* 255 means AP not in MLD or no this AP info */
			if (iob_entry->bss_chg_cnt == 255)
				iob_entry->bss_chg_cnt = 0;
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"[%s] update bss_chg_cnt to %d.\n", iob_entry->pNetDev->name,
				iob_entry->bss_chg_cnt);
			bss_mngr_con_sync_ie(iob_entry);
			updated_entry[iob_upd_num] = iob_entry;
			iob_upd_num++;
		}
		break;
	case BMGR_CRITICAL_UPDATE_SINGLE:
		// update single entry
		entry->bss_chg_cnt = (entry->bss_chg_cnt + 1) % 256;
		/* 255 means AP not in MLD or no this AP info */
		if (entry->bss_chg_cnt == 255)
			entry->bss_chg_cnt = 0;
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"[%s] update bss_chg_cnt to %d.\n",
			mt_os_net_dev_get_name(wdev->if_dev), entry->bss_chg_cnt);
		bss_mngr_con_sync_ie(entry);
		updated_entry[iob_upd_num] = entry;
		iob_upd_num++;
		break;
	case BMGR_CRITICAL_UPDATE_MLD_CUF:
		// update single entry
		updated_entry[iob_upd_num] = entry;
		iob_upd_num++;
		break;
	default:
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"\t[%d] invalid scope!\n", upd_scope);
		return;
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"trigger interface(%s), iob_upd_num(%d)\n",
			mt_os_net_dev_get_name(wdev->if_dev), iob_upd_num);

	/* step 2. prepare BSS bitmap for trigger Critical Update Flag */
	/* update all APs in the same AP MLD */
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		for (i = 0; i < iob_upd_num; i++) {
			iob_entry = updated_entry[i];
			mld = iob_entry->mld_ptr;
			if (!BMGR_VALID_MLO_DEV(mld)) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
					"Fail, bss_idx (%d) in mld (%d) is invalid\n",
					iob_entry->bss_idx, iob_entry->entry_info.mld_grp);
				continue;
			}
			peer_bss_idx = mld->bss_idx_mld[link];

			if (!BMGR_VALID_BSS_IDX(peer_bss_idx))
				continue;

			peer_entry = GET_BSS_ENTRY_BY_IDX(peer_bss_idx);
			if (!BMGR_VALID_MLO_BSS_ENTRY(peer_entry))
				continue;

			dev_type = peer_entry->entry_info.dev_type;

			if (IS_DEV_TYPE_W_BCN(dev_type))
				peer_entry->mbss.crit_upd_bitmap |= (1 << 0);
			else {
				u8 bss_idx_tx = peer_entry->bss_idx_tx;
				struct bmgr_entry *tx_entry = NULL;

				/* use tx-bss to store bitmap for non-tx BSSID */
				if (BMGR_VALID_BSS_IDX(bss_idx_tx))
					tx_entry = GET_BSS_ENTRY_BY_IDX(bss_idx_tx);
				else {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
						"\t[%d] TX-BSS undefined\n", peer_bss_idx);
					continue;
				}
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
					"bmgr_entry(%d) is Nontransmitted Bssid, update to tx bmgr_entry(%d)\n",
					peer_entry->bss_idx, tx_entry->bss_idx);

				tx_entry->mbss.crit_upd_bitmap |= (1 << peer_entry->entry_info.dot11v_mbssid_idx);
				peer_entry = tx_entry;
			}

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
				"[link=%d, updated_num=%d] tx entry(%s), bitmap(0x%x)\n", link, i,
				peer_entry->pNetDev->name, peer_entry->mbss.crit_upd_bitmap);
		}
	}

	/* step 3. update bcn (link_id that trigger critical update) */
	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		peer_entry = GET_BSS_ENTRY_BY_IDX(i);

		if (!BMGR_VALID_MLO_BSS_ENTRY(peer_entry) ||
			(peer_entry->link_id != entry->link_id))
			continue;

		dev_type = peer_entry->entry_info.dev_type;
		/* tx entry && bitmap != 0 */
		if (IS_DEV_TYPE_W_BCN(dev_type) && peer_entry->mbss.crit_upd_bitmap) {
			NdisZeroMemory(&crit_upd_info, sizeof(struct mld_crit_upd_info));
			crit_upd_info.bitmap = peer_entry->mbss.crit_upd_bitmap;
			if ((upd_scope == BMGR_CRITICAL_UPDATE_MLD_CUF) ||
				BCN_REASON_EQUAL(reason, BCN_UPDATE_CSA))
				crit_upd_info.bypass_bcn_seq_bmap = crit_upd_info.bitmap;

			event_ops->bmgr_event_mld_critical_update_bcn(
				peer_entry->pwdev, &crit_upd_info, reason);

			/* reset bitmap after update bcn */
			peer_entry->mbss.crit_upd_bitmap = 0;
		}
	}

	/* step 4. update bcn (link_id that NOT trigger critical update) */
	for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
		peer_entry = GET_BSS_ENTRY_BY_IDX(i);

		if (!BMGR_VALID_MLO_BSS_ENTRY(peer_entry) ||
			(peer_entry->link_id == entry->link_id))
			continue;

		dev_type = peer_entry->entry_info.dev_type;
		/* tx entry && bitmap != 0 */
		if (IS_DEV_TYPE_W_BCN(dev_type) && peer_entry->mbss.crit_upd_bitmap) {
			NdisZeroMemory(&crit_upd_info, sizeof(struct mld_crit_upd_info));
			crit_upd_info.bitmap = peer_entry->mbss.crit_upd_bitmap;
			if ((upd_scope == BMGR_CRITICAL_UPDATE_MLD_CUF) ||
				BCN_REASON_EQUAL(reason, BCN_UPDATE_CSA))
				crit_upd_info.bypass_bcn_seq_bmap = crit_upd_info.bitmap;

			event_ops->bmgr_event_mld_critical_update_bcn(
				peer_entry->pwdev, &crit_upd_info, reason);

			/* reset bitmap after update bcn */
			peer_entry->mbss.crit_upd_bitmap = 0;
		}
	}
}

BOOLEAN bss_mngr_con_mld_critical_update_op_lock(
	struct wifi_dev *wdev, u8 lock_flag)
{
	u8 i, link, mld_bss_idx = 0, iob_upd_num = 0, traversal_iob_upd = 0;
	u8 get_lock_result[BSS_MNGR_MAX_BAND_NUM];/*0:no op, 1:get lock, 2:get fail*/
	PNET_DEV	pNetDev_per_link[BSS_MNGR_MAX_BAND_NUM] = {0};
	PNET_DEV	pNetDev_per_link_11vt[16][BSS_MNGR_MAX_BAND_NUM] = {0};
	u8 idx_11vt = 0;
	BOOLEAN final_result = TRUE, need_to_lock[BSS_MNGR_MAX_BAND_NUM];
	u8 dev_type;
	struct bmgr_entry *updated_entry[32] = {NULL};
	struct bmgr_entry *entry = NULL;
	struct bmgr_entry *mld_entry, *iob_entry;
	struct bmgr_mlo_dev *mld = NULL;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();

	if (!wdev)
		return FALSE;
	entry = get_bss_entry_by_wdev(wdev);
	if (!BMGR_VALID_BSS_ENTRY(entry)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_ERROR,
			"\x1b[41mError: entry is NULL or invalid!\x1b[m\n\r");
		return FALSE;
	}

	/* skip the AP not affiliated in any AP MLD */
	if (!BMGR_VALID_MLO_BSS_ENTRY(entry)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_ERROR,
			"\x1b[41m[%d(%s)] not affiliated in any AP MLD\x1b[m\n\r",
			entry->bss_idx, entry->pNetDev->name);
		return FALSE;
	}

	if (lock_flag == BMGR_BPCC_OP_GET_LOCK_ALL) {
		/* search all band which belong to mld group */
		for (i = 0; i < BSS_MNGR_ENTRY_CNT; i++) {
			iob_entry = GET_BSS_ENTRY_BY_IDX(i);
			if (!BMGR_VALID_MLO_BSS_ENTRY(iob_entry))
				continue;
			/* skip BSSs that in different band */
			if (iob_entry->link_id != entry->link_id)
				continue;
			updated_entry[iob_upd_num] = iob_entry;
			iob_upd_num++;
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_INFO,
				"\x1b[42m record update mld entry[%d]=0x%p,iob_upd_num=%d\x1b[m\n\r",
				i, iob_entry, iob_upd_num);
		}
	}
mld_traversal:
	final_result = TRUE;
	if (lock_flag == BMGR_BPCC_OP_GET_LOCK_ALL) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_INFO,
			"\x1b[42m traversal mld_entry=%d\x1b[m\n\r",
			traversal_iob_upd);
		if (updated_entry[traversal_iob_upd])
			mld = updated_entry[traversal_iob_upd]->mld_ptr;
		else
			mld = entry->mld_ptr;
		if (iob_upd_num > 0) {
			iob_upd_num--;
			traversal_iob_upd++;
		}
	} else
		mld = entry->mld_ptr;

	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_ERROR,
			"\x1b[41mError, bss_idx (%d) in mld (%d) is invalid\x1b[m\n\r",
			entry->bss_idx, entry->entry_info.mld_grp);
		return FALSE;
	}


	/* init all variable and wanted wdev to lock*/
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		need_to_lock[link] = TRUE;
		get_lock_result[link] = 0;
		pNetDev_per_link[link] = NULL;
		mld_bss_idx = mld->bss_idx_mld[link];
		if (!BMGR_VALID_BSS_IDX(mld_bss_idx))
			continue;
		mld_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);
		if (!BMGR_VALID_MLO_BSS_ENTRY(mld_entry))
			continue;
		/* need to replace mld_entry to 11vt */
		dev_type = mld_entry->entry_info.dev_type;
		if (IS_DEV_TYPE_11V(dev_type)) {
			u8	bss_idx_tx;

			bss_idx_tx = mld_entry->bss_idx_tx;
			/* replace as 11vt */
			mld_entry = GET_BSS_ENTRY_BY_IDX(bss_idx_tx);
			if (pNetDev_per_link_11vt[idx_11vt][link] == 0) {
				need_to_lock[link] = TRUE;
				pNetDev_per_link_11vt[idx_11vt][link] = mld_entry->pNetDev;
			} else if (pNetDev_per_link_11vt[idx_11vt][link] == mld_entry->pNetDev) {
				need_to_lock[link] = FALSE;
				pNetDev_per_link_11vt[idx_11vt][link] = mld_entry->pNetDev;
			} else if (pNetDev_per_link_11vt[idx_11vt][link] != mld_entry->pNetDev) {
				need_to_lock[link] = TRUE;
				idx_11vt++;
				pNetDev_per_link_11vt[idx_11vt][link] = mld_entry->pNetDev;
			}
		}
		pNetDev_per_link[link] = mld_entry->pNetDev;
	}
	if ((lock_flag == BMGR_BPCC_OP_GET_LOCK) ||
		(lock_flag == BMGR_BPCC_OP_GET_LOCK_ALL)) {
		/* get bss BPCC semaphore which belong to the same MLD */
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			if (!pNetDev_per_link[link])
				continue;
			if (!need_to_lock[link])
				continue;
			if (get_lock_result[link] != 1) {
				if (event_ops->bmgr_event_mld_critical_update_op_lock(pNetDev_per_link[link], BMGR_BPCC_OP_GET_LOCK, mld->mld_grp) == 1)
					get_lock_result[link] = 1;
				else {
					/* if any one fail to get, it will give up others */
					get_lock_result[link] = 2;
					final_result = FALSE;
					break;
				}
			}
		}

		if (final_result == FALSE) {
			/* release all bpcc lock if any of link fail to get its' own pbcc lock */
			for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
				if (!pNetDev_per_link[link])
					continue;

				if (get_lock_result[link] == 1)
					event_ops->bmgr_event_mld_critical_update_op_lock(pNetDev_per_link[link], BMGR_BPCC_OP_RELEASE_LOCK, mld->mld_grp);
			}

			for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
				if (!pNetDev_per_link[link])
					continue;
				if (in_interrupt())
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_DEBUG,
						"\x1b[41m MLD[%d]Band[%d]=%d Get lock fail,final_result=%d\x1b[m\n\r",
						mld->mld_grp, link, get_lock_result[link], final_result);
				else
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_INFO,
						"\x1b[41m MLD[%d]Band[%d]=%d Get lock fail,final_result=%d\x1b[m\n\r",
						mld->mld_grp, link, get_lock_result[link], final_result);
			}
		} else {
			/* reset all bpcc lock timer if get all pbcc lock */
			for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
				if (!pNetDev_per_link[link])
					continue;
				if (get_lock_result[link] == 1)
					event_ops->bmgr_event_mld_critical_update_op_lock(pNetDev_per_link[link], BMGR_BPCC_OP_RESET_LOCK_TIMER, mld->mld_grp);
			}

			for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
				if (!pNetDev_per_link[link])
					continue;
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_INFO,
					"\x1b[42m MLD[%d]Band[%d] = %d Get lock ok,final_result=%d\x1b[m\n\r",
					mld->mld_grp, link, get_lock_result[link], final_result);
			}
		}

		if ((lock_flag == BMGR_BPCC_OP_GET_LOCK_ALL) && iob_upd_num != 0) {
			if (final_result == TRUE)
				goto mld_traversal;
		}
	} else if (lock_flag == BMGR_BPCC_OP_RELEASE_LOCK) {
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			if (!pNetDev_per_link[link])
				continue;
			event_ops->bmgr_event_mld_critical_update_op_lock(pNetDev_per_link[link], BMGR_BPCC_OP_RELEASE_LOCK, mld->mld_grp);
		}
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_INFO,
			"\x1b[42m unlock all, final_result = %d\x1b[m\n\r",
			final_result);
	} else if ((lock_flag == BMGR_BPCC_OP_MLD_ID_LOG_ON) ||
			(lock_flag == BMGR_BPCC_OP_MLD_ID_LOG_OFF)) {
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			if (!pNetDev_per_link[link])
				continue;
			event_ops->bmgr_event_mld_critical_update_op_lock(pNetDev_per_link[link], lock_flag, mld->mld_grp);
		}
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BPCC, DBG_LVL_INFO,
			"\x1b[42m sync mld id, final_result = %d\x1b[m\n\r",
			final_result);
	}

	return final_result;
}

void bss_mngr_con_mld_eml_op_update(
	IN struct wifi_dev *wdev, IN struct mld_eml_op *eml_op)
{
	u8 link, mld_bss_idx;
	bool valid_update = TRUE;
	u16 mld_sta_idx = eml_op->mld_sta_idx;
	struct bmgr_entry *entry = NULL;
	struct bmgr_entry *mld_entry;
	struct bmgr_mlo_dev *mld = NULL;
	struct bmgr_mld_sta *bmgr_sta = NULL;
	struct bss_mngr_event_ops *event_ops = NULL;

	if (!wdev)
		return;
	entry = get_bss_entry_by_wdev(wdev);
	if (BMGR_VALID_MLD_STA(mld_sta_idx))
		bmgr_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);

	if (!BMGR_VALID_MLO_BSS_ENTRY(entry) || !bmgr_sta || !bmgr_sta->valid) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Invalid info: bss_entry:%p(valid:%d, mlo:%d), mld_sta:%p(valid:%d)\n",
			entry, entry ? entry->valid : 0,
			entry ? entry->mlo_en : 0,
			bmgr_sta, bmgr_sta ? bmgr_sta->valid : 0);
		return;
	}

	/* peer do not support EMLSR */
	if (!bmgr_sta->emlsr_sup)
		return;

	mld = entry->mld_ptr;
	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error, bss_idx (%d) in mld (%d) is invalid\n",
			entry->bss_idx, entry->entry_info.mld_grp);
		return;
	}

	if (!mld->attr.eml_caps.emlsr_supp) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Fail, AP MLD %d not support emlsr\n",
			mld->mld_grp);
		return;
	}

	if (eml_op->emlsr_en) {
		if (!eml_op->eml_link_bmap)
			valid_update = FALSE;
		for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
			if (eml_op->eml_link_bmap & BIT(link)) {
				mld_bss_idx = mld->bss_idx_mld[link];

				if (!BMGR_VALID_BSS_IDX(mld_bss_idx)) {
					valid_update = FALSE;
					break;
				}

				/* associated link && support EMLSR */
				mld_entry = GET_BSS_ENTRY_BY_IDX(mld_bss_idx);
				if (!BMGR_VALID_MLO_BSS_ENTRY(mld_entry) ||
					!bmgr_sta->mld_link[link].active) {
					valid_update = FALSE;
					break;
				}
			}
		}
	} else
		eml_op->eml_link_bmap = 0;

	if (valid_update) {
		/* update peer MLD info */
		bmgr_sta->emlsr_en = eml_op->emlsr_en;
		bmgr_sta->emlsr_link_bmap = eml_op->eml_link_bmap;

		eml_op->eml_omn_en = mld->attr.eml_caps.eml_omn_en;

		event_ops = entry->entry_info.event_ops;
		if (event_ops) {
			event_ops->bmgr_event_mld_eml_op_update(entry->pwdev, eml_op);
		} else
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
				"Error: event_ops is not inited");
	} else {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Invalid notif: en(%d), link_bmap(%d)",
			eml_op->emlsr_en, eml_op->eml_link_bmap);
	}

}

static bool mld_link_recomm_sanity(
	IN u8 mld_grp_idx,
	IN struct mld_link_recomm *link_recomm
)
{
	u8 i, link;
	u16 mld_sta_num;
	struct bmgr_mld_sta *bmgr_sta;
	struct mld_recomm_sta_info *recomm_sta_info;

	if (!BMGR_VALID_MLD_GRP_IDX(mld_grp_idx))
		return FALSE;

	if (!link_recomm)
		return FALSE;

	mld_sta_num = link_recomm->mld_sta_num;
	if (!mld_sta_num) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Without any recommended MLD STA!\n");
		return FALSE;
	}

	recomm_sta_info = (struct mld_recomm_sta_info *)link_recomm->mld_sta_info;
	for (i = 0; i < link_recomm->mld_sta_num; i++, recomm_sta_info++) {
		if (!BMGR_VALID_MLD_STA(recomm_sta_info->mld_sta_idx)) {
			recomm_sta_info->valid = FALSE;
			mld_sta_num--;
			continue;
		}

		bmgr_sta = GET_MLD_STA_BY_IDX(recomm_sta_info->mld_sta_idx);
		if (!bmgr_sta->valid || (bmgr_sta->mld_grp_idx != mld_grp_idx)) {
			recomm_sta_info->valid = FALSE;
			mld_sta_num--;
			continue;
		}

		for (link = 0; link < (BSS_MNGR_MAX_LINK_ID + 1); link++) {
			if (!bmgr_sta->mld_link[link].active)
				recomm_sta_info->recomm_links &= ~(BIT(link));
		}

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_INFO,
			"final recommend link 0x%x\n", recomm_sta_info->recomm_links);

		if (recomm_sta_info->recomm_links == 0) {
			recomm_sta_info->valid = FALSE;
			mld_sta_num--;
			continue;
		}
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_NOTICE,
		"num of recommended MLD STA after sanity: %d\n", mld_sta_num);

	if (mld_sta_num == 0)
		return FALSE;

	return TRUE;
}

/*
 * Note that mld_recomm_sta_info pointed to by mld_sta_info in link_recomm
 * must be arranged in ascending order of AID
 */
void bss_mngr_con_mld_tx_link_recomm(
	IN u8 mld_grp_idx,
	IN u16 tx_link_bmap,
	IN struct mld_link_recomm *link_recomm)
{
	struct bmgr_mlo_dev *mld = NULL;
	u8 *f_buf = NULL, *pos;
	u8 link, bss_idx;
	u16 buf_len;
	struct bmgr_entry *entry;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();

	if (!mld_link_recomm_sanity(mld_grp_idx, link_recomm)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Sanity failed!\n");
		return;
	}

#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(mld_grp_idx);
#else
	mld = GET_MLD_BY_GRP_IDX(mld_grp_idx);
#endif
	if (!BMGR_VALID_MLO_DEV(mld))
		return;

	/* 1. build generic frame body */

	/* alloc 1024 bytes buffer */
	os_alloc_mem(NULL, (u8 **)&f_buf, BSS_MNGR_MAX_INFO_LEN);
	if (!f_buf)
		goto err;
	NdisZeroMemory(f_buf, BSS_MNGR_MAX_INFO_LEN);
	pos = f_buf;

	/* build AID Bitmap IE */
	pos = build_aid_bitmap_ie(link_recomm, pos);

	/* build MLT IE */
	pos = build_link_recomm_multi_link_traffic_ie(link_recomm, pos);

	buf_len = (u16)(pos - f_buf);

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_DEBUG,
		"buf_len %d\n", buf_len);

	if (!buf_len)
		goto err;

	/* 2. based on link, build frame header and transmit by bmgr_event */
	for (link = 0; link < BSS_MNGR_MAX_BAND_NUM; link++) {
		if (!(tx_link_bmap & BIT(link)))
			continue;

		bss_idx = mld->bss_idx_mld[link];
		if (!BMGR_VALID_BSS_IDX(bss_idx))
			continue;

		entry = GET_BSS_ENTRY_BY_IDX(bss_idx);
		if (!BMGR_VALID_MLO_BSS_ENTRY(entry))
			continue;

		event_ops->bmgr_event_mld_tx_link_recomm(entry->pwdev,
			link_recomm->reason_code, f_buf, buf_len);
	}

err:
	if (f_buf)
		os_free_mem(f_buf);
}

/**
 * @brief Basic check for Link Reconfiguration Operations
 *
 * This function validates LR operation requests by checking:
 *	1. the added link requested by non-AP MLD is affiliated with in AP MLD
 *	2. if non-AP MLD requests add to a connected link, it shall include delete
 *		operation for the connected link in LR Request frm.
 *	3. the deleted link requested by non-AP MLD is connected before Link Reconifg.
 *	4. the Link Address in Per-STA Profile for deleted link operation shall
 *		match the Link Address of connected link.
 *
 * @param mld AP MLD.
 * @param bmgr_sta non-AP (peer) MLD.
 * @param lr_req struct to handle Link Reconfiguration Request
 * @return int: Returns 0 on success, otherwise an error codes.
 */
static int bss_mngr_link_reconfig_req_op_check(
	IN struct bmgr_mlo_dev *mld,
	IN struct bmgr_mld_sta *bmgr_sta,
	IN struct mld_link_reconfig_req *lr_req
)
{
	u8 pf_idx;
	struct ml_ie_info *reconfig_ml_info = lr_req->reconfig_ml_info;
	struct bmgr_mld_link *peer_link;
	struct mld_link_reconfig_op_info *op_info;
	struct ml_ie_link *op_pf;

	if (!mld || !bmgr_sta) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: null input\n");
		return -EINVAL;
	}

	for (pf_idx = 0; pf_idx < reconfig_ml_info->num_per_sta_pf; pf_idx++) {
		op_pf = &reconfig_ml_info->link[pf_idx];
		op_info = &lr_req->per_op_info[pf_idx];

		if (MLD_LR_OP_IS_DECISION_DONE(op_info))
			continue;

		peer_link = &bmgr_sta->mld_link[op_pf->link_id];

		switch (op_pf->reconfig_type) {
		case ML_RECONFIG_OP_TYPE_ADD_LINK:
			/* check the added link id exists in AP MLD */
			if (!BMGR_VALID_BSS_IDX(mld->bss_idx_mld[op_pf->link_id])) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
					"Reject op %d add (ap no link)\n", pf_idx);

				MLD_LR_OP_SET_DECISION(op_info, MLME_REQUEST_DECLINED, MLD_LR_STS_SELF_NO_LINK);

				/* Link-Reconfig-Req Debug Cmd */
				MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, op_pf->reconfig_type,
					op_pf->link_id, MLME_REQUEST_DECLINED, MLD_LR_STS_SELF_NO_LINK);
				log_lr_op(LOG_EHT_LR_SANITY_ADD, "Sanity-Add", DBG_LVL_DEBUG, &lr_req->lr_log);
				/*****/
				continue;
			}

			/* check must include del op for
			 * link addition to a connected link (link id) */
			if (peer_link->active) {
				struct mld_link_reconfig_op_info *del_op_info;
				u8 del_pf_idx;

				if (!(lr_req->req_deleted_link_id_bmap & BIT(op_pf->link_id))) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
						"Reject op %d add (shall delete connected link): lk_id=%d\n",
						pf_idx, op_pf->link_id);

					MLD_LR_OP_SET_DECISION(op_info, MLME_REQUEST_DECLINED, MLD_LR_STS_NO_DEL);

					/* Link-Reconfig-Req Debug Cmd */
					MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, op_pf->reconfig_type,
						op_pf->link_id, MLME_REQUEST_DECLINED, MLD_LR_STS_NO_DEL);
					log_lr_op(LOG_EHT_LR_SANITY_ADD, "Sanity-Add", DBG_LVL_DEBUG, &lr_req->lr_log);
					/*****/
					continue;
				}

				/* check del op success */
				del_pf_idx = lr_req->map_del_link_id_2_sta_pf[op_pf->link_id];
				del_op_info = &lr_req->per_op_info[del_pf_idx];

				if (!MLD_LR_OP_IS_SUCCESS(del_op_info)) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
						"Reject op %d add (del before add fail): lk_id=%d\n",
						pf_idx, op_pf->link_id);

					MLD_LR_OP_SET_DECISION(op_info, MLME_REQUEST_DECLINED, MLD_LR_STS_NO_DEL);

					/* Link-Reconfig-Req Debug Cmd */
					MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, op_pf->reconfig_type,
						op_pf->link_id, MLME_REQUEST_DECLINED, MLD_LR_STS_NO_DEL);
					log_lr_op(LOG_EHT_LR_SANITY_ADD, "Sanity-Add", DBG_LVL_DEBUG, &lr_req->lr_log);
					/*****/
					continue;
				}

				/* NOTE: SW not handle delete & add same link id in one LR.req */
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
					"Reject op %d add (add a connected link): lk_id=%d\n",
					pf_idx, op_pf->link_id);

				MLD_LR_OP_SET_DECISION(op_info, MLME_REQUEST_DECLINED, MLD_LR_STS_ADD_EXIST_LINK);

				/* Link-Reconfig-Req Debug Cmd */
				MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, op_pf->reconfig_type,
					op_pf->link_id, MLME_REQUEST_DECLINED, MLD_LR_STS_ADD_EXIST_LINK);
				log_lr_op(LOG_EHT_LR_SANITY_ADD, "Sanity-Add", DBG_LVL_DEBUG, &lr_req->lr_log);
				/*****/
				continue;
			}
			break;

		case ML_RECONFIG_OP_TYPE_DELETE_LINK:
			/* same behaviour in eht_peer_mld_link_reconfig_req_del_link_basic_sanity */

			/* check link id connected */
			if (!peer_link->active) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
					"Reject op %d del (not connected link)\n", pf_idx);

				MLD_LR_OP_SET_DECISION(op_info, MLME_REQUEST_DECLINED, MLD_LR_STS_PEER_NO_LINK);

				/* Link-Reconfig-Req Debug Cmd */
				MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, op_pf->reconfig_type,
					op_pf->link_id, MLME_REQUEST_DECLINED, MLD_LR_STS_PEER_NO_LINK);
				log_lr_op(LOG_EHT_LR_SANITY_DELETE, "Sanity-Del", DBG_LVL_DEBUG, &lr_req->lr_log);
				/*****/
				continue;
			}

			/* check link id & link addr matched to connected link */
			if (!MAC_ADDR_EQUAL(peer_link->link_addr, op_pf->link_addr)) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
					"Reject op %d del (addr mismatch)\n", pf_idx);

				MLD_LR_OP_SET_DECISION(op_info,
					MLME_REQUEST_WITH_INVALID_PARAM, MLD_LR_STS_ADDR_MISMATCH);

				/* Link-Reconfig-Req Debug Cmd */
				MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, op_pf->reconfig_type,
					op_pf->link_id, MLME_REQUEST_WITH_INVALID_PARAM, MLD_LR_STS_ADDR_MISMATCH);
				log_lr_op(LOG_EHT_LR_SANITY_DELETE, "Sanity-Del", DBG_LVL_DEBUG, &lr_req->lr_log);
				/*****/
				continue;
			}
			break;

		default:
			/* rejected in collect_info */
			break;
		}
	}

	return 0;
}

/**
 * @brief Added Link Decision Maker for Add Link Reconfiguration Operations
 *
 * This function build association for requested added links.
 *
 * @param mld AP MLD.
 * @param bmgr_sta non-AP (peer) MLD.
 * @param lr_req struct to handle Link Reconfiguration Request
 * @return int: Returns 0 on success, otherwise an error codes.
 */
static int bss_mngr_link_reconfig_req_add_link_decision(
	IN struct bmgr_mlo_dev *mld,
	IN struct bmgr_mld_sta *bmgr_sta,
	IN struct mld_link_reconfig_req *lr_req
)
{
	int ret = 0;
	u8 pf_idx;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();
	struct ml_ie_info *reconfig_ml_info = lr_req->reconfig_ml_info;
	struct mld_link_reconfig_op_info *op_info;
	struct ml_ie_link *op_pf;

	u8 add_link_bss_idx, add_link_id;
	struct bmgr_entry *add_link_entry;
	struct bmgr_mld_link *add_link_peer;

	u16 add_links_gtk_len = 0;
	struct bmgr_lr_event lr_event;
	struct lr_event_link_decision *link_decision;
	struct time_log tl;

	if (!mld || !bmgr_sta) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: null input\n");
		return -EINVAL;
	}

	/* no add op */
	if (!lr_req->req_added_link_id_bmap)
		return 0;

	for (pf_idx = 0; pf_idx < reconfig_ml_info->num_per_sta_pf; pf_idx++) {
		op_pf = &reconfig_ml_info->link[pf_idx];
		op_info = &lr_req->per_op_info[pf_idx];

		if ((op_pf->reconfig_type == ML_RECONFIG_OP_TYPE_ADD_LINK) &&
			!MLD_LR_OP_IS_DECISION_DONE(op_info)) {

			/* basic sanity for STA Profile subfield */
			if (op_pf->sta_profile_len <= LENGTH_802_11_CAP_INFO) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
					"Reject op %d add (invalid sta profile,link=%d,pf_len=%d)\n",
					pf_idx, op_pf->link_id, op_pf->sta_profile_len);

				MLD_LR_OP_SET_DECISION(op_info,
					MLME_REQUEST_WITH_INVALID_PARAM, MLD_LR_STS_NO_ADD_LINK_PF);

				/* Link-Reconfig-Req Debug Cmd */
				MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, op_pf->reconfig_type,
					op_pf->link_id, MLME_REQUEST_WITH_INVALID_PARAM, MLD_LR_STS_NO_ADD_LINK_PF);
				log_lr_op(LOG_EHT_LR_SANITY_ADD, "Sanity-Add", DBG_LVL_DEBUG, &lr_req->lr_log);
				/*****/
				continue;
			}

			add_link_id = op_pf->link_id;
			add_link_peer = &bmgr_sta->mld_link[add_link_id];
			add_link_bss_idx = mld->bss_idx_mld[add_link_id];

			/* already verified in bss_mngr_link_reconfig_req_op_check() */
			if (!BMGR_VALID_BSS_IDX(add_link_bss_idx)) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
					"Reject op %d add (ap no link=%d)\n", pf_idx, add_link_id);

				MLD_LR_OP_SET_DECISION(op_info, MLME_REQUEST_DECLINED, MLD_LR_STS_SELF_NO_LINK);

				/* Link-Reconfig-Req Debug Cmd */
				MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, op_pf->reconfig_type,
					op_pf->link_id, MLME_REQUEST_DECLINED, MLD_LR_STS_SELF_NO_LINK);
				log_lr_op(LOG_EHT_LR_SANITY_ADD, "Sanity-Add", DBG_LVL_DEBUG, &lr_req->lr_log);
				/*****/
				continue;
			}
			add_link_entry = GET_BSS_ENTRY_BY_IDX(add_link_bss_idx);

			/* check link is not adding */
			if (add_link_peer->priv_temp_ptr) {
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
					"Reject op %d add (link=%d adding)\n", pf_idx, add_link_id);

				MLD_LR_OP_SET_DECISION(op_info, MLME_REQUEST_DECLINED, MLD_LR_STS_LINK_ADDING_REJ);

				/* Link-Reconfig-Req Debug Cmd */
				MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, op_pf->reconfig_type,
					op_pf->link_id, MLME_REQUEST_DECLINED, MLD_LR_STS_LINK_ADDING_REJ);
				log_lr_op(LOG_EHT_LR_SANITY_ADD, "Sanity-Add", DBG_LVL_DEBUG, &lr_req->lr_log);
				/*****/
				continue;
			}

			log_time_begin(LOG_TIME_UNIT_US, &tl);
			/* Link-Reconfig Event to make decision for add link request */
			bss_mngr_lr_event_init(&lr_event,
				BMGR_LR_EVENT_ADD_LINK_DECISION, lr_req->mld_sta_idx, bmgr_sta->mld_addr);
			link_decision = &lr_event.link_decision;
			link_decision->lr_frm_link_ptr = lr_req->lr_frm_link_ptr;
			COPY_MAC_ADDR(link_decision->self_mld_addr, mld->mld_addr);
			link_decision->gtk_len = add_links_gtk_len;
			link_decision->pwdev = add_link_entry->pwdev;
			link_decision->op_pf = op_pf;
			link_decision->op_info = op_info;
			link_decision->added_link_status = MLME_UNSPECIFY_FAIL;
			link_decision->priv_ptr_temp_entry = NULL;

			ret = event_ops->bmgr_event_mld_peer_link_reconfig(&lr_event);
			log_time_end(LOG_TIME_CONNECTION, "lr_add_link_decision", DBG_LVL_DEBUG, &tl);

			/* save the decision result */
			MLD_LR_OP_SET_DECISION(op_info, link_decision->added_link_status,
				(link_decision->added_link_status == MLME_SUCCESS) ?
					MLD_LR_STS_ACCEPT : MLD_LR_STS_ADD_FAIL);

			if (MLD_LR_OP_IS_SUCCESS(op_info)) {
				if (!link_decision->priv_ptr_temp_entry) {
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
						"Reject op %d add (MLME_SUCCESS but no link=%d temp entry)\n",
						pf_idx, add_link_id);

					MLD_LR_OP_SET_DECISION(op_info, MLME_UNSPECIFY_FAIL, MLD_LR_STS_ADD_FAIL);

					/* Link-Reconfig-Req Debug Cmd */
					MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, op_pf->reconfig_type,
						op_pf->link_id, MLME_UNSPECIFY_FAIL, MLD_LR_STS_ADD_FAIL);
					log_lr_op(LOG_EHT_LR_SANITY_ADD, "Sanity-Add", DBG_LVL_DEBUG, &lr_req->lr_log);
					/*****/
					continue;
				}

				add_link_peer->priv_temp_ptr = link_decision->priv_ptr_temp_entry;

				lr_req->at_least_one_link_success_add = TRUE;

				add_links_gtk_len += op_info->add_link_gtk_len;
			}

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
				"%s op %d add (link_id=%d, status=0x%x, temp_ptr=%p)\n",
				MLD_LR_OP_IS_SUCCESS(op_info) ? "accept" : "reject",
				pf_idx, add_link_id, link_decision->added_link_status,
				add_link_peer->priv_temp_ptr);

			/* Link-Reconfig-Req Debug Cmd */
			if (!MLD_LR_OP_IS_SUCCESS(op_info)) {
				MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, op_pf->reconfig_type,
					op_pf->link_id, link_decision->added_link_status, MLD_LR_STS_ADD_FAIL);
				log_lr_op(LOG_EHT_LR_SANITY_ADD, "Sanity-Add", DBG_LVL_DEBUG, &lr_req->lr_log);
			}
			/*****/
		}
	}

	return 0;
}

/**
 * @brief Make final decision for Link Reconfiguration Operations
 *
 * This function is based on the result of the added link association to check
 * whether there is no any link after Link Reconfiguration, which is
 * not allowed in spec. If this happens, will reject the delete link
 * for the setup (data) link to make sure at least one link is connected
 * after applying Link Reconfiguration.
 *
 * @param bmgr_sta non-AP (peer) MLD.
 * @param lr_req struct to handle Link Reconfiguration Request
 * @return int: Returns 0 on success, otherwise an error codes.
 */
static int bss_mngr_link_reconfig_req_op_final_decision(
	IN struct bmgr_mld_sta *bmgr_sta,
	IN struct mld_link_reconfig_req *lr_req
)
{
	u8 pf_idx, link_id;
	struct bmgr_mld_link *peer_link;
	struct mld_link_reconfig_op_info *op_info;

	if (!bmgr_sta) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: null input\n");
		return -EINVAL;
	}

	if (!lr_req->req_deleted_link_id_bmap) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
			"Info: No delete op\n");
		return 0;
	}

	if (lr_req->to_be_plan_update_data_link) {
		/* there is connected link do not be deleted */
		for (link_id = 0; link_id < BSS_MNGR_MAX_BAND_NUM; link_id++) {
			peer_link = &bmgr_sta->mld_link[link_id];

			if (peer_link->active) {
				if (!(lr_req->req_deleted_link_id_bmap & BIT(link_id))) {
					lr_req->new_data_link_id = link_id;
					return 0;
				}

				/* check del op status */
				pf_idx = lr_req->map_del_link_id_2_sta_pf[link_id];
				op_info = &lr_req->per_op_info[pf_idx];

				if (!MLD_LR_OP_IS_SUCCESS(op_info)) {
					lr_req->new_data_link_id = link_id;
					return 0;
				}
			}
		}

		/* delete all links, check any add operations accpeted */
		if (!(lr_req->req_added_link_id_bmap && lr_req->at_least_one_link_success_add)) {
			/* reject a delete link op to avoid no link -> choose original data link */
			pf_idx = lr_req->map_del_link_id_2_sta_pf[bmgr_sta->data_link_id];
			op_info = &lr_req->per_op_info[pf_idx];

			MLD_LR_OP_SET_DECISION(op_info, MLME_REQUEST_DECLINED, MLD_LR_STS_DEL_NO_LINK);

			lr_req->to_be_plan_update_data_link = FALSE;
			// lr_req->require_stop_tx = FALSE;

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
				"Reject del ops pf(%d) link id(%d) (delete all w/o add)\n",
				pf_idx, bmgr_sta->data_link_id);

			/* Link-Reconfig-Req Debug Cmd */
			MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, ML_RECONFIG_OP_TYPE_DELETE_LINK,
				bmgr_sta->data_link_id, MLME_REQUEST_DECLINED, MLD_LR_STS_DEL_NO_LINK);
			log_lr_op(LOG_EHT_LR_SANITY_DELETE, "Sanity-Del", DBG_LVL_DEBUG, &lr_req->lr_log);
			/*****/
		} else {
			/* there is at least one add link op success */
			;
		}
	}

	return 0;
}

/**
 * @brief Link Reconfiguration execution order planner
 *
 * This function plans execution order for the Link Reconfiguration
 * operations and the setup link update.
 *
 * @param lr_req struct to handle Link Reconfiguration Request
 * @return int: Returns 0 on success, otherwise an error codes.
 */
static int bss_mngr_link_reconfig_op_planner(
	IN struct mld_link_reconfig_req *lr_req
)
{
	struct link_reconfig_op_tuple *op_tuple = lr_req->op_list;

	u8 pf_idx, num_accept_op = 0, num_apply_op = 0;
	struct ml_ie_info *reconfig_ml_info = lr_req->reconfig_ml_info;
	struct mld_link_reconfig_op_info *op_info;
	struct ml_ie_link *op_pf;

	for (pf_idx = 0; pf_idx < reconfig_ml_info->num_per_sta_pf; pf_idx++) {
		op_pf = &reconfig_ml_info->link[pf_idx];
		op_info = &lr_req->per_op_info[pf_idx];

		if (!MLD_LR_OP_IS_DECISION_DONE(op_info)) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
				"Warn: %d-th op %d link id %d miss\n",
				pf_idx, op_pf->reconfig_type, op_pf->link_id);
		}
	}

	/* link that connected but not deleted */
	if (lr_req->to_be_plan_update_data_link && lr_req->new_data_link_id != MLD_LINK_MAX) {
		op_tuple->op_type = MLD_LR_OP_UPDATE_DATA_LINK;
		op_tuple->op_link_id = lr_req->new_data_link_id;
		lr_req->to_be_plan_update_data_link = FALSE;

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
			"LR Planner Data Link (conn) %d\n", op_tuple->op_link_id);

		op_tuple++;
		num_apply_op++;
	}

	/* Apply Delete Links */
	if (lr_req->req_deleted_link_id_bmap) {
		for (pf_idx = 0; pf_idx < reconfig_ml_info->num_per_sta_pf; pf_idx++) {
			op_pf = &reconfig_ml_info->link[pf_idx];
			op_info = &lr_req->per_op_info[pf_idx];

			if (MLD_LR_OP_IS_SUCCESS(op_info)) {
				if (op_pf->reconfig_type == ML_RECONFIG_OP_TYPE_DELETE_LINK) {
					op_tuple->op_type = MLD_LR_OP_DELETE_LINK;
					op_tuple->op_link_id = op_pf->link_id;

					lr_req->at_least_one_link_success_delete = TRUE;
					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
						"LR Planner Del %d\n", op_tuple->op_link_id);

					op_tuple++;
					num_accept_op++;
					num_apply_op++;
				}
			}
		}
	}

	/* Apply Add Links */
	if (lr_req->req_added_link_id_bmap) {
		for (pf_idx = 0; pf_idx < reconfig_ml_info->num_per_sta_pf; pf_idx++) {
			op_pf = &reconfig_ml_info->link[pf_idx];
			op_info = &lr_req->per_op_info[pf_idx];

			if (MLD_LR_OP_IS_SUCCESS(op_info)) {
				if (op_pf->reconfig_type == ML_RECONFIG_OP_TYPE_ADD_LINK) {
					if (lr_req->to_be_plan_update_data_link) {
						/* update data link (if required) asap. */
						lr_req->new_data_link_id = op_pf->link_id;

						op_tuple->op_type = MLD_LR_OP_ADD_AND_UPDATE_DATA_LINK;
						lr_req->to_be_plan_update_data_link = FALSE;
					} else
						op_tuple->op_type = MLD_LR_OP_ADD_LINK;

					op_tuple->op_link_id = op_pf->link_id;

					MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
						"LR Planner Add%s %d\n",
						(op_tuple->op_type == MLD_LR_OP_ADD_LINK) ?
							"" : "+UpdateDataLink",
						op_tuple->op_link_id);

					op_tuple++;
					num_accept_op++;
					num_apply_op++;
				}
			}
		}
	}

	/* Update Setup link if required, not enter in P1 */
	if (lr_req->to_be_plan_update_data_link) {
		if (lr_req->new_data_link_id == MLD_LINK_MAX) {
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
				"Error: No new data link can be planned\n");

			return -EINVAL;
		}

		op_tuple->op_type = MLD_LR_OP_UPDATE_DATA_LINK;
		op_tuple->op_link_id = lr_req->new_data_link_id;

		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
			"LR Planner Data Link (last) %d\n", op_tuple->op_link_id);

		op_tuple++;
		num_apply_op++;
	}

	/* sanity */
	if (num_apply_op >= lr_req->max_num_op_tuple)
		goto err;

	lr_req->num_accepted_op = num_accept_op;
	lr_req->num_op_tuple = num_apply_op;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_INFO,
		"LR Planner Results num_apply_op=%d (num_accept_op=%d)\n",
		lr_req->num_op_tuple, lr_req->num_accepted_op);

	return 0;

err:
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
		"LR Planner error num_apply_op=%d\n", num_apply_op);
	return -ENOMEM;
}

/**
 * @brief Link Reconfiguration Requested Op validation and execution order plan
 *
 * This function validates LR ops and plan execution order of ops by planner.
 *
 * @param mld AP MLD.
 * @param bmgr_sta non-AP (peer) MLD.
 * @param lr_req struct to handle Link Reconfiguration Request
 * @return int: Returns 0 on success, otherwise an error codes.
 */
static int bss_mngr_link_reconfig_op_validate_and_plan(
	IN struct bmgr_mlo_dev *mld,
	IN struct bmgr_mld_sta *bmgr_sta,
	IN struct mld_link_reconfig_req *lr_req
)
{
	int ret = 0;

	if (!lr_req) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: null input\n");
		return -EINVAL;
	}

	mutex_lock(&bss_mngr.op_mutex);
	if (!bmgr_sta || !bmgr_sta->valid) {
		mutex_unlock(&bss_mngr.op_mutex);
		ret = -EINVAL;
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: invalid mld_sta:%p (valid:%d)\n",
			bmgr_sta, bmgr_sta ? bmgr_sta->valid : 0);
		goto err;
	}

	if (!BMGR_VALID_MLO_DEV(mld)) {
		mutex_unlock(&bss_mngr.op_mutex);
		ret = -EINVAL;
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: mld_sta(%d) conn to mld(%d) is invalid\n",
			bmgr_sta->idx, bmgr_sta->mld_grp_idx);
		goto err;
	}

	if (bss_mngr_link_reconfig_req_op_check(mld, bmgr_sta, lr_req)) {
		mutex_unlock(&bss_mngr.op_mutex);
		goto err;
	}

	/* requested add link decision (status & STA Profile) */
	if (bss_mngr_link_reconfig_req_add_link_decision(mld, bmgr_sta, lr_req)) {
		mutex_unlock(&bss_mngr.op_mutex);
		goto err;
	}

	/* second sanity that reject delete if no add accepted */
	if (bss_mngr_link_reconfig_req_op_final_decision(bmgr_sta, lr_req)) {
		mutex_unlock(&bss_mngr.op_mutex);
		goto err;
	}
	mutex_unlock(&bss_mngr.op_mutex);

	/* planner: plan the Link Reconfig Operations execution order during Apply LR */
	if (bss_mngr_link_reconfig_op_planner(lr_req))
		goto err;

	return 0;
err:
	return -EINVAL;
}

/**
 * @brief Apply Link Reconfiguration
 *
 * This function applies Link Reconfiguration according to the
 * planner's planned execution order.
 *
 * @param mld AP MLD.
 * @param bmgr_sta non-AP (peer) MLD.
 * @param lr_req struct to handle Link Reconfiguration Request
 * @return int: Returns 0 on success, otherwise an error codes.
 */
static int bss_mngr_link_reconfig_op_apply(
	IN struct bmgr_mlo_dev *mld,
	IN struct bmgr_mld_sta *bmgr_sta,
	IN struct mld_link_reconfig_req *lr_req
)
{
	int ret = 0;
	u8 link_bss_idx;

	struct link_reconfig_op_tuple *op_tuple;
	struct ml_ie_info *reconfig_ml_info = lr_req->reconfig_ml_info;
	struct ml_ie_link *op_pf;

	struct bmgr_lr_event lr_event;
	struct bss_mngr_event_ops *event_ops = bmgr_event_ops_get();
	struct bmgr_mld_link *peer_link;
	struct time_log tl;
	u8 tuple_i, op_link_id, pf_idx, add_op_type;

	mutex_lock(&bss_mngr.op_mutex);

	if (!bmgr_sta || !bmgr_sta->valid) {
		mutex_unlock(&bss_mngr.op_mutex);
		ret = -EINVAL;
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: invalid mld_sta:%p (valid:%d)\n",
			bmgr_sta, bmgr_sta ? bmgr_sta->valid : 0);
		goto err;
	}

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
		"mld_sta_idx=%d (%pM), apply %d ops (req=%d, accept=%d ops)\n",
		bmgr_sta->idx, bmgr_sta->mld_addr, lr_req->num_op_tuple,
		reconfig_ml_info->num_per_sta_pf, lr_req->num_accepted_op);

	if (!BMGR_VALID_MLO_DEV(mld)) {
		mutex_unlock(&bss_mngr.op_mutex);
		ret = -EINVAL;
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: mld_sta(%d) conn to mld(%d) is invalid\n",
			bmgr_sta->idx, bmgr_sta->mld_grp_idx);
		goto err;
	}

	/* 1. Apply Delete Links first to FW to stop tx on deleted links */
	if (lr_req->at_least_one_link_success_delete) {
		u16 del_link_id_bmap = 0;

		log_time_begin(LOG_TIME_UNIT_US, &tl);
		for (tuple_i = 0; tuple_i < lr_req->num_op_tuple; tuple_i++) {
			op_tuple = &lr_req->op_list[tuple_i];

			if (op_tuple->op_type == MLD_LR_OP_DELETE_LINK)
				del_link_id_bmap |= BIT(op_tuple->op_link_id);
		}

		bss_mngr_lr_event_init(&lr_event,
			BMGR_LR_EVENT_HW_DEL_LINKS, lr_req->mld_sta_idx, bmgr_sta->mld_addr);
		lr_event.hw_del_links.del_link_id_bmap = del_link_id_bmap;
		lr_event.hw_del_links.lr_frm_link_ptr = lr_req->lr_frm_link_ptr;
		ret = event_ops->bmgr_event_mld_peer_link_reconfig(&lr_event);
		log_time_end(LOG_TIME_CONNECTION, "lr_cmd_del_link", DBG_LVL_DEBUG, &tl);

		if (ret) {
			mutex_unlock(&bss_mngr.op_mutex);
			goto err;
		}
	}

	/* 2. Apply Link Reconfiguration based on the execution order planned
	 * by LR Planner. During processing, also considers the status difference
	 * of both AP MLD and non-AP MLD between Sanity LR phase and Apply LR
	 * phase (occurs AP ML Reconfiguration or non-AP Link Reconfiguration).
	 */
	for (tuple_i = 0; tuple_i < lr_req->num_op_tuple; tuple_i++) {
		op_tuple = &lr_req->op_list[tuple_i];
		op_link_id = op_tuple->op_link_id;

		peer_link = &bmgr_sta->mld_link[op_link_id];

		switch (op_tuple->op_type) {
		case MLD_LR_OP_ADD_LINK:
		case MLD_LR_OP_ADD_AND_UPDATE_DATA_LINK:
			pf_idx = lr_req->map_add_link_id_2_sta_pf[op_link_id];
			op_pf = &reconfig_ml_info->link[pf_idx];

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
				"add%s link_id=%d,pf_idx=%d,addr=%pM,temp_ptr=%p,active=%d,priv=%p\n",
				(op_tuple->op_type == MLD_LR_OP_ADD_LINK) ? "" : "+UpdateDataLink",
				op_link_id, pf_idx, op_pf->link_addr, peer_link->priv_temp_ptr,
				peer_link->active, peer_link->priv_ptr);

			/* sanity: check AP link exists */
			link_bss_idx = mld->bss_idx_mld[op_link_id];
			if (!BMGR_VALID_BSS_IDX(link_bss_idx)) {
				mutex_unlock(&bss_mngr.op_mutex);
				ret = -EINVAL;
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_WARN,
					"Warn: no ap link, link_bss_idx(%d) link_id(%d)\n",
					link_bss_idx, op_link_id);
				goto err;
			}

			/* sanity: (inited) temp mac entry exists */
			if (!peer_link->priv_temp_ptr) {
				mutex_unlock(&bss_mngr.op_mutex);
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
					"Error: NULL temp_entry, add link_id=%d,pf_idx=%d,addr=%pM\n",
					op_link_id, pf_idx, op_pf->link_addr);
				ret = -ENODEV;
				goto err;
			}

			log_time_begin(LOG_TIME_UNIT_US, &tl);
			/* Apply LR event for add link - update hash table and mld_entry add link */
			add_op_type = (op_tuple->op_type == MLD_LR_OP_ADD_LINK) ?
				BMGR_LR_EVENT_APPLY_ADD_LINK : BMGR_LR_EVENT_APPLY_ADD_UPDATE_DATA_LINK;
			bss_mngr_lr_event_init(&lr_event,
				add_op_type, lr_req->mld_sta_idx, bmgr_sta->mld_addr);
			lr_event.link_entry.add_link_ptr = peer_link->priv_temp_ptr;
			ret = event_ops->bmgr_event_mld_peer_link_reconfig(&lr_event);
			if (ret) {
				mutex_unlock(&bss_mngr.op_mutex);
				goto err;
			}

			COPY_MAC_ADDR(peer_link->link_addr, op_pf->link_addr);
			/* TBD: based on Per-STA Profile - NSTR Bmap to set Str Bmap */
			peer_link->str_bmap = BITS(0, BSS_MNGR_MAX_BAND_NUM - 1);
			peer_link->priv_ptr = peer_link->priv_temp_ptr;
			peer_link->priv_temp_ptr = NULL;
			peer_link->active = TRUE;

			if (op_tuple->op_type == MLD_LR_OP_ADD_AND_UPDATE_DATA_LINK)
				bmgr_sta->data_link_id = op_link_id;

			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_DEBUG,
				"add link_id(%d), pEntry(%p)\n",
				op_link_id, peer_link->priv_ptr);

			log_time_end(LOG_TIME_CONNECTION, "lr_add_link", DBG_LVL_DEBUG, &tl);

			/* Link-Reconfig-Req Debug Cmd */
			MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, pf_idx, ML_RECONFIG_OP_TYPE_ADD_LINK,
				op_link_id, MLME_SUCCESS, MLD_LR_STS_ACCEPT);
			log_lr_op(LOG_EHT_LR_APPLY_ADD, "Apply-Add", DBG_LVL_DEBUG, &lr_req->lr_log);
			/*****/
			break;

		case MLD_LR_OP_DELETE_LINK:
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
				"delete link_id=%d,addr=%pM,temp_ptr=%p,active=%d,priv=%p\n",
				op_link_id, peer_link->link_addr, peer_link->priv_temp_ptr,
				peer_link->active, peer_link->priv_ptr);

			log_time_begin(LOG_TIME_UNIT_US, &tl);
			ret = bss_mngr_con_mld_sta_del_link(peer_link, MLD_DISC_OP_LR_DEL_LINK);
			if (ret != NDIS_STATUS_SUCCESS) {
				mutex_unlock(&bss_mngr.op_mutex);
				ret = -EBUSY;
				MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
					"Fail: mld_sta delete link id %d\n", op_link_id);
				goto err;
			}

			log_time_end(LOG_TIME_CONNECTION, "lr_delete_link", DBG_LVL_DEBUG, &tl);

			/* Link-Reconfig-Req Debug Cmd */
			MLD_LR_LOG_SET_FIELDS(&lr_req->lr_log, 0xFF, ML_RECONFIG_OP_TYPE_DELETE_LINK,
				op_link_id, MLME_SUCCESS, MLD_LR_STS_ACCEPT);
			log_lr_op(LOG_EHT_LR_APPLY_DELETE, "Apply-Del", DBG_LVL_DEBUG, &lr_req->lr_log);
			/*****/
			break;

		case MLD_LR_OP_UPDATE_DATA_LINK:
			MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
				"update data link_id=%d,addr=%pM,temp_ptr=%p,active=%d,priv=%p\n",
				op_link_id, peer_link->link_addr, peer_link->priv_temp_ptr,
				peer_link->active, peer_link->priv_ptr);

			log_time_begin(LOG_TIME_UNIT_US, &tl);
			bss_mngr_lr_event_init(&lr_event,
				BMGR_LR_EVENT_UPDATE_DATA_LINK, lr_req->mld_sta_idx, bmgr_sta->mld_addr);
			lr_event.update_data_link.new_data_link_id = op_link_id;
			ret = event_ops->bmgr_event_mld_peer_link_reconfig(&lr_event);
			if (ret) {
				mutex_unlock(&bss_mngr.op_mutex);
				goto err;
			}

			bmgr_sta->data_link_id = op_link_id;

			log_time_end(LOG_TIME_CONNECTION, "lr_upd_data_link", DBG_LVL_DEBUG, &tl);
			break;

		case MLD_LR_OP_START_DATA:
			break;

		case MLD_LR_OP_STOP_DATA:
			break;

		default:
			break;
		}
	}

	mutex_unlock(&bss_mngr.op_mutex);

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_NOTICE,
		"Apply LR Success mld_sta_idx=%d (%pM)\n",
		bmgr_sta->idx, bmgr_sta->mld_addr);

	return 0;

err:
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
		"Error: apply LR=%d\n", ret);
	return ret;
}

/**
 * @brief Post-Link-Reconfiguration Update
 *
 * This function performs update ops after Link Reconfiguration.
 *
 * @param mld AP MLD.
 * @param bmgr_sta non-AP (peer) MLD.
 * @param lr_req struct to handle Link Reconfiguration Request
 * @return int: Returns 0 on success, otherwise an error codes.
 */
static int bss_mngr_link_reconfig_post_update(
	IN struct bmgr_mlo_dev *mld,
	IN struct bmgr_mld_sta *bmgr_sta,
	IN struct mld_link_reconfig_req *lr_req
)
{
	int ret = 0;
	struct ml_ie_info *reconfig_ml_info = lr_req->reconfig_ml_info;
	struct time_log tl;

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_INFO,
		"mld_sta_idx=%d(%pM), post LR update\n",
		lr_req->mld_sta_idx, reconfig_ml_info->mld_addr);

	log_time_begin(LOG_TIME_UNIT_US, &tl);

	/* TBD: TTLM */

	/* TBD: MLD-Level Capability update */

	// log_time_end(LOG_TIME_CONNECTION, "lr_post", DBG_LVL_DEBUG, &tl);

	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_INFO,
		"Post LR update done\n");

	return ret;

/*
err:
	MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_RECONFIG, DBG_LVL_ERROR,
		"Error: Post LR Update ret=%d\n", ret);
	return ret;
*/
}

static int bss_mngr_con_mld_peer_link_reconfig_req(
	IN struct mld_link_reconfig_req *lr_req,
	IN enum _BMGR_LINK_RECONFIG_REQ_OP op
)
{
	int ret;
	struct bmgr_mlo_dev *mld = NULL;
	struct bmgr_mld_sta	*bmgr_sta = NULL;

	if (BMGR_VALID_MLD_STA(lr_req->mld_sta_idx))
		bmgr_sta = GET_MLD_STA_BY_IDX(lr_req->mld_sta_idx);

	if (!bmgr_sta || !bmgr_sta->valid) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: invalid mld_sta:%p (valid:%d)\n",
			bmgr_sta, bmgr_sta ? bmgr_sta->valid : 0);
		goto err;
	}

	/* AP MLD or non-AP MLD do not support Link Reconfiguration Operation */
	if (!bmgr_sta->link_reconfig_cap) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_WARN,
			"not support LR Op, mld_sta_idx=%d\n",
			bmgr_sta->idx);
		goto err;
	}

#ifdef MLD_GROUP_ID_REMAPPING_V1
	mld = mld_idx_mapping_v1_load(bmgr_sta->mld_grp_idx);
#else
	mld = BMGR_VALID_MLD_GRP_IDX(bmgr_sta->mld_grp_idx) ?
		GET_MLD_BY_GRP_IDX(bmgr_sta->mld_grp_idx) : NULL;
#endif
	if (!BMGR_VALID_MLO_DEV(mld)) {
		MTWF_DBG(NULL, DBG_CAT_MLO, CATMLO_BMGR, DBG_LVL_ERROR,
			"Error: invalid mld idx %d\n", bmgr_sta->mld_grp_idx);
		goto err;
	}

	switch (op) {
	case BMGR_LR_REQ_VAL_AND_PLAN:
		ret = bss_mngr_link_reconfig_op_validate_and_plan(mld, bmgr_sta, lr_req);
		if (ret)
			goto err;
		break;

	case BMGR_LR_REQ_APPLY:
		ret = bss_mngr_link_reconfig_op_apply(mld, bmgr_sta, lr_req);
		if (ret)
			goto err;
		break;

	case BMGR_LR_REQ_POST_UPDATE:
		ret = bss_mngr_link_reconfig_post_update(mld, bmgr_sta, lr_req);
		if (ret)
			goto err;
		break;

	default:
		goto err;
	}

	return NDIS_STATUS_SUCCESS;

err:
	/* caller handles error
	 *	Sanity LR: drop LR.req
	 *	Apply LR: disconnection
	 */
	return NDIS_STATUS_FAILURE;
}

#ifdef PRE_CFG_SUPPORT
u16 pre_cfg_mld_sta_add(
	IN struct wifi_dev *wdev,
	IN struct ml_ie_info *ml_info,
	IN UCHAR * setup_link_addr
)
{
	UINT16 mld_sta_idx = BMGR_MAX_MLD_STA_CNT;
	struct bmgr_entry *bss_entry = NULL;
	struct bmgr_mld_sta *bmgr_sta = NULL;

	if (!wdev)
		return mld_sta_idx;
	bss_entry = get_bss_entry_by_wdev(wdev);
	mld_sta_idx = mld_sta_idx_acquire(bss_entry, ml_info->mld_addr, SUBTYPE_AUTH, setup_link_addr);

	if (BMGR_VALID_MLO_BSS_ENTRY(bss_entry) && BMGR_VALID_MLD_STA(mld_sta_idx)) {
		bmgr_sta = GET_MLD_STA_BY_IDX(mld_sta_idx);
		mld_sta_create(bss_entry, ml_info, bmgr_sta);

		/* sanity check done */
		if (bmgr_sta->valid) {
			/* aid = mld_sta_idx + 1024 */
			bmgr_sta->aid = mld_sta_idx + START_MLD_STA_AID;
			bmgr_sta->BAOriTID = 0;
			bmgr_sta->BARecTID = 0;
			bmgr_sta->mld_link[0].str_bmap = 7;
			bmgr_sta->mld_link[1].str_bmap = 7;
			bmgr_sta->mld_link[2].str_bmap = 7;
			bmgr_sta->eml_caps = 0x1;
			bmgr_sta->emlsr_sup = 0x1;

			bss_mngr_con_mld_sta_add_links(bss_entry, bmgr_sta);
			bss_mngr_con_mld_sta_notify(wdev, mld_sta_idx);
		}
	} else {
		MTWF_DBG(NULL, DBG_CAT_TEST, CATTEST_PRECFG, DBG_LVL_ERROR,
			", invalid bss_entry or mld_sta.\n");
	}
	return mld_sta_idx;
}

#ifdef APCLI_SUPPORT
u16 pre_cfg_mld_ap_add(
	IN struct wifi_dev *wdev,
	IN struct ml_ie_info *ml_info
)
{
	struct mld_dev *mld = wdev->mld_dev;
	struct mld_link_entry *set_up_link = NULL;
	struct peer_mld_entry *peer = NULL;
	MAC_TABLE_ENTRY *pEntry = NULL;
	uint8_t i = 0, link_num = 0;
	uint16_t setup_wcid = 0;
	uint8_t setup_link_link_id = 0;
	struct mld_entry_para_t mld_entry_para = {0};

	set_up_link = get_sta_mld_link_by_wdev(mld, wdev);

	if (!set_up_link) {
		MTWF_DBG(NULL, DBG_CAT_TEST, CATTEST_PRECFG, DBG_LVL_ERROR,
					", invalid set_up_link.\n");
		return -1;
	}

	/* 1. disconnect current connection*/
	if (mld->peer_mld.valid)
		sta_mld_disconn_req(wdev);

	/* 3. parse mld ie*/
	ml_info->eml_caps = 0x1;
	ml_info->emlsr_sup = 0x1;
	ml_info->mld_caps = 0x1;

	set_up_link->is_setup_link = 1;

	peer = &mld->peer_mld;
	/* 4. fill peer mld info*/
	COPY_MAC_ADDR(peer->mld_addr, ml_info->mld_addr);
	peer->valid = 1;
	peer->idx = PEER_AP_MLD_IDX;
	peer->aid = peer->idx + START_MLD_STA_AID;
	peer->set_up_link = set_up_link;
	peer->BAOriTID = 0;
	peer->BARecTID = 0;

	mld_entry_para.mld_sta_idx = peer->idx;
	mld_entry_para.mld_addr = peer->mld_addr;
	if (mld_entry_add(wdev->sys_handle, &mld_entry_para))
		return -1;

	/*first insert set_up_link.*/
	for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++) {
		MTWF_DBG(NULL, DBG_CAT_TEST, CATTEST_PRECFG, DBG_LVL_ERROR,
				", [%d].active: %d\n",
				i, ml_info->link[i].active);
		if (ml_info->link[i].active && set_up_link == &mld->mld_own_links[i]) {
			MTWF_DBG(NULL, DBG_CAT_TEST, CATTEST_PRECFG, DBG_LVL_ERROR,
				"%s, MLD insert link(set_up_link): MacAddr = "MACSTR", i = %d, active = %d!\n", __func__,
				MAC2STR(ml_info->link[i].link_addr), i, ml_info->link[i].active);

			sta_mld_insert_link(mld, peer, ml_info, i, i, &setup_wcid, set_up_link, &link_num);
		}
	}
	/*insert other links*/
	for (i = 0; i < BSS_MNGR_MAX_BAND_NUM; i++) {
		MTWF_DBG(NULL, DBG_CAT_TEST, CATTEST_PRECFG, DBG_LVL_ERROR,
				", [%d].active: %d\n",
				i, ml_info->link[i].active);
		if (set_up_link == &mld->mld_own_links[i])
			continue;

		if (ml_info->link[i].active) {
			MTWF_DBG(NULL, DBG_CAT_TEST, CATTEST_PRECFG, DBG_LVL_ERROR,
				", MLD insert link: MacAddr = "MACSTR", i = %d, active = %d!\n",
				MAC2STR(ml_info->link[i].link_addr), i, ml_info->link[i].active);

			MTWF_DBG(NULL, DBG_CAT_TEST, CATTEST_PRECFG, DBG_LVL_ERROR,
				", wdev = %p\n", mld->mld_own_links[i].wdev);

			sta_mld_insert_link(mld, peer, ml_info, i, i, &setup_wcid, set_up_link, &link_num);
		}
	}

	/* 6. fill mlo info for each mac table entry*/
	for (i = 0; i < MLD_LINK_MAX; i++) {
		pEntry = (MAC_TABLE_ENTRY *)peer->single_link[i].priv_ptr;
		if (pEntry) {
			struct mld_entry_add_link_para_t link_para = {0};

			pEntry = peer->single_link[i].priv_ptr;
			if (pEntry->wdev == set_up_link->wdev)
				setup_link_link_id = pEntry->mlo.link_info.link_id;
			link_para.mld_sta_idx = peer->idx;
			link_para.mld_addr = peer->mld_addr;
			link_para.link_id = pEntry->mlo.link_info.link_id;
			link_para.str_map = 0x07;
			link_para.pEntry = pEntry;

			if (mld_entry_add_link(&link_para) == NDIS_STATUS_SUCCESS)
				fill_peer_mlo_info(peer, link_num, pEntry->wdev == set_up_link->wdev ? 1 : 0,
					setup_wcid, &pEntry->mlo);
		}
	}

	/*7. notify mld_entry to set setup_link and reserve necessary resource*/
	if (link_num > 0) {
		struct mld_entry_notify_para_t notify_para = {0};

		notify_para.mld_sta_idx = peer->idx;
		notify_para.mld_addr = peer->mld_addr;
		notify_para.eml_caps = ml_info->eml_caps;
		notify_para.setup_link_wcid = setup_wcid;
		notify_para.setup_link_link_id = setup_link_link_id;
		notify_para.lrr = 0;
		mld_entry_notify(wdev->sys_handle, &notify_para);
	}

	mld->peer_mld.valid = 1;

	return 0;
}
#endif /* APCLI_SUPPORT */
#endif /* PRE_CFG_SUPPORT */

#endif /* DOT11_EHT_BE */

struct bss_mngr_ops bmgr_ops = {
	.bmgr_init = bss_mngr_con_init,
	.bmgr_deinit = bss_mngr_con_deinit,
	.bmgr_bss_reg = bss_mngr_con_dev_reg,
	.bmgr_bss_dereg = bss_mngr_con_dev_dereg,
	.bmgr_bss_update = bss_mngr_con_dev_update,
	.bmgr_show_info = bss_mngr_con_info_show,
	.bmgr_ie_update = bss_mngr_con_ie_update,
	.bmgr_sync_bcn_update = bss_mngr_con_sync_bcn_update,
	.bmgr_mld_get_pad_by_band_idx = bss_mngr_get_pad_by_band_idx,
#ifdef DOT11V_MBSSID_SUPPORT
	.bmgr_query_mbss_info = bss_mngr_con_query_mbss_ie,
#endif
	.bmgr_query_rnr_info = bss_mngr_con_query_rnr_ie,
	.bmgr_query_is_repted_ssid = bss_mngr_con_query_is_repted_ssid,
	.bmgr_query_is_mld_wdev = bss_mngr_con_query_is_mld_enabled,
	.bmgr_query_is_in_mlo_csa = bss_mngr_con_query_is_in_mlo_csa,
#ifdef CONFIG_6G_SUPPORT
	.bmgr_update_he_bss_discov = bss_mngr_con_update_he_bss_discov,
#endif
	.bmgr_query_netdev_by_band = bss_mngr_con_query_netdev_by_band,
#ifdef DOT11_EHT_BE
	.bmgr_mld_group_create = bss_mngr_con_mld_group_create,
	.bmgr_mld_group_destroy = bss_mngr_con_mld_group_destroy,
	.bmgr_mld_group_attr_set = bss_mngr_con_mld_group_attr_set,
	.bmgr_mld_group_add_link = bss_mngr_con_mld_group_add_link,
	.bmgr_mld_group_del_link = bss_mngr_con_mld_group_del_link,
	.bmgr_query_mld_info = bss_mngr_con_query_mld_info,
	.bmgr_query_tid_to_link_info = bss_mngr_con_query_tid_to_link_map_ie,
	.bmgr_query_multi_link_traffic_ie = bss_mngr_con_query_multi_link_traffic_ie,
	.bmgr_mld_reconfig_ie_op = bss_mngr_con_mld_reconfig_ie_op,
	.bmgr_mld_query_netdev_by_link = bss_mngr_con_mld_query_netdev_by_link,
	.bmgr_mld_conn_req = bss_mngr_con_mld_conn_req,
	.bmgr_mld_conn_act = bss_mngr_con_mld_conn_act,
	.bmgr_mld_disconn_op = bss_mngr_con_mld_disconn_op,
	.bmgr_mld_sta_notify = bss_mngr_con_mld_sta_notify,
	.bmgr_mld_add_sta_profile = bss_mngr_con_mld_add_sta_profile,
	.bmgr_mld_remove_sta_profile = bss_mngr_con_mld_remove_sta_profile,
	.bmgr_mld_sync_ml_probe_rsp_per_sta_profile = bss_mngr_con_sync_ml_probe_rsp_per_sta_profile,
	.bmgr_mld_ba_add_to_asic = bss_mngr_con_mld_ba_add_to_asic,
	.bmgr_mld_ba_del_from_asic = bss_mngr_con_mld_ba_del_from_asic,
	.bmgr_mld_forward_action_to_link = bss_mngr_con_mld_twt_action_frm_forward,
	.bmgr_mld_breakdown_action_frame = bss_mngr_con_mld_twt_action_frm_breadown,
	.bmgr_mld_aggregate_action_frame = bss_mngr_con_mld_twt_action_frm_agg,
	.bmgr_mld_twt_wait_ack_inform = bss_mngr_con_mld_twt_wait_ack_inform,
#ifdef MWDS
	.bmgr_mld_mwds_cap_sync = bss_mngr_con_mwds_cap_sync,
#endif
	.bmgr_mld_critical_update_trigger = bss_mngr_con_mld_critical_update,
	.bmgr_mld_critical_update_op_lock = bss_mngr_con_mld_critical_update_op_lock,
	.bmgr_mld_eml_op_update = bss_mngr_con_mld_eml_op_update,
	.bmgr_mld_bss_linkup = bss_mngr_con_mld_bss_linkup,
	.bmgr_mld_bss_linkdown = bss_mngr_con_mld_bss_linkdown,
	.bmgr_mld_bmc_sn_qry = bss_mngr_con_mld_bmc_sn_qry,
	.bmgr_mld_tx_link_recomm = bss_mngr_con_mld_tx_link_recomm,
	.bmgr_mld_reconfig_peer_mld = bss_mngr_con_mld_reconfig_peer_mld,
	.bmgr_mld_peer_link_reconf_req = bss_mngr_con_mld_peer_link_reconfig_req,
	.bmgr_mld_group_addr_set = bss_mngr_con_mld_group_addr_set,
#endif
};

