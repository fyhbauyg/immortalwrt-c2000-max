/*
 * Copyright (c) [2020], MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws.
 * The information contained herein is confidential and proprietary to
 * MediaTek Inc. and/or its licensors.
 * Except as otherwise provided in the applicable licensing terms with
 * MediaTek Inc. and/or its licensors, any reproduction, modification, use or
 * disclosure of MediaTek Software, and information contained herein, in whole
 * or in part, shall be strictly prohibited.
*/
/*
 ***************************************************************************
 ***************************************************************************

	Module Name:
	cmm_mat_pppoe.c

	Abstract:
	    MAT convert engine subroutine for PPPoE protocol.Due to the difference
	of characteristic of PPPoE discovery stage and session stage, we seperate
	that as two parts and used different stretegy to handle it.

	Revision History:
	Who			When			What
	--------	----------		----------------------------------------------
	Shiang      02/26/07      Init version
*/

#ifdef MAT_SUPPORT

#include "rt_config.h"

static NDIS_STATUS MATProto_PPPoEDis_Init(MAT_STRUCT *pMatStruct);
static NDIS_STATUS MATProto_PPPoEDis_Exit(MAT_STRUCT *pMatStruct);
static PUCHAR MATProto_PPPoEDis_Rx(MAT_STRUCT *pMatStruct, PNDIS_PACKET pSkb, PUCHAR pLayerHdr, PUCHAR pDevMacAdr);
static PUCHAR MATProto_PPPoEDis_Tx(MAT_STRUCT *pMatStruct, PNDIS_PACKET pSkb, PUCHAR pLayerHdr, PUCHAR pDevMacAdr);

static NDIS_STATUS MATProto_PPPoESes_Init(MAT_STRUCT *pMatStruct);
static NDIS_STATUS MATProto_PPPoESes_Exit(MAT_STRUCT *pMatStruct);
static PUCHAR MATProto_PPPoESes_Rx(MAT_STRUCT *pMatStruct, PNDIS_PACKET pSkb, PUCHAR pLayerHdr, PUCHAR pDevMacAdr);
static PUCHAR MATProto_PPPoESes_Tx(MAT_STRUCT *pMatStruct, PNDIS_PACKET pSkb, PUCHAR pLayerHdr, PUCHAR pDevMacAdr);


/*
		  1                 2               3             4
    0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |  VER  | TYPE  |      CODE     |          SESSION_ID           |
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   |            LENGTH             |           payload             ~
   +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

	VER = 0x1, TYPE =0x1

PPPoE Discovery Stage(Ethernet protocol type = 0x8863):
	PADI:
		DESTINATION_ADDR = 0xffffffff
		CODE = 0x09, SESSION_ID = 0x0000
		LENGTH = payload length

	PADO:
		DESTINATION_ADDR = Unicast Ethernet address of sender
		CODE = 0x07, SESSION_ID = 0x0000
		LENGTH = payload length
		NEcessary TAGS: AC-NAME(0x0102), Sevice-Name(0x0101), and other service names.

		Note: if the PPPoE server cannot serve the PADI it MUST NOT respond with a PADO


	PADR:
		DESTINATION_ADDR = unicast Ethernet address
		CODE = 0x19, SESSION_ID = 0x0000
		LENGTH = payload length
		Necessary TAGS: Service-Name(0x0101)
		Optional TAGS: ....

	PADS:
		If success:
			DESTINATION_ADDR = unicast Ethernet address
			CODE = 0x65, SESSION_ID = unique value for this pppoe session.(16 bits)
			LENGHT - payload length
			Necessary TAGS: Service-Name(0x0101)

		if failed:
			SESSION_ID = 0x0000
			Necessary TAGS: Service-Name-Error(0x0201).

	PADT:
		DESTINATION_ADDR = unicast Ethernet address
		CODE = 0xa7, SESSION_ID = previous assigned 16 bits session ID.
		Necessary TAGS: NO.

PPPoE Session Stage(Ethernet protocol type = 0x8864):
	PPP data:
		DESTINATION_ADDR = unicast Ethernet address
		CODE = 0x00,
	LCP:
		DESTINATION_ADDR = unicast Ethernet address
		CODE = 0x00,

*/

#define PPPOE_CODE_PADI			0x09
#define PPPOE_CODE_PADO			0x07
#define PPPOE_CODE_PADR			0x19
#define PPPOE_CODE_PADS			0x65
#define PPPOE_CODE_PADT			0xa7
#define PPPOE_TAG_ID_HOST_UNIQ	0x0103
#define PPPOE_TAG_ID_AC_COOKIE	0x0104

#define PPPoE_SES_ENTRY_AGEOUT_TIME 3000

/* Data structure used for PPPoE discovery stage */
#define PPPOE_DIS_UID_LEN		6
typedef struct _UidMacMappingEntry {
	UCHAR isServer;
	UCHAR uIDAddByUs;				 /* If the host-uniq or AC-cookie is add by our driver, set it as 1, else set as 0. */
	UCHAR uIDStr[PPPOE_DIS_UID_LEN]; /* String used for identify who sent this pppoe packet in discovery stage. */
	UCHAR macAddr[MAC_ADDR_LEN];	 /* Mac address associated to this uid string. */
	ULONG lastTime;
	RTMP_HLIST_NODE list;
} UidMacMappingEntry, *PUidMacMappingEntry;

typedef struct _UidMacMappingTable {
	BOOLEAN valid;
	RTMP_HLIST_HEAD uidHash[MAT_MAX_HASH_ENTRY_SUPPORT];
} UidMacMappingTable;

/* "Host-Uniq <-> Mac Address" Mapping table used for PPPoE Discovery stage */

/* Data struct used for PPPoE session stage */
typedef struct _SesMacMappingEntry {
	UINT16	sessionID;	/* In network order */
	UCHAR	outMacAddr[MAC_ADDR_LEN];
	UCHAR	inMacAddr[MAC_ADDR_LEN];
	ULONG	lastTime;
	RTMP_HLIST_NODE	list;
} SesMacMappingEntry, *PSesMacMappingEntry;

typedef struct _SesMacMappingTable {
	BOOLEAN valid;
	RTMP_HLIST_HEAD sesHash[MAT_MAX_HASH_ENTRY_SUPPORT];
} SesMacMappingTable;

/* Declaration of protocol handler for PPPoE Discovery stage */
struct _MATProtoOps MATProtoPPPoEDisHandle = {
	.init = MATProto_PPPoEDis_Init,
	.tx = MATProto_PPPoEDis_Tx,
	.rx = MATProto_PPPoEDis_Rx,
	.exit = MATProto_PPPoEDis_Exit,
};

/* Declaration of protocol handler for PPPoE Session stage */
struct _MATProtoOps MATProtoPPPoESesHandle = {
	.init = MATProto_PPPoESes_Init,
	.tx = MATProto_PPPoESes_Tx,
	.rx = MATProto_PPPoESes_Rx,
	.exit = MATProto_PPPoESes_Exit,
};


NDIS_STATUS dumpSesMacTb(
	IN MAT_STRUCT *pMatCfg,
	IN int hashIdx)
{
	SesMacMappingTable *pSesMacTable;
	int startIdx, endIdx;

	pSesMacTable = (SesMacMappingTable *)pMatCfg->MatTableSet.SesMacTable;

	if ((!pSesMacTable) || (!pSesMacTable->valid)) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_MAT, DBG_LVL_ERROR, "SesMacTable not init yet, so cannot do dump!\n");
		return FALSE;
	}

	if (hashIdx < 0) {
		/* dump all. */
		startIdx = 0;
		endIdx = MAT_MAX_HASH_ENTRY_SUPPORT - 1;
	} else {
		/* dump specific hash index. */
		startIdx = endIdx = hashIdx;
	}

	MTWF_PRINT("%s():\n", __func__);

	for (; startIdx <= endIdx; startIdx++) {
		SesMacMappingEntry *pEntry;
		RTMP_HLIST_NODE *pTmp;

		RtmpHashListForEachSafe(pEntry, pTmp, &pSesMacTable->sesHash[startIdx], list) {
			MTWF_PRINT("SesMac[%d]:\n", startIdx);
			MTWF_PRINT("\tsesID=%d,inMac="MACSTR",outMac="MACSTR",lastTime=0x%lx\n",
					 pEntry->sessionID, MAC2STR(pEntry->inMacAddr), MAC2STR(pEntry->outMacAddr), pEntry->lastTime);
		}
	}

	MTWF_PRINT("\t----EndOfDump!\n");
	return TRUE;
}


NDIS_STATUS dumpUidMacTb(MAT_STRUCT *pMatCfg, int hashIdx)
{
	UidMacMappingTable *pUidMacTable;
	UidMacMappingEntry *pEntry;
	RTMP_HLIST_NODE *pTmp;
	int i;
	int startIdx, endIdx;
	pUidMacTable = (UidMacMappingTable *)pMatCfg->MatTableSet.UidMacTable;

	if ((!pUidMacTable) || (!pUidMacTable->valid)) {
		MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_MAT, DBG_LVL_ERROR, "UidMacTable not init yet, so cannot do dump!\n");
		return FALSE;
	}

	if (hashIdx < 0) {
		/* dump all. */
		startIdx = 0;
		endIdx = MAT_MAX_HASH_ENTRY_SUPPORT - 1;
	} else {
		/* dump specific hash index. */
		startIdx = endIdx = hashIdx;
	}

	MTWF_PRINT("%s():\n", __func__);

	for (; startIdx <= endIdx; startIdx++) {
		RtmpHashListForEachSafe(pEntry, pTmp, &pUidMacTable->uidHash[startIdx], list) {
			MTWF_PRINT("UidMac[%d]:\n", startIdx);
			MTWF_PRINT("\tisSrv=%d, uIDAddbyUs=%d, Mac="MACSTR", lastTime=0x%lx\n",
					 pEntry->isServer, pEntry->uIDAddByUs, MAC2STR(pEntry->macAddr), pEntry->lastTime);
			MTWF_PRINT("\tuIDStr=");

			for (i = 0; i < PPPOE_DIS_UID_LEN; i++)
				MTWF_PRINT("%02x", pEntry->uIDStr[i]);

			MTWF_PRINT("\n");
		}
	}

	MTWF_PRINT("\t----EndOfDump!\n");
	return TRUE;
}


static NDIS_STATUS UidMacTable_RemoveAll(
	IN MAT_STRUCT *pMatCfg)
{
	UidMacMappingTable *pUidMacTable;
	INT             i;
	pUidMacTable = (UidMacMappingTable *)pMatCfg->MatTableSet.UidMacTable;

	if (!pUidMacTable)
		return TRUE;

	if (pUidMacTable->valid) {
		pUidMacTable->valid = FALSE;

		for (i = 0; i < MAT_MAX_HASH_ENTRY_SUPPORT; i++) {
			UidMacMappingEntry *pEntry;
			RTMP_HLIST_NODE *pTmp;

			RtmpHashListForEachSafe(pEntry, pTmp, &pUidMacTable->uidHash[i], list) {
				RtmpHashListDel(&(pEntry->list));
				MATDBEntryFree(pMatCfg, (PUCHAR)pEntry);
			}
		}
	}

	os_free_mem(pMatCfg->MatTableSet.UidMacTable);
	pMatCfg->MatTableSet.UidMacTable = NULL;
	return TRUE;
}


static NDIS_STATUS SesMacTable_RemoveAll(
	IN MAT_STRUCT *pMatCfg)
{
	SesMacMappingTable *pSesMacTable;
	INT             i;
	pSesMacTable = (SesMacMappingTable *)pMatCfg->MatTableSet.SesMacTable;

	if (!pSesMacTable)
		return TRUE;

	if (pSesMacTable->valid) {
		pSesMacTable->valid = FALSE;

		for (i = 0; i < MAT_MAX_HASH_ENTRY_SUPPORT; i++) {
			SesMacMappingEntry *pEntry;
			RTMP_HLIST_NODE *pTmp;

			RtmpHashListForEachSafe(pEntry, pTmp, &pSesMacTable->sesHash[i], list) {
				RtmpHashListDel(&(pEntry->list));
				MATDBEntryFree(pMatCfg, (PUCHAR)pEntry);
			}
		}
	}

	os_free_mem(pMatCfg->MatTableSet.SesMacTable);
	pMatCfg->MatTableSet.SesMacTable = NULL;
	return TRUE;
}


static PUidMacMappingEntry UidMacTableUpdate(
	IN MAT_STRUCT		*pMatCfg,
	IN PUCHAR			pInMac,
	IN PUCHAR			pOutMac,
	IN PUCHAR			pTagInfo,
	IN UINT16			tagLen,
	IN UINT16			isServer)
{
	UINT				hashIdx, i = 0, uIDAddByUs = 0;
	UidMacMappingTable	*pUidMacTable;
	UidMacMappingEntry	*pEntry, *pNewEntry;
	RTMP_HLIST_NODE		*pTmp;
	UCHAR				hashVal = 0;
	PUCHAR				pUIDStr = NULL;
	ULONG				now;
	pUidMacTable = (UidMacMappingTable *)pMatCfg->MatTableSet.UidMacTable;

	if ((!pUidMacTable) || (!pUidMacTable->valid))
		return NULL;

	if (pTagInfo && tagLen > 0) {
		pUIDStr = pTagInfo;
		uIDAddByUs = 0;
		tagLen = (tagLen > PPPOE_DIS_UID_LEN ? PPPOE_DIS_UID_LEN : tagLen);
	} else {
		/*
			We assume the station just have one role,i.e., just a PPPoE server or just a PPPoE client.
			For a packet send by server, we use the destination MAC as our uIDStr
			For a packet send by client, we use the source MAC as our uIDStr.
		*/
		pUIDStr = isServer ? pOutMac : pInMac;
		tagLen = MAC_ADDR_LEN;
		uIDAddByUs = 1;
	}

	for (i = 0; i < tagLen; i++)
		hashVal ^= (pUIDStr[i] & 0xff);

	hashIdx = hashVal % MAT_MAX_HASH_ENTRY_SUPPORT;

	/*First, check if the hashIdx exists */
	RtmpHashListForEachSafe(pEntry, pTmp, &pUidMacTable->uidHash[hashIdx], list) {
		NdisGetSystemUpTime(&now);

		/* Find the existed UidMac Mapping entry */
		if (NdisEqualMemory(pUIDStr, pEntry->uIDStr, tagLen) && IS_EQUAL_MAC(pEntry->macAddr, pInMac)) {
			/* Update info of this entry */
			pEntry->isServer = isServer;
			pEntry->uIDAddByUs = uIDAddByUs;
			pEntry->lastTime = now;
			return pEntry;
		}
			/* handle the age-out situation */
		if (RTMP_TIME_AFTER(now, (pEntry->lastTime + MAT_TB_ENTRY_AGEOUT_TIME))) {
			/*After remove this entry from macHash list and uidHash list, free it! */
			RtmpHashListDelInit(&(pEntry->list));
			MATDBEntryFree(pMatCfg, (PUCHAR)pEntry);
			if (pMatCfg->nodeCount > 0)
				pMatCfg->nodeCount--;
		}
	}


#ifdef ETH_CONVERT_SUPPORT

	if (pMatCfg->nodeCount >= ETH_CONVERT_NODE_MAX)
		return FALSE;

#endif /* ETH_CONVERT_SUPPORT */
	/* Allocate a new UidMacMapping entry and insert into the double-hash */
	pNewEntry = (UidMacMappingEntry *)MATDBEntryAlloc(pMatCfg, sizeof(UidMacMappingEntry));

	if (pNewEntry) {
		NdisZeroMemory(pNewEntry, sizeof(UidMacMappingEntry));
		pNewEntry->isServer = isServer;
		pNewEntry->uIDAddByUs = uIDAddByUs;
		NdisMoveMemory(pNewEntry->macAddr, pInMac, MAC_ADDR_LEN);
		NdisMoveMemory(pNewEntry->uIDStr, pUIDStr, tagLen);
		NdisGetSystemUpTime(&pNewEntry->lastTime);
		RtmpHashNodeInit(&(pNewEntry->list));
		RtmpHashListAddHead(&(pNewEntry->list), &pUidMacTable->uidHash[hashIdx]);

		/*dumpUidMacTb(pMatCfg, hashIdx); //for debug */
		pMatCfg->nodeCount++;
		return pNewEntry;
	}

	return NULL;
}


static PUidMacMappingEntry UidMacTableLookUp(
	IN MAT_STRUCT		*pMatCfg,
	IN PUCHAR			pTagInfo,
	IN UINT16			tagLen)
{
	UINT				hashIdx;
	UINT16				len;
	UCHAR				hashValue = 0;
	UidMacMappingEntry	*pEntry;
	RTMP_HLIST_NODE		*pTmp;
	UidMacMappingTable *pUidMacTable;
	pUidMacTable = (UidMacMappingTable *)pMatCfg->MatTableSet.UidMacTable;

	if ((!pUidMacTable) || (!pUidMacTable->valid))
		return NULL;

	/* Use hash to find out the location of that entry and get the Mac address. */
	len = tagLen;

	while (len)
		hashValue ^= pTagInfo[--len];

	hashIdx = hashValue % MAT_MAX_HASH_ENTRY_SUPPORT;
	RtmpHashListForEachSafe(pEntry, pTmp, &pUidMacTable->uidHash[hashIdx], list) {
		if (NdisEqualMemory(pEntry->uIDStr, pTagInfo, tagLen)) {
			/*Update the lastTime to prevent the aging before pDA processed! */
			NdisGetSystemUpTime(&pEntry->lastTime);
			return pEntry;
		}
	}

	/* We didn't find any matched Mac address. */
	return NULL;
}


static PUCHAR getInMacByOutMacFromSesMacTb(
	IN MAT_STRUCT *pMatCfg,
	IN PUCHAR outMac,
	IN UINT16 sesID)
{
	UINT16				hashIdx;
	SesMacMappingEntry *pEntry;
	RTMP_HLIST_NODE *pTmp;
	SesMacMappingTable *pSesMacTable;
	pSesMacTable = (SesMacMappingTable *)pMatCfg->MatTableSet.SesMacTable;

	if (!pSesMacTable->valid)
		return NULL;

	/* Use hash to find out the location of that entry and get the Mac address. */
	hashIdx = sesID % MAT_MAX_HASH_ENTRY_SUPPORT;
	RtmpHashListForEachSafe(pEntry, pTmp, &pSesMacTable->sesHash[hashIdx], list) {
		if ((pEntry->sessionID == sesID) &&  IS_EQUAL_MAC(pEntry->outMacAddr, outMac)) {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_MAT, DBG_LVL_INFO,
				"find it! dstMac="MACSTR"\n", MAC2STR(pEntry->inMacAddr));
			/*Update the lastTime to prevent the aging before pDA processed! */
			NdisGetSystemUpTime(&pEntry->lastTime);
			return pEntry->inMacAddr;
		}
	}

	/* We didn't find any matched Mac address, just return and didn't do any modification */
	return NULL;
}


/* This function used to maintain the pppoe convert table which incoming node
	is a pppoe client and want to connect to use inner pppoe server.
*/
static NDIS_STATUS SesMacTableUpdate(
	IN MAT_STRUCT	*pMatCfg,
	IN PUCHAR		inMacAddr,
	IN UINT16		sesID,
	IN PUCHAR		outMacAddr)
{
	UINT16 hashIdx;
	SesMacMappingEntry *pEntry, *pNewEntry;
	RTMP_HLIST_NODE *pTmp;
	SesMacMappingTable *pSesMacTable;
	ULONG	now;

	pSesMacTable = (SesMacMappingTable *)pMatCfg->MatTableSet.SesMacTable;

	if ((!pSesMacTable) || (!pSesMacTable->valid))
		return FALSE;

	hashIdx = sesID % MAT_MAX_HASH_ENTRY_SUPPORT;

	RtmpHashListForEachSafe(pEntry, pTmp, &pSesMacTable->sesHash[hashIdx], list) {
		NdisGetSystemUpTime(&now);

		/* Find a existed IP-MAC Mapping entry */
		if ((sesID == pEntry->sessionID) &&
			IS_EQUAL_MAC(pEntry->inMacAddr, inMacAddr) &&
			IS_EQUAL_MAC(pEntry->outMacAddr, outMacAddr)) {
			/* compare is useless. So we directly copy it into the entry. */
			pEntry->lastTime = now;
			return TRUE;
		}
		/* handle the age-out situation */
		if (RTMP_TIME_AFTER(now, (pEntry->lastTime + PPPoE_SES_ENTRY_AGEOUT_TIME))) {
			/* Remove the aged entry */
			RtmpHashListDelInit(&(pEntry->list));
			MATDBEntryFree(pMatCfg, (PUCHAR)pEntry);
			if (pMatCfg->nodeCount > 0)
				pMatCfg->nodeCount--;
		}
	}

#ifdef ETH_CONVERT_SUPPORT

	if (pMatCfg->nodeCount >= ETH_CONVERT_NODE_MAX)
		return FALSE;

#endif /* ETH_CONVERT_SUPPORT */
	/* Allocate a new IPMacMapping entry and insert into the hash */
	pNewEntry = (SesMacMappingEntry *)MATDBEntryAlloc(pMatCfg, sizeof(SesMacMappingEntry));

	if (pNewEntry != NULL) {
		pNewEntry->sessionID = sesID;
		NdisMoveMemory(pNewEntry->inMacAddr, inMacAddr, MAC_ADDR_LEN);
		NdisMoveMemory(pNewEntry->outMacAddr, outMacAddr, MAC_ADDR_LEN);
		NdisGetSystemUpTime(&pNewEntry->lastTime);

		RtmpHashNodeInit(&(pNewEntry->list));
		RtmpHashListAddHead(&(pNewEntry->list), &pSesMacTable->sesHash[hashIdx]);

		/*dumpSesMacTb(pMatCfg, hashIdx); */
		pMatCfg->nodeCount++;
		return TRUE;
	}

	return FALSE;
}


/* PPPoE discovery stage Rx handler.
	When Rx, check if the PPPoE tag "Host-uniq" exists or not.
	If exists, we check our database and convert the dstMac to correct one.
 */
static PUCHAR MATProto_PPPoEDis_Rx(
	IN MAT_STRUCT		*pMatCfg,
	IN PNDIS_PACKET		pSkb,
	IN PUCHAR			pLayerHdr,
	IN PUCHAR			pDevMacAdr)
{
	PUCHAR pData, pDataEnd, pSrvMac = NULL, pCliMac = NULL, pOutMac = NULL, pInMac = NULL, pTagContent = NULL, pPayloadLen;
	INT32 payloadLen, leftLen;
	UINT16 tagID, tagLen = 0;
	UINT16 needUpdateSesTb = 0, sesID = 0, isPADT = 0;
	UINT16 findTag = 0;
	PUidMacMappingEntry pEntry = NULL;
	pData = pLayerHdr;
	pDataEnd = GET_OS_PKT_DATATAIL(pSkb);

	if ((pData + 6) > pDataEnd)
		return NULL;

	if (*(pData) != 0x11)
		return NULL;

	/* Check the Code type. */
	pData++;

	switch (*pData) {
	case PPPOE_CODE_PADO:
		/*It's a packet send by a PPPoE server which behind of our device. */
		findTag = PPPOE_TAG_ID_HOST_UNIQ;
		break;

	case PPPOE_CODE_PADS:
		needUpdateSesTb = 1;
		findTag = PPPOE_TAG_ID_HOST_UNIQ;
		pCliMac = (PUCHAR)(GET_OS_PKT_DATAPTR(pSkb));
		pSrvMac = (PUCHAR)(GET_OS_PKT_DATAPTR(pSkb) + 6);
		break;

	case PPPOE_CODE_PADR:
		/*It's a packet send by a PPPoE client which in front of our device. */
		findTag = PPPOE_TAG_ID_AC_COOKIE;
		break;

	case PPPOE_CODE_PADI:
		/*Do nothing! Just forward this packet to upper layer directly. */
		return NULL;

	case PPPOE_CODE_PADT:
		isPADT = 1;
		pOutMac = (PUCHAR)(GET_OS_PKT_DATAPTR(pSkb) + 6);
		break;

	default:
		return NULL;
	}

	/* Ignore the Code field(length=1) */
	pData++;

	if (needUpdateSesTb || isPADT)
		sesID = OS_NTOHS(get_unaligned((PUINT16)(pData)));

	if (isPADT) {
		pInMac = getInMacByOutMacFromSesMacTb(pMatCfg, pOutMac, sesID);
		return pInMac;
	}

	/* Ignore the session ID field.(length = 2) */
	pData += 2;
	/* Get the payload length, ignore the payload length field.(length = 2) */
	payloadLen = (INT)OS_NTOHS(get_unaligned((PUINT16)(pData)));
	pPayloadLen = pData;
	pData += 2;
	if (!payloadLen ||
	    (payloadLen > 0xFFFF) ||
	    ((pDataEnd - pData) < payloadLen))
		return NULL;

	/* First parsing the PPPoE paylod to find out the required tag(e.g., x0103 or 0x0104) */
	leftLen = payloadLen;

	while (leftLen >= 0) {
		if ((pData + 4) > pDataEnd)
			return NULL;
		tagID = OS_NTOHS(get_unaligned((PUINT16)(pData)));
		tagLen = OS_NTOHS(get_unaligned((PUINT16)(pData + 2)));

		if (tagID == findTag && tagLen > 0) {
			/*shift to the tag value field. */
			pTagContent = pData + 4;
			tagLen = tagLen > PPPOE_DIS_UID_LEN ? PPPOE_DIS_UID_LEN : tagLen;
			break;
		} else {
			pData += (tagLen + 4);
			leftLen -= (tagLen + 4);
		}
	}


	if ((pTagContent + tagLen) > pDataEnd)
		return NULL;

	/* Now update our pppoe discovery table "UidMacTable" */
	if (pTagContent) {
		pEntry  = UidMacTableLookUp(pMatCfg, pTagContent, tagLen);

		/* Remove the AC-Cookie or host-uniq if we ever add the field for this session. */
		if (pEntry) {
			if (pEntry->uIDAddByUs) {
				PUCHAR tagHead, nextTagHead;
				UINT removedTagLen, tailLen;
				removedTagLen = 4 + tagLen; 	/*The total length tag ID/info we want to remove. */
				tagHead = pTagContent - 4;	/*The start address of the tag we want to remove in sk bufffer */
				tailLen = GET_OS_PKT_LEN(pSkb) - (pTagContent - (PUCHAR)(GET_OS_PKT_DATAPTR(pSkb))) - removedTagLen; /*Total left bytes we want to move. */

				if (tailLen) {
					nextTagHead = pTagContent + tagLen;	/*The start address of next tag ID/info in sk buffer. */
					memmove(tagHead, nextTagHead, tailLen);
				}

				OS_PKT_TAIL_ADJUST(pSkb, removedTagLen);
				*((UINT16 *)pPayloadLen) = OS_HTONS(payloadLen - removedTagLen);
			}

			if (needUpdateSesTb) {
				SesMacTableUpdate(pMatCfg, pEntry->macAddr, sesID, pSrvMac);
			}

			return pEntry->macAddr;
		}
	}

	return NULL;
}



/* PPPoE discovery stage Tx handler.
	If the pakcet is PADI/PADR, check if the PPPoE tag "Host-uniq" exists or not.
		If exists, we just record it in our table, else we insert the Mac address
		 of Sender as well as the host-uniq, then forward to the destination. It's
		 a one(MAC)-to-one(Host-uniq) mapping in our table.
	If the packet is PADO/PADS, check if the PPPoE tag "AC-Cookie" exists or not.
		If exists, we just record it in our table, else we insert the Mac address
		of Sender as well as the AC-Cookie, then forward to the destination. It may
		one(MAC)-to-many(AC-Cookie) mapping in our table.

    Host-uniq TAG ID= 0x0103
    AC-Cookie TAG ID= 0x0104
 */
static PUCHAR MATProto_PPPoEDis_Tx(
	IN MAT_STRUCT		*pMatStruct,
	IN PNDIS_PACKET		pSkb,
	IN PUCHAR			pLayerHdr,
	IN PUCHAR			pDevMacAdr)
{
	PUCHAR pData, pTagContent = NULL, pPayloadLen, pPPPPoETail;
	PUCHAR pSrcMac, pDstMac;
	UINT16 payloadLen, offset;
	UINT32 leftLen;
	UINT16 tagID, tagLen = 0;
	UINT16 isServer = 0, needUpdateSesTb = 0, sesID = 0;
	UINT16 findTag = 0;
	PUidMacMappingEntry pEntry = NULL;
	PUCHAR pPktHdr;
	PNDIS_PACKET pModSkb = NULL;
	UCHAR *pkt_end;
	UINT32 pkt_len = GET_OS_PKT_LEN(pSkb);

	pPktHdr = GET_OS_PKT_DATAPTR(pSkb);
	pkt_end = pPktHdr + pkt_len;
	pDstMac = pPktHdr;
	pSrcMac = (pPktHdr + 6);
	pData = pLayerHdr;

	/* Check the pppoe version and Type. It should be 0x11 */
	if (*(pData) != 0x11)
		return NULL;

	/* Check the Code type. */
	pData++;
	if (pData >= pkt_end)
		return NULL;

	switch (*pData) {
	/* Send by pppoe client */
	case PPPOE_CODE_PADI:
	case PPPOE_CODE_PADR:
		findTag = PPPOE_TAG_ID_HOST_UNIQ;
		break;

	/* Send by pppoe server */
	case PPPOE_CODE_PADO:
	case PPPOE_CODE_PADS:
		isServer = 1;
		findTag = PPPOE_TAG_ID_AC_COOKIE;

		if (*pData == PPPOE_CODE_PADS)  /* For PADS, we need record the session ID. */
			needUpdateSesTb = 1;

		break;

	/* Both server and client can send this packet */
	case PPPOE_CODE_PADT:
		/* TODO:
			currently we didn't handle PADT packet. We just leave the
			session entry and make it age-out automatically. Maybe we
			can remove the entry when we receive this packet.
		 */
		return NULL;

	default:
		return NULL;
	}

	/*
		Ignore the Code field(length=1) and if it's a PADS packet, we
		should hold the session ID and for latter to update our table.
	*/
	pData++;
	if (pData >= (pkt_end-2))
		return NULL;

	if (needUpdateSesTb)
		sesID = OS_NTOHS(get_unaligned((PUINT16)(pData)));

	/* Ignore the session ID field.(length = 2) */
	pData += 2;
	if (pData >= (pkt_end-2))
		return NULL;
	/* Get the payload length, and  shift the payload length field(length = 2) to next field. */
	os_move_mem(&payloadLen, pData, sizeof(payloadLen));
	payloadLen = OS_NTOHS(payloadLen);
	if ((pData+payloadLen) > pkt_end)
		return NULL;
	pPayloadLen = pData;
	offset = pPayloadLen - (PUCHAR)(GET_OS_PKT_DATAPTR(pSkb));
	pData += 2;
	if (pData >= pkt_end)
		return NULL;
	/* First parsing the PPPoE paylod to find out the required tag(e.g., x0103 or 0x0104) */
	leftLen = payloadLen;
	if (!leftLen || leftLen > 0xFFFF)
		return NULL;

	while (leftLen >= 4) {
		tagID = OS_NTOHS(get_unaligned((PUINT16)(pData)));
		tagLen = OS_NTOHS(get_unaligned((PUINT16)(pData + 2)));

		if (tagID == findTag && tagLen > 0 && leftLen >= tagLen + 4) {
			/* Move the pointer to the tag value field. 4 = 2(TAG ID) + 2(TAG_LEN) */
			pTagContent = pData + 4;
			/*			tagLen = tagLen > PPPOE_DIS_UID_LEN ? PPPOE_DIS_UID_LEN : tagLen; */
			break;
		} else {
			if (leftLen < tagLen + 4) /* handle boundary error */
				break;
			pData += (tagLen + 4);
			leftLen -= (tagLen + 4);
		}
	}

	/* Now update our pppoe discovery table "UidMacTable" */
	pEntry  = UidMacTableUpdate(pMatStruct, pSrcMac, pDstMac, pTagContent, tagLen, isServer);

	if (pEntry && (pTagContent == NULL)) {
		PUCHAR tailHead;

		if (OS_PKT_CLONED(pSkb)) {
			/*			pModSkb = (PNDIS_PACKET)skb_copy(RTPKT_TO_OSPKT(pSkb), MEM_ALLOC_FLAG); */
			OS_PKT_COPY(RTPKT_TO_OSPKT(pSkb), pModSkb);
		} else
			pModSkb = (PNDIS_PACKET)RTPKT_TO_OSPKT(pSkb);

		if (!pModSkb)
			return NULL;

		/*		tailHead = skb_put(RTPKT_TO_OSPKT(pModSkb), (PPPOE_DIS_UID_LEN + 4)); */
		tailHead = OS_PKT_TAIL_BUF_EXTEND(pModSkb, (PPPOE_DIS_UID_LEN + 4));

		if (tailHead) {
			pPayloadLen = GET_OS_PKT_DATAPTR(pModSkb) + offset;
			pPPPPoETail = pPayloadLen + payloadLen;

			if (tailHead > pPPPPoETail)
				tailHead = pPPPPoETail;

			if (pEntry->isServer) {
				/*Append the AC-Cookie tag info in the tail of the pppoe packet. */
				tailHead[0] = 0x01;
				tailHead[1] = 0x04;
				tailHead[2] = 0x00;
				tailHead[3] = PPPOE_DIS_UID_LEN;
				tailHead += 4;
				NdisMoveMemory(tailHead, pEntry->uIDStr, PPPOE_DIS_UID_LEN);
			} else {
				/*Append the host-uniq tag info in the tail of the pppoe packet. */
				tailHead[0] = 0x01;
				tailHead[1] = 0x03;
				tailHead[2] = 0x00;
				tailHead[3] = PPPOE_DIS_UID_LEN;
				tailHead += 4;
				NdisMoveMemory(tailHead, pEntry->uIDStr, PPPOE_DIS_UID_LEN);
			}

			*(UINT16 *)pPayloadLen = OS_HTONS(payloadLen + 4 + PPPOE_DIS_UID_LEN);
		}
	}

	if (needUpdateSesTb)
		SesMacTableUpdate(pMatStruct, pSrcMac, sesID, pDstMac);

	return (PUCHAR)pModSkb;
}


/* PPPoE discovery stage init function */
static NDIS_STATUS MATProto_PPPoEDis_Init(
	IN MAT_STRUCT	*pMatCfg)
{
	UidMacMappingTable *pUidMacTable;
	SesMacMappingTable *pSesMacTable;
	INT i;

	pUidMacTable = (UidMacMappingTable *)pMatCfg->MatTableSet.UidMacTable;

	if (!pUidMacTable) {
		os_alloc_mem_suspend(NULL, (UCHAR **)&(pMatCfg->MatTableSet.UidMacTable), sizeof(UidMacMappingTable));

		if (pMatCfg->MatTableSet.UidMacTable) {
			pUidMacTable = (UidMacMappingTable *)pMatCfg->MatTableSet.UidMacTable;
			NdisZeroMemory(pUidMacTable, sizeof(UidMacMappingTable));
			for (i = 0; i < MAT_MAX_HASH_ENTRY_SUPPORT; i++)
				RtmpHashHeadInit(&pUidMacTable->uidHash[i]);
		} else {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_MAT, DBG_LVL_ERROR,
				"Allocate memory for UidMacTable failed!\n");
			return FALSE;
		}
	}

	pUidMacTable->valid = TRUE;
	pSesMacTable = (SesMacMappingTable *)pMatCfg->MatTableSet.SesMacTable;

	if (!pSesMacTable) {
		os_alloc_mem_suspend(NULL, (UCHAR **)&(pMatCfg->MatTableSet.SesMacTable), sizeof(SesMacMappingTable));

		if (pMatCfg->MatTableSet.SesMacTable) {
			pSesMacTable = (SesMacMappingTable *)pMatCfg->MatTableSet.SesMacTable;
			NdisZeroMemory(pSesMacTable, sizeof(SesMacMappingTable));
			for (i = 0; i < MAT_MAX_HASH_ENTRY_SUPPORT; i++)
				RtmpHashHeadInit(&pSesMacTable->sesHash[i]);
		} else {
			MTWF_DBG(NULL, DBG_CAT_PROTO, CATPROTO_MAT, DBG_LVL_ERROR,
				"Allocate memory for SesMacTable failed!\n");
			return FALSE;
		}
	}

	pSesMacTable->valid = TRUE;
	return TRUE;
}


/* PPPoE discovery stage exit function */
static NDIS_STATUS MATProto_PPPoEDis_Exit(
	IN MAT_STRUCT *pMatCfg)
{
	UidMacTable_RemoveAll(pMatCfg);
	SesMacTable_RemoveAll(pMatCfg);
	return TRUE;
}


/* PPPoE Session stage Rx handler
	When we receive a ppp pakcet, first check if the srcMac is a PPPoE server or not.
		if it's a server, check the session ID of specific PPPoEServeryEntry and find out the
			correct dstMac Address.
		if it's not a server, check the session ID and find out the cor

 */
static PUCHAR MATProto_PPPoESes_Rx(
	IN MAT_STRUCT		*pMatCfg,
	IN PNDIS_PACKET		pSkb,
	IN PUCHAR			pLayerHdr,
	IN PUCHAR			pDevMacAdr)
{
	PUCHAR srcMac, dstMac = NULL, pData, pDataEnd;
	UINT16 sesID;

	pDataEnd = GET_OS_PKT_DATATAIL(pSkb);
	srcMac = (GET_OS_PKT_DATAPTR(pSkb) + 6);
	pData = pLayerHdr;
	if ((pData + 6) > pDataEnd)
		return NULL;
	/*skip the first two bytes.(version/Type/Code) */
	pData += 2;
	/*get the session ID */
	sesID = OS_NTOHS(get_unaligned((PUINT16)(pData)));
	/* Try to find the dstMac from SesMacHash table. */
	dstMac = getInMacByOutMacFromSesMacTb(pMatCfg, srcMac, sesID);
	return dstMac;
}

/* PPPoE Session stage Tx handler */
static PUCHAR MATProto_PPPoESes_Tx(
	IN MAT_STRUCT		*pMatStruct,
	IN PNDIS_PACKET		pSkb,
	IN PUCHAR			pLayerHdr,
	IN PUCHAR			pDevMacAdr)
{
	/*
		For transmit packet, we do nothing.
	 */
	return NULL;
}


/* PPPoE session stage init function */
static NDIS_STATUS MATProto_PPPoESes_Init(
	IN MAT_STRUCT	*pMatStruct)
{
	return TRUE;
}

/* PPPoE session stage exit function */
static NDIS_STATUS MATProto_PPPoESes_Exit(
	IN MAT_STRUCT	*pMatStruct)
{
	return TRUE;
}

#endif /* MAT_SUPPORT */

