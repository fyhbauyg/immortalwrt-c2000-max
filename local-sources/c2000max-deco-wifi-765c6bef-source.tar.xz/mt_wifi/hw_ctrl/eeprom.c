/*
 * Copyright (c) [2020], MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws.
 * The information contained herein is confidential and proprietary to
 * MediaTek Inc. and/or its licensors.
 * Except as otherwise provided in the applicable licensing terms with
 * MediaTek Inc. and/or its licensors, any reproduction, modification, use or
 * disclosure of MediaTek Software, and information contained herein, in whole
 * or in part, shall be strictly prohibited.
*/
/*
 ***************************************************************************
 ***************************************************************************

	Module Name:
	eeprom.c

	Abstract:

	Revision History:
	Who			When			What
	--------	----------		----------------------------------------------
	Name		Date			Modification logs
*/
#include "rt_config.h"

struct chip_map {
	UINT32 ChipVersion;
	RTMP_STRING *name;
};

struct chip_map RTMP_CHIP_E2P_FILE_TABLE[] = {
	{0x3071,	"RT3092_PCIe_LNA_2T2R_ALC_V1_2.bin"},
	{0x3090,	"RT3092_PCIe_LNA_2T2R_ALC_V1_2.bin"},
	{0x3593,	"HMC_RT3593_PCIe_3T3R_V1_3.bin"},
	{0x5392,	"RT5392_PCIe_2T2R_ALC_V1_4.bin"},
	{0x5592,	"RT5592_PCIe_2T2R_V1_7.bin"},
	{0,}
};


struct chip_map chip_card_id_map[] = {
	{7620, ""},
};


INT rtmp_read_rssi_langain_from_eeprom(RTMP_ADAPTER *pAd)
{
	INT i;
	UINT16 value = 0;
	/* Get RSSI Offset on EEPROM 0x9Ah & 0x9Ch.*/
	/* The valid value are (-10 ~ 10) */
	/* */
	{
		RT28xx_EEPROM_READ16(pAd, EEPROM_RSSI_BG_OFFSET, value);
		pAd->BGRssiOffset[0] = value & 0x00ff;
		pAd->BGRssiOffset[1] = (value >> 8);
	}
	{
		RT28xx_EEPROM_READ16(pAd, EEPROM_RSSI_BG_OFFSET + 2, value);
		{
			pAd->BGRssiOffset[2] = value & 0x00ff;
			pAd->ALNAGain1 = (value >> 8);
		}
	}
	{
		RT28xx_EEPROM_READ16(pAd, EEPROM_LNA_OFFSET, value);
		pAd->BLNAGain = value & 0x00ff;
		/* External LNA gain for 5GHz Band(CH36~CH64) */
		pAd->ALNAGain0 = (value >> 8);
		RT28xx_EEPROM_READ16(pAd, EEPROM_RSSI_A_OFFSET, value);
		pAd->ARssiOffset[0] = value & 0x00ff;
		pAd->ARssiOffset[1] = (value >> 8);
	}
	{
		RT28xx_EEPROM_READ16(pAd, (EEPROM_RSSI_A_OFFSET + 2), value);
		{
			pAd->ARssiOffset[2] = value & 0x00ff;
			pAd->ALNAGain2 = (value >> 8);
		}
	}

	if (((UCHAR)pAd->ALNAGain1 == 0xFF) || (pAd->ALNAGain1 == 0x00))
		pAd->ALNAGain1 = pAd->ALNAGain0;

	if (((UCHAR)pAd->ALNAGain2 == 0xFF) || (pAd->ALNAGain2 == 0x00))
		pAd->ALNAGain2 = pAd->ALNAGain0;

	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
		"ALNAGain0 = %d, ALNAGain1 = %d, ALNAGain2 = %d\n",
		pAd->ALNAGain0, pAd->ALNAGain1, pAd->ALNAGain2);

	/* Validate 11a/b/g RSSI 0/1/2 offset.*/
	for (i = 0; i < 3; i++) {
		if ((pAd->BGRssiOffset[i] < -10) || (pAd->BGRssiOffset[i] > 10))
			pAd->BGRssiOffset[i] = 0;

		if ((pAd->ARssiOffset[i] < -10) || (pAd->ARssiOffset[i] > 10))
			pAd->ARssiOffset[i] = 0;
	}

	return TRUE;
}


/*
	CountryRegion byte offset (38h)
*/
INT rtmp_read_country_region_from_eeporm(RTMP_ADAPTER *pAd)
{
	struct physical_device *ph_dev = pAd->physical_dev;
	UINT16 value, value2;

	value = ph_dev->EEPROMDefaultValue[EEPROM_COUNTRY_REG_OFFSET] >> 8;	/* 2.4G band*/
	value2 = ph_dev->EEPROMDefaultValue[EEPROM_COUNTRY_REG_OFFSET] & 0x00FF;	/* 5G band*/

	if ((value <= REGION_MAXIMUM_BG_BAND) || (value == REGION_31_BG_BAND) || (value == REGION_32_BG_BAND) ||
		(value == REGION_33_BG_BAND))
		pAd->CommonCfg.CountryRegion = ((UCHAR) value) | EEPROM_IS_PROGRAMMED;

	if (value2 <= REGION_MAXIMUM_A_BAND)
		pAd->CommonCfg.CountryRegionForABand = ((UCHAR) value2) | EEPROM_IS_PROGRAMMED;

	return TRUE;
}


/*
	Read frequency offset setting from EEPROM which used for RF
*/
INT rtmp_read_freq_offset_from_eeprom(RTMP_ADAPTER *pAd)
{
	UINT16 value = 0;
	RT28xx_EEPROM_READ16(pAd, EEPROM_FREQ_OFFSET, value);
	{
		if ((value & 0x00FF) != 0x00FF)
			pAd->RfFreqOffset = (ULONG) (value & 0x00FF);
		else
			pAd->RfFreqOffset = 0;
	}
	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
		"E2PROM: RF FreqOffset=0x%x\n", pAd->RfFreqOffset);
	return TRUE;
}


INT rtmp_read_txpwr_from_eeprom(RTMP_ADAPTER *pAd)
{
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(pAd->hdev_ctrl);

	/* if not return early. cause fail at emulation.*/
	/* Init the channel number for TX channel power*/
	if (ops->read_chl_pwr)
		ops->read_chl_pwr(pAd);

#ifdef SINGLE_SKU
	{
		RT28xx_EEPROM_READ16(pAd, EEPROM_DEFINE_MAX_TXPWR, pAd->CommonCfg.DefineMaxTxPwr);
	}

	/*
		Some dongle has old EEPROM value, use ModuleTxpower for saving correct value fo DefineMaxTxPwr.
		ModuleTxpower will override DefineMaxTxPwr (value from EEPROM) if ModuleTxpower is not zero.
	*/
	if (pAd->CommonCfg.ModuleTxpower > 0)
		pAd->CommonCfg.DefineMaxTxPwr = pAd->CommonCfg.ModuleTxpower;

	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
		"TX Power set for SINGLE SKU MODE is : 0x%04x\n",
		pAd->CommonCfg.DefineMaxTxPwr);
	pAd->CommonCfg.bSKUMode = FALSE;

	if ((pAd->CommonCfg.DefineMaxTxPwr & 0xFF) <= 0x50) {
		if ((pAd->CommonCfg.AntGain > 0) && (pAd->CommonCfg.BandedgeDelta >= 0))
			pAd->CommonCfg.bSKUMode = TRUE;
	}

	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
		"Single SKU Mode is %s\n",
		pAd->CommonCfg.bSKUMode ? "Enable" : "Disable");
#endif /* SINGLE_SKU */
#ifdef SINGLE_SKU_V2
	InitSkuRateDiffTable(pAd);
#endif /* SINGLE_SKU_V2 */
	return TRUE;
}

/*
	Read BAND_SELECT_BAND from EEPROM
*/

INT show_bandinfo_proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	UINT16 BandSel = 0;

	RTMP_GET_BAND_SELECT(pAd, &BandSel);

	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO, "BAND_SELECT_BAND = %x\n", BandSel);
	return TRUE;
}

VOID rtmp_read_eeprom_for_cal(
	struct _RTMP_ADAPTER *mac_ad)
{
#ifdef PRE_CAL_TRX_SET2_SUPPORT
	UINT16 PreCalSize;
#endif /* PRE_CAL_TRX_SET2_SUPPORT */
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(mac_ad->hdev_ctrl);
#if defined(PRE_CAL_TRX_SET2_SUPPORT) || \
	defined(PRE_CAL_MT7915_SUPPORT) || defined(PRE_CAL_MT7986_SUPPORT) || \
	defined(PRE_CAL_MT7981_SUPPORT) || defined(PRE_CAL_MT7916_SUPPORT) || \
	defined(PRE_CAL_MT7990_SUPPORT) || defined(PRE_CAL_MT7992_SUPPORT) || \
	defined(PRE_CAL_MT7993_SUPPORT) || defined(PRE_CAL_BLACKHAWK_SUPPORT)
	UINT16 DoPreCal = 0;
	UINT32 setPreCalTotal = 0;
	USHORT setPreCalIdx = 0;
	UINT32 sendLength = 0;
#endif
	struct physical_device *ph_dev = mac_ad->physical_dev;

	MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO, "-->\n");

	if (ops->eeinit) {
#ifdef CAL_FREE_IC_SUPPORT
		BOOLEAN bCalFree = FALSE;
#endif
		/* If we are run in Multicard mode */
		ops->eeinit(mac_ad);
#ifdef CAL_FREE_IC_SUPPORT
		RTMP_CAL_FREE_IC_CHECK(mac_ad, bCalFree);
		if (bCalFree) {
			MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO, "Cal Free IC!!\n");
			RTMP_CAL_FREE_DATA_GET(mac_ad);
		} else {
			MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
				"Non Cal Free IC!!\n");
		}
#endif	/* CAL_FREE_IC_SUPPORT */
	}
#ifdef PRE_CAL_MT7990_SUPPORT
		if (IS_MT7990(mac_ad)) {
			struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(mac_ad->hdev_ctrl);
			UINT32 reg_val = 0;
			UINT32 reg_val_is_2adie = 0;
			UINT32 reg_val_2adie_triband = 0;

			/* Check DoPreCal bits */
			RTMP_IO_READ32(mac_ad->hdev_ctrl,
				MT7990_CBTOP_GPIO_ADIE_COMBATION_STRAP_ADDR, &reg_val);

			reg_val_is_2adie = (reg_val
						& MT7990_CBTOP_GPIO_ADIE_COMBATION_STRAP_MASK) >>
						MT7990_CBTOP_GPIO_ADIE_COMBATION_STRAP_SHIF;

			reg_val_2adie_triband = (reg_val
						& MT7990_CBTOP_GPIO_2ADIE_TRIBAND_STRAP_MASK) >>
						MT7990_CBTOP_GPIO_2ADIE_TRIBAND_STRAP_SHIF;

			if ((reg_val_is_2adie == MT7990_2ADIE_75_77)
				|| (reg_val_is_2adie == MT7990_2ADIE_76_77)) {
				if (reg_val_2adie_triband == MT7990_2ADIE_3BAND) {
					cap->prek_ee_info.pre_cal_total_size =
						cap->prek_ee_info.pre_cal_total_size_2adie;
					MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
						"2Die modify group cal size\n");
				}
			}
			RT28xx_EEPROM_READ16(mac_ad, PRECAL_INDICATION_BYTE, DoPreCal);
			MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
				"\x1b[34m EEPROM 0x%2x %x\x1b[m\n",
				PRECAL_INDICATION_BYTE, DoPreCal);
			if (ph_dev->E2pAccessMode == E2P_FLASH_MODE ||
				ph_dev->E2pAccessMode == E2P_BIN_MODE) {
				if (DoPreCal & (1 << GROUP_PRECAL_INDN_BIT)) {
					MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
					"Group Pre-Cal finished, load Group Pre-Cal data\n");
					setPreCalTotal = cap->prek_ee_info.pre_cal_total_size;
					while (setPreCalTotal > 0) {
						sendLength =
							(setPreCalTotal >= PRE_CAL_SET_MAX_LENGTH) ?
							PRE_CAL_SET_MAX_LENGTH : setPreCalTotal;
						MtCmdSetGroupPreCal_7990(
							mac_ad, setPreCalIdx, sendLength);
						MTWF_DBG(mac_ad,
							DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
							"idx=%d,sendLength=%d,remainedLength=%d\n",
							setPreCalIdx, sendLength, setPreCalTotal);
						setPreCalIdx++;
						setPreCalTotal -= sendLength;
					}
				}
				if (DoPreCal & (1 << DPD5G_PRECAL_INDN_BIT)) {
					MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
						"DPD 5G Pre-Cal finished!\n");
				}
				if (DoPreCal & (1 << DPD6G_PRECAL_INDN_BIT)) {
					MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
						"DPD 6G Pre-Cal finished!\n");
				}
				if (DoPreCal & (1 << DPD2G_PRECAL_INDN_BIT)) {
					MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
						"DPD 2G Pre-Cal finished!\n");
				}
			}
		}
#endif /* PRE_CAL_MT7990_SUPPORT */

#ifdef PRE_CAL_MT7992_SUPPORT
		if (IS_MT7992(mac_ad)) {
			struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(mac_ad->hdev_ctrl);

			/* Check DoPreCal bits */
			RT28xx_EEPROM_READ16(mac_ad, PRECAL_INDICATION_BYTE, DoPreCal);
			MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
				"\x1b[34m EEPROM 0x%2x %x\x1b[m\n",
				PRECAL_INDICATION_BYTE, DoPreCal);
			if (ph_dev->E2pAccessMode == E2P_FLASH_MODE ||
				ph_dev->E2pAccessMode == E2P_BIN_MODE) {
				if (DoPreCal & (1 << GROUP_PRECAL_INDN_BIT)) {
					MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
					"Group Pre-Cal finished, load Group Pre-Cal data\n");
					setPreCalTotal = cap->prek_ee_info.pre_cal_total_size;
					while (setPreCalTotal > 0) {
						sendLength =
							(setPreCalTotal >= PRE_CAL_SET_MAX_LENGTH) ?
							PRE_CAL_SET_MAX_LENGTH : setPreCalTotal;
						MtCmdSetGroupPreCal_7992(
							mac_ad, setPreCalIdx, sendLength);
						MTWF_DBG(mac_ad,
							DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
							"idx=%d,sendLength=%d,remainedLength=%d\n",
							setPreCalIdx, sendLength, setPreCalTotal);
						setPreCalIdx++;
						setPreCalTotal -= sendLength;
					}
				}
				if (DoPreCal & (1 << DPD5G_PRECAL_INDN_BIT)) {
					MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
						"DPD 5G Pre-Cal finished!\n");
				}
				if (DoPreCal & (1 << DPD2G_PRECAL_INDN_BIT)) {
					MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
						"DPD 2G Pre-Cal finished!\n");
				}
			}
		}
#endif /* PRE_CAL_MT7992_SUPPORT */

#ifdef PRE_CAL_MT7993_SUPPORT
		if (IS_MT7993(mac_ad)) {
			struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(mac_ad->hdev_ctrl);

			/* Check DoPreCal bits */
			RT28xx_EEPROM_READ16(mac_ad, PRECAL_INDICATION_BYTE, DoPreCal);
			MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
				"\x1b[34m EEPROM 0x%2x %x\x1b[m\n",
				PRECAL_INDICATION_BYTE, DoPreCal);
			if (ph_dev->E2pAccessMode == E2P_FLASH_MODE ||
				ph_dev->E2pAccessMode == E2P_BIN_MODE) {
				if (DoPreCal & (1 << GROUP_PRECAL_INDN_BIT)) {
					MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
					"Group Pre-Cal finished, load Group Pre-Cal data\n");
					setPreCalTotal = cap->prek_ee_info.pre_cal_total_size;
					while (setPreCalTotal > 0) {
						sendLength =
							(setPreCalTotal >= PRE_CAL_SET_MAX_LENGTH) ?
							PRE_CAL_SET_MAX_LENGTH : setPreCalTotal;
						MtCmdSetGroupPreCal(
							mac_ad, setPreCalIdx, sendLength);
						MTWF_DBG(mac_ad,
							DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
							"idx=%d,sendLength=%d,remainedLength=%d\n",
							setPreCalIdx, sendLength, setPreCalTotal);
						setPreCalIdx++;
						setPreCalTotal -= sendLength;
					}
				}
				if (DoPreCal & (1 << DPD5G_PRECAL_INDN_BIT)) {
					MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
						"DPD 5G Pre-Cal finished!\n");
				}
				if (DoPreCal & (1 << DPD2G_PRECAL_INDN_BIT)) {
					MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
						"DPD 2G Pre-Cal finished!\n");
				}
			}
		}
#endif /* PRE_CAL_MT7993_SUPPORT */


#ifdef PRE_CAL_TRX_SET2_SUPPORT

	PreCalSize = PRE_CAL_SIZE_ONE_CARD;

	/* Check DoPreCal bits */
	RT28xx_EEPROM_READ16(mac_ad, 0x52, DoPreCal);

	MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
			 "\x1b[34m EEPROM 0x52 %x\x1b[m\n", DoPreCal);

	/* Pre Cal only supports Bin or Flash Mode */
	if (PD_GET_E2P_ACCESS_MODE(mac_ad->physical_dev) == E2P_FLASH_MODE
		|| PD_GET_E2P_ACCESS_MODE(mac_ad->physical_dev) == E2P_BIN_MODE) {
	/* Restore when RLM cache is empty */
		if (!rlmCalCacheDone(mac_ad->rlmCalCache) && (DoPreCal & (1 << 2))) {
			INT32 ret = 0;
			INT32 ret_cal_data = NDIS_STATUS_SUCCESS;
			ret = os_alloc_mem(mac_ad,
				&mac_ad->PreCalReStoreBuffer, PreCalSize);/* Allocate 16K buffer*/

			if (ret != NDIS_STATUS_SUCCESS) {
				MTWF_DBG(mac_ad, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"\x1b[42m Not enough memory for pre-cal restored buffer!!\x1b[m\n");
			} else {
				/* Read pre-cal data from flash and store to pre-cal buffer*/
#ifdef RTMP_FLASH_SUPPORT
				if (PD_GET_E2P_ACCESS_MODE(mac_ad->physical_dev) == E2P_FLASH_MODE)
					RtmpFlashRead(mac_ad->hdev_ctrl,
						mac_ad->PreCalReStoreBuffer,
						get_dev_eeprom_offset(ph_dev) + PRECALPART_OFFSET,
						PreCalSize);
#endif /* RTMP_FLASH_SUPPORT */
				if (PD_GET_E2P_ACCESS_MODE(mac_ad->physical_dev) == E2P_BIN_MODE) {
					ret_cal_data = rtmp_cal_load_from_bin(
						mac_ad, mac_ad->PreCalReStoreBuffer,
						get_dev_eeprom_offset(ph_dev) + PRECALPART_OFFSET,
						PreCalSize);

					if (ret_cal_data != NDIS_STATUS_SUCCESS) {
						/* Erase DoPreCal bit */
						DoPreCal &= ~(1 << 2);
						RT28xx_EEPROM_WRITE16(mac_ad, 0x52, DoPreCal);
						MTWF_DBG(mac_ad,
							DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
							"Reset EEPROM 0x52[2] bit");
						MTWF_DBG(mac_ad,
							DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
							", Let FW do On-line Calibration\n");
					}
				}

				if (ret_cal_data == NDIS_STATUS_SUCCESS)
					ret = MtCmdPreCalReStoreProc(mac_ad,
						(INT32 *)mac_ad->PreCalReStoreBuffer);
			}
		}
	} else {
		/* Force Erase DoPreCal bit for any mode other than Bin & Flash*/
		DoPreCal &= ~(1 << 2);
		RT28xx_EEPROM_WRITE16(mac_ad, 0x52, DoPreCal);
	}
#endif /* PRE_CAL_TRX_SET2_SUPPORT */

#ifdef MT_DFS_SUPPORT
	/*	Dynamically enable or disable DFS calibration in firmware.
		Must be performed before power on calibration*/
	DfsSetCalibration(mac_ad, mac_ad->CommonCfg.DfsParameter.DisableDfsCal);
#endif
#ifdef MT_MAC
	/*Send EEprom parameter to FW*/
#ifdef CONFIG_ATE
	if (!ATE_ON(mac_ad))
#endif
	{
		MtCmdEfusBufferModeSet(mac_ad, PD_GET_EEPROM_TYPE(ph_dev));
	}
#endif /* MT_MAC */
}

/*
	========================================================================

	Routine Description:
		Read initial parameters from EEPROM

	Arguments:
		Adapter						Pointer to our adapter

	Return Value:
		None

	IRQL = PASSIVE_LEVEL

	Note:

	========================================================================
*/
INT NICReadEEPROMParameters(
	RTMP_ADAPTER *pAd, RTMP_STRING *mac_addr)
{
	EEPROM_VERSION_STRUC Version = {0};
	EEPROM_ANTENNA_STRUC Antenna;
#ifdef MAC_ADDR_ADJACENT_CHK
	u8 MaxBands = PD_GET_BAND_NUM(pAd->physical_dev);
#endif /* MAC_ADDR_ADJACENT_CHK */
	USHORT  Addr01 = 0, Addr23 = 0, Addr45 = 0;
	struct physical_device *ph_dev = pAd->physical_dev;
	UINT16 BandSel = 0;
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(pAd->hdev_ctrl);

	os_zero_mem(&Antenna, sizeof(EEPROM_ANTENNA_STRUC));

	/* Read MAC setting from EEPROM and record as permanent MAC address */
	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
		"Initialize MAC Address from E2PROM\n");

	RTMP_GET_BAND_SELECT(pAd, &BandSel);

	/* Replace Country code and Country Region in Profile by Effuse content */
	if (ops && ops->Config_Effuse_Country)
		ops->Config_Effuse_Country(pAd);
	else
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_NOTICE,
			"No Config_Effuse_Country hook api, check.\n");

	if (hc_get_hw_band_idx(pAd) == BAND0) {
		RT28xx_EEPROM_READ16(pAd, EEPROM_BAND0_MAC0, Addr01);
		RT28xx_EEPROM_READ16(pAd, EEPROM_BAND0_MAC1, Addr23);
		RT28xx_EEPROM_READ16(pAd, EEPROM_BAND0_MAC2, Addr45);
		pAd->PermanentAddress[0] = (UCHAR)(Addr01 & 0xff);
		pAd->PermanentAddress[1] = (UCHAR)(Addr01 >> 8);
		pAd->PermanentAddress[2] = (UCHAR)(Addr23 & 0xff);
		pAd->PermanentAddress[3] = (UCHAR)(Addr23 >> 8);
		pAd->PermanentAddress[4] = (UCHAR)(Addr45 & 0xff);
		pAd->PermanentAddress[5] = (UCHAR)(Addr45 >> 8);
	} else if (hc_get_hw_band_idx(pAd) == BAND1) {
		RT28xx_EEPROM_READ16(pAd, EEPROM_BAND1_MAC0, Addr01);
		RT28xx_EEPROM_READ16(pAd, EEPROM_BAND1_MAC1, Addr23);
		RT28xx_EEPROM_READ16(pAd, EEPROM_BAND1_MAC2, Addr45);
		pAd->PermanentAddress[0] = (UCHAR)(Addr01 & 0xff);
		pAd->PermanentAddress[1] = (UCHAR)(Addr01 >> 8);
		pAd->PermanentAddress[2] = (UCHAR)(Addr23 & 0xff);
		pAd->PermanentAddress[3] = (UCHAR)(Addr23 >> 8);
		pAd->PermanentAddress[4] = (UCHAR)(Addr45 & 0xff);
		pAd->PermanentAddress[5] = (UCHAR)(Addr45 >> 8);
	} else if (hc_get_hw_band_idx(pAd) == BAND2) {
		RT28xx_EEPROM_READ16(pAd, EEPROM_BAND2_MAC0, Addr01);
		RT28xx_EEPROM_READ16(pAd, EEPROM_BAND2_MAC1, Addr23);
		RT28xx_EEPROM_READ16(pAd, EEPROM_BAND2_MAC2, Addr45);
		pAd->PermanentAddress[0] = (UCHAR)(Addr01 & 0xff);
		pAd->PermanentAddress[1] = (UCHAR)(Addr01 >> 8);
		pAd->PermanentAddress[2] = (UCHAR)(Addr23 & 0xff);
		pAd->PermanentAddress[3] = (UCHAR)(Addr23 >> 8);
		pAd->PermanentAddress[4] = (UCHAR)(Addr45 & 0xff);
		pAd->PermanentAddress[5] = (UCHAR)(Addr45 >> 8);
	}

	/*more conveninet to test mbssid, so ap's bssid &0xf1*/
	if (pAd->PermanentAddress[0] == 0xff)
		pAd->PermanentAddress[0] = RandomByte(pAd) & 0xf8;

	if (IS_BELLWETHER(pAd)) {
		if (hc_get_hw_band_idx(pAd) == BAND1)
			pAd->PermanentAddress[0] |= (0x8);

		if (hc_get_hw_band_idx(pAd) == BAND2)
			pAd->PermanentAddress[0] |= (0xc);

	}

	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO, "E2PROM MAC: ="MACSTR"\n",
			 MAC2STR(pAd->PermanentAddress));

	/* Assign the actually working MAC Address */
	if (pAd->bLocalAdminMAC) {
		COPY_MAC_ADDR(pAd->PermanentAddress, pAd->CurrentAddress);
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
				 "Use the MAC address what is assigned from Configuration file(.dat).\n");
	} else if (mac_addr &&
			   strlen((RTMP_STRING *)mac_addr) == 17 &&
			   (strcmp(mac_addr, "00:00:00:00:00:00") != 0)) {
		INT j;
		RTMP_STRING *macptr;
		macptr = (RTMP_STRING *) mac_addr;

		for (j = 0; j < MAC_ADDR_LEN; j++) {
			AtoH(macptr, &pAd->CurrentAddress[j], 1);
			macptr = macptr + 3;
		}

		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
			"Use the MAC address what is assigned from Moudle Parameter.\n");
	} else {
		COPY_MAC_ADDR(pAd->CurrentAddress, pAd->PermanentAddress);
		if (pAd->bRandomMac) {
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_WARN,
			"\n\n\n\n\n\033[1;31m[Wanrning] you are using random MAC!!!\033[0m\n"
			"\033[1;31m[Wanrning]please update the MAC before use the board!!!!!!!\033[0m\n\n\n\n\n");
		} else
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
					"Use the MAC address what is assigned from EEPROM.\n");
	}

	/*Insert MAC address to ra mac table*/
	if (hc_get_hw_band_idx(pAd) == BAND0)
		COPY_MAC_ADDR(ph_dev->ra_mac_table[BAND0], pAd->CurrentAddress);
	else if (hc_get_hw_band_idx(pAd) == BAND1)
		COPY_MAC_ADDR(ph_dev->ra_mac_table[BAND1], pAd->CurrentAddress);
	else if (hc_get_hw_band_idx(pAd) == BAND2)
		COPY_MAC_ADDR(ph_dev->ra_mac_table[BAND2], pAd->CurrentAddress);

#ifdef MAC_ADDR_ADJACENT_CHK
	/* per band MAC in sequence condition check  */
	if ((MaxBands >= 2) && (hc_get_hw_band_idx(pAd) == (MaxBands-1))) {
		INT i  = 0;
		UCHAR InvalidMac[MAC_ADDR_LEN] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
		UCHAR zeroMac[MAC_ADDR_LEN]  = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

		for (i = 0 ; i < (MaxBands-1); i++) {
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_NOTICE, "BN(%d) MAC: ="MACSTR"\n",
					  i, MAC2STR(ph_dev->ra_mac_table[i]));
			if (!NdisEqualMemory(InvalidMac, ph_dev->ra_mac_table[i], MAC_ADDR_LEN)
				&& !NdisEqualMemory(zeroMac, ph_dev->ra_mac_table[i], MAC_ADDR_LEN)
				&& !NdisEqualMemory(InvalidMac, ph_dev->ra_mac_table[i+1], MAC_ADDR_LEN)
				&& !NdisEqualMemory(zeroMac, ph_dev->ra_mac_table[i+1], MAC_ADDR_LEN)) {
				if ((ph_dev->ra_mac_table[i][5] & 0xF0) == (ph_dev->ra_mac_table[i+1][5] & 0xF0))
					MTWF_PRINT("\x1b[41m !!! BN(%d) and BN(%d): MAC ADDR ADJACENT !!! \x1b[m\n", i, (i+1));
			}
		}
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_NOTICE, "BN(%d) MAC: ="MACSTR"\n",
				  i, MAC2STR(ph_dev->ra_mac_table[i]));
	}
	MTWF_PRINT("%s: MacAddrAdj=0x%x\n",
				__func__, PD_GET_MAC_ADDR_ADJ(ph_dev));
#endif /* MAC_ADDR_ADJACENT_CHK */

	/* if E2PROM version mismatch with driver's expectation, then skip*/
	/* all subsequent E2RPOM retieval and set a system error bit to notify GUI*/
	RT28xx_EEPROM_READ16(pAd, EEPROM_VERSION_OFFSET, Version.word);
	ph_dev->EepromVersion = Version.field.Version + Version.field.FaeReleaseNumber * 256;
	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
		"E2PROM: Version = %d, FAE release #%d\n", Version.field.Version,
		Version.field.FaeReleaseNumber);

	RTMP_CHIP_ANTENNA_INFO_DEFAULT_RESET(pAd, &Antenna);

	/* Save value for future using */
	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
		"RxPath = %d, TxPath = %d, RfIcType = %d\n",
		Antenna.field.RxPath, Antenna.field.TxPath,
		Antenna.field.RfIcType);
	/* Save the antenna for future use*/
	pAd->Antenna.word = Antenna.word;
	/* Set the RfICType here, then we can initialize RFIC related operation callbacks*/
	pAd->Mlme.RealRxPath = (UCHAR) Antenna.field.RxPath;

#ifdef LED_CONTROL_SUPPORT
	rtmp_read_led_setting_from_eeprom(pAd);
#endif /* LED_CONTROL_SUPPORT */
	rtmp_read_txpwr_from_eeprom(pAd);
	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
		"pAd->Antenna.field.BoardType = %d\n",
		pAd->Antenna.field.BoardType);
	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO, "<--\n");
	return TRUE;
}

#ifdef	CONNAC_EFUSE_FORMAT_SUPPORT

NDIS_STATUS rtmp_eeprom_Sys_update(
	RTMP_ADAPTER * pAd,
	UCHAR GetOrSet,
	UCHAR ColumnIdx,
	UCHAR *value
)
{
	PUINT8 pu1Param = NULL;
	struct physical_device *ph_dev = pAd->physical_dev;

	/* get pointer to system module */
	pu1Param = (PUINT8)(ph_dev->EfuseInfoAll.prSys);

	/*Sanity check*/
	if (!pu1Param)
		return NDIS_STATUS_FAILURE;

	/* Set/Get Efuse Info value */
	if (GetOrSet == ENUM_EFUSE_INFO_SET)
		*(pu1Param + ColumnIdx) = *value;
	else
		*value = *(pu1Param + ColumnIdx);
	return NDIS_STATUS_SUCCESS;
}


NDIS_STATUS rtmp_eeprom_WfCmm_update(
	RTMP_ADAPTER * pAd,
	UCHAR eBand,
	ENUM_EFUSE_COMMON_CATOGORY eCmmType,
	UCHAR GetOrSet,
	UCHAR ChGroup,
	UCHAR ColumnIdx,
	UCHAR *value
)
{
	PUINT8 pu1Param = NULL;
	BOOLEAN  fgGBand;
	struct physical_device *ph_dev = pAd->physical_dev;
								/* BAND_5G						BAND_2G4 */
	UINT_8 u1StartAdd[EFUSE_COMMON_CATOGORY_NUM][CFG_WIFI_RAM_BAND_NUM] = {{EFUSE_INFO_5G_COMMON_TEMP_TSSI_OFFSET, EFUSE_INFO_2G4_COMMON_TEMP_TSSI_OFFSET},
								  {EFUSE_INFO_5G_COMMON_DYNAMIC_IPA_SWITCH_OFFSET, EFUSE_INFO_2G4_COMMON_DYNAMIC_IPA_SWITCH_OFFSET},
								  {EFUSE_INFO_5G_COMMON_ELNA_OFFSET, EFUSE_INFO_2G4_COMMON_ELNA_OFFSET},
								  {EFUSE_INFO_5G_COMMON_THERMO_COMP_OFFSET, EFUSE_INFO_2G4_COMMON_THERMO_COMP_OFFSET},
								  {EFUSE_INFO_5G_COMMON_EPA_DPD_OFFSET, EFUSE_INFO_2G4_COMMON_EPA_DPD_OFFSET}
								};
								/* BAND_5G		BAND_2G4 */
	UINT_8 u1GroupNum[EFUSE_COMMON_CATOGORY_NUM][CFG_WIFI_RAM_BAND_NUM] = {{8, 1},
								  {SINGLE_GROUP, SINGLE_GROUP},
								  {3, 1},
								  {SINGLE_GROUP, SINGLE_GROUP},
								  {SINGLE_GROUP, SINGLE_GROUP}
								};
								 /* BAND_5G						BAND_2G4 */
	UINT_8 u1ColumnNum[EFUSE_COMMON_CATOGORY_NUM][CFG_WIFI_RAM_BAND_NUM] = {{EFUSE_COMMON_TEMP_TSSI_CATEGORY_ITEM_NUM, EFUSE_COMMON_TEMP_TSSI_CATEGORY_ITEM_NUM},
								   {EFUSE_COMMON_DYNAMIC_IPA_SWITCH_CATEGORY_ITEM_NUM, EFUSE_COMMON_DYNAMIC_IPA_SWITCH_CATEGORY_ITEM_NUM},
								   {EFUSE_5G_COMMON_ELNA_CATEGORY_ITEM_NUM, EFUSE_2G4_COMMON_ELNA_CATEGORY_ITEM_NUM},
								   {EFUSE_COMMON_THERMO_COMP_CATEGORY_ITEM_NUM, EFUSE_COMMON_THERMO_COMP_CATEGORY_ITEM_NUM},
								   {EFUSE_COMMON_EPA_DPD_CATEGORY_ITEM_NUM, EFUSE_COMMON_EPA_DPD_CATEGORY_ITEM_NUM}
								};

	/* check Channel Band */
	fgGBand = (eBand == BAND_24G) ? (TRUE) : (FALSE);

	/* get pointer to common module */
	pu1Param = (eBand == BAND_24G) ?
		((PUINT8)ph_dev->EfuseInfoAll.pr2G4Cmm) : ((PUINT8)ph_dev->EfuseInfoAll.pr5GCmm);

	/*Sanity check*/
	if (!pu1Param)
		return NDIS_STATUS_FAILURE;
	if (GetOrSet >= ENUM_EFUSE_INFO_MODE_NUM)
		return NDIS_STATUS_FAILURE;

	if (eCmmType >= EFUSE_COMMON_CATOGORY_NUM)
		return NDIS_STATUS_FAILURE;

	if (ChGroup >= u1GroupNum[eCmmType][fgGBand])
		return NDIS_STATUS_FAILURE;

	if (ColumnIdx >= u1ColumnNum[eCmmType][fgGBand])
		return NDIS_STATUS_FAILURE;

	/* get pointer to Common Specific Category */
	pu1Param += u1StartAdd[eCmmType][fgGBand];

	/* get pointer to Common Specific channel group
	If no group info, please fill CH_GROUP_NOT_CARE for ChGroup*/
	if (ChGroup == CH_GROUP_NOT_CARE)
		;
	else
		pu1Param += (ChGroup * u1ColumnNum[eCmmType][fgGBand]);

	/* Set/Get Efuse Info value */
	if (GetOrSet == ENUM_EFUSE_INFO_SET)
		*(pu1Param + ColumnIdx) = *value;
	else
		*value = *(pu1Param + ColumnIdx);
	return NDIS_STATUS_SUCCESS;
}

NDIS_STATUS rtmp_eeprom_WfPath_update(
	RTMP_ADAPTER * pAd,
	UCHAR eBand,
	ENUM_EFUSE_WF_PATH_CATOGORY eWFPathType,
	UCHAR AntIdx,
	UCHAR GetOrSet,
	UCHAR ChGroup,
	UCHAR ColumnIdx,
	UCHAR *value
)
{
	PUINT8 pu1Param = NULL;
	BOOLEAN  fgGBand;
	struct physical_device *ph_dev = pAd->physical_dev;

	UINT_8 u1StartAdd[EFUSE_WF_PATH_CATOGORY_NUM][CFG_WIFI_RAM_BAND_NUM] = {{EFUSE_INFO_5G_WF_PATH_FE_LOSS_OFFSET, EFUSE_INFO_2G4_WF_PATH_FE_LOSS_OFFSET},
								   {EFUSE_INFO_5G_WF_PATH_TSSI_OFFSET, EFUSE_INFO_2G4_WF_PATH_TSSI_OFFSET},
								   {EFUSE_INFO_5G_WF_PATH_PHY_POWER_OFFSET, EFUSE_INFO_2G4_WF_PATH_PHY_POWER_OFFSET},
								   {EFUSE_INFO_5G_WF_PATH_TX_POWER_OFFSET_OFFSET, EFUSE_INFO_2G4_WF_PATH_TX_POWER_OFFSET_OFFSET},
								   {EFUSE_INFO_5G_WF_PATH_DPD_G0_OFFSET, EFUSE_INFO_2G4_WF_PATH_DPD_G0_OFFSET},
								   {EFUSE_INFO_5G_WF_PATH_LNA_GAIN_OFFSET, EFUSE_INFO_2G4_WF_PATH_LNA_GAIN_OFFSET}
								};
								 /* BAND_5G		 BAND_2G4 */
	UINT_8 u1GroupNum[EFUSE_WF_PATH_CATOGORY_NUM][CFG_WIFI_RAM_BAND_NUM] = {{3, 1},
								   {8, 1},
								   {SINGLE_GROUP, SINGLE_GROUP},
								   {8, 1},
								   {4, 1},
								   {8, 1}
								};
								  /* BAND_5G						 BAND_2G4 */
	UINT_8 u1ColumnNum[EFUSE_WF_PATH_CATOGORY_NUM][CFG_WIFI_RAM_BAND_NUM] = {{EFUSE_5G_WF_PATH_FE_LOSS_CATEGORY_ITEM_NUM, EFUSE_2G4_WF_PATH_FE_LOSS_CATEGORY_ITEM_NUM},
								    {EFUSE_WF_PATH_TSSI_CATEGORY_ITEM_NUM, EFUSE_WF_PATH_TSSI_CATEGORY_ITEM_NUM},
								    {EFUSE_WF_PATH_PHY_POWER_CATEGORY_ITEM_NUM, EFUSE_WF_PATH_PHY_POWER_CATEGORY_ITEM_NUM},
								    {EFUSE_5G_WF_PATH_TX_POWER_OFFSET_CATEGORY_ITEM_NUM, EFUSE_2G4_WF_PATH_TX_POWER_OFFSET_CATEGORY_ITEM_NUM},
								    {EFUSE_WF_PATH_DPD_G0_CATEGORY_ITEM_NUM, EFUSE_WF_PATH_DPD_G0_CATEGORY_ITEM_NUM},
								    {EFUSE_WF_PATH_LNA_GAIN_CATEGORY_ITEM_NUM, EFUSE_WF_PATH_LNA_GAIN_CATEGORY_ITEM_NUM}
								};

	/* check Channel Band */
	fgGBand = (eBand == BAND_24G) ? (TRUE) : (FALSE);

	/*Sanity check*/
	if (GetOrSet >= ENUM_EFUSE_INFO_MODE_NUM)
		return NDIS_STATUS_FAILURE;
	if (eWFPathType >= EFUSE_WF_PATH_CATOGORY_NUM)
		return NDIS_STATUS_FAILURE;
	if (AntIdx >= MAX_ANTENNA_NUM)
		return NDIS_STATUS_FAILURE;
	if (ChGroup >= u1GroupNum[eWFPathType][fgGBand])
		return NDIS_STATUS_FAILURE;
	if (ColumnIdx >= u1ColumnNum[eWFPathType][fgGBand])
		return NDIS_STATUS_FAILURE;

	/* get pointer to common module */
	pu1Param =
		(eBand == BAND_24G) ?
			((PUINT8)ph_dev->EfuseInfoAll.pr2G4WFPath[AntIdx])
			: ((PUINT8)ph_dev->EfuseInfoAll.pr5GWFPath[AntIdx]);

	if (!pu1Param)
		return NDIS_STATUS_FAILURE;

	/* get pointer to Common Specific Category */
	pu1Param += u1StartAdd[eWFPathType][fgGBand];

	/* get pointer to Common Specific channel group
	If no group info, please fill CH_GROUP_NOT_CARE for ChGroup*/
	if (ChGroup == CH_GROUP_NOT_CARE)
		;
	else
		pu1Param += (ChGroup * u1ColumnNum[eWFPathType][fgGBand]);

	/* Set/Get Efuse Info value */
	if (GetOrSet == ENUM_EFUSE_INFO_SET)
		*(pu1Param + ColumnIdx) = *value;
	else
		*value = *(pu1Param + ColumnIdx);

	return NDIS_STATUS_SUCCESS;
}

NDIS_STATUS rtmp_eeprom_TxPwr_update(
	RTMP_ADAPTER * pAd,
	UCHAR eBand,
	EFUSE_INFO_TX_POWER_CATEGORY eTxPwrParamCat,
	UCHAR GetOrSet,
	UCHAR ColumnIdx,
	UCHAR *value
)
{
	PUINT8 pu1Param = NULL;
	BOOLEAN  fgGBand;
	UCHAR ColumnNum = 0;
	struct physical_device *ph_dev = pAd->physical_dev;

	/* get pointer to common module */
	switch (eTxPwrParamCat) {
	case CATEGORY_NTX_POWER_OFFSET:
		pu1Param = (PUINT8)(ph_dev->EfuseInfoAll.prNTxPowerOffset);
		ColumnNum = EFUSE_NTX_POWER_OFFSET_ITEM_NUM;
		break;
	case CATEGORY_TX_POWER_RATE:
		fgGBand = (eBand == BAND_24G) ? (TRUE) : (FALSE);
		pu1Param =
			(eBand == BAND_24G) ?
				((PUINT8)(ph_dev->EfuseInfoAll.pr2G4TxPower))
				: ((PUINT8)(ph_dev->EfuseInfoAll.pr5GTxPower));
		if (fgGBand == TRUE)
			ColumnNum = EFUSE_2G4_TXPOWER_RATE_POWER_ITEM_NUM;
		else
			ColumnNum = EFUSE_5G_TXPOWER_RATE_POWER_ITEM_NUM;
		break;
	default:
		break;
	}

	/*Sanity check*/
	if (!pu1Param)
		return NDIS_STATUS_FAILURE;
	if (GetOrSet >= ENUM_EFUSE_INFO_MODE_NUM)
		return NDIS_STATUS_FAILURE;
	if (ColumnIdx >= ColumnNum)
		return NDIS_STATUS_FAILURE;

	/* Set/Get Efuse Info value */
	if (GetOrSet == ENUM_EFUSE_INFO_SET)
		*(pu1Param + ColumnIdx) = *value;
	else
		*value = *(pu1Param + ColumnIdx);

	return NDIS_STATUS_SUCCESS;
}

NDIS_STATUS rtmp_eeprom_IBF_update(
	RTMP_ADAPTER * pAd,
	UCHAR eBand,
	UCHAR GetOrSet,
	UCHAR ColumnIdx,
	UCHAR *value
)
{
	PUINT8 pu1Param = NULL;
	UCHAR ColumnNum;
	BOOLEAN  fgGBand;
	struct physical_device *ph_dev = pAd->physical_dev;

	/* get pointer to common module */
	pu1Param =
		(eBand == BAND_24G) ?
		((PUINT8)(ph_dev->EfuseInfoAll.pr2G4IBfParam))
		: ((PUINT8)(ph_dev->EfuseInfoAll.pr5GIBfParam));
	fgGBand = (eBand == BAND_24G) ? (TRUE) : (FALSE);
	if (fgGBand == TRUE)
		ColumnNum = IBF_PARAM_NUM * G_BAND_CH_GROUP_NUM;
	else
		ColumnNum = IBF_PARAM_NUM * A_BAND_CH_GROUP_NUM;

	/*Sanity check*/
	if (!pu1Param)
		return NDIS_STATUS_FAILURE;
	if (GetOrSet >= ENUM_EFUSE_INFO_MODE_NUM)
		return NDIS_STATUS_FAILURE;
	if (ColumnIdx >= ColumnNum)
		return NDIS_STATUS_FAILURE;

	/* Set/Get Efuse Info value */
	if (GetOrSet == ENUM_EFUSE_INFO_SET)
		*(pu1Param + ColumnIdx) = *value;
	else
		*value = *(pu1Param + ColumnIdx);

	return NDIS_STATUS_SUCCESS;
}

NDIS_STATUS rtmp_eeprom_DelayComp_update(
	struct _RTMP_ADAPTER *pAd,
	UCHAR eBand,
	UCHAR GetOrSet,
	EFUSE_INFO_DELAY_COMP_CATEGORY eDelayCompParamCat,
	UCHAR ColumnIdx,
	UCHAR *value
)
{
	PUINT8 pu1Param = NULL;
	struct physical_device *ph_dev = pAd->physical_dev;

	/* get pointer to common module */
	switch (eDelayCompParamCat) {
	case CATEGORY_DEALY_COMP_CTRL:
		pu1Param = (PUINT8)(ph_dev->EfuseInfoAll.prDelayCompCtrl);
		break;
	case CATEGORY_RX_LATENCY:
		pu1Param =
			(eBand == BAND_24G) ?
			((PUINT8)(ph_dev->EfuseInfoAll.pr2G4RxLatency))
			: ((PUINT8)(ph_dev->EfuseInfoAll.pr5GRxLatency));
		break;
	default:
		break;
	}

	/* sanity check for pointer null status */
	if (!pu1Param)
		return NDIS_STATUS_FAILURE;

	/* Set/Get Efuse Info value */
	if (GetOrSet == ENUM_EFUSE_INFO_SET)
		*(pu1Param + ColumnIdx) = *value;
	else
		*value = *(pu1Param + ColumnIdx);

	return NDIS_STATUS_SUCCESS;
}

INT32 show_UpdateEfuse_Example(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	UCHAR value = 0xB3;
	int status;
	struct physical_device *ph_dev = pAd->physical_dev;

	/*Example for set 2.4G Dymaic iPA switch : PA CCK Threshold (chip out) for HPA: 0xB6*/
	MTWF_PRINT("\x1b[1;33m Before change: EEPROM[0x%x] is 0x%x \x1b[m \n",
		 0xB6, ph_dev->EEPROMImage[0xB6]);
	status = rtmp_eeprom_WfCmm_update(pAd, BAND_24G,
		 EFUSE_COMMON_CATEGORY_DYNAMIC_IPA_SWITCH, ENUM_EFUSE_INFO_SET,
		 CH_GROUP_NOT_CARE,
		 EFUSE_COMMON_DYNAMIC_IPA_SWITCH_CATEGORY_HPA_CCK_THRESHOLD,
		 &value);

	MTWF_PRINT("\x1b[1;33m After change: EEPROM[0x%x] is 0x%x \x1b[m \n",
		 0xB6, ph_dev->EEPROMImage[0xB6]);
	return TRUE;
}
#endif /*#ifdef	CONNAC_EFUSE_FORMAT_SUPPORT*/

static NDIS_STATUS rtmp_ee_bin_init(PRTMP_ADAPTER pAd)
{
	struct physical_device *ph_dev = pAd->physical_dev;

	if (ph_dev->EEPROMImage == NULL) {
		os_alloc_mem(pAd, &ph_dev->EEPROMImage, get_dev_eeprom_size(ph_dev));
		if (ph_dev->EEPROMImage == NULL) {
			MTWF_DBG(pAd, DBG_CAT_FW, CATHW_EEPROM, DBG_LVL_ERROR,
				"Allocate memory for ph_dev->EEPROMImage failed!\n");
			return NDIS_STATUS_FAILURE;
		}
	}

	rtmp_ee_load_from_bin(pAd);
#ifdef PRE_CAL_TRX_SET1_SUPPORT
	{
		os_alloc_mem(pAd, &pAd->CalDCOCImage, DCOC_IMAGE_SIZE);
		if (pAd->CalDCOCImage == NULL) {
			MTWF_DBG(pAd, DBG_CAT_FW, CATHW_EEPROM, DBG_LVL_ERROR,
				"Allocate memory for pAd->CalDCOCImage failed!\n");
			return NDIS_STATUS_FAILURE;
		}
		os_alloc_mem(pAd, &pAd->CalDPDAPart1Image, TXDPD_IMAGE1_SIZE);
		if (pAd->CalDPDAPart1Image == NULL) {
			MTWF_DBG(pAd, DBG_CAT_FW, CATHW_EEPROM, DBG_LVL_ERROR,
				"Allocate memory for pAd->CalDPDAPart1Image failed!\n");
			if (pAd->CalDCOCImage != NULL)
				os_free_mem(pAd->CalDCOCImage);
			return NDIS_STATUS_FAILURE;
		}
		os_alloc_mem(pAd, &pAd->CalDPDAPart2Image, TXDPD_IMAGE2_SIZE);
		if (pAd->CalDPDAPart2Image == NULL) {
			MTWF_DBG(pAd, DBG_CAT_FW, CATHW_EEPROM, DBG_LVL_ERROR,
				"Allocate memory for pAd->CalDPDAPart2Image failed!\n");
			if (pAd->CalDCOCImage != NULL)
				os_free_mem(pAd->CalDCOCImage);

			if (pAd->CalDPDAPart1Image != NULL)
				os_free_mem(pAd->CalDPDAPart1Image);
			return NDIS_STATUS_FAILURE;
		}
		NdisZeroMemory(pAd->CalDCOCImage, DCOC_IMAGE_SIZE);
		NdisZeroMemory(pAd->CalDPDAPart1Image, TXDPD_IMAGE1_SIZE);
		NdisZeroMemory(pAd->CalDPDAPart2Image, TXDPD_IMAGE2_SIZE);

		if (NDIS_STATUS_SUCCESS == rtmp_cal_load_from_bin(pAd, pAd->CalDCOCImage, 0, DCOC_IMAGE_SIZE))
			pAd->bDCOCReloaded = TRUE;
		else
			MTWF_DBG(pAd, DBG_CAT_FW, CATHW_EEPROM, DBG_LVL_INFO,
					"bDCOCReloaded = false.\n");

		if ((NDIS_STATUS_SUCCESS ==
				rtmp_cal_load_from_bin(pAd, pAd->CalDPDAPart1Image, DPDPART1_OFFSET, TXDPD_IMAGE1_SIZE)) &&
			(NDIS_STATUS_SUCCESS ==
				rtmp_cal_load_from_bin(pAd, pAd->CalDPDAPart2Image, DPDPART2_OFFSET, TXDPD_IMAGE2_SIZE)))
			pAd->bDPDReloaded = TRUE;
		else
			MTWF_DBG(pAd, DBG_CAT_FW, CATHW_EEPROM, DBG_LVL_INFO,
					"bDPDReloaded = false.\n");
	}
#endif /* PRE_CAL_TRX_SET1_SUPPORT */

	if (ph_dev->chip_op->prek_preinit)
		ph_dev->chip_op->prek_preinit(pAd);

	return NDIS_STATUS_SUCCESS;
}

extern UINT32 get_dev_eeprom_size(VOID *pvPhDev);
extern UINT32 get_dev_eeprom_offset(VOID *pvPhDev);

static NDIS_STATUS rtmp_ee_fr_host(
	struct _RTMP_ADAPTER *ad,
	VOID *cmd,
	UINT8 cmd_seq,
	UINT8 cmd_total)
{
	INT ret = NDIS_STATUS_FAILURE;
	UINT16 ctrl_msg = 0;
#ifdef CONFIG_MT7976_SUPPORT
	EEPROM_PWR_ON_MODE_T mode;
#endif /* CONFIG_MT7976_SUPPORT */
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(ad->hdev_ctrl);

	ctrl_msg = (EEPROM_MODE_BUFFER << SOURCE_MODE_SHIFT);

#ifdef CONFIG_MT7976_SUPPORT
	/* only MT7915 need to overwrite the mode to 2G + 6G */
	if (IS_MT7915(ad)) {
		mode = get_power_on_cal_mode(ad);
		ctrl_msg |= (mode << PWR_ON_CAL_SEL_SHIFT);
	}
#endif /* CONFIG_MT7976_SUPPORT */

	ctrl_msg |= (CONTENT_FORMAT_WHOLE_CONTENT << 8);
	ctrl_msg |= ((((cmd_total-1) << BUFFER_BIN_TOTAL_PAGE_SHIFT) & BUFFER_BIN_TOTAL_PAGE_MASK) << 8);
	ctrl_msg |= (((cmd_seq << BUFFER_BIN_PAGE_INDEX_SHIFT) & BUFFER_BIN_PAGE_INDEX_MASK) << 8);

	if (ops->bufferModeCmdFill) {
		ops->bufferModeCmdFill(ad, cmd, ctrl_msg);
		ret = NDIS_STATUS_SUCCESS;
	} else {
		MTWF_DBG(ad, DBG_CAT_FW, CATHW_EEPROM, DBG_LVL_ERROR,
			 "invalid ops for filling cmd, dismissed!\n");
	}

	return ret;
}

#ifdef RTMP_EFUSE_SUPPORT
static NDIS_STATUS rtmp_ee_fr_mcu(
	struct _RTMP_ADAPTER *ad,
	VOID *cmd,
	UINT8 cmd_seq,
	UINT8 cmd_total)
{
	INT ret = NDIS_STATUS_FAILURE;
	UINT16 ctrl_msg = 0;
#ifdef CONFIG_MT7976_SUPPORT
	EEPROM_PWR_ON_MODE_T mode;
#endif /* CONFIG_MT7976_SUPPORT */
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(ad->hdev_ctrl);
	ctrl_msg = (EEPROM_MODE_EFUSE << SOURCE_MODE_SHIFT);

#ifdef CONFIG_MT7976_SUPPORT
	/* only MT7915 need to overwrite the mode to 2G + 6G */
	if (IS_MT7915(ad)) {
		mode = get_power_on_cal_mode(ad);
		ctrl_msg |= (mode << PWR_ON_CAL_SEL_SHIFT);
	}
#endif /* CONFIG_MT7976_SUPPORT */

#ifdef	CONNAC_EFUSE_FORMAT_SUPPORT
	ctrl_msg |= (CONTENT_FORMAT_WHOLE_CONTENT << 8);
#endif

	if (ops->bufferModeCmdFill) {
		ops->bufferModeCmdFill(ad, cmd, ctrl_msg);
		ret = NDIS_STATUS_SUCCESS;
	} else {
		MTWF_DBG(ad, DBG_CAT_FW, CATHW_EEPROM, DBG_LVL_ERROR,
			 "invalid ops for filling cmd, dismissed!\n");
	}

	return ret;
}
#endif /* RTMP_EFUSE_SUPPORT */

BOOLEAN rtmp_get_default_bin_file_by_chip(
	IN PRTMP_ADAPTER pAd,
	IN UINT32	ChipVersion,
	OUT RTMP_STRING **pBinFileName)
{
	BOOLEAN found = FALSE;
	INT i;

	for (i = 0; RTMP_CHIP_E2P_FILE_TABLE[i].ChipVersion != 0; i++) {
		if (RTMP_CHIP_E2P_FILE_TABLE[i].ChipVersion == ChipVersion) {
			*pBinFileName = RTMP_CHIP_E2P_FILE_TABLE[i].name;
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
					 "Found E2P bin file name:%s\n", *pBinFileName);
			found = TRUE;
			break;
		}
	}

	if (found == TRUE)
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
			"Found E2P bin file name=%s\n", *pBinFileName);
	else
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"E2P bin file name not found\n");

	return found;
}


BOOLEAN rtmp_ee_bin_read16(RTMP_ADAPTER *pAd, UINT32 Offset, UINT16 *pValue)
{
	BOOLEAN IsEmpty = 0;
	struct physical_device *ph_dev = pAd->physical_dev;

	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_DEBUG, "Read from EEPROM buffer\n");
	NdisMoveMemory(pValue, &(ph_dev->EEPROMImage[Offset]), 2);
	*pValue = le2cpu16(*pValue);

	if ((*pValue == 0xffff) || (*pValue == 0x0000))
		IsEmpty = 1;

	return IsEmpty;
}


INT rtmp_ee_bin_write16(
	IN RTMP_ADAPTER	 *pAd,
	IN UINT32			Offset,
	IN USHORT			data)
{
	struct physical_device *ph_dev = pAd->physical_dev;

	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_DEBUG, "Write to EEPROM buffer\n");
	data = le2cpu16(data);
	NdisMoveMemory(&(ph_dev->EEPROMImage[Offset]), &data, 2);
	return 0;
}

BOOLEAN rtmp_ee_bin_read_with_range(PRTMP_ADAPTER pAd, UINT32 start, UINT32 Length, UCHAR *pbuf)
{
	BOOLEAN IsEmpty = 0;
	UINT16  u2Loop;
	UCHAR   ucValue = 0;
	struct physical_device *ph_dev = pAd->physical_dev;

	memcpy(pbuf, ph_dev->EEPROMImage + start, Length);

	for (u2Loop = 0; u2Loop < Length; u2Loop++)
		ucValue |= pbuf[u2Loop];

	if ((ucValue == 0xff) || (ucValue == 0x00))
		IsEmpty = 1;

	return IsEmpty;
}

INT rtmp_ee_bin_write_with_range(PRTMP_ADAPTER pAd, UINT32 start, UINT32 Length, UCHAR *pbuf)
{
	struct physical_device *ph_dev = pAd->physical_dev;

	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_DEBUG,
		"Write data range to EEPROM buffer\n");
	NdisMoveMemory(&(ph_dev->EEPROMImage[start]), pbuf, Length);

	return 0;
}

INT rtmp_ee_load_from_bin(
	IN PRTMP_ADAPTER	pAd)
{
	CHAR src[100] = {'\0'};
	INT ret_val;
	MT_OS_FD srcf;
	MT_OS_FS_INFO osFSInfo;
	EEPROM_CONTROL *pE2pCtrl = PD_GET_E2P_CTRL_PTR(pAd->physical_dev);
	struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(pAd->hdev_ctrl);
	struct physical_device *ph_dev = pAd->physical_dev;
	INT ret;
	BOOLEAN fgBinMode = TRUE;

	pE2pCtrl->e2pCurMode = E2P_BIN_MODE;
#ifdef CONFIG_CPE_SUPPORT
lib_firmware:
#endif
	if (ops && ops->get_bin_image_file != NULL) {
		ops->get_bin_image_file(pAd, src, fgBinMode);
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
			"bin FileName=%s\n", src);
	} else {
		strncat(src, BIN_FILE_PATH, strlen(BIN_FILE_PATH));
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO, "FileName=%s\n", src);
	}

	os_fs_info_change(&osFSInfo, TRUE);

	if (strlen(src)) {
		struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);

		srcf = os_file_open(src, O_RDONLY, 0);
		if (IS_FILE_OPEN_ERR(srcf)) {
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
					 "Error opening %s\n", src);
#ifdef CONFIG_CPE_SUPPORT
			if (fgBinMode) {
				fgBinMode = FALSE;
				os_fs_info_change(&osFSInfo, FALSE);
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"\n\n\n\n\n\n");
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"********************************************************\n");
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"********************************************************\n");
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"*                                                      *\n");
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"*      Notice! Notice! Notice Notice! Notice!          *\n");
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"*                                                      *\n");
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"*        Did Not Find Correct Bin File in Path:        *\n");
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"*                 %-37s*\n", src);
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"*       Bin File Mode May Not Work Correctly!!!        *\n");
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"*                                                      *\n");
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"********************************************************\n");
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"********************************************************\n");
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"\n\n\n\n\n");
				/*In the CPE project, if loading bin fail in nvcfg,*/
				/*then loading from /lib/firmware/MT7990_EEPROM.bin*/
				goto lib_firmware;
			}
#endif
			goto error;
		} else {
			NdisZeroMemory(ph_dev->EEPROMImage,
				((get_dev_eeprom_size(ph_dev) > chip_cap->EEPROM_DEFAULT_BIN_SIZE) ?
				get_dev_eeprom_size(ph_dev) : chip_cap->EEPROM_DEFAULT_BIN_SIZE));
			os_file_seek(srcf, get_dev_eeprom_offset(ph_dev));
			ret_val = os_file_read(srcf, (RTMP_STRING *)ph_dev->EEPROMImage,
				((get_dev_eeprom_size(ph_dev) > chip_cap->EEPROM_DEFAULT_BIN_SIZE) ?
				get_dev_eeprom_size(ph_dev) : chip_cap->EEPROM_DEFAULT_BIN_SIZE));

			if (ret_val > 0) {
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
						 "Load EEPROM Buffer from %s\n", src);
				ret_val = NDIS_STATUS_SUCCESS;
			} else {
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
						 "Read file \"%s\" failed(errCode=%d)!\n", src, ret_val);
				goto error;
			}
		}
	} else {
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				 "Error src or srcf is null\n");
		goto error;
	}

	ret_val = os_file_close(srcf);

	if (ret_val)
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				 "Error %d closing %s\n", -ret_val, src);

	pE2pCtrl->e2pSource = E2P_SRC_FROM_BIN;
	ret = snprintf(pE2pCtrl->BinSource, sizeof(pE2pCtrl->BinSource), "%s", src);
	if (os_snprintf_error(sizeof(pE2pCtrl->BinSource), ret))
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"snprintf error!\n");
	os_fs_info_change(&osFSInfo, FALSE);
	return TRUE;
error:
	if (cap->EEPROM_DEFAULT_BIN != NULL) {
		NdisMoveMemory(ph_dev->EEPROMImage, cap->EEPROM_DEFAULT_BIN,
					   ((cap->EEPROM_DEFAULT_BIN_SIZE > MAX_EEPROM_BUFFER_SIZE) ? cap->EEPROM_DEFAULT_BIN_SIZE :
					   MAX_EEPROM_BUFFER_SIZE));
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"Load EEPROM Buffer from default BIN.\n");
		pE2pCtrl->e2pSource = E2P_SRC_FROM_BIN;
		ret = snprintf(pE2pCtrl->BinSource, sizeof(pE2pCtrl->BinSource), "Default BIN");
		if (os_snprintf_error(sizeof(pE2pCtrl->BinSource), ret))
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
					"snprintf error!\n");
	}
	os_fs_info_change(&osFSInfo, FALSE);

	return FALSE;
}

#if defined(PRE_CAL_TRX_SET1_SUPPORT) || defined(PRE_CAL_TRX_SET2_SUPPORT) || defined(RLM_CAL_CACHE_SUPPORT)
NDIS_STATUS rtmp_cal_load_from_bin(
	IN PRTMP_ADAPTER	pAd,
	IN UCHAR *buf,
	IN ULONG offset,
	IN ULONG len)
{
	RTMP_STRING src[100] = {"\0"};
	INT ret_val;
	MT_OS_FD srcf;
	MT_OS_FS_INFO osFSInfo;
	RTMP_CHIP_OP *chip_ops = hc_get_chip_ops(pAd->hdev_ctrl);

	if (chip_ops->get_prek_image_file)
		chip_ops->get_prek_image_file(pAd, src);
	else {
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"Unknown PreK image file\n");
		return NDIS_STATUS_FAILURE;
	}

	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO, "FileName=%s\n", src);
	os_fs_info_change(&osFSInfo, TRUE);

	if (strlen(src)) {
		srcf = os_file_open(src, O_RDONLY, 0);

		if (IS_FILE_OPEN_ERR(srcf)) {
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
				 "Error opening %s\n", src);
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"\e[0;31m Run RXDCOC/TXDPD/PRECAL cmds to generate caldata files\e[m\n");
			os_fs_info_change(&osFSInfo, FALSE);
			return NDIS_STATUS_FAILURE;
		} else {
			os_file_seek(srcf, offset);
			ret_val = os_file_read(srcf, (RTMP_STRING *)buf, len);

			if (ret_val > 0) {
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
					"Load from %s (Read = %d)\n", src, ret_val);
				ret_val = NDIS_STATUS_SUCCESS;
			} else {
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
					"Read file \"%s\" failed(errCode=%d)!\n", src, ret_val);
			}
		}
	} else {
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"Error src or srcf is null\n");
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"FAIL!!! Load Cal Data from file.\n");
		os_fs_info_change(&osFSInfo, FALSE);
		return NDIS_STATUS_FAILURE;
	}

	ret_val = os_file_close(srcf);

	if (ret_val)
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"Error %d closing %s\n", -ret_val, src);

	os_fs_info_change(&osFSInfo, FALSE);
	return NDIS_STATUS_SUCCESS;
}


NDIS_STATUS rtmp_cal_write_to_bin(
	IN PRTMP_ADAPTER	pAd,
	IN UCHAR *buf,
	IN ULONG offset,
	IN ULONG len)
{
	CHAR *src = NULL;
	INT ret_val;
	MT_OS_FD srcf;
	MT_OS_FS_INFO osFSInfo;
	RTMP_CHIP_OP *chip_ops = hc_get_chip_ops(pAd->hdev_ctrl);

	if (chip_ops->get_prek_image_file)
		chip_ops->get_prek_image_file(pAd, src);
	else {
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"Unknown PreK image file\n");
		return NDIS_STATUS_FAILURE;
	}

	MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO, "FileName=%s\n", src);
	os_fs_info_change(&osFSInfo, TRUE);

	if (strlen(src)) {
		srcf = os_file_open(src, O_WRONLY | O_CREAT, 0);

		if (IS_FILE_OPEN_ERR(srcf)) {
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"Error opening %s\n", src);
			os_fs_info_change(&osFSInfo, FALSE);
			return NDIS_STATUS_FAILURE;
		} else {
			os_file_seek(srcf, offset);
			os_file_write(srcf, (RTMP_STRING *)buf, len);
		}
	} else {
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"Error src or srcf is null\n");
		os_fs_info_change(&osFSInfo, FALSE);
		return NDIS_STATUS_FAILURE;
	}

	ret_val = os_file_close(srcf);

	if (ret_val)
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"Error %d closing %s\n", -ret_val, src);

	os_fs_info_change(&osFSInfo, FALSE);
	return NDIS_STATUS_SUCCESS;
}
#endif	/* PRE_CAL_TRX_SET1_SUPPORT */

INT rtmp_ee_write_to_bin(
	IN PRTMP_ADAPTER	pAd)
{
	CHAR src[100] = {'\0'};
	INT ret_val;
	MT_OS_FD srcf;
	MT_OS_FS_INFO osFSInfo;
	struct physical_device *ph_dev = pAd->physical_dev;
#ifdef RT_SOC_SUPPORT
#ifdef MULTIPLE_CARD_SUPPORT
	RTMP_STRING bin_file_path[128];
	RTMP_STRING *bin_file_name = NULL;
	UINT32 chip_ver = (pAd->MACVersion >> 16);
	int ret;

	if (rtmp_get_default_bin_file_by_chip(pAd, chip_ver, &bin_file_name) == TRUE) {
		if (pAd->MC_RowID > 0) {
			ret = snprintf(bin_file_path, sizeof(bin_file_path), "%s%s", EEPROM_2ND_FILE_DIR, bin_file_name);
			if (os_snprintf_error(sizeof(bin_file_path), ret)) {
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
					"snprintf error!\n");
				return FALSE;
			}
		} else {
			ret = snprintf(bin_file_path, sizeof(bin_file_path), "%s%s", EEPROM_1ST_FILE_DIR, bin_file_name);
			if (os_snprintf_error(sizeof(bin_file_path), ret)) {
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
					"snprintf error!\n");
				return FALSE;
			}
		}

		strlcpy(src, bin_file_path, sizeof(src));
	} else
#endif /* MULTIPLE_CARD_SUPPORT */
#endif /* RT_SOC_SUPPORT */
	{
		struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(pAd->hdev_ctrl);

		if (ops && ops->get_bin_image_file != NULL) {
			ops->get_bin_image_file(pAd, src, TRUE);
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
				"bin FileName=%s\n", src);
		} else {
			strncat(src, BIN_FILE_PATH, strlen(BIN_FILE_PATH));
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
				"src FileName=%s\n", src);
		}
	}

	os_fs_info_change(&osFSInfo, TRUE);

	if (strlen(src)) {
		struct _RTMP_CHIP_CAP *chip_cap = hc_get_chip_cap(pAd->hdev_ctrl);

		srcf = os_file_open(src, O_WRONLY | O_CREAT, 0);
		if (IS_FILE_OPEN_ERR(srcf)) {
			MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"Error opening %s\n", src);
			os_fs_info_change(&osFSInfo, FALSE);
			return FALSE;
		} else {
			os_file_seek(srcf, get_dev_eeprom_offset(ph_dev));
			os_file_write(srcf, (RTMP_STRING *)ph_dev->EEPROMImage,
				((get_dev_eeprom_size(ph_dev) > chip_cap->EEPROM_DEFAULT_BIN_SIZE)
#if defined(PRE_CAL_TRX_SET2_SUPPORT) || defined(PRE_CAL_MT7915_SUPPORT) || \
	defined(PRE_CAL_MT7986_SUPPORT) || defined(PRE_CAL_MT7981_SUPPORT) || \
	defined(PRE_CAL_MT7916_SUPPORT) || defined(PRE_CAL_MT7990_SUPPORT) || \
	defined(PRE_CAL_MT7992_SUPPORT) || defined(PRE_CAL_MT7993_SUPPORT) || \
	defined(PRE_CAL_BLACKHAWK_SUPPORT)
					&& (ph_dev->EEPROMImage[PRECAL_INDICATION_BYTE])
#endif
				) ? get_dev_eeprom_size(ph_dev):chip_cap->EEPROM_DEFAULT_BIN_SIZE);
		}
	} else {
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"Error src or srcf is null\n");
		os_fs_info_change(&osFSInfo, FALSE);
		return FALSE;
	}

	ret_val = os_file_close(srcf);

	if (ret_val)
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"Error %d closing %s\n", -ret_val, src);

	os_fs_info_change(&osFSInfo, FALSE);
	return TRUE;
}


INT Set_LoadEepromBufferFromBin_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	LONG bEnable = os_str_tol(arg, 0, 10);
	INT result;
	struct physical_device *ph_dev = pAd->physical_dev;

	if (bEnable < 0)
		return FALSE;
	else {
		MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
			"Load EEPROM buffer from BIN, and change to BIN buffer mode\n");
		result = rtmp_ee_load_from_bin(pAd);

		if (result == FALSE) {
			struct _RTMP_CHIP_CAP *cap = hc_get_chip_cap(pAd->hdev_ctrl);

			if (cap->EEPROM_DEFAULT_BIN != NULL) {
				NdisMoveMemory(ph_dev->EEPROMImage, cap->EEPROM_DEFAULT_BIN,
							   cap->EEPROM_DEFAULT_BIN_SIZE > MAX_EEPROM_BUFFER_SIZE ? MAX_EEPROM_BUFFER_SIZE :
							   cap->EEPROM_DEFAULT_BIN_SIZE);
				MTWF_DBG(pAd, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
					"Load EEPROM Buffer from default BIN.\n");
			}
		}

		/* Change to BIN eeprom buffer mode */
		RtmpChipOpsEepromHook(pAd->physical_dev, E2P_BIN_MODE);
		return TRUE;
	}
}


INT Set_EepromBufferWriteBack_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	UINT e2p_mode = os_str_tol(arg, 0, 10);

	if (e2p_mode >= NUM_OF_E2P_MODE)
		return FALSE;

	switch (e2p_mode) {
#ifdef RTMP_EFUSE_SUPPORT

	case E2P_EFUSE_MODE:
		MTWF_PRINT("Write EEPROM buffer back to eFuse\n");
		rtmp_ee_write_to_efuse(pAd);
		break;
#endif /* RTMP_EFUSE_SUPPORT */
#ifdef RTMP_FLASH_SUPPORT

	case E2P_FLASH_MODE:
		MTWF_PRINT("Write EEPROM buffer back to Flash\n");
		rtmp_ee_flash_write_all(pAd);
		break;
#endif /* RTMP_FLASH_SUPPORT */

	case E2P_EEPROM_MODE:
		MTWF_PRINT("Write EEPROM buffer back to EEPROM\n");
		//rtmp_ee_write_to_prom(pAd);
		rtmp_ee_write_to_i2c_eeprom(pAd);
		break;

	case E2P_BIN_MODE:
		MTWF_PRINT("Write EEPROM buffer back to BIN\n");
		rtmp_ee_write_to_bin(pAd);
		break;

	default:
		MTWF_PRINT("Do not support this EEPROM access mode\n");
		return FALSE;
	}

	return TRUE;
}

INT Set_bufferMode_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	UINT EepromType = os_str_tol(arg, 0, 10);
	MtCmdEfusBufferModeSet(pAd, EepromType);

	return TRUE;
}


static PCHAR e2p_mode[] = {"NONE", "Efuse", "Flash", "Eeprom", "Bin"};
static PCHAR e2p_src[] = {[E2P_SRC_FROM_EFUSE] = "Efuse",
						  [E2P_SRC_FROM_FLASH] = "Flash",
						  [E2P_SRC_FROM_EEPROM] = "Eeprom",
						  [E2P_SRC_FROM_BIN] = "Bin",
						  [E2P_SRC_FROM_FLASH_AND_EFUSE] = "Flash + ical data  from efuse(merge mode)",
						  [E2P_SRC_FROM_BIN_AND_EFUSE] = "Bin + ical data from efuse(merge mode)"
						 };
INT show_e2pinfo_proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	EEPROM_CONTROL *pE2pCtrl = PD_GET_E2P_CTRL_PTR(pAd->physical_dev);
#ifdef CAL_FREE_IC_SUPPORT
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(pAd->hdev_ctrl);
#endif /* CAL_FREE_IC_SUPPORT */

	MTWF_PRINT("Default eeprom mode from profile: %s\n",
		e2p_mode[PD_GET_E2P_ACCESS_MODE(pAd->physical_dev)]);
	MTWF_PRINT("Current mode: %s\n", e2p_mode[pE2pCtrl->e2pCurMode]);
	MTWF_PRINT("E2p source: %s\n", e2p_src[pE2pCtrl->e2pSource]);
#ifdef CAL_FREE_IC_SUPPORT

	if (!(pE2pCtrl->e2pSource & E2P_SRC_FROM_EFUSE)
		&& ops->check_is_cal_free_merge) {
		if (ops->check_is_cal_free_merge(pAd))
			MTWF_PRINT("ical data merge: YES\n");
		else
			MTWF_PRINT("ical data merge: No\n");
	}

#endif /* CAL_FREE_IC_SUPPORT */

	if (pE2pCtrl->e2pSource & E2P_SRC_FROM_BIN)
		MTWF_PRINT("Bin file Source: %s\n", pE2pCtrl->BinSource);

	return TRUE;
}


#ifdef CAL_FREE_IC_SUPPORT
INT Set_LoadCalFreeData_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	UINT value = os_str_tol(arg, 0, 10);
	EEPROM_CONTROL *pE2pCtrl = PD_GET_E2P_CTRL_PTR(pAd->physical_dev);

	if (value == 1) {
		BOOLEAN bCalFree = 0;
		RTMP_CAL_FREE_IC_CHECK(pAd, bCalFree);

		if (bCalFree) {
			RTMP_CAL_FREE_DATA_GET(pAd);
			MTWF_PRINT("Merge successfully");

			if (pE2pCtrl->e2pCurMode == E2P_FLASH_MODE)
				MTWF_PRINT(",plz write back to flash");

			MTWF_PRINT("\n");
		} else
			MTWF_PRINT("Merge fail\n");
	} else if (value == 2) {
		RTMP_CAL_FREE_DATA_GET(pAd);
		MTWF_PRINT("Merge successfully");
	} else
		return FALSE;

	return TRUE;
}

INT Set_CheckCalFree_Proc(RTMP_ADAPTER *pAd, RTMP_STRING *arg)
{
	struct _RTMP_CHIP_OP *ops = hc_get_chip_ops(pAd->hdev_ctrl);

	if (ops->check_is_cal_free_merge) {
		if (ops->check_is_cal_free_merge(pAd))
			MTWF_PRINT("CalFree data has been merged!!\n");
		else
			MTWF_PRINT("CalFree data has not been merged!!\n");
	} else {
		MTWF_PRINT("Not Support CalFree Merge Check!\n");
		return FALSE;
	}

	return TRUE;
}

#endif



/*******************************************************************************
 *                         PER CARD INIT
 *******************************************************************************
 */

INT RtmpChipOpsEepromHook(
	struct physical_device *ph_dev, INT forceMode)
{
	UCHAR e2p_type;
	UCHAR e2p_default = 0;
	EEPROM_CONTROL *pE2pCtrl = NULL;
	RTMP_CHIP_CAP *cap = &ph_dev->chip_cap;
	RTMP_CHIP_OP *pChipOps = ph_dev->chip_op;

	pE2pCtrl = PD_GET_E2P_CTRL_PTR(ph_dev);

	if (forceMode != E2P_NONE && forceMode < NUM_OF_E2P_MODE) {
		e2p_type = forceMode;
		MTWF_DBG(NULL, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
			"forceMode: %d\n", e2p_type);
	} else {
		e2p_type = PD_GET_E2P_ACCESS_MODE(ph_dev);
		MTWF_DBG(NULL, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
			"e2p_type=%d\n", e2p_type);

		/* If e2p_type is out of range, get the default mode */
		e2p_type =
			((e2p_type != 0) && (e2p_type < NUM_OF_E2P_MODE)) ? e2p_type : e2p_default;

#ifdef RTMP_EFUSE_SUPPORT
		if (e2p_type != E2P_EFUSE_MODE)
			PD_SET_USE_EFUSE(ph_dev, FALSE);
#endif /* RTMP_EFUSE_SUPPORT */

	}

	MTWF_DBG(NULL, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
		"E2P type(%d), E2pAccessMode = %d, E2P default = %d\n",
		e2p_type, PD_GET_E2P_ACCESS_MODE(ph_dev), e2p_default);
	PD_SET_EEPROM_TYPE(ph_dev, (e2p_type == E2P_EFUSE_MODE ||
		e2p_type == E2P_EEPROM_MODE) ? EEPROM_EFUSE : EEPROM_FLASH);
	pE2pCtrl->e2pCurMode = e2p_type;

	if (ph_dev->EEPROMImage == NULL) {
		os_alloc_mem(NULL, &ph_dev->EEPROMImage,
				(get_dev_eeprom_size(ph_dev) > cap->EFUSE_BUFFER_CONTENT_SIZE) ?
				 get_dev_eeprom_size(ph_dev) : cap->EFUSE_BUFFER_CONTENT_SIZE);
		if (ph_dev->EEPROMImage == NULL) {
			MTWF_DBG(NULL, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"Allocate memory for ph_dev->EEPROMImage failed, please check!\n");
		}
	}

	switch (e2p_type) {
	case E2P_EEPROM_MODE: {
		pChipOps->eeinit = rtmp_ee_i2c_eeprom_init;
		pChipOps->eeread = rtmp_ee_i2c_eeprom_read16;
		pChipOps->eewrite = rtmp_ee_i2c_eeprom_write16;
		pChipOps->ee_gen_cmd = rtmp_ee_fr_mcu;

		MTWF_DBG(NULL, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO, "NVM is I2C_EEPROM mode\n");
		break;
	}

	case E2P_BIN_MODE: {
		pChipOps->eeinit = rtmp_ee_bin_init;
		pChipOps->eeread = rtmp_ee_bin_read16;
		pChipOps->eewrite = rtmp_ee_bin_write16;
		pChipOps->eeread_range = rtmp_ee_bin_read_with_range;
		pChipOps->eewrite_range = rtmp_ee_bin_write_with_range;
		pChipOps->ee_gen_cmd = rtmp_ee_fr_host;
		MTWF_DBG(NULL, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO, "NVM is BIN mode\n");
		break;
	}

#ifdef RTMP_FLASH_SUPPORT

	case E2P_FLASH_MODE: {
		pChipOps->eeinit = rtmp_nv_init;
		pChipOps->eeread = rtmp_ee_flash_read;
		pChipOps->eewrite = rtmp_ee_flash_write;
		pChipOps->eeread_range = rtmp_ee_flash_read_with_range;
		pChipOps->eewrite_range = rtmp_ee_flash_write_with_range;
		pChipOps->ee_gen_cmd = rtmp_ee_fr_host;

		MTWF_DBG(NULL, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
			"NVM is FLASH mode. dev_idx [%d] FLASH OFFSET [0x%X]\n",
			ph_dev->device_idx, get_dev_eeprom_offset(ph_dev));
		break;
	}

#endif /* RTMP_FLASH_SUPPORT */
#ifdef RTMP_EFUSE_SUPPORT
	case E2P_EFUSE_MODE:
		if (PD_GET_USE_EFUSE(ph_dev)) {
			pChipOps->eeinit = eFuse_init;
			pChipOps->eeread = rtmp_ee_efuse_read16;
			pChipOps->eewrite = rtmp_ee_efuse_write16;
			pChipOps->ee_gen_cmd = rtmp_ee_fr_mcu;
			MTWF_DBG(NULL, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO,
				"NVM is EFUSE mode\n");
		} else
			MTWF_DBG(NULL, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
				"hook efuse mode failed\n");
		break;

#endif /* RTMP_EFUSE_SUPPORT */

	default:
		MTWF_DBG(NULL, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_ERROR,
			"Do not support E2P type(%d), change to BIN mode\n",
			e2p_type);
		pChipOps->eeinit = rtmp_ee_bin_init;
		pChipOps->eeread = rtmp_ee_bin_read16;
		pChipOps->eewrite = rtmp_ee_bin_write16;
		pChipOps->ee_gen_cmd = rtmp_ee_fr_host;
		MTWF_DBG(NULL, DBG_CAT_HW, CATHW_EEPROM, DBG_LVL_INFO, "NVM is BIN mode\n");
		break;
	}

	return 0;
}

